#!/usr/bin/env bash
set -euo pipefail

CLIENT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
cd "$CLIENT_DIR"

mkdir -p "$HOME/.claude/commands"
mkdir -p "$HOME/.claude/skills"

cp -f .claude/commands/*.md "$HOME/.claude/commands/"
cp -R .claude/skills/test-plan-generation "$HOME/.claude/skills/"

echo "Installed Claude commands to: $HOME/.claude/commands"
echo "Installed Claude skill to:    $HOME/.claude/skills/test-plan-generation"
echo
echo "Recommended MCP registration:"
echo "  claude mcp add-json aem-guides-dataset-studio \"\$(cat \"$CLIENT_DIR/claude-mcp-server.json\")\""
echo
echo "Commands available after restarting Claude Code:"
echo "  /aem-ask-dita-expert"
echo "  /aem-guides-test-plan"
echo "  /aem-rag-status"
