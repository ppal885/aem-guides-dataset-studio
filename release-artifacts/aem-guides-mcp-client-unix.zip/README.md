# AEM Guides MCP Client for Claude Code

Lightweight macOS/Linux client for team members who use Claude Code with the
central VM-hosted AEM Guides Dataset Studio backend.

This package does **not** contain the full dataset-studio repo, RAG corpus,
ChromaDB, JSON chunks, or backend code. Live RAG stays on the VM.

## What Team Members Need

- macOS or Linux
- Python 3.10+
- Claude Code installed
- VPN/network access to the VM backend
- VM backend URL, for example `http://<VM-IP>:8001`

## Install

```bash
unzip aem-guides-mcp-client-unix.zip
cd aem-guides-mcp-client
chmod +x install.sh smoke_test.sh install_claude_assets.sh
./install.sh http://<VM-IP-or-host>:8001 dev-bypass
./install_claude_assets.sh
```

If the VM is exposed through nginx on another port, use that base URL instead.

## Register MCP in Claude Code

Recommended:

```bash
claude mcp add-json aem-guides-dataset-studio "$(cat claude-mcp-server.json)"
claude mcp list
```

Fallback:

```bash
cd /path/to/aem-guides-mcp-client
claude
```

The package writes a project-local `.mcp.json`, so running Claude Code from this
folder can load the MCP server even without editing global config.

## Installed Slash Commands

After `./install_claude_assets.sh` and a Claude Code restart:

```text
/aem-rag-status
/aem-ask-dita-expert
/aem-guides-test-plan
```

## MCP Tools Exposed

- `health_check`
- `ask_dita_expert`
- `lookup_aem_guides`
- `lookup_dita_spec`
- `lookup_dita_attribute`
- `search_jira_issues`
- `guides_test_plan_generator`
- `test_plan_pipeline`
- `find_recipes`
- `generate_dita`
- `review_dita_xml`
- `fix_dita_xml`
- `list_jobs`
- `get_job_status`

## Smoke Test

```bash
./smoke_test.sh
```

Expected:

- `health.status: healthy`
- Chroma available
- Non-zero AEM Guides/RAG counts
- Lookup count greater than zero

## Important Rules

- Do not clone the full dataset-studio repo on teammate laptops.
- Do not copy RAG JSON, ChromaDB, or DITA corpus to teammate laptops.
- Reindex and maintain RAG only on the VM.
- If RAG is stale, fix the VM backend/index, then all clients get updated evidence.

## Troubleshooting

### Cannot reach VM backend

Check VPN, URL, firewall, and VM service:

```bash
systemctl status aem-backend
curl http://localhost:8001/health
```

### Claude does not show MCP tools

Run:

```bash
claude mcp list
claude mcp add-json aem-guides-dataset-studio "$(cat claude-mcp-server.json)"
```

Or start Claude Code from the client folder:

```bash
cd /path/to/aem-guides-mcp-client
claude
```

### Python venv fails on Ubuntu

```bash
sudo apt-get update
sudo apt-get install -y python3-venv python3-pip
./install.sh http://<VM-IP-or-host>:8001 dev-bypass
```
