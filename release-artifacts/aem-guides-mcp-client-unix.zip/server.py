#!/usr/bin/env python3
"""Lightweight MCP bridge for the VM-hosted AEM Guides Dataset Studio backend.

This client intentionally contains no RAG corpus, ChromaDB, backend app code, or
dataset-studio repository dependency. It only forwards MCP tool calls to the
central VM backend configured by AEM_STUDIO_URL.
"""

from __future__ import annotations

import asyncio
import json
import os
import re
from pathlib import Path
from typing import Any

import httpx
from mcp import types
from mcp.server import Server
from mcp.server.stdio import stdio_server


CLIENT_ROOT = Path(__file__).resolve().parent


def _load_env_file(path: Path) -> None:
    if not path.exists():
        return
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = value


_load_env_file(CLIENT_ROOT / ".env")
_load_env_file(CLIENT_ROOT / "client.env")

BACKEND_URL = os.environ.get("AEM_STUDIO_URL", "http://127.0.0.1:8001").rstrip("/")
AUTH_TOKEN = os.environ.get("AEM_STUDIO_TOKEN", "dev-bypass")
TIMEOUT_SECONDS = float(os.environ.get("AEM_STUDIO_TIMEOUT_SECONDS", "300"))

server = Server("aem-guides-dataset-studio")


def _headers() -> dict[str, str]:
    return {
        "Authorization": f"Bearer {AUTH_TOKEN}",
        "Content-Type": "application/json",
    }


async def _get(path: str, params: dict[str, Any] | None = None) -> Any:
    async with httpx.AsyncClient(timeout=TIMEOUT_SECONDS) as client:
        response = await client.get(f"{BACKEND_URL}{path}", headers=_headers(), params=params)
        response.raise_for_status()
        return response.json()


async def _post(path: str, body: dict[str, Any]) -> Any:
    async with httpx.AsyncClient(timeout=TIMEOUT_SECONDS) as client:
        response = await client.post(f"{BACKEND_URL}{path}", headers=_headers(), json=body)
        response.raise_for_status()
        return response.json()


def _fmt(result: Any) -> str:
    if isinstance(result, str):
        return result
    return json.dumps(result, indent=2, ensure_ascii=False, default=str)


def _text_tool(name: str, description: str, properties: dict[str, Any], required: list[str] | None = None) -> types.Tool:
    return types.Tool(
        name=name,
        description=description,
        inputSchema={
            "type": "object",
            "properties": properties,
            "required": required or [],
        },
    )


@server.list_tools()
async def list_tools() -> list[types.Tool]:
    return [
        _text_tool(
            "health_check",
            "Check VM backend health and RAG readiness counts.",
            {
                "tenant_id": {
                    "type": "string",
                    "description": "Tenant id for RAG status; default is default.",
                    "default": "default",
                }
            },
        ),
        _text_tool(
            "ask_dita_expert",
            (
                "Ground a DITA, DITA-OT, or AEM Guides behavior question using the VM RAG. "
                "Returns AEM Guides evidence, DITA spec evidence, and DITA attribute evidence when detected."
            ),
            {
                "question": {
                    "type": "string",
                    "description": "Question about DITA, DITA-OT, AEM Guides, publishing, UI behavior, or workflow rules.",
                },
                "tenant_id": {
                    "type": "string",
                    "description": "Tenant id; default is kone.",
                    "default": "kone",
                },
            },
            ["question"],
        ),
        _text_tool(
            "lookup_aem_guides",
            "Search VM-hosted AEM Guides Experience League RAG evidence.",
            {
                "query": {
                    "type": "string",
                    "description": "AEM Guides feature, UI workflow, admin/configuration, Assets, or publishing question.",
                }
            },
            ["query"],
        ),
        _text_tool(
            "lookup_dita_spec",
            "Look up DITA specification evidence for an element, attribute, or behavior question.",
            {
                "query": {
                    "type": "string",
                    "description": "DITA element/concept question, for example '<topicref>', 'keyref', or 'reltable behavior'.",
                }
            },
            ["query"],
        ),
        _text_tool(
            "lookup_dita_attribute",
            "Look up a DITA attribute catalog entry and related RAG evidence.",
            {
                "attribute_name": {
                    "type": "string",
                    "description": "Attribute name without @, for example 'keyref', 'conref', 'processing-role'.",
                }
            },
            ["attribute_name"],
        ),
        _text_tool(
            "search_jira_issues",
            "Search AEM Guides Jira issues through the VM backend/index.",
            {
                "query": {
                    "type": "string",
                    "description": "Jira key or natural-language query.",
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum results; default 5.",
                    "default": 5,
                },
            },
            ["query"],
        ),
        _text_tool(
            "guides_test_plan_generator",
            "Build an evidence packet for an AEM Guides Jira test plan using VM Jira/RAG/repo evidence.",
            {
                "jira_key": {"type": "string", "description": "Jira key, for example GUIDES-48450."},
                "tenant_id": {"type": "string", "description": "Tenant id; default kone.", "default": "kone"},
                "evidence_k": {"type": "integer", "description": "RAG chunks to retrieve; default 8.", "default": 8},
                "include_repository_evidence": {
                    "type": "boolean",
                    "description": "Use repository evidence configured on the VM; default true.",
                    "default": True,
                },
                "max_repo_matches": {"type": "integer", "description": "Max repo matches; default 30.", "default": 30},
                "external_historical_jiras": {
                    "type": "array",
                    "description": "Optional rows from Adobe Jira MCP historical search.",
                    "items": {"type": "object"},
                    "default": [],
                },
                "skip_uac_label_gate": {"type": "boolean", "description": "Default false.", "default": False},
                "full_rag": {"type": "boolean", "description": "Run full semantic RAG; default true.", "default": True},
            },
            ["jira_key"],
        ),
        _text_tool(
            "test_plan_pipeline",
            "Run the full VM test-plan pipeline: Jira, RAG, UAC intelligence, scoring, and draft plan.",
            {
                "jira_key": {"type": "string", "description": "Jira key, for example GUIDES-48450."},
                "tenant_id": {"type": "string", "description": "Tenant id; default kone.", "default": "kone"},
                "evidence_k": {"type": "integer", "description": "RAG chunks to retrieve; default 8.", "default": 8},
                "include_repository_evidence": {"type": "boolean", "description": "Default true.", "default": True},
                "max_repo_matches": {"type": "integer", "description": "Default 30.", "default": 30},
                "external_historical_jiras": {
                    "type": "array",
                    "description": "Optional rows from Adobe Jira MCP historical search.",
                    "items": {"type": "object"},
                    "default": [],
                },
                "skip_uac_label_gate": {"type": "boolean", "description": "Default false.", "default": False},
                "full_rag": {"type": "boolean", "description": "Default true.", "default": True},
                "include_uac_intelligence": {"type": "boolean", "description": "Default true.", "default": True},
                "compose_draft_plan": {"type": "boolean", "description": "Default true.", "default": True},
                "publish_to_team_ui": {"type": "boolean", "description": "Default false.", "default": False},
                "human_review_threshold": {"type": "integer", "description": "Default 50.", "default": 50},
            },
            ["jira_key"],
        ),
        _text_tool(
            "find_recipes",
            "Search DITA dataset recipe types available on the VM backend.",
            {"query": {"type": "string", "description": "Recipe search text, for example 'keyref' or 'bookmap'."}},
            ["query"],
        ),
        _text_tool(
            "generate_dita",
            "Generate a DITA dataset bundle through the VM backend.",
            {
                "text": {"type": "string", "description": "Jira text, feature description, or freeform request."},
                "instructions": {"type": "string", "description": "Optional generation instructions.", "default": ""},
            },
            ["text"],
        ),
        _text_tool(
            "review_dita_xml",
            "Validate a DITA XML string through the VM backend.",
            {
                "xml": {"type": "string", "description": "DITA XML content."},
                "filename": {"type": "string", "description": "Optional filename hint.", "default": "topic.dita"},
            },
            ["xml"],
        ),
        _text_tool(
            "fix_dita_xml",
            "Repair common DITA XML issues through the VM backend.",
            {
                "xml": {"type": "string", "description": "DITA XML content."},
                "filename": {"type": "string", "description": "Optional filename hint.", "default": "topic.dita"},
            },
            ["xml"],
        ),
        _text_tool(
            "list_jobs",
            "List recent VM dataset generation jobs.",
            {"limit": {"type": "integer", "description": "Max jobs; default 10.", "default": 10}},
        ),
        _text_tool(
            "get_job_status",
            "Get VM dataset generation job status.",
            {"job_id": {"type": "string", "description": "Job id returned by generate_dita or list_jobs."}},
            ["job_id"],
        ),
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[types.TextContent]:
    try:
        result = await _dispatch(name, arguments or {})
        return [types.TextContent(type="text", text=_fmt(result))]
    except httpx.HTTPStatusError as exc:
        detail = exc.response.text[:2000]
        message = f"Backend error {exc.response.status_code} from {BACKEND_URL}: {detail}"
        return [types.TextContent(type="text", text=message)]
    except httpx.ConnectError:
        return [
            types.TextContent(
                type="text",
                text=(
                    f"Cannot reach VM backend at {BACKEND_URL}. Check VPN, VM URL, firewall, "
                    "and that `systemctl status aem-backend` is healthy on the VM."
                ),
            )
        ]
    except Exception as exc:
        return [types.TextContent(type="text", text=f"Error ({type(exc).__name__}): {exc}")]


async def _dispatch(name: str, args: dict[str, Any]) -> Any:
    if name == "health_check":
        tenant_id = args.get("tenant_id", "default")
        health = await _get("/health")
        rag = await _get("/api/v1/ai/rag-status", {"tenant_id": tenant_id})
        return {
            "backend_url": BACKEND_URL,
            "health": health,
            "rag_status": rag,
        }

    if name == "ask_dita_expert":
        question = str(args["question"]).strip()
        attr_names = sorted({m.group(1) for m in re.finditer(r"@([A-Za-z_][\w.-]*)", question)})
        attribute_evidence = []
        for attr in attr_names[:3]:
            try:
                attribute_evidence.append(await _post("/api/v1/mcp/lookup-dita-attribute", {"attribute_name": attr}))
            except Exception as exc:
                attribute_evidence.append({"attribute": attr, "error": str(exc)})
        return {
            "question": question,
            "answering_instruction": (
                "Use the evidence below. Answer directly first, cite source titles/URLs from evidence, "
                "and mark anything not present as unverified."
            ),
            "aem_guides_evidence": await _post("/api/v1/mcp/lookup-aem-guides", {"query": question}),
            "dita_spec_evidence": await _post("/api/v1/mcp/lookup-dita-spec", {"query": question}),
            "attribute_evidence": attribute_evidence,
        }

    if name == "lookup_aem_guides":
        return await _post("/api/v1/mcp/lookup-aem-guides", {"query": args["query"]})

    if name == "lookup_dita_spec":
        return await _post("/api/v1/mcp/lookup-dita-spec", {"query": args["query"]})

    if name == "lookup_dita_attribute":
        return await _post("/api/v1/mcp/lookup-dita-attribute", {"attribute_name": args["attribute_name"]})

    if name == "search_jira_issues":
        return await _post(
            "/api/v1/mcp/search-jira",
            {"query": args["query"], "limit": args.get("limit", 5)},
        )

    if name == "guides_test_plan_generator":
        return await _post(
            "/api/v1/mcp/guides-test-plan-generator",
            {
                "jira_key": args["jira_key"],
                "tenant_id": args.get("tenant_id", "kone"),
                "evidence_k": args.get("evidence_k", 8),
                "include_repository_evidence": args.get("include_repository_evidence", True),
                "max_repo_matches": args.get("max_repo_matches", 30),
                "external_historical_jiras": args.get("external_historical_jiras", []),
                "skip_uac_label_gate": args.get("skip_uac_label_gate", False),
                "full_rag": args.get("full_rag", True),
            },
        )

    if name == "test_plan_pipeline":
        return await _post(
            "/api/v1/mcp/test-plan-pipeline",
            {
                "jira_key": args["jira_key"],
                "tenant_id": args.get("tenant_id", "kone"),
                "evidence_k": args.get("evidence_k", 8),
                "include_repository_evidence": args.get("include_repository_evidence", True),
                "max_repo_matches": args.get("max_repo_matches", 30),
                "external_historical_jiras": args.get("external_historical_jiras", []),
                "skip_uac_label_gate": args.get("skip_uac_label_gate", False),
                "full_rag": args.get("full_rag", True),
                "include_uac_intelligence": args.get("include_uac_intelligence", True),
                "compose_draft_plan": args.get("compose_draft_plan", True),
                "publish_to_team_ui": args.get("publish_to_team_ui", False),
                "human_review_threshold": args.get("human_review_threshold", 50),
            },
        )

    if name == "find_recipes":
        return await _post("/api/v1/mcp/find-recipes", {"query": args["query"]})

    if name == "generate_dita":
        return await _post(
            "/api/v1/ai/generate-from-text",
            {"text": args["text"], "instructions": args.get("instructions") or ""},
        )

    if name == "review_dita_xml":
        return await _post(
            "/api/v1/mcp/review-dita-xml",
            {"xml": args["xml"], "filename": args.get("filename", "topic.dita")},
        )

    if name == "fix_dita_xml":
        return await _post(
            "/api/v1/mcp/fix-dita-xml",
            {"xml": args["xml"], "filename": args.get("filename", "topic.dita")},
        )

    if name == "list_jobs":
        return await _get("/api/v1/jobs", {"limit": args.get("limit", 10)})

    if name == "get_job_status":
        return await _get(f"/api/v1/jobs/{args['job_id']}")

    raise ValueError(f"Unknown tool: {name}")


async def main() -> None:
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())


if __name__ == "__main__":
    asyncio.run(main())
