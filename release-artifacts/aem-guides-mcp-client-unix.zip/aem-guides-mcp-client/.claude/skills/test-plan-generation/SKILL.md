---
name: test-plan-generation
description: "Generate evidence-backed, plain-English AEM Guides QA test plans and UACs from Jira, Dynamics/support incidents, customer escalations, PRs, branches, commits, pasted diffs, logs, screenshots, Figma designs, or user-cloned repos. Also use when a reviewer reads a Jira UAC and supplies Human feedback in a fresh Claude/Codex chat: capture the selected correction with exact reviewed-source binding and separate QE approval for shared learning. Use for pre-development UAC planning, implementation review, and post-fix validation; inspect available product and automation clones; apply lifecycle-stage-specific evidence requirements so missing PRs are not blockers before development; and output concise plain-English plans."
---

# Test Plan Generation

## Goal

Produce a concrete AEM Guides QA test plan that reads like a senior manual QA engineer wrote it: practical, evidence-backed, plain-English, and bullet-only. Acceptance criteria must be easy to understand on the first read, including for non-native English speakers. Adapt evidence requirements to the lifecycle stage. Use RAG to learn product behaviour, but do not let RAG replace issue facts, UAC, current implementation evidence, or an available fix diff. Treat Jira UAC, pasted acceptance criteria, or a normalized support-incident acceptance contract as the primary scope and sign-off contract.

## Route reviewer feedback before plan generation

When the user reviews a UAC already on Jira and gives a correction (missed coverage,
unnecessary scope, wrong expectation, or difficult wording), read
`references/shared-human-uac-learning.md` and use its fresh-chat capture path. The
original generation session or draft ID is not required. This is a feedback task, not
a request to generate another UAC: do not run plan-generation gates, require product
clones, or retrieve unrelated RAG before saving the selected Human correction.

- Announce that only the selected correction will be saved for QE review; respect an
  explicit request not to save/share it. Never upload the whole conversation.
- Fetch the live issue through configured Jira MCP, including the raw UAC field,
  actual field-name metadata, and issue update time. Bind the exact field bytes using
  `feedback_capture.py prepare-jira-review`, then capture. Do not hash a paraphrase,
  rendered HTML, or the newly corrected AC as the original. If the reviewer refers to
  an older version, do not silently substitute the current Jira field.
- If that raw source is unavailable, capture without a fabricated draft/run/hash and
  report `PENDING_BINDING`. A changed-source conflict requires reconfirming the reviewed
  version; do not retry with a newly guessed pin. Editing/posting the Jira UAC remains
  a separate request and follows the existing posting gates.
- Check shared-learning readiness with the installed helper/MCP when configured. A
  readiness response describes configuration, not a saved record, reviewer authority,
  successful index, or proof of learning. Missing tools/credentials are reported, never
  concealed by a local success claim. Status-only requests must not flush the queue.
- Report the actual receipt: queued locally, saved pending binding, saved pending QE
  review, approved publication, and indexing are different states. Capture never grants
  approval, even when the person giving feedback is the ticket's QE Assignee. Reusable
  lesson approval requires that person's explicit decision and live server identity check.
- Apply the full generation workflow only if the user also asks for a revised plan.

## Operating Mode

- Treat `CanonicalTestPlanRuntime` as the only production reasoning and final-rendering authority. This skill gathers and verifies evidence, prepares a hash-bound compatibility record, and delegates it; it must not publish its own draft, compact projection, inferred gate status, or legacy packet composition as the final QE plan.
- Never activate a domain, reference pack, retrieval query, acceptance candidate, threshold, or expected result because an issue key matches a historical example. Historical issues may exist only in regression fixtures and evaluation references; production reasoning uses current source facts plus verified subject-specific evidence.
- Work evidence-first: classify lifecycle stage, collect facts, inspect available clones, normalize behaviour, retrieve RAG, inspect an available diff when stage-relevant, then write scenarios.
- Apply conflict priority in this order: Jira/UAC or normalized incident acceptance contract > inspected fix implementation when one exists > accepted RAG documentation > Figma UI intent > verified current product clone > automation clone > team memory. Surface material contradictions instead of silently choosing.
- Derive edge cases from concrete evidence: UAC boundaries, PR diff, code branches, API contracts, configs, old automation failures, and past similar Jira history; do not invent edge cases from generic module names.
- A current implementation proves what the code does; it does not by itself approve a new product requirement. If a fix adds user-visible handling that Jira or accepted UAC did not request, keep it Proposed and expose the scope choice as an Open Question. Do not promote it to sign-off scope merely because it appears in a PR.
- Map integration impact for every plan: identify adjacent workflows, callers, configs, output types, permissions, and automation areas that can break even if not directly changed.
- Use exact evidence probes before broad reasoning: RAG queries, Jira searches, repo searches, and automation searches must include the precise API path, config key, UI label, DITA construct, error text, or release/version boundary whenever one is available.
- Treat setup and test data as part of QA quality: each plan must make required environment, role, config, fixture, file type, output preset, and upgrade/source-target version needs visible inside `Test Scenarios`, `Regression Areas`, or `Open Questions`.
- Start `Test Scenarios` with one or more `Test data to prepare:` bullets, then write every P0/P1/P2 primary scenario in simple English using `Action:` and `Expected:`. Write `Regression Areas` as executable retest-and-risk bullets so the compact renderer can merge them into `Test Scenarios` as senior-QA `P3 [Regression]` checks.
- Keep the final answer short and tester-facing; keep raw evidence, chunk scores, backend traces, and reasoning audits internal.
- Judge readiness against the lifecycle stage: UAC-ready before development, implementation-review-ready while code is changing, or QA-sign-off-ready after a fix is available.
- Ask for a PR, branch, commit, or pasted diff only in implementation-review or post-fix stages, or when the user explicitly requests changed-code claims.
- Inspect every relevant user-provided or discoverable local clone before declaring code or automation evidence unavailable; do not ask teammates to clone dataset-studio, copy RAG JSON, copy ChromaDB, or run old test-plan MCP tools.
- Clone discovery is not limited to the current workspace. Follow the bounded Windows/Mac/Linux discovery protocol in `references/pr-and-repo-evidence.md`, resolve wrapper directories to the nested `.git` repository, and list the paths actually inspected.

## Tool Boundary

- Use `ask_dita_expert` as the only VM RAG path for AEM Guides, Experience League, DITA, DITA-OT, workflow, release-note, and configuration behaviour facts.
- Use the FluffyJaws connector ONLY as a `SUPPORTING_DISCOVERY` source, and only when it is registered in the session AND `SKILL_FLUFFYJAWS_MODE` is `FLUFFYJAWS_SHADOW` or `FLUFFYJAWS_SECOND_PASS` (default `FLUFFYJAWS_DISABLED` => never call it). When enabled, call the connector's own tool for discovery, then RE-GROUND every finding into a first-class source (spec / DITA-OT / product doc / current code / historical Jira) that keeps its own authority before it can raise any AC coverage. FluffyJaws synthesis can hallucinate: it is never an authority, never the sole basis for a Covered/Partially-covered claim, and there is no FluffyJaws -> AC path. Record it in the manifest `fluffyjaws` block (see "### FluffyJaws Supporting-Discovery"); enforced by `fluffyjaws_evidence`. See `docs/fluffyjaws_setup.md` and `references/fluffyjaws-evidence.md`.
- Use Jira MCP first for current Jira facts and historical similar-ticket search. If Jira MCP is unavailable, use pasted Jira, Dynamics, support-case, customer-escalation, log, screenshot, and investigation details; state the evidence source without automatically blocking a pre-development UAC.
- Use the Jira MCP `list_attachments` and `download_attachment` tools to pull every attachment to a scratchpad path, then analyse it (Read images/screenshots, open logs and sample content as text). Never describe an attachment's contents from its filename alone.
- When the Dataset Studio app or local repo is available, use its `jira_qa` related-ticket retrieval as the first historical-learning candidate source, then validate mutable Jira facts with Jira MCP. Treat indexed learning as historical QA evidence only, never as current Jira truth or product documentation.
- After direct product RAG and Jira-history retrieval, call `query_test_evidence_graph` to evaluate connected findings and discover same-mechanism regressions. Default to shadow influence unless the packet/deployment explicitly enables augment; shadow output cannot change the plan. Never use the graph instead of the required direct calls, and never treat a path ID as evidence.
- Use GitHub MCP to inspect or discover a PR only when development may have started, a fix is claimed, or changed-code evidence is requested. Do not search for or request a PR when the issue is explicitly pre-development and no implementation exists.
- When live Jira contains a development link, PR URL, branch, commit, or pull-request reference, treat it as mandatory implementation evidence for `Implementation Review` and `Post-Fix Validation`. Use GitHub MCP when connected; do not stop at Jira development metadata or a PR title.
- Use Figma MCP read-only when Jira, PR, comments, attachments, or the user provides design links, frame names, prototype links, or asks to verify against existing UX/design flow.
- Do not use or expect any generated test-plan slash command or test-plan MCP tool.
- Use connected Jira/GitHub MCPs only if available in the current session. If unavailable, rely on user-provided evidence and local clones, then apply only stage-relevant gaps or blockers.
- For automation evidence, inspect synchronized local clones first because they support exact code, fixture, helper, tag, and history searches. Use GitHub MCP to inspect automation repositories when a local clone is unavailable or stale, to inspect automation PRs/branches, and to validate current remote files or default-branch coverage. Combine both sources when available and state which revision was inspected.
- Use connected Figma MCP only if available in the current session. If unavailable, rely on pasted screenshots/design notes and mark the Figma evidence gap.
- Before using a local product or automation clone as current evidence, run the guarded synchronization flow in `references/git-repo-sync.md`. Fetch every relevant clone, preserve dirty tracked and untracked developer work in a uniquely named stash when synchronization is safe, pull only with `--ff-only`, and report the pre-sync SHA, post-sync SHA, upstream state, and retained stash reference. Never reset, merge, rebase, force-checkout, drop a developer stash, or resolve conflicts automatically.

## Required References

- Read `references/evidence-preflight.md` before evidence retrieval. Run an actual availability check for product RAG, indexed Jira history, live Jira, Git, and Figma; connector configuration alone does not prove availability.
- Read `references/rag-query-cookbook.md` before calling or judging `ask_dita_expert` evidence.
- Read `references/output-generation-overview-evidence.md` for publishing scope, Publish Dashboard tasks, LwDITA output or publishing privileges; use the overview to find the relevant detailed evidence, not to assume engine parity or add every publishing feature to an AC set.
- Read `references/map-collection-publishing-evidence.md` for Map Collection publishing, preset selection or bulk metadata; separate membership from enablement, selection from filters, and collection removal from asset deletion. Do not substitute New Map Collection behaviour or turn the reference into mandatory ACs.
- Read `references/native-pdf-publishing-evidence.md` when current scope concerns Native PDF templates, output presets, or environment configuration; use its source/chunk and image ledger to retrieve the applicable behaviour, preserving engine, version, and UI-label boundaries.
- Read `references/bookmap-toc-native-pdf-evidence.md` for Native PDF TOC/list generation or layout ordering; distinguish bookmap structure from ordinary DITA-map template controls and retrieve the exact source before deciding coverage.
- Read `references/custom-dita-ot-setup-evidence.md` for custom toolkit deployment or DITA Profile configuration; distinguish the uploaded ZIP, assigned repository paths and output-preset settings, and verify release/deployment applicability.
- Read `references/output-path-variables-evidence.md` for publishing destination/name substitutions; retrieve field-specific variable restrictions and keep these separate from Native PDF Language Variable behaviour.
- Read `references/html5-publishing-evidence.md` when current scope concerns HTML5 output presets; retrieve the relevant source-backed dependencies and preserve Map console/Map dashboard and DITA-OT/FMPS distinctions. The reference is not an automatic AC checklist.
- Read `references/custom-publishing-evidence.md` for Custom DITA-OT output presets; preserve plugin/transformation dependencies, console/dashboard labels, and source inconsistencies rather than importing another output family's contract.
- Read `references/condition-presets-evidence.md` for condition-preset creation, editing, default actions or output-preset selection; retrieve surface-specific rules and preserve the documented console/dashboard differences and naming ambiguity.
- Read `references/profile-output-presets-evidence.md` for Global/Folder Profile preset management or map Download as PDF defaults; distinguish shared, map-independent profile configuration from map-specific presets and do not infer PDF-engine equivalence.
- Read `references/output-preset-actions-evidence.md` for editing, duplicating, or deleting output presets; preserve Map console versus Map dashboard controls and the documented template-preset administrator restriction without inventing copy or deletion side effects.
- Read `references/fluffyjaws-evidence.md` before calling the FluffyJaws connector or recording a `fluffyjaws` manifest block; it defines the SUPPORTING_DISCOVERY-only, re-grounding, and no-FJ-to-AC invariants the `fluffyjaws_evidence` gate enforces.
- Read `references/pr-and-repo-evidence.md` before searching GitHub MCP, inspecting PRs, or using user-cloned repos.
- Read `references/git-repo-sync.md` and use `scripts/sync_evidence_repo.py` before treating a local clone as current product or automation evidence.
- Read `references/design-evidence-flow.md` before using Figma MCP or design screenshots as evidence.
- Read `references/output-template.md` before writing the final test plan.
- Read `references/plain-language-ac-writing.md` before writing or rewriting acceptance criteria. Apply its short-clause limits, one-main-idea rule, simple-word substitutions, and split rules without removing required technical identifiers.
- Read `references/component-routing.md`, then run `python scripts/component_reference_router.py <jira-json-or-text-file> --out <reference-routing.json>`. Load only the returned generic component pack. `references/uac-reference-examples.md` is a non-authoritative regression/evaluation catalog: never load it to route or draft a production plan, and never use an example issue key or its exact values as acceptance authority.
- Read `references/component-authoring.md` when the router selects Authoring, especially for asset-browser thumbnails, map-Xref display labels, hierarchy selection counts, or Explorer filename/title sorting.
- Read `references/component-integration.md` when the router selects the asset CRUD API mechanism, especially for caller-supplied content/metadata, independent filename/GUID identity, or UPDATE-as-UPSERT behavior.
- Read `references/component-platform.md` when the router selects bulk same-name asset overwrite/session behavior, especially for terminal-state, `/bin/fmdita/import`, CSRF, login-redirect, and asset-integrity evidence.
- Read `references/authoring-state-uac.md` when current evidence mentions Author-canvas scroll/viewport/caret state, Map Preview restoration, CALS multi-column deletion, or the `largeFileTagCount` configuration.
- For those mechanisms, run `python scripts/authoring_state_contract.py <jira-text-file> --out <candidate-contract.json>` and use only the route activated by current mechanism terms. An issue key alone must never activate a route. The helper produces candidate AC/scenario wording; current Jira/UAC remains the scope authority.
- Read `references/review-workflow-uac.md` when Jira scope mentions review tasks, review comments, review right panel, comment import, side-by-side review diff, task dropdowns, current/closed task state, or author incorporation of review comments.
- Read `references/open-questions-catalog.md` before writing the `Open Questions` section.
- Read `references/clarification-gate.md` after behavior/coverage discovery and before authoring acceptance criteria. Enumerate every material dimension, resolve it from evidence or ask the user, and stop while a blocking question is unanswered.
- Read `references/v3-reasoning-authoring.md` and `references/discovery-disposition.md` before authoring any behavioral plan or revising its coverage. Build the real evidence-grounded model, run `v3_scaffold.py --manifest <manifest.json>` to create editable graph/closure/question/file-binding records, then run `dimension_synthesizer.py --manifest <manifest.scaffold.json> --json`. Replace every author-review placeholder with an inspected decision and carry each exact discovery through directed retrieval, verification, disposition, and promotion. An axis/feature tag or copied candidate without this chain leaves DISCOVERY REVIEW non-postable. Repeat discovery for a reported omission or scope/behavior change; a wording-only edit is not a fresh completeness run. Scaffold success is not gate success. Do not start from a v2 fixture or generate blanket waivers.
- Read `references/manifest-completeness.md` before finalizing the evidence manifest. Behavioral `behavior_model`, `coverage_hypotheses`, and `verifications` cannot use ordinary author waivers. Every reasoning waiver emits REVIEW and makes the receipt non-postable, including a genuinely reviewed escape.
- Read `references/qe-completeness-coverage.md` before finalizing any plan with Open Questions, regression items, or QE/reviewer checks. Checkable reviewer requirements belong in ACs, not a separate QE-checks section; genuine undecided product outcomes remain Open Questions. Map every requested check to its AC or unresolved question before responding. For UAC-only output, omit a separate QE-checks section. Classify retained full-plan checklist items explicitly in `qe_completeness`.
- Read `references/root-cause-fix-driven.md` whenever current evidence supplies a root cause, linked PR/commit/fix branch/diff, or a positive merged/fixed/verified claim. Populate `root_cause_fix` before authoring so the fix contract, preserved invariants, newly introduced risks, added tests, and verification gaps drive the plan instead of appearing only as citations.
- Read `references/execution-outcome-loop.md` when importing Human or trusted-CI execution results. Validate any `execution_outcome` block; convert only Human-confirmed escapes into governed `CANDIDATE` miss-probe inputs, and use repeated defect-finding ACs only to raise a mapped generic dimension's priority. Never let an outcome auto-author an AC or auto-promote a pattern.
- Read `references/shared-human-uac-learning.md` whenever a Human corrects a generated UAC, asks the skill to learn from feedback, or asks to bind, approve, reject, revoke, supersede, or inspect a shared lesson. Any authenticated tenant teammate may capture; only the ticket's current live QE Assignee, using a personal named Human identity, may bind/review. Capture only the selected correction with its draft identifiers; never upload the whole chat, treat queued/pending feedback as saved or approved, or retry review automatically. Roles, admin status, draft ownership, ordinary Jira Assignee and names in prose grant no review authority.
- Read `references/missing-question-quality-contract.md` before Claude Desktop writes Missing Questions. Submit only hash-bound contextual questions; a generic or rejected question cannot satisfy a mandatory family, and authoritative evidence must be tried before Human escalation.
- Read `references/operational-incident-contract.md` and populate the versioned `operational_contract` manifest block for every plan. Mark it inactive with a concrete reason only when no job, queue, retry, restart, listener, batch, migration, repair, or long-running behavior is involved.
- Read `references/native-aemsite-baseline-metadata.md` when Jira scope mentions Native AEM Site, baseline publishing, output preset metadata, metadata propagation, copy-to, or incremental publishing metadata.
- Read `references/quality-gate-checklist.md` before marking a plan review-ready.
- Read `references/evidence-graph-contract.md` before calling `query_test_evidence_graph`, recording graph evidence, or using a graph-connected claim.
- Read `references/performance-assessment-contract.md` before deciding whether the ticket needs a Performance AC.
- Read `references/api-implementation-evidence.md` whenever the ticket names a code artifact (REST path, servlet operation, handler method, service class, or config key). Read the actual handler in the clone/GitHub and verify the ticket's current-behaviour premise against the code before writing any AC that asserts current behaviour; declare an `implementation_grounding` manifest block citing the inspected `file:line`. `run_gates.py` fails an API/operation plan that asserts current behaviour without this grounding — never write API ACs from the ticket text alone.
- Read `references/security-coverage.md` whenever the plan or manifest mentions XML/DITA parsing or ingestion, DITA upload/import, entity or DTD handling, conref/keyref/href/xref resolution, a content-accepting REST/servlet endpoint, publishing/output to a shared location, or an ACL/role/permission-bearing operation. Populate all three `security_coverage` dimensions and map each applicable one to ACs or a QA-impact Open Question; explicitly disposition genuinely inapplicable dimensions. `security_coverage.py` hard-fails silence after a security signal.
- Read `references/localization-regression-coverage.md` whenever the changed area touches content/topic/map body, metadata/properties, conref/keyref/reuse, publishing/output, or explicitly names translation/localization/XLIFF/multilingual behavior. Populate `TRANSLATION_STATE`, `XLIFF_ROUNDTRIP`, and `PROJECT_TYPES` in `localization_coverage`; map applicable dimensions to ACs or a QA-impact Open Question and give every not-applicable dimension a concrete reason. `localization_regression_coverage.py` hard-fails silence after a localization signal.
- Read `references/upgrade-migration-coverage.md` whenever current ticket or evidence mentions a version/release upgrade, stored-data or schema migration, non-UUID-to-UUID conversion, on-premise-to-cloud migration, backward/forward compatibility, or a fix-version boundary that changes stored data or configuration format. Populate `PRE_STATE`, `MIGRATION_EXECUTION`, `POST_STATE_AND_MIXED`, and `ROLLBACK_OR_IRREVERSIBILITY` in `upgrade_migration_coverage`. `temporal_evidence.py` still owns evidence applicability; `upgrade_migration_coverage.py` hard-fails silence about testing the migration operation itself.
- Read `references/configuration-driven-enumerations.md` whenever Jira, a PR, code, or supplied UI evidence shows that supported attributes, elements, options, labels, actions, or other UI entries come from a repository/profile/OSGi/JSON/CSV/XML configuration. Apply its dynamic-entry, mapping/fallback, applicability, reload, preservation, and hardcoded-consumer checks before finalizing ACs or scenarios.
- Read `references/aem-feature-map.md` before using or disposing `FEATURE_MAP` discovery candidates. It defines the curated, Human-approved, Experience-League-only domain checklist, environment qualifications, fail-open behavior, and the invariant that a matched native feature is an investigation candidate rather than an AC.
- Read `references/offline-authoring-rag.md` before using `OFFLINE_CHROMA` discovery candidates. It defines the local `aem_guides`/`jira_qa` fallback, bounded feature-map query expansion, non-authoritative provenance, Human-UAC exclusion, fail-open behavior, and the invariant that offline history never claims `indexed_history_run=true`.
- Read `references/customer-discovery-learning.md` before importing CSV precedents or using mined/customer-profile candidates. It separates historical AC text from theme-only rows, requires versioned provenance, and keeps all mined advice VALIDATING/non-authoritative until separate Human review.
- Read `references/golden-benchmark.md` only when evaluating or releasing a test-plan skill, RAG, Jira retrieval, evidence graph, ranking, or AC-contract change. The 18-case benchmark is not part of an ordinary plan request.
- When changing or releasing this skill, run `python scripts/audit_production_hardcoding.py`. Any historical Jira identity or known fixture threshold in active instructions, scripts, data, or generic references blocks release. Regression/evaluation catalogs are the only allowed location for such examples.
- Run the compatibility preflight `python scripts/run_gates.py --plan <body> --combined <plan+appendix> --manifest <manifest> --receipt <gate-receipt.json>` before delegation. New records use evidence-manifest schema `aem-guides-evidence-manifest-v3`; legacy v2 records remain readable but cannot bypass behavioral reasoning. Populate activated blocks through `references/v3-reasoning-authoring.md`. Reasoning waivers are exceptional, non-postable review records under `manifest_completeness_gate`, not a substitute for executing the pipeline. The preflight validates exact artifact binding, AC grammar, UAC/status fidelity, source-requirement fidelity, enumerated requirements, operational and concurrency contracts, semantic records, and self-tests. Its receipt proves only that the input record is safe to delegate; it is not authority for a final plan. A nonzero result or `postable=false` stops the run.
- After the preflight exits 0, route the same artifacts through `python scripts/canonical_runtime_adapter.py --jira-key <key> --tenant-id <tenant> --manifest <manifest> --plan <full-plan.md> --receipt <gate-receipt.json> --out <runtime-envelope.json>` when the Dataset Studio backend checkout is available through `--repo-root`, `AEM_STUDIO_REPO`, or an ancestor directory. When Claude has a submission bound to the returned `qe_investigation.preparation_id`, also pass `--claude-question-submission <submission.json>`. The adapter must verify the receipt and every bound hash, invoke the fixed canonical stage order exactly once, and return the canonical gates, structured plan, trace, and `rendered_output`. Caller-supplied prose or gate-status text is never authority.
- In a packaged Claude installation without that backend checkout, call the configured `guides_test_plan_generator` MCP tool instead and accept its result only when `runtime_id=aem-guides-test-plan-runtime`, the trace contains the full canonical stage order, and the three canonical gates are present. This is a transport fallback to the same VM runtime, not a second reasoning path. If neither canonical transport is available, stop safely.
- Return only canonical `rendered_output` / `plan_markdown` when `status` is `completed` or `needs_human_review`, `validation_status=passed`, and ContractIntegrityGate, BehavioralCompletenessGate, and AcceptancePromotionGate all passed. `needs_human_review` is a valid fresh-Jira result but is never postable or Jira-write authority. Do not run `render_compact_view.py` as a second final renderer. It remains a compatibility preview for old stored records only.
- Before handing acceptance criteria to an AI automation-draft agent, run `python scripts/extract_acs.py <full-plan.md> --out <acceptance-criteria.json>`. A nonzero exit blocks handoff. The automation agent consumes this JSON and must not re-parse chat prose or invent setup, actions, assertions, or evidence outside its fields.
- Jira mutation is a separate, explicit human-authorized step. A compatibility receipt alone is not enough to authorize a write: the posting boundary must also verify the completed canonical runtime envelope and post only canonically promoted acceptance records. Until a posting client supports that binding, stop rather than use the legacy compact or eleven-section draft as authority.
- Minimum evidence manifest fields include `"schema_version": "aem-guides-evidence-manifest-v3"`, a canonical Jira issue key, explicit boolean `accepted_uac_present`, stable `open_questions` records (`id`, `question`, `qa_impact`), a versioned `enumerated_requirements` block, a versioned `operational_contract` block, the complete `evidence_preflight` contract, `"rag_tool": "ask_dita_expert"`, three exact `rag_probes`, `"jira_history_tool": "search_jira_history"`, `"indexed_history_run": true`, two scoped `jira_history_queries`, `history_attempts`, an `evidence_graph` record, a complete `performance_assessment`, clone state, and the canonical semantic blocks `contract_facts`, `issue_domains`, `behavior_model`, `behavior_graph`, `semantic_closure`, `coverage_hypotheses`, `missing_questions`, `evidence_lifecycle`, `verifications`, `dispositions`, and `acceptance_promotions`. Each contract fact's literal text must be an exact excerpt of the canonical Jira field, accepted UAC, attested attachment text, or artifact-and-hash-bound `contract_source_records` capture named by its `source_ref`. When `enumerated_requirements.active=true`, also include `source_requirement_ledger` schema `aem-guides-source-requirement-ledger-v1`. When event/async signals exist, also include versioned `concurrency_race_analysis`.
- Record every Jira-history attempt in `history_attempts` using records such as `[{"source":"search_jira_history","query":"exact query","result":"empty","count":0}]`; `OFFLINE_CHROMA` and `Jira JQL` are also valid source descriptions. `source` and `query` are non-empty strings; `count` is a non-negative integer. Use `ok` only with one or more returned results, and use `empty` or `unavailable` with count zero. This attempt ledger is separate from `jira_history_queries`: it records the observable result even when no result can be cited.
- Run the manifest through `feature_class_registry.py`. Declare every applicable class in `feature_classification` and include each required dimension block. For UI constructs, enumerate only the affected construct's grounded render surfaces and disposition every entry in `scripts/data/ui_surface_catalog.json`; when review discovers another reusable surface, add it with `add_catalog_surface()` so that construct cannot silently miss the same surface again. An undeclared detected class is a REVIEW signal for legacy compatibility, not permission to omit the classification from a new plan.
- Run `relationship_traversal.py` for the affected construct. Record grounded one-hop code and corpus edges, all five cross-cutting dimensions, the exact code/corpus searches, searched clones, and the sibling-config, sibling-UI-option, caller, and same-path findings. Every discovered neighbor must be covered by an AC, exposed as an Open Question, or explicitly out of scope. This is the umbrella; role provisioning and UI-surface checks plug into its PRECONDITION and CONSUMER edges.
- Mark a UI consumer edge with `neighbor_kind: UI_SURFACE`. That marker requires `ui_surface_scope`; a list of screen-like names without the marker is not an acceptable substitute for classification.
- When an AC is supported only by a PR, commit, or diff, declare `implementation_scope_authority` with schema `aem-guides-implementation-scope-authority-v1`. Keep the AC Proposed and map it to a real Open Question, or cite an explicit accepted-UAC/product-decision source. Implementation evidence alone is not product authority.
- For a configuration-backed set, declare `configuration_driven_enumeration` and populate `configuration_enumeration_scope` schema `aem-guides-configuration-enumeration-scope-v1`. Disposition authoritative source and overlay precedence, dynamic discovery, mapped and fallback labels, applicability, activation, unrelated-entry preservation, invalid/duplicate/removal behavior, upgrade, and rollback to real ACs, Open Questions, or grounded out-of-scope reasons.
- Before canonical delegation, write the compatibility record to a UTF-8 temporary file and run `python scripts/validate_test_plan.py <draft-file>`. If it reports any error, repair the record and rerun. This check does not replace the canonical runtime gates or renderer.
- After structural validation passes, run `python scripts/verify_evidence.py <draft-file>` to audit that every cited drive-absolute source-file path exists on disk and that every cited line number is in range. Repair or remove any hallucinated path or line before returning the plan; never present unverified file/line citations as current implementation. Proposed new files, runtime paths, and relative test paths are skipped by design and are not failures.
- When the issue has attachments, write an evidence manifest JSON (`{"issue": ..., "attachments": [{"id", "filename", "downloaded_to", "analyzed": true, "note"}]}`) recording the scratchpad path each attachment was downloaded to, and run `python scripts/verify_evidence.py <draft-file> --attachments-manifest <manifest>`. It fails if any declared download is missing on disk or any attachment is not attested analyzed. This proves each attachment was fetched and attested; it does not prove the Jira list is complete, so still confirm the attachment count against `list_attachments`.
- When source-file evidence came from a subagent or a clone, treat a `verify_evidence.py` failure as a real finding: the path or line is wrong or invented, not a tooling glitch.
- If the validator or evidence scripts are edited, run `python scripts/test_skill_scripts.py` and keep it green; it is the regression guard for both scripts.
- Whenever the plan cites existing automation as `Covered` or `Partially covered`, or the user asks for a shareable or linkable artifact, produce a single deliverable Markdown file: the eleven-section plan body followed by an `Appendix A - Automation Evidence` section. In that appendix, for each Covered or Partially covered AC, read the cited file and quote the relevant step/method/fixture verbatim in a fenced code block, with its absolute path and a one-line note on what it proves and the precise gap, plus the reusable helpers a gap test would build on. Keep code fences OUT of the eleven validated sections (they are bullet-only and code fences fail `validate_test_plan.py`); the appendix lives after the validated body. Validate the plan body alone, then run `python scripts/verify_evidence.py <combined-file>` so source paths quoted in the appendix are disk-checked too, and deliver the file to the user (do not only paste it in chat).
- Quote real code, never paraphrased or invented code. If a cited file cannot be read, say so in the appendix rather than reconstructing its contents from memory.

### Deterministic Authoring-State Routing

- **Authoring viewport stability** is the route only when current evidence identifies the Author editing canvas plus an active caret/selection/element, reference insertion, or viewport-jump symptom. Cover only source-named triggers and state, then investigate other actions that share the verified viewport/focus controller. Restore visibility relative to the active element when that relationship is approved; do not import a historical action matrix or exact pixel offset.
- Do not automatically add left map-tree/outline state, save/reopen persistence, old/new editor parity, or numeric performance thresholds to an Authoring viewport plan unless current Jira/UAC evidence names them. Large content is a fixture, not an SLA. Do not claim data loss when the evidence establishes only disruption or wrong-location risk.
- **Map Preview state restoration** is a separate route. Enumerate only the preview state and transitions named by current evidence; treat scroll, selected topic, panel/condition state, refresh, and Edit-return as independent candidates until a shared state owner/consumer is verified. Area overlap such as `scroll` does not make Map Preview a same-mechanism Author-canvas match.
- **CALS multi-column deletion** uses the source-defined row/column counts and selected-column positions with distinct cell values. The result keeps the row count, removes exactly the selected columns, preserves retained content/order, produces no ghost column, and leaves no orphan column/span metadata. Do not import historical counts or add `simpletable`/`reltable` parity unless current evidence names them.
- **Large-file safeguard behavior** is configuration-driven when current evidence names `largeFileTagCount`. Test immediately below and at/above the effective parsed-tag threshold. Never convert an observed UI item, cell, or file count into the configured parsed-tag boundary or an invented performance SLA.
- Exact screenshot-only Jira examples may teach a generic candidate pattern but must not be indexed as an exact historical Jira record. Exact UAC indexing requires a live Jira record or Jira CSV provenance with a verified source hash.

### Component-Scoped Reference Routing

- Canonical Jira component labels select the first reference pack. When the component is missing, infer it from accepted UAC, then summary, then description, and record the inference source. Component routing reduces prompt size; it does not establish product behaviour.
- If the accepted UAC and stale description describe different mechanisms, use accepted UAC for ACs/scenarios and keep the displaced request out of Confirmed scope. Surface it only as an evidence-backed Open Question when QA sign-off depends on its disposition.
- When a later accepted scope conflicts with an older description, use the accepted scope and retain the older request only as context or an Open Question. For example, a thumbnail contract does not inherit an older multi-selection request; generic wording that selection still works does not authorize new selection semantics.
- For map-Xref display labels, separate visible text from destination semantics. Preserve `href`, `format`, `scope`, `type`, and external-link behavior unless current accepted evidence changes them. A duplicate or historical issue without accepted UAC can support retrieval only, not an AC.
- For hierarchy-selection counts, derive the expected selected set and count from the current fixture. Test a cold first interaction and a repeat interaction; later self-recovery cannot hide an initial mismatch. Do not import a historical count, content-type list, or root-cause theory.
- For Explorer sorting, keep display label, sort key, sort direction, persisted preference, and feature-flag state separate. Use only the interaction and defaults shown by current accepted UAC or inspected design/runtime evidence. A static image cannot establish hidden menu behavior, precedence, persistence, collation, or accessibility state; expose those missing decisions instead of copying an historical design.
- For asset CRUD API requests, keep filename, path, product identity, version identity, and response identity independent. Discover the current endpoints, fields, defaults, and existing/missing-target behavior from the target handler and approved contract. Keep CREATE/READ/UPDATE/DELETE controls separate even when names look similar. Never import a legacy endpoint or parameter from a historical example; unresolved payload, collision, atomicity, status, retry, and file-type decisions become Open Questions.

## Lifecycle

### Phase 0 — Run Evidence Preflight And Classify Stage

- Before drafting, check `product_rag`, `jira_history`, `live_jira`, `git`, and `figma` exactly as defined in `references/evidence-preflight.md`; record all five results in `evidence_preflight` with a timezone-aware timestamp.
- Do not label a source available because its MCP, credentials, endpoint, or clone is configured. `available` requires a successful lightweight call or inspected evidence; `not_applicable` requires a lifecycle/input reason.
- Enter `degraded` mode whenever any required check is unavailable. Continue with supported work, but apply the source-specific claim restrictions and lifecycle-aware readiness impact instead of inventing facts or blocking unrelated claims.
- Start `Evidence boundary:` with `Evidence mode: full` or `Evidence mode: degraded`. In degraded mode, name every unavailable source and state what remains unverified.
- Classify the lifecycle stage before applying evidence gates:
  - `Pre-Development UAC`: acceptance criteria are being created or refined and development has not started.
  - `Implementation Review`: a branch, commit, PR, patch, or active implementation exists and code-impact review is required.
  - `Post-Fix Validation`: a candidate fix/build exists and QA sign-off or regression validation is required.
- Classify the input source: Jira, Dynamics/support case, customer escalation, logs, screenshots, investigation notes, PR, branch/commit, pasted diff, Figma, local clones, or a combination.
- Infer `Pre-Development UAC` when the user states that UAC is not final, development has not started, or no code change exists. In this stage, missing PR, changed files, and line counts are `Not applicable`, not Draft blockers.
- Treat operational incidents as valid pre-development inputs when they include customer context, symptoms, logs, investigation findings, recovery actions, similar incidents, and an end goal. Normalize these facts into an acceptance contract and targeted open questions.
- If the stage is unclear, infer it from explicit evidence and state the assumption under `Scope From Git`; ask only when the distinction materially changes the plan.
- Keep a pre-development plan Draft only for missing sign-off-critical UAC decisions, unsupported expected behaviour, missing required product-clone evidence, or unresolved environment/test-data constraints—not merely because implementation does not exist.

### Phase 1 — Collect Issue Facts

- Use connected Jira MCP first for a Jira-backed request whenever available; otherwise use pasted Jira, Dynamics, support-case, customer-escalation, logs, screenshots, and investigation details and identify the source.
- When the user supplies a concrete Jira key, fetch that issue before drafting the plan. Do not silently describe the source as pasted text, and do not continue from historical RAG as though it were the live issue. If Jira MCP cannot fetch the key, state the exact Jira evidence failure; use pasted issue content only when the user supplied it.
- Treat placeholders such as `GUIDES-XXXXX` as missing input, not as a real Jira key. Ask for the actual key instead of producing a Jira-backed plan.
- Extract summary, description, expected/actual behaviour, acceptance criteria/UAC, customer and business impact, environment, product/version, logs, error text, affected assets/workflows, actions already taken, requested engineering help, attachments, linked issues, and development links when present.
- Resolve customer context from explicit Jira customer/account fields first, then customer-identifying labels. Preserve multiple customers separately, surface material field/label conflicts, and never infer a customer from reporter identity, email, IMS Org ID, or incidental description text.
- Do not stop at attachment filenames. List every attachment (Jira MCP `list_attachments`), then download and actually analyse each one that could carry evidence: `download_attachment` to a scratchpad path, then Read images/screenshots visually, open logs/HAR/stack traces as text, and inspect sample DITA/maps/zips. Extract concrete facts a QA plan can assert — exact property values and identifier formats (for example `GUID-<uuid>-en`), how a symptom actually renders in the UI (for example an orphan shown as an empty value between commas), affected columns/fields, enum values, error strings, timestamps, and counts.
- Also mine content embedded in the description and comments, not just prose: inline log/stack-trace snippets, code or JSON/XML blocks, tables, `{noformat}`/`{code}` regions, and pasted images. Treat these embedded snippets as first-class evidence alongside attachments.
- Label each such fact by provenance (for example "verified from the attached screenshot") and prefer it over inference; when the plan would otherwise say "matches the attached screenshot", the screenshot must have been opened, not merely listed. If an attachment cannot be fetched or opened, say so explicitly rather than describing its contents.
- Treat supplied UAC as authoritative. When UAC does not exist, derive a proposed acceptance contract from the problem statement and end goal, label every derived criterion `[Proposed]`, label Jira criteria `[Confirmed]`, and do not pretend proposed criteria are already approved.
- Historical observations, completed cleanup steps, support comments, and previously successful recovery are evidence for `Expected Behaviour` or `Incident recovery validation`; they are not Jira-authored AC and must not receive `[Confirmed]` when the native Jira/UAC acceptance field is empty.
- Do not convert a working-as-designed complaint into Confirmed AC. Preserve the current surface-specific behavior as a non-fix historical decision, and label any requested harmonization or taxonomy change `[Proposed]` until a new enhancement Jira supplies accepted UAC.
- Do not treat a configuration-gated control as removed or deprecated merely because it is hidden by default. Verify the exact configuration key/value and default, distinguish product changes from documentation or automation-only work, and never create `[Confirmed]` AC when Jira says `UAC Not Required`.
- Product-fix chronology without accepted UAC remains candidate regression evidence. Explicit `fixed in develop`, merged/cherry-picked hotfix, and exact build-verification comments may prove that code changed and named builds were exercised, but they do not supply an accepted behavior contract or root cause. Keep all derived ACs `[Proposed]`, preserve the exact release/build boundaries, and do not mark the history as a verified reusable fix until the behavior contract, RCA, and QA oracle are all explicit.
- Preserve contradictory automation labels such as `Automated` and `Won't_Automate` as an evidence conflict. Inspect linked automation or ask which label is current; never guess the coverage verdict from either label alone.
- Respect investigation chronology. Text using `could`, `may`, `seems`, `hypothesis`, `to confirm`, or equivalent language is not a confirmed root cause; a later explicit confirmation or invalidation outranks it. Keep disproved theories as negated context and never reuse them as RCA, expected behaviour, or Confirmed AC.
- Do not equate `Resolution: Fixed` with a verified product-code fix. Inspect final comments and implementation evidence. When a Jira is explicitly closed through a workaround, configuration migration, or documentation follow-up with no product change, classify it as non-product historical risk, never as `implemented_fix`, `[Confirmed]` AC, or current expected behaviour. A later explicit merged or build-verified product fix may override an earlier workaround.
- Never merge a mainline accepted UAC into a hotfix ticket when final Jira evidence explicitly narrows the hotfix. Preserve the release/build boundary, reuse only the stated point-fix behavior for that hotfix, and keep the broader mainline contract as candidate context.
- Collapse repeated identical UAC blocks deterministically before assigning source IDs; duplicate pasted criteria must not create duplicate ACs, scenarios, evidence weight, or coverage credit.
- Treat `Automation` sections and automation-PR notes as execution context, not product acceptance clauses. They can prove coverage or expose gaps, but cannot broaden accepted behavior.
- Incident workload observations are not performance SLAs. A repository size, file count, observed duration, 503, CPU/memory spike, or crash proves performance relevance, but pass/fail thresholds require an approved workload, environment, repetitions, percentile, timeout, and resource ceiling. When accepted UAC says no performance change and supplies no threshold, set `performance_contract_complete=false` and ask for the missing oracle instead of inventing one.
- Do not invent AC, comments, customer impact, linked PRs, or related Jira keys.
- Assign stable IDs (`AC-01`, `AC-02`, ...) to every acceptance criterion. Write each criterion as an independently testable product contract containing input or precondition, behavior, and observable outcome; do not write acceptance criteria as generic `Verify...` test instructions.
- Write for first-read understanding. Lead with one concrete outcome in a short sentence, use familiar QE words and the documented product name, and place required cases in short sub-points. Do not force setup, action and result into one long sentence. Move implementation jargon to a `Note for developer:` without removing source-required identifiers. Follow `references/plain-language-ac-writing.md` for loss-less grouping and terminology. Outcomes over 28 words or two sentences require review; only grossly long outcomes hard-fail.
- Evaluating an existing or AI-supplied AC/UAC set must construct the same evidence manifest and run the full `run_gates.py` pipeline. Never return a conversational-only review as if it were a gated evaluation.
- Preserve human reviewer wording as the semantic baseline. Simplify structure without changing its actor, scope, UI label, timing, fallback, exact path, or outcome. If current code conflicts, keep the requirement Proposed and expose the conflict as an Open Question instead of substituting the implementation behavior.
- Never reference another AC ID inside Given, When, or Then. Repeat the short observable rule or split the criteria so every AC is independently readable and testable.
- Split compound requirements when their required behavior or outcomes differ. Independent failure of two test cases alone does not require two ACs. Preserve every named enum, mode, project type, provider, state, filter, version boundary, and failure outcome as a distinct contract or an explicit same-outcome matrix within one AC; never hide differing fallback, timing, ordering or permission rules.
- Convert unclear AC into tester-readable product contracts and keep ambiguity visible. Never infer defaults for omitted filters, duplicate handling, reference classification, rollback, response codes, or status semantics; move undecided behavior to `Open Questions`.
- AC decidability is a hard gate. Reject unresolved/conditional markers (`to be agreed`, `pending scope`, `if approved`), vague bounds (`bounded`, `reasonable`, `does not continue forever`) without a numeric/configured/source-backed oracle, implementation-choice menus (`via an index, keyset, or custom index`), and combined terminal outcomes (`failed or aborted`). Define success, failure, cancellation, shutdown, retry exhaustion, and recovery separately when applicable. A number elsewhere in the sentence does not quantify an unrelated bound.
- Transcribe every reporter-numbered or bulleted requirement into `enumerated_requirements` schema `aem-guides-enumerated-requirements-v1`, preserving source order and count. Each `REQ-##` maps to real `ac_refs`, one real `open_question_ref`, or an explicit out-of-scope reason. Independently pass/fail items may share an AC only with a concrete `shared_contract_justification`; list omission and unknown references are hard failures.

#### Source Requirement Fidelity Gate

- Whenever `enumerated_requirements.active=true`, populate `source_requirement_ledger` using schema `aem-guides-source-requirement-ledger-v1`. This requirement applies even when `accepted_uac_present=false`; acceptance authority and semantic fidelity are separate decisions.
- Record each source as a stable `SRC-##` object with `type`, durable `locator`, exact `raw_text`, and the lowercase SHA-256 of that UTF-8 text. Do not normalize, summarize, or reconstruct the raw source before hashing it.
- Record one ordered ledger item for every enumerated `REQ-##`. Its `verbatim_text` must be an exact substring of the cited source; its `text` must exactly equal `verbatim_text` and the corresponding enumerated text. The source index, disposition, and AC/Open Question mapping must also match the enumerated item exactly.
- Give every ledger item an independent `authority` of `Proposed` or `Confirmed` and a non-empty set of semantic atoms. Authority controls status elsewhere; it never disables the fidelity check.
- For every atom, copy `text` as an exact substring of the item's `verbatim_text`, then declare `required_terms_all` and/or `required_terms_any` that must survive in the mapped AC or Open Question. Do not replace user-level, per-user, role, scope, timing, fallback, surface, upgrade, configuration, or other source semantics with an implementation observation.
- Preserve exact paths, URLs, backticked names, code-like identifiers, config keys, and any additional `protected_exact` values from the verbatim source in the mapped AC/Open Question. A shortened label or generic phrase is not equivalent to an exact identifier.
- When implementation evidence conflicts with a source atom, do not silently substitute the implementation behavior. Mark that atom `evidence_conflict=true`, map it to a real `open_question_ref`, and preserve the conflicting atom and protected identifiers in that question. Resolve the source contract before sign-off.

#### Accepted UAC Fidelity Gate

- When Jira or the user supplies final accepted UAC, normalize it instead of independently redesigning it. Preserve 100% of its semantic contract: scope, prerequisites, trigger, expected outcome, ordering, formatting, defaults, exact config names and values, parity targets, and out-of-scope boundaries.
- Assign internal source IDs (`UAC-01`, `UAC-02`, ...) to every accepted in-scope clause and (`OOS-01`, `OOS-02`, ...) to every out-of-scope clause. Require bidirectional traceability: every accepted in-scope clause maps to at least one `[Confirmed]` AC, and every `[Confirmed]` AC maps back only to accepted clauses.
- Splitting a compound accepted clause into atomic ACs is allowed; weakening it, broadening it, replacing its oracle, or adding a more specific outcome is not. Preserve exact identifiers such as feature flags, preset arguments, fields, enums, output names, and ordering rules.
- Treat the newest accepted UAC as higher authority than earlier draft ACs, linked test tickets, RAG, historical Jira, comments, or an earlier generated plan. Keep useful extra coverage `[Proposed]`; never use it to silently change a `[Confirmed]` outcome.
- When the native acceptance field is empty, a Jira comment may supply Confirmed UAC only when the issue has an accepted-UAC label and the comment explicitly declares a final/accepted `Scope:` or says the ticket scope is limited to named behavior. Use the chronologically latest such comment, record `jira_comment_accepted_scope`, keep earlier scope proposals as chronology context, and never promote arbitrary discussion, a pending-scope comment, or any comment when Jira says `UAC Not Required`.
- When accepted UAC says behaviour must match another surface such as AEM Sites, use that surface as the comparison oracle. Compare the accepted dimensions explicitly: entry presence, visible text, order, formatting, clickability, and destination. Do not invent a more specific result until the reference output has been inspected or Jira states it.
- When behaviour requires independent controls, such as a server feature flag plus an output-preset argument, keep them separate and cover the configuration truth table. Do not substitute one control for the other or claim the feature is enabled when only one prerequisite is present.
- Do not turn out-of-scope outputs or behaviours into sign-off ACs. They may appear only as a clearly non-blocking boundary confirmation when needed; a known intentional difference must never be reported as a failure.
- Record the internal comparison in the evidence manifest under `uac_fidelity` using schema `aem-guides-uac-fidelity-v1`. Set `accepted_uac_present=true`, map every accepted clause, list unresolved clauses, contradictions, and scope expansions, and mark `status=pass` only when all accepted clauses are covered with no unresolved clause, contradiction, or expansion. Keep this audit out of the visible test-plan sections.
- Set `accepted_uac_present=false` explicitly when no accepted UAC exists; then omit `uac_fidelity` and keep every AC `[Proposed]`. `Needs_Human_Review`, implementation evidence, a posted draft, or user interest in a behavior does not convert it to `[Confirmed]`. Actual plan statuses must exactly match the fidelity manifest.

### Phase 2 — Normalize Behaviour

- Before summarization, build `contract_facts` schema `aem-guides-contract-facts-v1`. Preserve literal source wording for direct expected behavior, scope, product/output/preset, DITA-OT state, deployment/version, feature state, exact labels/defaults/values/status/colors/counts/limits, human terminology, compatibility, negative requirements, and human/engineering questions. Every material fact must land in an AC, Open Question, explicit scope/out-of-scope record, or a justified non-contract disposition. `contract_integrity_gate.py` fails when a protected term or outcome disappears from the visible plan.
- Route the issue with `issue_domains` schema `aem-guides-issue-domains-v1`; never select a Jira-specific prompt. Classify only positive, in-scope source clauses: ignore negated, unaffected, not-applicable, and structured out-of-scope values. Recognize normal inflections/plurals and treat an explicit thousand-scale workload as a performance-risk route, not as an invented SLA. Active `PUBLISHING` requires `publishing_scope`; it requires `generated_output_contract` only when source evidence places generated artifact content, structure, or delivery in scope. Publishing configuration alone never implies a download/delivery contract. Active `ASSETS` requires `content_identity_contract`. Resolve exact preset/output ownership, `Enable DITA-OT Processing` as `ON`/`OFF`/`BOTH`/`NOT_APPLICABLE`/`UNRESOLVED`, deployment, in/out of scope, and shared-path outputs. When generated delivery is in scope, record `delivery_in_scope=true`, its real surface, and a covered `DELIVERY_AVAILABLE` product oracle; when it is out of scope or unresolved, disposition that oracle accordingly. Unresolved fields become Open Questions; do not silently test every output type.
- Build `behavior_graph` schema `aem-guides-behavior-graph-v1`. Each node and typed edge cites an ID in the canonical source/evidence registry. Each edge records a subject and an authority allowed by that subject's policy, plus currentness, applicability, confidence, verification state, and materiality. Inferred edges are investigation candidates only. Traverse a bounded code/semantic neighborhood and record readers, writers, callers, consumers, configuration, generated artifacts, shared processors, error paths, persisted state, and downstream decision consumers.
- Complete `semantic_closure` schema `aem-guides-semantic-closure-v1` for every material graph entity. Every canonical dimension must be explicitly `APPLICABLE`, `NOT_APPLICABLE`, or `UNRESOLVED`, then end as `COVERED`, `INVESTIGATED_AND_REJECTED`, or `UNRESOLVED_AND_EXPOSED`. Do not use wildcard entity references: every closure decision must name the evidence-bound material entity it covers. Omission is not equivalent to not applicable.
- Every material unresolved fact, edge, or closure record automatically requires a linked `missing_questions` record with subject-specific preferred sources, an `OQ-##` destination, and a genuinely new linked second-pass query in `evidence_lifecycle`. Every USED/REJECTED evidence record links to a declared question or hypothesis. A verification may cite only USED evidence bound to that same hypothesis and subject; every claimed authority must be carried by that cited evidence. No retrieval result remains unresolved; it is never treated as `REJECTED` by absence.
- Route every accepted material question through mandatory research routing before coverage finalizes it (Question Planner -> Research Requirement Classification -> Doc/Code/Historical research -> Question Resolver -> Coverage Reasoner -> Writer -> Reviewer). Classify `research_requirement` (`NONE`, `DOCUMENTATION`, `IMPLEMENTATION`, `HISTORICAL`, `DOCUMENTATION_AND_IMPLEMENTATION`, `MULTI_SOURCE`) from the question's declared evidence path immediately after question planning, execute the mandated research, and record `research_status` (`NOT_REQUIRED`, `PENDING`, `ANSWER_FOUND`, `PARTIAL`, `NOT_FOUND`, `SOURCE_UNAVAILABLE`, `CONFLICTED`, `NOT_APPLICABLE`) with the request/evidence links in the `question_research` manifest block, enforced by `scripts/question_research.py` (see `references/question-research-routing.md`). Hard gate: a material question whose requirement is not `NONE` and whose status is still `PENDING` fails review, and Coverage must not finalize it from the current Jira/configuration evidence alone; the Writer never compensates for missing research. `NOT_FOUND` means the mandated research executed and found no answer - it never asserts the opposite behavior. An explicit Human Accepted AC classifies `NONE`/`NOT_REQUIRED` and proceeds on Jira authority without unnecessary documentation research. The canonical runtime enforces the same contract in its `ResearchRequirementClassifier` stage.
- Keep "documented today" separate from "required after this fix" (enforced by `scripts/behavior_classification.py`; see `references/behavior-classification.md`). Existing documentation establishes baseline/current behavior; the current ticket establishes desired new behavior. Classify every resolved behavior as `EXISTING_CONFIRMED`, `NEW_REQUIREMENT`, `MODIFIED_EXISTING_BEHAVIOR`, `PRESERVED_EXISTING_BEHAVIOR`, `UNKNOWN`, or `CONFLICTED` in the `behavior_classification` manifest block. Never use existing documentation to claim a new feature is already documented, never describe new implementation/configuration as historical documented behavior, name the existing behavior that must remain compatible (`PRESERVED_EXISTING_BEHAVIOR`), and combine sources in an AC's `Evidence:` line only when each source genuinely supports part of that AC - a source line never credits a documentation source for behavior that documentation does not establish. `UNKNOWN`/`CONFLICTED` behaviors stay open questions until resolved.
- Disposition every material contract fact, graph item, closure record, generated-output oracle, and content-identity lifecycle state exactly once. Run `acceptance_promotion.py` separately from hypothesis verification: code, PR, runtime, tests, history, or inference may establish actual implementation but cannot alone authorize intended product behavior. A candidate and visible AC may each be promoted at most once; candidate, subject, authority, disposition, mapped AC, and visible Confirmed/Proposed status must all agree. Every visible AC must have a subject-authorized promotion record; regression, implementation mechanics, unsupported exact values, and unresolved decisions cannot promote.
- Convert Jira text into current behaviour, expected behaviour, affected workflow, data shape, error contract, version boundary, configuration boundary, roles/permissions, user impact, and open questions.
- Build an integration impact map: direct workflow, upstream callers, downstream outputs, shared components/APIs, configs, roles/permissions, environment matrix, test-data fixtures, and automation suites likely affected.
- Derive edge cases from UAC boundaries, inspected PR branches, API contracts, config permutations, old automation failures, and past similar tickets.
- When a configuration defines a set of supported UI entries, do not test only the entries visible in the supplied environment. Include a newly added valid entry and use `references/configuration-driven-enumerations.md` to separate membership discovery, friendly/display-name mapping, unmapped fallback, active schema/profile applicability, supported reload timing, preservation of existing entries, and invalid or duplicate configuration behavior. Inspect every consumer for hardcoded arrays, enums, switches, and default maps that can silently exclude future entries.
- Complete the internal principal-performance-QA review from `references/performance-assessment-contract.md`: assess all seven scale, concurrency, duration, latency/throughput, resource, dependency/queue, and stale-state categories using Jira, attachments/logs, exact docs, same-mechanism history, and inspected code. Store only the structured decision and provenance in the evidence manifest; do not add a Performance Analysis section or standalone plan bullet.
- Use exactly one performance decision. `required` emits one or more evidence-backed `(Performance)` ACs with a quantified workload and numeric or source-backed comparative metric oracle plus mapped performance scenarios. A retained same-mechanism or inspected shared-execution-path historical contract with a quantified workload/oracle also forces `required`; never leave it only under Regression Areas. `conditional` emits no Performance AC and instead adds one QA-impact Open Question for the missing workload/SLA/baseline. `not_required` emits no Performance AC and no reader-facing filler. Never invent a threshold from an approximate customer observation.
- Cite every retained historical performance Jira in the visible Performance AC `Evidence` field. An unrelated Performance AC or generic load scenario cannot satisfy a retained same-mechanism contract.
- Label inferred ownership, impacted code, or workflow assumptions as inferred unless PR/repo evidence confirms them.
- Build focused search intents before retrieval: exact failure/API/config/UI label, expected workflow, boundary/config/version, and regression/automation coverage.
- In `Known Jira Bugs / Past Similar Tickets`, retain full status/RCA/version provenance only in the durable artifact. The compact UI reduces each validated entry to Jira key, title, and one reason it is worth checking.
- In `Automation Coverage & Gaps`, map every AC to direct inspected evidence and decide whether the main feature is Covered, Partially covered, Not covered, or Unverified. The compact UI exposes only that main-feature verdict and high-level guidance for the relevant UI feature file or backend integration/IT test; never invent an exact test path that was not inspected.

#### Operational Incident And Recovery UAC Rules

- Use these rules for Dynamics/support incidents, production escalations, stuck jobs, queue blockage, workflow failures, cleanup requests, performance degradation, concurrency failures, and customer-restoration plans.
- Populate `operational_contract` schema `aem-guides-operational-contract-v1`. Strong job/queue/retry/restart/partial-write signals require `active=true`; `active=false` cannot bypass detected signals. Disposition every dimension to real AC, stable `TS-##` scenario, stable `OQ-##`, or a concrete out-of-scope reason.
- Separate immediate remediation from permanent product behavior: backend cleanup, service restoration, workflow/config correction, code safeguard, resource change, and automation must each have explicit in-scope or out-of-scope status.
- Do not turn a destructive operational procedure into a product acceptance criterion. Node deletion, workflow termination, pod restart, manual queue repair, and similar one-time engineering actions belong under `Test Scenarios` as an `Incident recovery validation` bullet; acceptance criteria may state only the observable restoration or permanent product contract.
- For mixed-lifecycle incidents, distinguish `Incident recovery validation` from the pre-development product UAC. A closed incident or successful cleanup does not confirm that a proposed concurrency, retry, cancellation, queue, or status-consistency safeguard has been implemented.
- Convert the end goal into proposed acceptance criteria, but keep unapproved engineering choices visible as open questions rather than presenting them as decided UAC.
- Define the exact affected output type, workflow, environment/build, target paths, job IDs/UUIDs, queue states, customer-like fixture size, and normal-versus-failure timing baseline.
- Require terminal-state contracts for success, failure, cancel, retry exhaustion, and recovery; define the maximum allowed duration for Waiting, Executing, Post Publishing, cancellation requested, or equivalent states.
- Enumerate failure points across acquisition, query construction/execution, result iteration, item mutation/delete, save/commit, refresh/cleanup, and result reporting when those phases exist. Define retryable versus terminal categories, maximum attempts, delay/backoff source, short-circuit rule, exhausted outcome, and aggregate logging bound across all attempts.
- Keep scheduler/deployment trigger, queue-level retry, and an in-run loop as distinct recurrence sources. Cover every caller/producer path, environment/build, individual-item action, and bulk/profile action that evidence places in scope.
- Define concurrency behavior for same map, same preset, same destination, overlapping destinations, and unrelated destinations: serialize, lock, retry, fail fast, or isolate.
- Define snapshot behavior for source additions, deletions, renames, and updates during paging/traversal; specify the observable no-skip/no-duplicate/output-integrity oracle without prescribing a cursor implementation unless accepted UAC does.
- Define partial-write behavior: rollback, reuse, overwrite, cleanup, idempotent retry, duplicate prevention, orphan prevention, and preservation of previously valid output.
- Define queue isolation and fairness: one failed job must not indefinitely block unrelated jobs, and recovery must specify whether successors auto-resume or require manual restart.
- Define cleanup safety: exact nodes/workflows targeted, correlation evidence, backup, approval, audit trail, unrelated-state preservation, rollback, and post-cleanup verification.
- Define restart and failover behavior for author pod restart, workflow restart, deployment, timeout, network interruption, and repeated cancellation.
- Define performance and resource acceptance separately: completion SLA, dataset scale, heap/pod limits, indexing state, CPU/memory evidence, and criteria for deciding whether a resource increase is required.
- Never convert an observed customer duration, approximate normal runtime, topic count, heap recommendation, or support anecdote into a hard pass/fail oracle unless Jira/UAC, an approved SLA, or a controlled benchmark defines the dataset, environment, repetitions, percentile, and threshold. Otherwise treat it as a measured baseline or an open question.
- Define observability: required correlation IDs, job/output/workflow UUIDs, target path, stage timings, retry count, terminal reason, actionable errors, and sensitive-data redaction.
- Provide an explicit fallback value when failure happens before path/page/item context exists, and bound both per-attempt and aggregate cross-retry log volume.
- Verify the final generated output, not only DITA-OT/build success or UI status: page/file count, links, assets, metadata, navigation, history nodes, workflow completion, and absence of partial/orphan state as applicable.
- For evidence-backed publishing/export artifacts, populate every oracle in `aem-guides-generated-output-contract-v2`: artifact existence, content/title/hierarchy/order/navigation/links/metadata/repository state/output path/locale, duplicates, orphans, stale output, unchanged-content rewrites, activation state, status-versus-real-output, and conditional delivery availability. Record primary-content versus diagnostic inventory and root/hierarchy/relative-path rules. Require the real download surface and cover `DELIVERY_AVAILABLE` only when `delivery_in_scope=true`; mark it not applicable when false or expose an Open Question when unresolved. An archive that contains only logs or merely exists is not a sufficient product oracle.
- Inspect product clones using exact stack-trace classes, workflow model names, JCR paths, APIs, config keys, and error strings; inspect automation clones for timeout, polling, cancel, cleanup, concurrency, performance, and recovery gaps.
- Keep destructive production reproduction out of scope unless explicitly approved; prefer a production-equivalent clone and engineering-approved cleanup validation.

#### Translation Project API UAC Reference

- Use this UAC when scope covers an automation API that creates a translation project for a supplied DITA map and selected filters.
- Require support for project types `newTranslationProject`, `xliffTranslationProject`, `newMultiLingualTranslationProject`, `addToExistingProject`, and `newScopingTranslationProject`.
- For `latestVersion`, resolve forward references from the latest saved version of the DITA map and exclude working-copy changes.
- For `baseline`, resolve forward references exactly as they existed when the specified baseline was created.
- For `versionAsOfDate`, resolve forward references exactly as they existed at the supplied date and time.
- Cover `referenceType` values `Direct` and `Indirect`.
- Cover `fileType` values `Map`, `Topic`, and `Others`.
- Cover `documentState` values `Draft`, `In-Review`, and `Reviewed`.
- Cover `translationStatus` values `Out of Date`, `In Progress`, `In Sync`, `Out of Sync`, and `Missing copy`.
- Require the API request to accept the DITA map, project title, project type, language list, version selection and required version value, and selected filters.
- Verify the API creates missing target-language folders before creating or updating the translation project.
- Derive positive, negative, boundary, filter-combination, version-resolution, missing-language-folder, permissions, idempotency, validation, error-contract, and automation-consumability scenarios from this UAC.
- Keep unspecified API details as open questions, including endpoint and method, request/response schema, baseline identifier format, date/time zone and inclusivity, filter combination semantics, existing-project identifier, duplicate project-title behavior, partial-failure rollback, folder naming/location, and permissions.

#### EDS GitHub And GitLab Publishing Profile UAC Reference

- Use this UAC when scope covers creating or using EDS Publishing Profiles with GitHub or GitLab repositories.
- Support GitHub Cloud public/private, GitLab Cloud public/private, self-hosted GitHub Enterprise, and self-hosted GitLab repositories.
- Provide a `Git Provider` selector with GitHub and GitLab options, dynamically update provider-specific UI fields, and default the server URL to the self-hosted GitLab URL when GitLab is selected.
- Enforce mandatory-field validation and enable `Save` only after all required fields are present and authentication succeeds; never persist an unauthenticated profile.
- Support OAuth authentication for both providers using Client ID, Client Secret, and token exchange.
- Show clear errors for invalid repository details or credentials, expired/revoked tokens, insufficient or read-only permissions, authentication failures, network interruption, API timeout, and server failure.
- Prevent publishing when authentication fails or repository permissions are insufficient.
- Verify `Push to Live` commits and pushes content to the configured repository and branch for both providers, while preserving the existing EDS workflow and downstream EDS pipeline trigger.
- Verify Publishing Profile APIs behave consistently for GitHub and GitLab.
- Preserve backward compatibility for existing GitHub publishing profiles, Push to Live, APIs, logging, upgrades, and all supported AEM Guides Cloud versions.
- Preserve existing publishing profiles during upgrades and confirm no impact to Salesforce publishing.
- Verify the required AEM Admin suffix configuration change from `HTML` to `HTM`; keep the exact setting, scope, default, and upgrade behavior as open questions when Jira does not define them.
- Verify supported content publishes through both providers without content loss or formatting issues, including DITA topics, DITAMAPs, Bookmaps, Markdown, images, multimedia, MathML, tables, code blocks, cross-references, keyrefs, conrefs, conditional content, multilingual content, and other supported assets.
- Require logging for authentication, token exchange, publishing, commit creation, push operations, API failures, and retries when applicable.
- Verify Client Secret, Access Token, and OAuth Token values are never logged, exposed in UI errors, or returned through unsafe API responses.
- Derive positive, negative, provider/platform matrix, public/private repository, permission, authentication lifecycle, UI-state, API-contract, upgrade, logging/redaction, retry, pipeline-trigger, content-fidelity, and regression scenarios from this UAC.
- Keep unspecified details as open questions, including exact OAuth grant/token-exchange flow, redirect URI, scopes, token storage/refresh, provider-specific required fields, self-hosted TLS/proxy requirements, GitLab default URL behavior, branch protections, retry policy, rollback after partial commit/push failure, supported file-size limits, and the supported AEM Guides Cloud version matrix.

### Phase 3 — Retrieve Behaviour RAG

- Call `ask_dita_expert` with focused questions from normalized behaviour, not raw keyword spam.
- Run at least three focused RAG probes when behaviour matters: exact API/config/UI/construct terms, expected workflow, and regression/config/version boundary. This is mandatory and front-loaded - do not write the plan until the three probes have run. A single probe that returns noise or off-topic chunks is NOT "RAG unavailable": reformulate with different exact terms and retry to at least three attempts before concluding the behaviour is undocumented, and never let one weak probe stand in for the set.
- Record product-documentation retrieval separately in the evidence manifest as `"rag_tool": "ask_dita_expert"` and a `rag_probes` list containing the exact questions asked; `verify_evidence.py` fails when fewer than three are recorded unless `behaviour_matters` is false and `behaviour_not_applicable_reason` is supplied. Never put Jira-history queries in `rag_probes`. Fold every grounded finding into `Expected Behaviour` with a `RAG` provenance label; a probe that returns nothing still counts, but state plainly what was and was not found.
- Use RAG to ground expected behaviour, workflow rules, product constraints, release-note behaviour, configuration effects, and regression areas.
- If RAG conflicts with Jira/UAC, PR implementation, or Figma design intent, keep Jira/UAC primary and surface the conflict instead of hiding it.
- Prefer latest matching release docs or current Experience League pages over older release notes when both describe the same behaviour; use older release notes only for version-specific upgrade/history claims.
- Reject chunks that only share broad vocabulary such as `topic`, `map`, `assets`, `metadata`, `cloud`, `report`, `translation`, or `workflow` without proving the actual behaviour.
- Never use attribute-only DITA evidence as proof for an exact element behaviour, or generic DITA docs as proof for AEM Guides UI behaviour.
- If RAG is unavailable, noisy, or unrelated, state that evidence status under `Expected Behaviour` or `Regression Areas`. Add a Draft blocker only when the affected behaviour is not already supported by the acceptance contract, exact logs, verified current implementation, design evidence, or another authoritative source.

### Phase 4 — Find Past Similar Tickets

- Use the app's indexed Jira learning retrieval (`jira_qa`) when available, then use Jira MCP/JQL to validate current status, links, comments, and any facts that may have changed. If indexed retrieval is unavailable, use Jira MCP/JQL; otherwise use only user-provided related tickets or available team memory.
- When Jira identifies a customer, query the matching `customer_jira_profile` with current-issue component, workflow/output, and failure-signature terms. Treat profile frequencies as aggregate regression guidance, not usage telemetry or direct product-behaviour proof.
- Querying the indexed `jira_qa` history of already-fixed tickets is a mandatory Phase-4 step, not optional, and must run before writing Known Jira Bugs. Record `"jira_history_tool": "search_jira_history"`, `"indexed_history_run": true`, and a `jira_history_queries` list with both `same_customer` and `cross_customer` entries containing the exact query, component, and customer where applicable. If the tool is unavailable, record an empty query list, `jira_history_unavailable_reason`, and the fallback reason in `indexed_history_run`. The indexed corpus holds past fixed tickets by area and customer, not test data or a live customer inventory; validate status, resolution, and fix version live before citing.
- Record the outcome of every live, offline, JQL, empty, or unavailable history search in `history_attempts`. A record contains non-empty `source` and `query`, `result` as `ok`, `empty`, or `unavailable`, and a non-negative integer `count`. A thin or empty Known Jira Bugs section is valid only when an attempt explicitly records `empty` or `unavailable`; never leave the search outcome implicit.
- Treat the `component` argument to `search_jira_history` as a strict Chroma filter over normalized scalar `component_primary` metadata. Use exactly one canonical Jira value: `Editor`, `Authoring`, `Publishing`, `Platform`, `Schematron`, or `Integration`; never combine `Platform` and `Integration`. If a broader second pass is needed, intentionally omit the component and label any retained result as cross-component instead of presenting it as a same-component match.
- Prefer `learning_behavior_chunk`, acceptance-criteria, resolution/RCA, and test-evidence hits over summary-only matches when their structural evidence is comparable.
- Preserve each learning hit's confidence, historical outcome, verified-fix flag, behavior contract, root cause, QA oracle, and regression risks. A `caution` or non-fix outcome is a risk signal only and must never define current expected behavior.
- Reuse a historical behavior contract or QA oracle only when the outcome is an implemented fix and confidence is `medium` or `high`; keep current Jira/UAC authoritative.
- Search with multiple narrow JQL passes by exact Jira key links, exact error text, API route, config key, workflow, UI label, data shape, version boundary, and likely code area.
- Keep at most five past tickets. For each, explain why similar and what coverage it adds.
- Rank candidates by shared defect mechanism, not by shared feature area, subsystem name, or overlapping keywords. A ticket qualifies only when it exhibits the same failure shape (for example the same stale-reference-after-delete, same orphan-reference, same not-cleaned-up-on-lifecycle-change, same API-contract, or same root-cause family) as the issue under test. Sharing a module name (for example "version purge", "map console", "translation") or a generic word (for example "cleanup", "reference", "btree", "report") is not similarity and must not, by itself, place a ticket in this section.
- State each entry's match strength explicitly (for example strongest match, structural twin, adjacent, or weak/setup-only) and name the concrete shared mechanism. If a ticket is only regression-adjacent rather than the same defect class, put it under `Regression Areas`, not here.
- Prefer four sharply-matched tickets, or fewer, over five where the last one or two are padding. It is correct to list only one or two genuinely similar tickets, or to state that no same-defect-class history exists, rather than filling to five with area-only or keyword-only matches.
- Include both resolved historical bugs that provide reusable RCA/test oracles and open known bugs that can affect execution, expected results, environment choice, or sign-off. Validate current status with Jira MCP before calling a bug open, closed, fixed, duplicated, deferred, or regressed.
- For each selected Jira bug, capture the key, similarity reason, current status/resolution, affected/fix version when available, historical root cause or behavior contract, reusable test evidence, and the exact scenario or regression area it changes. Do not expose raw retrieval scores.
- Record the actual JQL/search intents used and whether each historical fact came from current Jira fields, comments, linked test evidence, or indexed history. Write `not available in current evidence` for missing fix versions, affected versions, RCA, or test evidence; never silently omit those fields or infer them from ticket status.
- Reject broad results that match only generic words, a shared feature/subsystem area, or unrelated automation-bulk tickets; if only noisy matches exist, say historical evidence is unavailable instead of padding the section. Before listing any ticket, name the one specific defect mechanism it shares with the issue under test; if that sentence would only cite a shared area or keyword, drop the ticket.
- Exclude by default any candidate whose feature or component differs from the issue under test. Broad text JQL (for example `text ~ "parent map"`, `orphan`, `reference not cleaned`) will surface cross-feature tickets such as version-purge, map-collection, or translation bugs; treat every such hit as a candidate to DISPROVE, and include it only if you can concretely show the same code path, property, or failure - never on a shared symptom word like "parent map", "orphan", "cleanup", or "reference". When in doubt, leave it out and note in the search-status line that it was surfaced and excluded.
- Do not name-drop a Jira key anywhere else in the plan (especially `Regression Areas`) unless that key is vetted and listed in `Known Jira Bugs / Past Similar Tickets`. Reference a regression risk by its workflow, code path, or automation (for example a specific IT class), not by an unrelated ticket number. The validator fails any Regression Areas Jira key that is absent from Known Jira Bugs.
- Re-audit the whole list, not just newly-flagged tickets, every time you apply the exclude-by-default rule. A ticket added earlier is never grandfathered in; if it survives only on an abstract shape (for example "a deleted thing is not auto-removed from its container") across a different feature, entity, and code path, remove it too. Apply the same test to same-domain-but-different-target tickets (for example orphan Site pages vs a JCR parent-map property): shared domain is not shared mechanism.
- Do not keep a cross-feature or different-surface ticket by relabelling it "adjacent" and listing it as a past similar ticket. If a ticket is not a same-defect-class match, exclude it and record it in the search-status note; when it still carries reusable value, cite it where that value lives (automation setup under `Automation Coverage & Gaps`, or a triage caution under `Open Questions`), not as a similar bug. It is correct for `Known Jira Bugs` to state that no same-defect-class history exists and list only the excluded candidates.

### Phase 4.5 — Connect Evidence Graph

- Call `query_test_evidence_graph` only after the three focused `ask_dita_expert` probes and the same-customer and cross-customer `search_jira_history` calls have completed.
- Read the packet's influence mode and default to `shadow` when it is absent. In `shadow`, record graph status, paths, leaves, and runtime only; do not change plan content, ACs, scoring, citations, repository scope, or automation verdicts.
- Query with the normalized failure shape plus the exact Jira key, customer, one canonical component, outputs, and DITA entities when known; keep traversal at two hops and no more than 20 paths unless a narrower result is insufficient.
- Retain only paths with underlying leaf citations. Reject candidate-only claims, generic fallback oracles, caution outcomes, and customer/component/domain/feature-only Jira matches.
- Use graph results to connect direct evidence and find same-mechanism risks, never to override current Jira/UAC, inspected implementation, verified Figma evidence, or direct authoritative documentation.
- Deduplicate graph citations against direct RAG and Jira results by leaf/source identifier so one source is not scored twice.
- Record the graph status, exact query, active generation ID, path IDs, and deduplicated leaf citations in the evidence manifest. A path ID is traceability metadata only.
- If graph access is disabled, unavailable, or degraded, record the reason and continue when authoritative direct evidence covers the behavior; graph unavailability alone is not a Draft blocker.
- Only in explicit `augment` mode, fold retained findings into the existing output sections. Do not add an Evidence Graph heading or expose raw graph JSON.

### FluffyJaws Supporting-Discovery (optional, mode-gated)

FluffyJaws broadens *discovery* of relevant behaviour, but it is a synthesis engine, not an authority. Use it only to widen the net for candidate dimensions and behaviours; never as evidence on its own.

- **Gate on the mode.** Read `SKILL_FLUFFYJAWS_MODE`. `FLUFFYJAWS_DISABLED` (default) => do not call FluffyJaws and claim no discoveries. Only `FLUFFYJAWS_SHADOW` or `FLUFFYJAWS_SECOND_PASS` may call it, and only when the connector is actually registered in this session. If the mode is enabled but the connector is not reachable, set `available: false` and record no discoveries (fall back to the normal RAG path).
- **Query for discovery, then re-ground.** Ask FluffyJaws focused discovery questions derived from the normalized behaviour model. For every finding it surfaces, RE-GROUND it into a first-class source that keeps its own authority (spec / DITA-OT / product doc / current code / historical Jira) before it can raise any AC's coverage. A finding that cannot be re-grounded stays an Open Question or is dropped - it never becomes an AC.
- **Record it in the manifest `fluffyjaws` block** so `fluffyjaws_evidence` can enforce the invariants: `{"mode": "FLUFFYJAWS_SHADOW|FLUFFYJAWS_SECOND_PASS", "available": true|false, "discoveries": [{"finding": "...", "authority": "SUPPORTING_DISCOVERY", "regrounded_evidence_id": "E#"}]}`. Every discovery's `authority` must be `SUPPORTING_DISCOVERY` and must name a `regrounded_evidence_id`; a discovery present while `DISABLED`/`available:false` is a hard failure.
- **Mode effect.** `FLUFFYJAWS_SHADOW` records discoveries for trace/evaluation only - the final plan stays baseline-equivalent, unchanged versus `DISABLED`. `FLUFFYJAWS_SECOND_PASS` may let a re-grounded discovery become an `INVESTIGATION_CANDIDATE` in the coverage pipeline, still `SUPPORTING_DISCOVERY` and still with no FluffyJaws -> AC path.
- **Transport note.** The connector-driven path above (this skill calling the registered FluffyJaws tool) is the supported path here. The separate backend HTTPS provider (`build_fluffyjaws_provider` with an injected authenticated transport) requires human-only setup - service-app registration, the operator-guide MCP/API schemas, and the confirmed API base per `docs/fluffyjaws_setup.md`; do not guess that transport.

### Phase 5 — Inspect Clones And Available Git Changes

- Always inspect every relevant available clone, regardless of lifecycle stage: Starling/backend, xmleditor, new editor, `guides-ui-tests`, and `dxml-it-tests`.
- Check user-provided workspace roots, environment variables, common teammate paths, and known paths such as `C:\UI TEST\guides-ui-tests` and `C:\UI TEST\dxml-it-tests` before declaring a clone unavailable.
- Synchronize every relevant clone before code or automation mining. Use `python scripts/sync_evidence_repo.py <absolute-repo-path> --stash-dirty`: it records state, fetches/prunes/tags, stashes dirty tracked and untracked developer work only after safety checks, and pulls only when the branch can fast-forward. Leave the named safety stash intact after a successful update and report its exact OID/ref plus restore command.
- If a repo is detached, diverged, lacks an upstream, has an in-progress Git operation, contains dirty submodules, or fetch/pull fails, do not reset, merge, rebase, switch branches, or force synchronization. Inspect the verified upstream/default remote ref with read-only Git commands when possible and label worktree-dependent claims provisional.
- In `Pre-Development UAC`, inspect product clones to identify the current implementation directly implicated by exact classes, workflow names, API paths, config keys, error strings, logs, or UI labels. Report these as `Current implementation implicated`, never as changed code.
- In `Pre-Development UAC`, inspect automation clones for existing happy-path, negative, concurrency, recovery, role/config, performance, and regression coverage. Missing PR/diff and line counts are `Not applicable — development has not started`.
- In `Implementation Review`, inspect the branch/commit/PR diff and capture changed files, functions/classes/components, added/deleted counts, key hunks, tests, config/migration changes, API/error contracts, and gaps. Also compare changed code with the current implementation and existing automation.
- In `Post-Fix Validation`, inspect the exact candidate-fix diff/build source and map changed branches, guards, retries, persistence, cleanup, errors, and tests to fix-safety and regression scenarios.
- Prefer connected GitHub MCP for a referenced PR. If development is expected but Jira has no PR link, search by Jira key, summary, branch, commit message, and PR body before asking for a PR.
- For every referenced or confidently discovered PR, inspect through GitHub MCP: repository, base/head branches, PR state, commits, changed files, complete diff hunks, added/deleted lines, review comments and unresolved threads when available, checks/test results, and linked Jira context. Read the implementation branches and error paths, not only filenames.
- Map each relevant PR hunk and branch to acceptance criteria, test scenarios, regression areas, logging/error behavior, permissions/configuration, persistence/cleanup, concurrency/retry, backward compatibility, and automation impact. Report unrelated or generated-file changes separately and do not inflate QA scope from them.
- If GitHub MCP is unavailable, inspect the exact PR/branch/commit from an available local clone or user-provided diff. In implementation/post-fix stages, do not claim deep PR analysis when only Jira metadata or a summary was available.
- For `guides-ui-tests` and `dxml-it-tests`, mine existing tests, skipped/flaky history, fixtures, selectors/API clients, reusable scenarios, polling/timeouts, cleanup helpers, and automation gaps.
- Before searching `guides-ui-tests`, `dxml-it-tests`, editor E2E, or any discovered automation repository, run the same guarded `sync_evidence_repo.py --stash-dirty` flow used for product clones. Do not report automation as current until fetch/pull state and the exact inspected revision are recorded; preserve dirty local automation development in a named stash with its restore command.
- Also inspect relevant editor E2E or repository-specific automation suites discovered locally or through GitHub MCP. Search by Jira key, AC terms, endpoint and request fields, UI labels, project types, enum values, config keys, workflow names, failure text, and exact implementation symbols.
- Build an AC-to-automation map internally: `Covered`, `Partially covered`, `Not covered`, or `Not suitable for automation`. For covered items, retain exact repository, file, scenario/test method, helper/fixture, layer, and revision. For gaps, recommend the correct UI/API/integration layer, reusable fixture/helper, data setup, cleanup, assertions, tags/suite, and whether a new test or extension is needed.
- Classify automation by the complete AC contract, not by feature-name similarity. A happy-path publish test does not partially cover post-cleanup recovery, concurrency safety, orphan-state cancellation, queue draining, or cross-dashboard consistency unless it creates that precondition and asserts that outcome. Use `Partially covered` only when an existing test proves a named clause of the same AC; otherwise use `Not covered` and list reusable helpers separately.
- A gap recommendation must name the exact repository and candidate test file/class/method, automation layer, reusable client/helper/fixture, deterministic failure or state-injection mechanism, data setup, polling endpoint and terminal oracle, timeout source, output-integrity assertions, cleanup/rollback, suite/tags, and whether to extend or add a test. If the repository cannot safely create the required state, say which test hook or harness capability is needed instead of prescribing manual production mutation.
- Do not claim zero automation from one repository or broad keyword search. Search every relevant discovered automation clone and GitHub automation repository before declaring a gap; distinguish missing coverage from undiscovered, stale, skipped, flaky, quarantined, or inaccessible coverage.
- Never label files as changed without a real diff. Never infer current implementation from generic Jira keywords; require exact repo matches or label the area inferred.
- If an implementation-stage diff is unavailable, add `Draft blocker: implementation diff not inspected`. Do not emit this blocker in pre-development.

### Phase 5.5 — Doc Research Routing (MANDATORY contract after Evidence)

After evidence collection and before any coverage/writing work, record the doc-research
routing decision in the manifest `doc_research` block, validated by
`scripts/doc_research_routing.py` (see `references/doc-research-routing.md`). This
enforces invocation of the existing UAC Doc Researcher role
(`agents/uac-doc-researcher.md`); it introduces no new agent and changes no source
authority.

- **Route to `DOC_RESEARCH_REQUIRED` when materially relevant**: the ticket changes
  existing documented functionality; existing behavior must be understood or preserved;
  configuration semantics are not sufficiently established by the ticket;
  product/version/surface applicability needs confirmation; backward compatibility
  materially affects acceptance; terminology materially affects behavior; the ticket's
  evidence is insufficient but authorized product documentation may answer the missing
  behavior; or the Evidence Agent explicitly requests documentation research. Declare
  the fired triggers in `doc_research.routing.triggers`. Never invoke the Doc Researcher
  merely because related documentation exists.
- **An explicit authoritative Human Accepted AC may be sufficient without research**
  when documentation would not materially change acceptance reasoning: record
  `RESEARCH_NOT_REQUIRED` with `not_required_reason`.
- **HARD GATE:** when the routing state is `DOC_RESEARCH_REQUIRED` and no terminal Doc
  Researcher result exists (`DOC_RESEARCH_COMPLETED` / `DOC_RESEARCH_PARTIAL` /
  `DOC_RESEARCH_UNAVAILABLE` / `DOC_RESEARCH_CONFLICTED`), Coverage/Writer MUST NOT
  proceed, and the gate fails the plan. The coordinator/main agent must not impersonate
  the missing Researcher — every result names `produced_by: uac-doc-researcher`.
- **Doc Researcher output contract:** `research_id`, `status`, `topics[]`, `findings[]`,
  `source_ids[]`, `applicability`, `limitations[]`, `conflicts[]`; every finding carries
  `claim`, `source_id`, `source_type`, `authority`, `applicability`, currentness/version
  when available, and `evidence_role` (`EXISTING_BEHAVIOR`, `REQUIREMENT_CLARIFICATION`,
  `SUPPORTING_CONTEXT`).
- **The Researcher must NOT** write ACs, decide final acceptance scope, override a Human
  Accepted AC, infer new behavior from old documentation, promote nearby functionality,
  or treat NOT_FOUND as evidence of the opposite behavior.
- **The Writer receives only admitted research** (`admitted_research_ids`) through the
  existing reasoning path — never arbitrary raw search results. The Reviewer fails the
  plan when required research was skipped, an AC cites documentation that was never
  retrieved, PARTIAL research is represented as complete, or documentation is used to
  support behavior it does not establish.

### Phase 6 — Inspect Figma Design Evidence

- Use Figma MCP when a design/prototype/frame is linked or when the Jira is UI-flow heavy and the user says Figma should be used.
- Learn the existing flow before writing scenarios: entry point, primary path, alternate path, empty/error/loading states, dialogs, toasts, permissions, responsive states, and component variants.
- Compare design evidence with Jira UAC, RAG product behaviour, and PR implementation; call out contradictions as Draft blockers in the affected section.
- Do not treat Figma as proof of backend/API behaviour, permissions, versioning, or persistence unless Jira/PR/RAG also supports it.
- If Figma MCP or design access is missing for a design-dependent ticket, write `Draft blocker: Figma design evidence not inspected`.

### Phase 6.5 — Discovery-First Dimension Sweep (MANDATORY before authoring)

Do this BEFORE writing a single acceptance criterion. Most misses are discovery gaps, not
writing gaps: an AC set drafted from the ticket text plus a couple of greps silently drops
a dimension a reviewer then has to add. Run the full sweep first, disposition every
dimension, and only then author.

Run every applicable probe and trace, then record the result in the manifest
`dimension_inventory` block (each dimension COVERED_BY_AC / OPEN_QUESTION / OUT_OF_SCOPE /
NOT_APPLICABLE with a one-line reason — the gate fails closed if any is missing):

- Miss-probe library: load `data/miss_probes.json` and, for every ACTIVE probe whose
  signal matches this ticket's evidence, treat its implied dimension as a required
  investigation candidate (entry points, consumers/siblings, value provenance, locale
  granularity, and any newer learned probe). These encode real past misses — never skip a
  matched probe.
- Mined precedents and customer profiles: include matching LEARNED/VALIDATING
  probes and the versioned corpus-side customer checklist through
  `dimension_synthesizer.py`. These are advisory candidates, not mandatory scope or
  evidence of a confirmed miss. Record each relevant candidate's exact equivalence
  key and current-evidence disposition. A customer label can widen investigation;
  it cannot approve an AC. Never copy historical acceptance text into a blinded
  target plan or claim that unavailable history was retrieved.
- Consumers / siblings / entry points: trace the touched construct to ALL code consumers,
  sibling code paths, and every entry point that reaches the same path (UI action, API,
  service, scheduler), with file:line — do not stop at two greps. Translate each to plain
  observable behaviour in the ACs; never put the code identifiers in an AC.
- State / config partitions: enumerate both values of every state axis (profile, baseline,
  enum-bound/unbound, feature flag on/off, single- vs multi-language, setting on/off).
- Output scope: which output presets/types are affected, and DITA-OT processing on vs off.
- Output-engine parity benchmark (Native PDF vs Direct DITA-OT): for any Native-PDF or
  output-rendering ticket, GENERATE the affected construct with BOTH Native PDF and Direct
  DITA-OT and diff the two outputs on numbering, placement, ordering, and label text. A
  divergence is a defect unless an explicit product requirement documents it. This is the
  one class the sweep cannot infer from ticket text, code grep, or spec - it only appears
  by producing and comparing both outputs, so it must be run, not reasoned about. Use the
  dita-ot output-generation capability for the benchmark; probe MP-007 surfaces this
  dimension (advisory until promoted). Record the diff result in the dimension inventory.
- Error / negative / boundary paths, performance/scale (when any workload signal exists),
  security, localization (regional vs generic locale), and upgrade/migration.
- Reviewer comments: every imperative check a reviewer raised must be dispositioned.
- Evidence: run RAG at least 3× on the feature's real behaviour and the indexed Jira
  history for the component; record both. Thin/absent history is a recorded gap, not silence.

Only when every dimension above is dispositioned may you proceed to Phase 7. If the sweep
surfaces a blocking unknown, resolve it from evidence or raise it as an Open Question FIRST
— do not author around it.

### Phase 6.6 — Question-Based Reasoning (Planner → Research Router → Resolver)

Structured reasoning stages between discovery and authoring. The Question Planner and
Question Resolver are coordinator/reasoning stages, NOT new autonomous agents — the
existing Evidence Agent, Doc Researcher, Writer, and Reviewer roles are unchanged.
Flow: evidence → Question Planner → material questions → Research Router → Doc
Researcher / other authorized evidence routes → Question Resolver → coverage reasoning
input → Writer → Reviewer → final UAC. Record the stages in the manifest `question_plan`
and `question_resolutions` blocks, validated by `scripts/question_planner.py` and
`scripts/question_resolver.py` (see `references/question-based-reasoning.md`).

- **Plan only material questions.** Emit a question only when its answer could materially
  improve acceptance understanding or coverage — never carpet every category. The closed
  category vocabulary: EXPECTED_OUTCOME, STATE_TRANSITION, PERSISTENCE, NEGATIVE_CONTRACT,
  SCOPE, VARIANT, ENTRY_PATH, CONFIGURATION, APPLICABILITY, PRESERVATION, ERROR_RECOVERY,
  SCALE, COMPATIBILITY. Every question carries `question_id`, `category`, `question`,
  `why_material`, `triggering_evidence_ids`, `acceptance_impact`, `applicability`,
  `  research_requirement`, and `status` (plus `research_topics[]` when research is routed).
- **The question budget is bounded** (`question_plan.budget`, default 12). If the
  material-question budget is exceeded, do not silently discard questions: move the excess
  into `question_plan.overflow` with `state: QUESTION_BUDGET_EXCEEDED` and an explicit
  escalation note.
- **Route every question through the Research Router** (`question_research` block) before
  resolving it, reusing the R1 Doc Researcher routing contract (Phase 5.5): a
  documentation-requiring material question requires a terminal `doc_research` routing
  state — R1-required research cannot be skipped, and a `RESEARCH_NOT_REQUIRED` doc
  routing contradicts documentation-requiring questions. Required research cannot be
  skipped; NOT_FOUND is not negative proof.
- **Resolve every planned question exactly once** with a terminal disposition: ANSWERED,
  PARTIALLY_ANSWERED, ACCEPTANCE_TBD, INVESTIGATION_ONLY, NOT_APPLICABLE, DUPLICATE, or
  CONFLICTED. The resolution carries `question_id`, `disposition`, `answer`,
  `source_ids`, `source_authority`, `applicability`, `limitations`, `contradictions`,
  `decision_reason`, and `research_ids` binding the admitted research that produced a
  documentation answer - stale or wrong-bound research cannot answer another question,
  and documentation is never cited without admitted research. Semantic decisions are
  externalized in these artifacts; downstream stages consume them rather than
  reconstructing answers from raw ticket text.
- **Hard rules:** a question is not an AC; an answer is not automatically an AC; Actual
  Result cannot establish Expected Result; never reverse a reported failure to invent
  desired behavior; a suspected root cause does not become acceptance behavior; an
  attachment observation does not establish desired behavior; historical Jira does not
  automatically establish current behavior; PARTIAL research cannot produce a fully
  confirmed answer; an equal-authority conflict remains unresolved (stay CONFLICTED, or
  record the higher-authority basis in `conflict_resolution`); a DUPLICATE preserves all
  triggering evidence IDs on the surviving question; root-cause/diagnostic/mechanics
  uncertainty never becomes ACCEPTANCE_TBD merely because it matters to engineering;
  ACCEPTANCE_TBD is allowed only when different plausible answers materially change
  acceptance behavior/scope/configuration/applicability/compatibility/preservation; root
  cause, diagnostics, and implementation mechanics are normally INVESTIGATION_ONLY. The
  Writer never receives raw unresolved questions, and a question is never rendered
  directly as an AC - ACCEPTANCE_TBD questions reach the final Open Questions contract
  only through the existing approved downstream path.
- **Preserved invariants:** source authority, observation-vs-requirement separation, exact
  Jira intake, attachment evidence handling, Doc Researcher routing, the Writer language
  contract, Reviewer independence, and draft-only behavior all remain exactly as defined
  elsewhere in this skill — these stages only add traceable structure between discovery
  and authoring.

### Phase 6.6.5 — Evidence Sufficiency (before coverage decisions)

"Evidence exists" is not "evidence is sufficient to support this answer or coverage."
Evaluate sufficiency at BOTH the resolved-question level and the coverage-decision
level in the manifest `evidence_sufficiency` block, enforced by
`scripts/evidence_sufficiency.py` (see `references/evidence-sufficiency.md`).

- Every material resolved question carries `sufficiency_status` (SUFFICIENT / PARTIAL /
  INSUFFICIENT / CONFLICTED) with the structured sub-states `authority_status`,
  `research_completion`, `applicability_status`, `currentness_status`,
  `contradiction_status`, plus claim-level `supported_claims[]` /
  `unsupported_claims[]`, `limitations[]`, bound `evidence_ids[]` / `research_ids[]`,
  and `decision_reason`. No numeric confidence as authority.
- One applicable authoritative source may be SUFFICIENT; many related passages are not
  automatically sufficient. Do not require documentation when Jira authority itself is
  sufficient. PARTIAL research caps the answer at the established portion unless the
  remaining limitation is demonstrably immaterial to that specific answer; NOT_FOUND is
  never proof of the opposite behavior; CONFLICTED stays CONFLICTED until an existing
  authority rule settles it.
- Wrong-applicability evidence (wrong version / engine / surface) stays insufficient
  without explicit compatibility evidence; UNCLEAR applicability is never confirmed
  applicability. Sufficiency for one claim never bleeds into a neighboring claim.
- Coverage sufficiency is computed from the underlying questions and evidence; P0/P1
  ACCEPTANCE coverage requires SUFFICIENT unless explicitly represented as
  ACCEPTANCE_TBD; the Writer handoff never carries INSUFFICIENT/CONFLICTED coverage or
  an unnamed PARTIAL portion, and the Writer cannot reinterpret evidence to upgrade
  sufficiency.

### Phase 6.7 — Coverage Reasoning (dedicated Coverage Reasoner)

A dedicated Coverage Reasoner — never the Writer — decides coverage on top of resolved
question evidence, recorded in the manifest `coverage_decisions` block and validated by
`scripts/coverage_reasoner.py` (see `references/coverage-reasoner.md`). Inputs:
authoritative requirements, resolved questions, research findings, applicability,
conflicts, attachment observations, existing behavior, new behavior, and preservation
requirements.

- Emit one decision per candidate behavior with `coverage_id`, `behavior`,
  `question_ids`, `evidence_ids`, `research_ids` (the admitted research behind the
  underlying questions), `priority`, `coverage_class`, `contract_type`
  (`POSITIVE`/`NEGATIVE`/`PRESERVATION`), `surface`, `state_or_transition`,
  `configuration`, `applicability`, `variants` (same-outcome variants each bound by
  their own evidence), `reason`, `acceptance_impact`, and the
  `dimensions_considered` axes reasoned about when applicable (single/bulk,
  refresh/revisit, state transitions, negative contracts, alternate UI paths,
  configuration branches, New/Old Editor, Author/Source, Collections/Explorer/Map
  Console, Cloud/6.5, Native PDF/DITA-OT, preprocessing ON/OFF, scale, preservation).
- **priority**: `P0` = behavior required to prove the primary ticket contract and prevent
  the direct customer regression (class `ACCEPTANCE`); `P1` = materially related
  regression behavior (class `QE_REGRESSION`); `SUPPORTING` = supporting regression or
  investigation coverage; `EXCLUDED` = explicitly excluded with a reason, never reaching
  the Writer. Do not promote generic test ideas: every decision traces to resolved
  questions and/or evidence.
- A decision may stand only on questions whose resolution and research permit it:
  ANSWERED is eligible; PARTIALLY_ANSWERED grounds only the established portion
  (regression/investigation); ACCEPTANCE_TBD is never converted into confirmed
  behavior; INVESTIGATION_ONLY never becomes acceptance coverage; NOT_APPLICABLE
  produces no coverage; a DUPLICATE contributes linkage through its surviving
  question and never creates duplicate coverage; CONFLICTED never silently produces
  confirmed acceptance coverage. An acceptance decision never rests on actual-result,
  observation, suspected-root-cause, or historical-ticket authority. NOT_FOUND or
  otherwise incomplete required research cannot ground an ACCEPTANCE decision.
  Documented-today (EXISTING_CONFIRMED) behavior must not be repackaged as new
  acceptance coverage, and a NEW_REQUIREMENT is not a preservation contract.
- **The Writer receives an explicit admitted coverage package** (`writer_handoff` is
  mandatory once decisions exist) containing only accepted (non-EXCLUDED) decisions and
  every P0 decision. The Writer must not invent additional acceptance behavior, promote
  QE_REGRESSION to ACCEPTANCE, convert INVESTIGATION into an AC, resolve
  ACCEPTANCE_TBD, add unapproved variants, or independently decide P0/P1 — it may
  simplify wording, combine approved same-outcome variants, and preserve required
  product terminology.
- **The Reviewer verifies** (via the `writer_package` block) that every AC maps to
  admitted ACCEPTANCE coverage ids, all P0 accepted behavior is represented, P1 did not
  expand acceptance scope, QE_REGRESSION/INVESTIGATION never leak into ACs,
  ACCEPTANCE_TBD was not silently resolved, no unapproved variants were introduced, and
  source mapping stays consistent with the evidence/question/research bindings.
  Semantic failures route upstream to the Coverage Reasoner; the Reviewer never
  silently repairs acceptance semantics.

### Phase 6.8 — Semantic Coverage / AC Equivalence

After coverage reasoning, classify pairs of coverage decisions for semantic equivalence
BEFORE the Writer authors ACs, recorded in the manifest `coverage_equivalence` block and
validated by `scripts/coverage_equivalence.py` (see
`references/coverage-equivalence.md`). The primary comparison happens on coverage
decisions, not merely Writer prose: compare `coverage_id`s structurally across coverage
IDs, question IDs, expected outcome, state transition, scope, configuration, and
applicability — never textual similarity alone. Same nouns do not mean the same outcome;
different wording does not mean different outcomes.

- **Classifications:** `SAME_OUTCOME_VARIANT` (same expected outcome through variant
  phrasing/polarity — the Writer should normally create one AC), `DISTINCT_OUTCOME`
  (different expected outcomes), `DEPENDENT_OUTCOME` (one outcome depends on the other;
  record the dependency; never auto-merged), `CONFLICT` (the same outcome asserted
  contradictorily; kept visible, never merged, routed upstream).
- **Decision record:** `decision_id`, the two coverage ids, `classification`, declared
  `shared_dimensions`/`differing_dimensions`, `reason`, and `merge_allowed` (true only
  for SAME_OUTCOME_VARIANT).
- **Merge groups** carry `equivalence_id`, `coverage_refs`, `canonical_outcome` (an
  internal grouping label — never evidence), `question_refs`, `evidence_refs`,
  `research_refs`, `variant_refs`, `source_lineage`, `priority`, `applicability`, and
  `partial_members`. A merge requires a SAME_OUTCOME_VARIANT basis decision with
  `merge_allowed`, preserves all question/evidence/research IDs, all approved variants,
  and all lineage, keeps the highest member priority, and never crosses applicability,
  surface, configuration, or state (parity is never inferred). INSUFFICIENT or
  CONFLICTED coverage never merges; PARTIAL coverage participates only through its
  bounded established portion; an ACCEPTANCE_TBD question is never absorbed into a
  confirmed merge; EXCLUDED coverage never merges; one decision survives into exactly
  one AC. Do not merge distinct behavior simply to reduce AC count.
- **Writer/Reviewer binding:** the Writer receives equivalence-resolved groups; an AC
  may reference a merge via `equivalence_refs` and must then carry every merged variant;
  two ACs may never cover different members of the same merge. The Reviewer detects
  duplicate ACs for a merged group, collapsed distinct outcomes, lost TBD dimensions,
  omitted or invented variants, and lost source lineage — and routes semantic failures
  upstream instead of repairing them.

### Phase 6.9 — Requirement Lineage (end-to-end AC traceability)

Trace every final AC back to the evidence that justified it, recorded in the manifest
`requirement_lineage` block and validated by `scripts/requirement_lineage.py` (see
`references/requirement-lineage.md`): Original Source -> Evidence -> Question ->
Research (when required) -> Question Resolution -> Sufficiency -> Coverage Decision ->
Equivalence Group (when applicable) -> Written AC -> Reviewer Decision. Existing
production IDs are preserved; `SRC-` (original source) and `REV-` (review decision)
are recorded conceptually and reference the existing IDs without rewriting them.

- `sources[]` records each original admitted source with `source_type`, locator,
  optional version/applicability, status, and `evidence_ids`; `ac_lineage[]` binds each
  final AC to its `coverage_refs`, `equivalence_refs`, `question_refs`,
  `evidence_refs`, `research_refs`, `source_refs`, `writer_revision`,
  `source_versions`, and the human-facing `human_source_line`; `tbd_lineage[]` keeps
  every unresolved ACCEPTANCE_TBD question visible with its research attempt, partial
  or insufficient result, and reason — a TBD row never references a confirmed AC;
  `reviews[]` binds each Reviewer decision to the exact Writer revision.
- **Integrity rules:** every referenced ID exists in the producing block; the Writer
  cannot fabricate lineage; unrelated or unused retrieved evidence never contaminates
  an AC; a QE_REGRESSION member of an equivalence group never becomes acceptance
  authority through the group; `human_source_line` derives only from admitted
  supporting sources and never exposes internal IDs (`Q-`, `COV-`, `SUF-`, `EQ-`,
  `DR-`, `EV-`, `SRC-`, `REV-`, `MERGE-`, `canonical_outcome`); a Writer revision
  change makes the review stale and a source-version change invalidates the dependent
  lineage; unsuccessful research stays visible in `tbd_lineage` instead of being
  erased.
- Lineage proves provenance and structural integrity, not semantic correctness; it
  adds traceability only and introduces no new acceptance semantics.

### Phase 6.9.5 — Historical Jira Evidence Safety

Historical Jira similarity is discovery evidence, not acceptance authority: an old
ticket never automatically becomes an authority for the current ticket. Record every
historical item considered for a material Question in the manifest
`historical_jira_assessment` block, validated by
`scripts/historical_jira_safety.py` (see `references/historical-jira-safety.md`). This
extends the existing temporal/authority/resolver path; it creates no competing
framework and no new authority hierarchy.

- Assess per Question (never globally per ticket): `history_id`, `question_id`,
  `jira_key_or_source_id`, `relationship`, the six match dimensions, `currentness`,
  `superseded_status`, `human_accepted_ac_available`, `applicability`,
  `authority_role`, `allowed_use`, `reason`, `limitations[]`. Never classify from
  vector similarity or lexical overlap alone.
- **Relationships:** `AUTHORITATIVE_HISTORY` (only with an `authority_basis` naming
  the existing permitting rule plus exact applicability — a historical Human Accepted
  AC is not automatically authoritative for a different ticket),
  `SUPPORTING_PRECEDENT` (may contribute; S1 still decides; never overrides current
  Jira), `DISCOVERY_ONLY` (locates terminology/sources/paths; never establishes an
  answer or enters Source lines), `NOT_APPLICABLE` (forced by any material
  surface/version/configuration difference — similarity never overrides it),
  `CONFLICTING_HISTORY` (preserve the disagreement; route through existing Q1/S1
  conflict/TBD behavior).
- Historical Actual Results, reproduction steps, and suspected root causes remain
  observation/investigation evidence — never converted into current acceptance
  requirements; historical Human UAC is never copied into the current UAC without
  current-question reasoning and Coverage admission.
- S1 never reaches SUFFICIENT on non-establishing history; C1 never lets historical
  evidence create coverage directly (only through its bound Question); E1 never merges
  current and historical outcomes for similar wording; L1 keeps every historical
  contribution visible and keeps unused history out of final Source lines.

### Phase 6.9.6 — Question-Level Retrieval Quality and Evidence Admission

Retrieval is not evidence: evaluate and control retrieval against explicit material
Questions via the manifest `retrieval_requests` / `retrieval_results` blocks,
validated by `scripts/retrieval_admission.py` (see
`references/retrieval-admission.md`). This extends the existing read-only retrieval
path — it builds no new RAG system, replaces no vector store, and never reindexes.

- Every retrieval request binds a `question_id`, `research_id`, the actual `query`,
  `required_source_type`, `product_context`, `applicability`, `requested_claim`, a
  bounded `top_k`, and a `retrieval_mode`; query rewrites never change the Question
  binding; retrieval budgets are tracked and no answer is a valid result.
- Every candidate records rank, score (discovery metadata — never authority), source
  identity/version, applicability (`CONFIRMED`/`UNCLEAR`/`WRONG`/`NOT_ASSESSED`), and
  a `relationship`: `TOPIC_MATCH` (discovery only), `RELEVANT`, `SUPPORTS_CLAIM`
  (S1 decides sufficiency), `DECISIVE` (subject to source authority — never
  automatically authoritative or sufficient).
- A declared relationship never exceeds the structural admission ceiling: fetch exact
  evidence before material use; wrong or unassessed applicability stays TOPIC_MATCH;
  unclear applicability is never DECISIVE; exact configuration/property identity is
  required (a same-looking numeric value on a nearby property is not the same
  property); stale retrieval is rejected; retrieved historical Jira routes through H1.
- TOPIC_MATCH/RELEVANT never make a Question SUFFICIENT; only fetched
  SUPPORTS_CLAIM/DECISIVE evidence reaches AC lineage and final Source lines; unused
  chunks stay auditable outside them.
- Retrieval quality is evaluated offline by `scripts/retrieval_benchmark.py` over
  question-level fixtures (retrieval and admission metrics reported separately; the
  headline metric is DECISIVE_EVIDENCE_MISADMISSION_RATE). A live smoke check reports
  read-only gateway connectivity only — never semantic-quality proof.

- Write the minimum number of scenarios needed to cover every acceptance criterion and material risk. Use 6-10 for narrow changes and 12-20 for broad APIs, multi-provider workflows, large enum matrices, recovery incidents, or cross-version features; coverage takes priority over an arbitrary cap.
- Each P0/P1/P2 scenario must use the literal fields `Action:` and `Expected:` in one plain-English bullet. When an operational manifest references a scenario, add a stable `[TS-##]` token before the AC mapping, for example `- P0 [TS-01] [AC-01]: Action: ... Expected: ...`.
- Prefix every scenario with the acceptance IDs it covers, for example `P0 [AC-01, AC-04]`. No confirmed or proposed AC may remain without at least one scenario, and no expected result may introduce behavior absent from an AC or accepted evidence.
- Cover happy path, negative/boundary, role/permission, configuration, data-shape, environment matrix, setup/test-data fixture, upgrade/version, API contract, and fix-safety checks when relevant.
- Every P0/P1 scenario must trace to Jira AC, accepted RAG, PR diff, Figma flow evidence, a medium/high implemented-fix Jira learning oracle, or an explicit high-risk regression. Cautionary/non-fix Jira history may justify exploration but not a sign-off expectation.
- Include integration-impact scenarios when the ticket touches shared APIs, shared UI components, configs, publishing paths, editor flows, translation flows, upload/status flows, review flows, or automation infrastructure.

### Phase 8 — Capture Open Questions

- Capture only questions that materially affect QA sign-off, expected behaviour, configuration, environment setup, or scenario coverage.
- Give every real question a unique, contiguous `OQ-##` prefix starting at `OQ-01` and the literal `QA impact:` marker; preserve source order and use the same ordered IDs in the manifest. Do not encode an unresolved decision as an AC.
- Ask permission, role, XML Editor config, AEM config, translation config, DITA, and DITA-OT output questions when the Jira domain requires them.
- For on-premise release, service pack, or upgrade tickets, always ask upgrade-impact questions when not answered: source/target versions, config migration, custom UI config retention, changed defaults, manual post-upgrade steps, backward compatibility, and cloud/on-prem parity.
- For publishing/output tickets, include DITA-OT, PDF, HTML5, preset, transformation, and output validation questions when not answered by Jira/RAG/PR.
- Do not ask generic questions already answered by Jira, RAG, Figma, PR, or repo evidence.
- If there are no meaningful unknowns, write `No open questions from current evidence`.

### Phase 9 — Decide Draft vs Review-Ready

- Use `Draft blocker:` bullets inside the affected final section; do not create a separate blocker section.
- For `Pre-Development UAC`, mark UAC-ready when issue facts, proposed acceptance criteria, current product-clone evidence where available, automation evidence where available, expected-behaviour support, regression areas, test-data/environment needs, and sign-off decisions are sufficiently explicit. PRs, changed files, and line counts are not required.
- For `Implementation Review`, mark review-ready only when the implementation diff, changed files, line counts, current-code comparison, expected behaviour, test scenarios, and integration impact are inspected.
- For `Post-Fix Validation`, mark QA-sign-off-ready only when the candidate fix/build, changed code, acceptance coverage, regression evidence, required environment matrix, and sign-off-critical questions are resolved.
- RAG or historical search unavailability is a blocker only when the missing evidence is necessary to establish a disputed or otherwise unsupported behaviour claim. Do not block a well-supported pre-development UAC merely because an optional source is unavailable.
- Dirty or unavailable clones block only claims that depend on those clones. Keep verified evidence and mark dependent findings provisional instead of downgrading every section automatically.

### After delivery — Capture explicit Human corrections

- At the start of a configured generation/capture invocation, make one bounded `feedback_capture.py flush-queue` attempt before capturing new feedback; status/readiness-only requests never flush. Replay capture records only, preserve the exact queued request and identity/service binding, and report how many moved from `QUEUED_LOCAL` to `SAVED_REMOTE`. If the queue is blocked or belongs to a different service/credential, leave it intact and report that state. Never retry binding, review, approval, rejection, revocation, or supersession, and never replace a stale reviewed-source pin silently.
- When shared feedback capture is configured and the Human directly corrects the UAC in the current conversation, use `scripts/feedback_capture.py capture` as the primary capture path whenever the helper is available. It minimizes/redacts the request before the first send and can queue that exact capture DTO after a retryable failure. Send the selected correction with `source_kind=HUMAN_CORRECTION`, a unique idempotency key, and the available `draft_id`, `plan_fingerprint`, `evidence_bundle_id`, `run_id`, and `ac_id`. Use MCP `capture_uac_feedback` only as a non-queueing alternate. If an MCP response is lost, reconcile with list/status or replay the exact same MCP arguments; never switch the same idempotency key to a differently normalized helper payload. Use `AI_PROPOSAL` for machine-authored suggestions and `UNCONFIRMED` when origin is not established; neither may be promoted as Human truth. Do not infer a correction from silence, a question, model critique, or third-party AI output.
- Send only the correction and minimum trace identifiers. Never send the entire Claude/Codex transcript, hidden reasoning, credentials, unrelated attachments, or a locally generated approval decision.
- Report the returned transport and lifecycle states exactly. `QUEUED_LOCAL` means not saved; `SAVED_REMOTE` does not mean approved; only an explicit server `index_status=INDEXED` may be called indexed. A `PENDING_BINDING` record requires an authenticated source binding before review. For a new chat reviewing Jira, follow the exact Jira snapshot path above instead of requiring the original generation draft.
- Do not approve automatically. Any authenticated tenant teammate may capture, but only the ticket's current live QE Assignee, authenticated as a named Human, may bind/review. The server verifies the personal Jira identity and the live `QE Assignee` field; roles, admin status, draft ownership, ordinary Assignee and names in prose grant no authority. That QE must inspect provenance, applicability, counterexamples and the current revision before deliberately calling `review_uac_feedback`. Supporting corrections from another case need their own prior QE approval. Missing identity/field or Jira unavailability leaves review unauthorized; report the unchanged record state and continue normal generation. Binding/review decisions are never queued or automatically retried.
- Future generation may consume only approved, server-published shared learning returned by the authenticated canonical resolver. Default shared mode is `SHADOW`; it cannot change the plan. In `ENABLED`, discovery lessons remain investigation guidance and language lessons remain `RETRIEVED_NOT_APPLIED` authoring guidance until deliberately applied. If the VM is unavailable, retain the existing approved TRAIN baseline and record shared learning as `UNAVAILABLE`; never read pending feedback or a stale local shared snapshot.

## Output Contract

- Presentation vs record: retain the eleven-section hash-bound compatibility record and evidence appendix for auditability, but never present either as the canonical result. The default Claude/Codex response is the canonical runtime's `rendered_output`.
- The canonical renderer may emit these non-empty sections, in order: `Issue understanding`, `Publishing / product scope`, `Acceptance contract` or `Proposed acceptance contract`, `Product decisions required`, `Semantic coverage`, `Structural / hierarchy coverage`, `Referenced content coverage`, `Configuration / state coverage`, `Transformation / processing coverage`, `Generated output validation`, `Reference / link integrity`, `Negative / boundary coverage`, `Failure / recovery coverage`, `Lifecycle coverage`, `Cross-mode regression`, `NFR coverage`, `Explicit out of scope`, `Investigated and rejected`, `Evidence gaps`, and `Coverage gate result`. Do not show empty sections or manually compress away a material disposition.
- `render_compact_view.py` and its four-section output are legacy compatibility projections only. They may be generated for an explicitly requested historical record, but they cannot replace, rewrite, authorize, or be posted instead of the canonical runtime result.
- Compact Acceptance Criteria show each validated product contract as one plain-English `AC-##` line, optionally with short indented sub-points that break a long criterion into scannable clauses. Do not show `Given`, `When`, `Then`, pipes, status, sphere, or evidence in chat. Status, sphere, and all analysis remain in the full record and extracted JSON.
- Consolidate the presented Acceptance Criteria to at most ten AC points (chat AND the posted Jira field). If synthesis produced more, merge related criteria into one AC and express the detail as sub-points, keeping any remaining granularity in the linked full-record markdown - never drop accepted meaning. Enforced by `ac_contract.validate_ac_count` via `uac_linter`.
- Project full-record `Regression Areas` into smart `P3 [Regression]` Action/Expected scenarios under compact `Test Scenarios`; never expose a separate compact Regression heading.
- Performance analysis never adds another compact section. Its internal manifest decision is visible in compact output only through a justified `(Performance)` AC when required; a conditional QA-impact question remains in the hidden full record.
- Keep `Understanding From Jira`, `Expected Behaviour`, `Scope From Git`, `Code Touched`, `Lines Changed`, `Automation Coverage & Gaps`, and `Appendix A` in the full `.md` artifact. `Test Scenarios` remains visible in compact output. Show the complete record or any named hidden section only when the user explicitly requests it.
- `Jira Tickets Worth Checking` contains only each validated same-mechanism Jira key and concise title. Hide similarity explanation, status, resolution, versions, RCA, ownership, search narration, excluded candidates, and aggregate profiles.
- `Automation Coverage` starts with an explicit main-feature verdict (`Covered`, `Partially covered`, `Not covered`, or `Unverified`) and gives only high-level feature-file/UI or integration/API guidance.
- Output Markdown bullets only.
- Posting ACs into a Jira COMMENT (MANDATORY): a Jira comment body is Jira WIKI markup AND Jira auto-links any issue-key-shaped token. The plan's own labels (AC-01, OQ-03, TS-05, ...) match the issue-key shape `[A-Z]+-\d+`, so Jira links them to a non-existent issue and renders them with a STRIKETHROUGH (removing bold/dashes does NOT fix it). Build the comment body with `scripts/jira_safe_text.py` `jira_comment_body(text)`, which strips Markdown and wraps the body in a `{noformat}` block so Jira interprets no markup and auto-links nothing; the AC ids then render literally. To correct a comment already posted with markup, edit it in place via `JiraClient.update_comment(issue_key, comment_id, body)`, do not pile on a duplicate. `jira_safe_text.validate_jira_safe` flags a body that still carries wiki markup or an unwrapped issue-key-shaped label.
- Paste-safe plain text for Acceptance Criteria and every chat-listed AC/UAC (MANDATORY): ACs are pasted straight into Jira/Confluence, so the AC text itself must contain NO inline markdown that a renderer turns into a link or strikethrough. Specifically, inside an AC line do not use backticks/code spans, bold/italic markers, or a Markdown link; do not wrap a token in `~` (a stray `~` or a slash between formatting spans renders as strikethrough). Name properties, config keys, enums, and API paths in plain words with a bare token (e.g. baseVersion, guides-navigation, HTTP 409, referencelistener postdita) and no surrounding markup; a bare Jira key or URL in the Evidence field is fine, but never a clickable `[text](url)` link inside an AC. The canonical record uses `(<Sphere>) <plain-English criterion>. Evidence: ...` with no Given/When/Then labels or pipes anywhere. Chat and Jira show the plain one-line `AC-##` projection with optional sub-points; `[Proposed]` / `[Confirmed]` stay in the validated record only. Enforced by `validate_test_plan.py` and the shared AC projector.
- Generalize the acceptance criteria (MANDATORY - anti over-decomposition): write the FEWEST ACs that cover the behaviour. Do NOT emit a separate AC per micro-variation - blank vs missing an attribute, one AC per surface, one per edit/lifecycle transition, one per structural form (direct href vs nested mapref) - fold equivalent variations into ONE behavioural AC and put concrete cases as examples INSIDE that AC, not as new ACs. Keep each AC to one to three plain sentences with no embedded markup or code (no <keydef ...> tags, no code fences - describe the condition in words). When you are unsure whether an adjacent surface is in scope or whether two structural forms share the resolver, make it ONE Open Question, not multiple asserted ACs. The presented UAC must not exceed ten AC points; more than ten is over-decomposed - merge related criteria and use sub-points, and relint/re-phrase a large synthesized set down to the cap the way a senior human QA would, without losing accepted meaning. Enforced by coverage_forcing (AC-count, no-markup-in-AC, restated-instance) and the hard `ac_contract.validate_ac_count` cap in `uac_linter`.
- Do not use tables.
- Do not output JSON unless explicitly requested.
- Do not include raw RAG chunks, chunk scores, backend traces, evidence matrices, or long citations.
- Never expose numeric retrieval confidence such as `0.88` in the user-facing plan. Describe evidence as verified, partial, inferred, conflicting, or unavailable and identify the evidence type.
- Emit valid UTF-8 text. Before returning, scan for mojibake markers such as `â€`, `â‰`, `Ã`, `Â`, or the replacement character; repair them or use ASCII punctuation such as `-`, `->`, and `>=` when the client encoding is uncertain.
- In the full record, do not emit a title, lifecycle preamble, authorization warning, tool trace, or quality-audit prose outside the eleven required sections. Put the concise issue interpretation under `Understanding From Jira` and detailed lifecycle/evidence availability under `Scope From Git`.
- The compatibility input record uses exactly these sections, in this order; these are not a second final-output contract:
  1. `Understanding From Jira`
  2. `Acceptance Criteria`
  3. `Expected Behaviour`
  4. `Scope From Git`
  5. `Code Touched`
  6. `Lines Changed`
  7. `Test Scenarios`
  8. `Known Jira Bugs / Past Similar Tickets`
  9. `Regression Areas`
  10. `Automation Coverage & Gaps`
  11. `Open Questions`

## Section Rules

- **Understanding From Jira**: Give the user a concise confidence check before the plan. Use exactly five bullets beginning `Issue understood:`, `Why it matters: Customer context resolved from Jira:`, `Requested outcome:`, `Lifecycle understood as:`, and `Evidence boundary:`. Restate the Jira or supplied issue in plain English without copying raw fields, inventing implementation, or writing test cases. Begin `Evidence boundary:` with the validated `Evidence mode: full` or `Evidence mode: degraded`; identify whether facts came from live Jira, indexed Jira, or supplied incident text, and expose every unavailable source, resulting claim restriction, contradiction, or missing Jira access. Keep this section to the issue's user-visible problem, impact, requested end state, lifecycle interpretation, and evidence limit.
- **Acceptance Criteria**: In the record, write every criterion in the exact grammar `- AC-## [Confirmed|Proposed]: (Basic|Negative|Integration|Performance) <plain-English acceptance criterion>. Evidence: <underlying source>.` with no Given/When/Then labels or pipes. Break a long criterion into short indented sub-points rather than stacking clauses on one line. Use contiguous unique IDs beginning at `AC-01`, and cap the presented set at ten AC points - merge related criteria and use sub-points if synthesis produced more, keeping remaining granularity in the linked full-record markdown without losing accepted meaning. `Confirmed` is only for accepted-UAC behavior and must match `uac_fidelity`; otherwise every criterion remains `Proposed`. Every AC cites an underlying source; a graph path ID alone is invalid. Follow `references/plain-language-ac-writing.md`: keep one main contract, prefer common words, group same-outcome cases as named sub-points, and split only different required behavior or outcomes. Make each criterion independently pass/fail and decided: no pending/conditional markers, qualitative bounds, non-finite negatives, alternative implementation menus, or ambiguous terminal outcome unions. Keep sign-off-critical unknowns in stable `OQ-##` records.
- Every AC must add one distinct product contract, not another phrasing of the same result. Do not add a final recap AC. Preserve any unique, source-backed cases from a merged AC in visible sub-points and mapped Test Scenarios; keep an internal old-to-new coverage mapping. Put implementation-only behavior in Expected Behaviour or an Open Question until product scope approves it.
- A readability or implementation-scope REVIEW keeps the gate exit backward-compatible but makes its receipt non-postable. Resolve the wording or authority decision before any Jira write.
- **Acceptance Criteria - performance**: Add `(Performance)` only when the internal assessment is `required`. Its `Given` must state a numeric workload such as topic, user, job, reference, or iteration count, and its `Then` must state either a numeric latency, throughput, error, timeout, resource, queue, growth, or cardinality threshold with units, or a source-backed comparative target such as `at least 2x p95 improvement versus the recorded before-fix baseline`. The manifest's `performance_ac_ids` must exactly match the visible Performance AC IDs, and every Performance AC must map to an explicit performance/load/stress/soak/scalability/concurrency/benchmark scenario. Never emit a Performance AC for `conditional` or `not_required`.
- **Expected Behaviour**: State intended behaviour from Jira plus accepted `ask_dita_expert` and Figma design-flow evidence. Separate observation, supported inference, and confirmed root cause. Do not use exclusive wording such as `purely`, `only cause`, or `proves the root cause` unless the evidence rules out credible alternatives for the relevant time window. If unsupported, write `Unknown from current evidence`.
- **Scope From Git**: Start with lifecycle stage and readiness target. List issue/development-link source, relevant clone discovery and sync state, GitHub MCP/PR status only when stage-relevant, current or changed product area, diff-inspection state, and Figma evidence state when applicable. For every cited clone include absolute repository path, branch, pre-sync SHA, inspected post-sync SHA/ref, upstream/ahead/behind state, pre/post dirty state, fetch/pull result, whether claims use the synchronized worktree or a verified remote ref, and any retained developer-work stash OID/ref with its restore command.
- **Code Touched**: In pre-development, write `No code changes yet — development has not started`, then list exact current files/functions/classes/workflows under `Current implementation implicated` and evidence-backed likely change points under `Potential code impact`; label inference and never present it as changed code. Use complete absolute file paths and exact symbols; never abbreviate a path with `...`. In implementation/post-fix stages, list actual changed files/symbols from the inspected diff, plus adjacent callers, shared services, configs, persistence paths, UI states, and automation code that can be impacted, with a short QA implication for each.
- **Lines Changed**: In pre-development, write `Not applicable — development has not started`; never add a line-level Draft blocker. In implementation/post-fix stages, summarize added/deleted counts and key hunks by file; if unavailable, add `Draft blocker: implementation diff not inspected`.
- **Test Scenarios**: Open this section with one or more concrete bullets beginning exactly `- Test data to prepare:` (not P-prefixed) before the P0/P1/P2 bullets: name exact fixtures, paths, identifiers, properties/fields, config positive/negative values, environment matrix, deterministic failure injection, cleanup, and pass/fail oracles. Every primary scenario uses literal `Action:` and `Expected:` and maps to one or more AC IDs; add `[TS-##]` when the operational manifest references it. Put destructive one-time remediation under a clearly labelled `Incident recovery validation` bullet rather than an AC. Such validation must include target ownership/correlation, approved exact scope, backup/export, dry-run or pre-delete inventory, unrelated-state preservation, audit evidence, rollback, post-cleanup queue/dashboard checks, and safe production boundaries. For concurrency safeguards, separately assert successful completion, output integrity, no duplicate/partial/orphan state, and the exact bounded retry-exhaustion outcome.
- **Known Jira Bugs / Past Similar Tickets**: List up to five validated Jira keys covering relevant open known bugs and resolved historical bugs, ranked by shared defect mechanism and never padded to five with area-only or keyword-only matches. Each entry must begin its rationale with a `Similarity:` clause that names the concrete shared failure shape (not a shared subsystem name or generic word) and states the match strength; a ticket that only shares a feature area or keyword belongs in `Regression Areas`, not here. Include status/resolution, RCA or behavior lesson when available, affected/fix version, reusable test evidence, and concrete impact on scenarios or regression. Include the narrow Jira/JQL and indexed-history search status, and state there which weak/area-only candidates were deliberately dropped. Mark every unavailable field explicitly instead of inferring or omitting it. If no same-defect-class ticket exists, say so plainly rather than listing near-misses.
- **Regression Areas**: Write each item the way a senior manual QA engineer would - a concrete regression bullet that names the specific workflow, API, config, role, data shape, or build/environment to re-test and states the risk (what could break and why the fix endangers it), not a bare area name or keyword fragment. For example, prefer "Re-run adding a topic to a map via topicref and key/keydef and confirm the properties are still written, because the fix touches the shared write/remove service" over "add-to-map write path". Order by likely blast radius, and call out the single highest-priority regression explicitly. Cover nearby workflows, APIs, configs, roles, browsers, data shapes, design states, component variants, upgrade paths, integration impact, and automation coverage gaps likely to break. Each bullet must be a full sentence, not a terse label; the validator rejects fragments below a minimum length.
- **Automation Coverage & Gaps**: Begin with exactly one `- Main feature coverage: Covered|Partially covered|Not covered|Unverified - <reason>.` bullet. For every AC or grouped matrix, state a verdict. `Partially covered` requires an existing test to exercise and assert a named clause of that same AC; adjacent happy-path coverage is reusable infrastructure only. For existing coverage, include exact repository, full path, exact test/scenario symbol, helper/fixture, layer, and revision. For gaps, include exact candidate location, reusable infrastructure, deterministic setup/injection, polling oracle, timeout source, output-integrity assertions, cleanup/rollback, suite/tags, and whether to extend or add. Search every relevant automation repository and exact implementation symbol before declaring `Not covered`.
- **Open Questions**: Prefix every real question `- OQ-##:` with unique, contiguous IDs starting at `OQ-01`, and include literal `QA impact:` describing what each plausible answer changes for scenarios, expected results, environment, or sign-off. Use the same ordered IDs in the manifest. Cover only relevant permission/config/DITA/output/upgrade/operational decisions. If there are no meaningful unknowns, write exactly `- No open questions from current evidence` as the only bullet and use an empty manifest list.

## Non-Negotiable Rules (presentation, scope, coverage)

These are permanent, human-set, and each is enforced by a named gate so it cannot recur. Apply them from the start of authoring, not only at gate time.

- **GATE-WHILE-AUTHORING IS MANDATORY (run gates in the SAME flow, the first time, self-correct, present only when clean):** authoring a UAC is NOT complete until the gate suite exits clean. The flow is one loop: draft -> run `coverage_forcing.validate` (plus `uac_linter` and, for the full plan, `validate_test_plan.py` / `run_gates.py`) -> for EVERY failure, revise the draft to disposition the missing dimension (as an AC or Open Question) -> re-run -> repeat until zero failures -> only then present or post. NEVER present or post a UAC that has not been run through the gates. Do not hand-author in chat and skip the gate, and do not gate as an afterthought - the gates run during first authoring, every time. The automated form of this loop is `scripts/uac_eval/measure_gate_effect.py` (generate -> gate -> auto-correct -> re-gate); use it as the reference for the flow. Presenting an ungated draft is itself a defect.
- **AC presentation:** every AC a human reads (chat compact view AND the posted Jira Acceptance Criteria field) is ONE plain-language line, no Starting point/Action/Expected scaffolding, no Given/When/Then labels or pipes. A long criterion may carry short indented sub-points. Enforced by `ac_presentation.project_ac_for_people` (one-line) and `ac_readability`.
- **AC consolidation (max 10) is loss-less:** the presented UAC must not exceed ten AC points, but consolidation only REORGANIZES coverage - it never removes a checkable point. Before merging, list every distinct checkable point; after merging, each one must survive as a clause of a merged AC, a sub-point under it, or an entry in the linked full-record markdown. Nothing is dropped. Relint/re-phrase a large synthesized set (e.g. twenty) down to at most ten the way a senior human QA does - merge criteria that share a behaviour and express the merged detail as short sub-points. Never delete a point to hit the cap and never split one idea into thin ACs to pad the list. If ten merged ACs still cannot hold every point, keep the full granular set in the linked markdown and make the comment link it. Enforced by the hard `ac_contract.validate_ac_count` cap in `uac_linter` and the coverage_forcing over-decomposition check.
- **Acceptance contract cannot disappear:** when `behaviour_matters` is not explicitly `false`, the plan must contain an `Acceptance contract`, `Proposed acceptance contract`, or `Acceptance criteria` section with at least one AC. Only an explicit non-behavioral opt-out skips this check. Enforced by `coverage_forcing._validate_acceptance_contract_present`.
- **Near-duplicate ACs must be merged:** compare only the acceptance-contract section, never the whole document. Two ACs with content-word Jaccard overlap at or above `0.6` fail until they are combined into one distinct product outcome. Enforced by `coverage_forcing._validate_ac_redundancy`; the threshold must remain aligned with `scripts/uac_eval/precision.py`.
- **History attempts cannot be silent:** whenever the manifest declares `evidence_lifecycle`, Jira-history, or Known Jira Bugs intent, `history_attempts` must record each source, exact query, result, and result count. Empty or unavailable evidence is valid when explicitly recorded; omission fails closed. Enforced by `coverage_forcing._validate_history_attempt_recorded`.
- **No status tag in human-facing ACs:** never show `[Proposed]`/`[Confirmed]` in chat or in the Jira field; the tag is internal-record only and the `Needs_Human_Review` label conveys not-yet-accepted status. `post_acs_to_jira.py` posts with `include_status=False`; verify the field has no tag after posting.
- **Simple first-read language:** no code/jargon/Class.method/file paths inside AC text; move them to the Evidence field or a developer note. Enforced by `ac_readability` (REVIEW blocks a postable receipt until simplified).
- **Publishing tickets:** the ACs must cover DITA-OT processing ON and OFF and preset IN-scope / OUT-of-scope. Enforced by `publishing_scope_coverage`.
- **Security-sensitive XML/DITA paths:** hostile or malformed input, reference-scope traversal, and permission enforcement must be covered or consciously deferred whenever their strong signals activate. Record `INPUT_SAFETY`, `REFERENCE_TRAVERSAL`, and `AUTHZ` in `security_coverage`; an activated dimension cannot be silently omitted, and a genuinely not-applicable dimension needs a concrete reason explaining why the signalled change does not exercise that boundary. Enforced by `security_coverage`.
- **Localization regression coverage:** content, metadata, reusable-reference, and publishing changes must disposition their effect on existing translation-project status; structural/XLIFF changes must disposition XLIFF export/import integrity; translation-project creation/scope changes must cover the complete documented project-type set. Record every dimension in `localization_coverage`; silence or a placeholder N/A fails. Enforced by `localization_regression_coverage`.
- **Upgrade and migration coverage:** version, stored-data/schema, identifier, deployment, compatibility, and persisted-format migration signals must disposition the old stored state, the migration operation and its completion/repeat/failure contract, the migrated result plus evidence-supported mixed state, and rollback support or irreversibility. Record every dimension in `upgrade_migration_coverage`; temporal applicability alone cannot satisfy this test-path contract. Silence or a placeholder N/A fails. Enforced by `upgrade_migration_coverage`.
- **Value/metadata/property tickets:** the ACs must cover the value's provenance channels beyond the authoring UI - repository node via CRX/DE (`jcr:content/metadata`), source map/topic file, API/import, migration. Enforced by `value_provenance_coverage`.
- **Shared implementation path:** when code shows a path shared across consumers (a base class/method extended or used by several output types, engines, callers, or surfaces), the other consumers are SHARED-PATH REGRESSION (re-test their output unchanged), never silently out of scope. Enforced by `shared_path_regression_coverage`.
- **Ask before authoring:** Enumerate the full dimension space and resolve or ask every material dimension BEFORE authoring ACs (`clarification_gate`). A blocking question must be answered by evidence or by the user before the AC it governs is authored; unknowns are never silently assumed. See `references/clarification-gate.md` and "## Ask-First Clarification Workflow".
- **No manifest omission bypass:** Populate signal-activated reasoning blocks using the v3 authoring workflow, not blanket `block_waivers`. For behavioral plans, an ordinary waiver of `behavior_model`, `coverage_hypotheses`, or `verifications` hard-fails. A recorded reviewed escape is still REVIEW/non-postable. Legacy structural waivers remain migration records, never evidence that reasoning ran. See `references/manifest-completeness.md`.
- **Reviewer-requested checks and shared-consumer surfaces remain explicit acceptance coverage:** when a human reviewer requests a check, or evidence places a shared-path consumer in scope, cover it in an AC and a mapped scenario. Named surfaces with an identical contract may share one AC with explicit sub-points; a different outcome needs a distinct contract. Never hide an in-scope check only in Regression or an Open Question to shorten the list. Unresolved applicability remains an Open Question rather than an invented parity requirement. Enforced by `reviewer_request_coverage`.
- **Root cause and fix must DRIVE the plan (not just be cited):** when a Jira comment, linked PR, commit, or diff supplies a root cause and/or a described fix, it is not enough to mention it. The plan MUST (0) build the requirement oracle FIRST from ticket + EVERY attachment (open images, not filenames) + the UI clone for any user-configurable surface, and validate the fix AGAINST it - the diff is never the spec; record a `scope_delta` for any requirement the fix does not fully cover (mapped to an AC or Open Question), and treat any unconfirmed implementation choice (precedence/tie-break, ordering, defaults, dedup winner) as an Open Question, not an AC that asserts the code is correct; (1) classify the lifecycle as Implementation Review or Post-Fix Validation, not Pre-Development; (2) ground the affected ACs in the requirement oracle and confirm the fix's stated contract against it, naming which AC guards each invariant the fix must preserve; (3) enumerate fix-INTRODUCED risks - what the change itself could newly break - as negative ACs or P0 negative scenarios, not buried Open Questions; (4) produce an Automation Coverage verdict off any test the fix added (a fix that adds a regression test is at least Partially covered at that layer) and name the remaining E2E/preset/engine/shared-path gaps; (5) scope QA sign-off to exactly what the developer's stated verification did NOT exercise. Enforced by `root_cause_fix_driven` and specified in "## Root-Cause / Fix-Driven Authoring".
- **QE-owned UAC is complete - every checkable behavior is an AC:** the UAC is a QE responsibility and QE-centric, so coverage is never parked in Open Questions or Regression to avoid committing. If QE can state a testable expected outcome, it is an Acceptance Criterion. Open Questions are reserved ONLY for a genuine product/scope decision QE cannot assert an outcome for; even then, prefer writing the AC with the QE-expected contract and flagging that dev may down-scope it in review, over dropping the coverage. Promote to ACs: reviewer-requested checks, shared-consumer surfaces (preview, single-topic download), intermediate/temp representations, metadata-context sources (prolog/keywords, map topicmeta), and engine/variant matrices. A UAC that ends with checkable behaviour left only in Open Questions or Regression is incomplete. Enforced by `qe_completeness_coverage`.
- **Working-As-Designed assessment BEFORE fix-ACs (incident/support/escalation tickets):** completeness is not correctness - a UAC can cover every dimension and still be wrong-framed. For any support incident, customer escalation, or "X does not work" complaint, run a WAD assessment BEFORE authoring any fix-shaped AC: (1) is the reported behaviour the INTENDED effect of an explicit configuration or design (e.g. an ignore/exclude list deliberately turning a feature off on a path; a platform default such as no auto-versioning on overwrite; a global clientlib/UX behaviour)? (2) separate CONFIRMED-EXPECTED behaviour (assert it, do not "fix" it) from the GENUINELY DEFECT-SHAPED claim, and mark the defect claim UNVERIFIED until a targeted repro proves it (do not treat an unproven customer inference as a confirmed defect); (3) make the intended-behaviour question a BLOCKING product-decision Open Question, and recommend triage-as-WAD or enhancement when the reported behaviour is by-design. Do not convert a working-as-designed complaint into fix ACs. See "## Working-As-Designed Assessment".
- **Reproducibility assessment before fix-ACs:** before authoring fix-validation ACs, establish whether the issue actually REPRODUCES. Check the ticket for "unable to reproduce", "cannot reproduce", intermittent/flaky wording, a `needs-clarification` / `crosshair` label, a working-hypothesis-only root cause, or QE-couldn't-repro comments. When reproduction is unconfirmed, the PRIMARY deliverable is a REPRODUCTION STRATEGY (the exact conditions to reliably trigger it - concurrency, timing, collision setup, batch size, environment, data shape), not fix-validation ACs; any fix ACs stay Proposed and explicitly gated on "once reproduced". For a suspected race/concurrency/intermittent defect, the reproduction difficulty itself (e.g. forcing two concurrent UUID collisions on a shared session) is the central test-design problem and must be the plan's focus. Never write ACs that assume a defect is real and reproducible when the evidence says it is not. See "## Working-As-Designed Assessment".
- **Offline history is mandatory when the live tool is down:** never record "history tool not run" as a cop-out. If `search_jira_history` MCP is unavailable but the local `jira_qa` Chroma corpus is reachable, run the offline query (`embed_query` + `query_collection` over `CHROMA_COLLECTION_JIRA_QA`, the UACDISCOVER-04 path) and record the same-mechanism candidates (validate mutable status live before asserting it). "Not run" is honest only when neither the tool nor the local corpus is available.
- **Read the LATEST comments and reflect current status before drafting (works-now recency):** the reproducibility rule above catches the CANNOT-reproduce case; this catches the opposite miss - drafting fix-ACs over behaviour a recent comment says already works or is partly resolved. ALWAYS read the newest comments, not just the description. When a comment reports the reported operation now works (e.g. "validation works fine on stage and prod now") or the issue is partially resolved, the plan must reflect that current status in Understanding AND scope itself to what still reproduces; do not assert a fix-AC for behaviour a comment says already works, and raise the changed scope as an Open Question. Enforced by `coverage_forcing._validate_current_status_recency` (works-now signal + acceptance criteria but no status reflection/Open Question fails closed).
- **Server-error surfaces need a UI-behaviour decision (error-surface Open Question):** whenever evidence shows a user-facing server error (503 / 5xx / "service unavailable" / "File is not valid" / a panel that never loads), the plan must disposition what the UI should DO on that error - the exact message shown to the user, whether the action is blocked, allowed, or retried, and the panel/error state - as an Acceptance Criterion (once decided) or an Open Question (while undecided). Do not leave the on-error UX unaddressed. Enforced by `coverage_forcing._validate_error_surface_open_question`.
- **Wrong/false-status fixes need an anti-over-correction AC:** when the ticket is that a run's shown status is wrong (a successful or in-progress run shown as Failed, a false/red/stale failure, "failed but the files were produced"), the plan must ALSO assert that genuine failures still show Failed, cancelled runs stay Cancelled, and successful-with-warnings keep their warning - so the fix does not over-correct and start masking real failures. This is the fix-introduced-risk guard for status defects. Enforced by `coverage_forcing._validate_status_anti_overcorrection`.
- **Concurrency/overlap defects need an isolation AC:** when the defect involves overlapping or concurrent runs (a second request while a previous job is still running, same map and preset, parallel jobs), the plan must disposition isolation - a rejected or aborted overlapping request keeps its own correct status (it is not shown as the other run's success), and unrelated maps, presets, or jobs keep their own status, links, and logs. Enumerate the in-progress/queued/success/failed/cancelled states and the per-request outcomes; do not collapse them. Enforced by `coverage_forcing._validate_concurrency_isolation`.
- **Name the exact screen, never a vague collective surface:** an AC must name each exact screen (for example the Map Dashboard Outputs tab, the Bulk Publish dashboard) - never a vague plural like "both dashboards", "the dashboards", "both panels". When the ticket names specific surfaces, name each one in the AC. Enforced by `coverage_forcing._validate_vague_surface_reference` (in addition to the existing plain-language "exact screen name" guidance).
- **Restrict an AC to the ticket's specific construct - never broaden it to the general category:** when the ticket scopes a specific reference or construct type (for example relationship-table / reltable topics), the AC must assert exactly that type, not its general parent category. Writing "excludes indirect references" when the ticket means reltable silently widens the fix contract, because indirect references also cover Scope=peer, conref/keyref reuse, and other kinds. Keep the AC to the named construct and park the broader category as an Open Question (for example "are Scope=peer and other indirect references in scope, or a separate ticket?"), especially when a comment explicitly proposes a separate ticket. This is reviewer-applied: a wrong-but-plausible broadening reads as valid English, so no gate can catch it - name the exact construct the ticket named.
- **Every surface the Jira names must be dispositioned (named-surface parity):** if the ticket names a product surface (a Panel or Dashboard - Baseline Panel, Translation Panel, Reports Panel, Conditions panel, Subject Scheme Panel, the Map dashboard, etc.), that exact surface must appear in an Acceptance Criterion or an Open Question. Never paraphrase a stated surface into a vague phrase ("baseline-based topic list" instead of Baseline Panel) or silently drop it - the ticket's current-state matrix usually names several surfaces and the reported problem is often the inconsistency ACROSS them, so each one is in scope. The Baseline, Translation, Map, Conditions, Reports, and Subject Scheme surfaces are Panels, not dashboards; use the exact product term. Enforced by `coverage_forcing._validate_named_surface_parity` (subject-matched, so the ticket saying "dashboard" while the AC correctly says "Panel" is not a false miss).
- **RAG must DRIVE the AC terminology and behaviour, not just be a coverage side-lookup (non-negotiable):** before authoring, identify the ticket's core product concept(s) (e.g. "language variables", "output history", "conditions") and RUN a RAG probe for each via `ask_dita_expert` / `lookup_aem_guides`; then bind the ACs to what RAG returns - use the EXACT product terms and the documented behaviour (especially fallback and edge-case behaviour) from the retrieved doc. NEVER invent a term or a behaviour for a concept that RAG documents (e.g. do not write "regional value / 2-character locale / falls back to the generic language" when the doc says values are defined per language and fall back to the UI language). The static `guides_vocabulary` gate only catches already-known wrong terms; it cannot catch a novel concept, so the RAG-grounding step is what protects new concepts - and every correct term/behaviour learned this way should be added to `data/guides_vocabulary.json` so the gate keeps learning. If RAG does not have the concept, say so and mark the term/behaviour unverified - do not invent. Retrieval working is not enough: the loop is only closed when the AC wording and behaviour COME FROM the retrieved evidence.
- **Read the COMPLETE Jira before authoring is non-negotiable:** read the ENTIRE description (every stated data point - every current-state row, per-surface count/list, expectation, and business reason - not just the summary), EVERY comment top to bottom (reviewer/PM directives, proposed solutions, related-ticket references), and EVERY attachment (open and analyze all images, logs, and documents - never from the filename; download them and read them). Every explicit data point the ticket states is test-oracle evidence: if the description gives a per-surface matrix (e.g. Baseline=a; Translation=a,b,c; Translation+baseline=a; Metadata=a,b,c), that matrix is the verification baseline and the target the fix must satisfy. Do NOT dismiss any stated surface, row, or scenario as "unchanged / out of scope" without dispositioning it as an Acceptance Criterion or an Open Question - the reported problem often IS the cross-surface inconsistency itself. Anchor the requirement on the ticket's own stated Expectation (e.g. "like the Map dashboard"), not on the surface you happened to find in code first. Then run the dimension-enumeration rule below.
- **Dimension enumeration BEFORE authoring is non-negotiable (surfaces x sources x terms x directives):** never write ACs first and enumerate reactively as reviewers catch misses. For ANY feature/UI ticket, before writing a single AC, build and (when a reviewer is present) confirm the complete dimension grid, grounded in code + RAG, not memory: (1) EVERY UI surface the behaviour applies to - enumerate ALL editors (Web Editor AND the new Editor) and every panel/view; a UI behaviour is presumed to apply to BOTH editors (parity) unless evidence bounds it. (2) EVERY data source that feeds the affected surface - read the code that populates it and list ALL inputs it can pull from (for the Conditions panel: global profile, folder profile including custom/user-defined, and Subject Scheme maps via the workspace preference), never a remembered subset. (3) The exact product term for every surface/object, RAG- or code-verified (e.g. "Web Editor" not "authoring"; "output history" not "workflow") - see the vocabulary rule below. (4) Reviewer/PM directives as SOURCE OF TRUTH: a PM/reviewer comment (e.g. "sort within each language group too") is a confirmed requirement to encode as an AC, not to demote to a blocking Open Question. Only genuinely undecided mechanism details become Open Questions. Reading a file is not enough - extract the COMPLETE set from what you read. Write-then-patch across reviewer rounds is itself a defect.
- **Use correct AEM Guides product vocabulary; never invent a product concept from support/ticket wording:** write each AC straightforwardly with the concrete thing named, and do not turn a support-ticket phrase into a product mechanism it does not have. Known corrections (curated in `data/guides_vocabulary.json`, enforced by `coverage_forcing._validate_guides_vocabulary`): there is NO "stale preset" concept - it is an existing preset and recreating it (delete + create again) was a support workaround, so never assert stale-preset detection/advice (put "should the product detect a broken/misconfigured preset?" in an Open Question); there is NO run "workflow" object - use "output history" (a run's output history), not "workflow" or "output-history record/details"; do not write a vague "generated file" - name the concrete location (the generated output lands in the fmdita-outputs folder set for that preset); and do not dress a straightforward requested outcome in vague language (write "reading a run's output history must not fail with an error, and such a run must not be shown as Failed", not "the read error"). A Jira "Requested Outcome" that PROPOSES a behaviour (message text, a new state, a new detection) is a candidate, not confirmed - it goes to an Open Question; the AC asserts only the confirmed defect. This grounding rule covers OPERATION VERBS as well as object names, in NEGATIVE/boundary ACs too: every action verb in an AC must be a real Guides operation - do not carry in generic-QA clichés ("moved to the wrong group" is invalid because conditions are grouped automatically by attribute and there is no move operation; "conditional preview" is invalid because the surface is called Editor Preview). Additional known-correct terms are in `data/guides_vocabulary.json` (`canonical_terms` and `synonyms`, e.g. V2 Baseline == New Baseline). Vague placeholder qualifiers ("the configured output folder", "appropriate/relevant/corresponding/respective <noun>", "as applicable") are enforced by `coverage_forcing._validate_underspecified_terms`; the product-vocabulary judgement is reviewer-applied (gates cannot catch a wrong-but-plausible term). See `references/plain-language-ac-writing.md`.
- **Table paste/import/convert tickets must enumerate the variant space (non-negotiable):** for any ticket about pasting, importing, or converting a table, the predictable variant axes MUST each be dispositioned as an Acceptance Criterion, an Open Question, or an explicit scope bound - never authored from the single reported case. The axes are: source apps (Word, Excel, Google Doc, HTML), nested tables, merged/spanned cells, multiple/repeat header rows, simple table vs normal table, topic types (concept/reference/task), and editor scope (new/old). A missing axis fails closed. Enforced by `coverage_forcing._validate_transformation_variant_coverage`.
- **Link / URL / cross-reference tickets must enumerate protocol schemes:** for any weblink, hyperlink, URL, href, or cross-reference ticket, the plan must disposition the URL protocol-scheme variants (http, https, ftp, ftps, mailto, tel, and similar) as an Acceptance Criterion or Open Question - observable behaviour can differ by scheme, so naming only one path shape is incomplete. Enforced by `coverage_forcing._validate_link_scheme_coverage`.
- **Defect tickets must carry a negative/boundary criterion (corpus-learned, 52%):** mining 313 human UACs showed a negative/error/boundary criterion is the single most common dimension (51.8%). For a defect / wrong-behaviour ticket, the plan must include at least one negative Acceptance Criterion, scenario, or Open Question (must-not, invalid input, empty/missing, no data loss, error/fallback). Enforced by `coverage_forcing._validate_negative_boundary_present`. Derive the next discovery gates this way - by mining the corpus with `scripts/uac_eval/mine_uac_dimensions.py`, not by reacting to one ticket.
- **Authoring/content/element tickets must disposition topic types (corpus-learned, 16%):** for a ticket about inserting/editing a DITA content construct (paste, table, xref, conref, keyref, footnote, tgroup, etc.), the plan must confirm the behaviour across topic types (concept, reference, task) or bound the scope explicitly, as an AC or Open Question. Enforced by `coverage_forcing._validate_topic_type_coverage`.

## Root-Cause / Fix-Driven Authoring

A root cause names the exact mechanism, and a described fix names exactly what changed - together they are the strongest edge-case and regression driver in the ticket. Citing them without exploiting them wastes the best evidence. When evidence carries a root-cause statement, a PR/commit/diff, or a "fixed in / merged / verified" claim, apply this before finalizing:

**0. Build the requirement oracle FIRST, independent of the diff (the fix is not the spec).** Before reading the diff as the source of ACs, derive what the ticket actually ASKS from the requirement evidence: the Jira description, EVERY attachment (download and open images/screenshots, do not describe them from the filename), embedded snippets, linked issues, and - for any user-configurable feature (a preset option, dialog, selector, action) - the UI clone (e.g. xmleditor). The acceptance oracle is this requirement, not the code change. Then VALIDATE the fix against it. A fix diff that touches one narrow mechanism (e.g. one property such as `damPath`) does not shrink the requirement to that mechanism; the headline ask may be broader (e.g. "the selected File-properties list, as per other presets"). Record `requirement_oracle` (grounded in ticket/attachment/UI evidence, with at least one attachment or UI source when the issue has attachments or names a UI surface) and a `scope_delta[]` list: every requirement item the fix does NOT fully cover, or covers only partially, mapped to an AC or an Open Question - never silently narrowed to what the diff happens to do. If the fix fully covers the requirement, say so explicitly with `fix_fully_covers_requirement: true` and a one-line reason. Any implementation choice the diff makes but no requirement/spec/Jira confirms (tie-break/precedence, ordering, defaults, dedup winner) is an Open Question, NOT an AC that asserts the code is correct.

**1. Reclassify the lifecycle.** A described or merged fix means Implementation Review or Post-Fix Validation. ACs still stay Proposed when there is no accepted UAC (and `Needs_Human_Review` is present), but the plan's job is now to VALIDATE the fix and its blast radius, not to restate the customer's wish.

**2. Extract the fix contract and split it into what-it-adds vs what-it-must-preserve.** State the change in one line, then map ACs to both halves. Example shape: fix = "include text from non-indexterm child elements" (the added behaviour) + "still exclude nested indexterm children" (the invariant) => the nested-separation ACs are specifically the guard that the invariant survived the change; say so explicitly.

**3. Derive fix-INTRODUCED risks.** Ask what the change itself could newly break, not only whether it fixes the reported symptom. A change that now collects a broader set (all non-indexterm children) may wrongly capture siblings with separate semantics (for example index-see / index-see-also / index-sort-as). Such a risk is a negative AC or a P0 negative scenario; if it cannot be confirmed against code, it is the HIGHEST-priority Open Question because the fix's own change endangers it.

**4. Turn the fix's own tests into an Automation Coverage verdict.** A PR that adds a regression test makes the main feature at least "Partially covered" at that layer - name the exact added test - then list the gaps it does not cover (rendered-output/E2E, preset matrix, engine variants, shared paths).

**5. Scope sign-off to the verification gap.** If the developer verified with one local build plus a unit test, QA sign-off scope is everything that build did not exercise (preset matrix, engine/version variants, metadata-context sources, and shared consumers such as preview/download paths).

Record this in the manifest `root_cause_fix` block (`requirement_oracle`, `scope_delta[]` each mapped to an AC or Open Question (or `fix_fully_covers_requirement` with a reason), `root_cause`, `fix_contract`, `fix_adds`, `fix_preserves`, `fix_introduced_risks[]` each mapped to an AC or Open Question, `added_tests[]`, `verification_performed`, `verification_gap`) so `root_cause_fix_driven` can enforce that a cited fix actually drove the plan and that the requirement oracle - not the diff - defined acceptance.

## Working-As-Designed Assessment

Run this for any support incident, customer escalation, Dynamics case, or "X does not work" complaint, BEFORE authoring fix-shaped acceptance criteria. The feature-map and probes stop MISSED dimensions; they do not stop WRONG FRAMING (treating an intended behaviour as a bug, or writing fix-ACs for something that does not reproduce). These steps do.

**0. Does it reproduce, and is the root cause confirmed?** Before anything else, check reproducibility: "unable/cannot reproduce", intermittent/flaky wording, a needs-clarification/crosshair label, working-hypothesis-only RCA, or QE-couldn't-repro comments. If reproduction is UNCONFIRMED, the primary deliverable is a REPRODUCTION STRATEGY (exact trigger conditions - concurrency, timing, collision setup, batch size, environment, data), not fix-validation ACs; keep any fix ACs Proposed and gated on "once reproduced". For a suspected race/concurrency/intermittent defect, the reproduction difficulty is the central test-design problem. Do not write ACs that assume a real, reproducible defect when the evidence says otherwise.

**1. Is it the intended effect of an explicit configuration or design?** Check the config/code the complaint touches. An ignore/exclude list deliberately turns a feature off on a path; a platform default (e.g. native AEM Assets does not auto-version on overwrite) is not a Guides defect; a missing UI control can be a global clientlib/UX behaviour, not a broken function. If the reported behaviour is the documented/inspected intended effect, it is Working-As-Designed - assert it, do not "fix" it.

**2. Separate expected from defect.** Split the ticket into: (a) CONFIRMED-EXPECTED behaviour (WAD - covered by "confirm expected behaviour" ACs, not fix ACs); and (b) the GENUINELY DEFECT-SHAPED claim, if any. A customer inference ("the binary is stale") is UNVERIFIED until a targeted repro proves it - the evidence often shows the pipeline completed. Mark it unverified and give it a single prove-or-kill repro (e.g. re-download and byte-compare), run FIRST.

**3. Make intent a blocking product decision.** The "what is the intended behaviour here?" question is a BLOCKING product-decision Open Question - the answer decides whether there is a defect at all. Author ACs to the QE-expected reading but keep them Proposed and decision-dependent.

**4. Recommend the right disposition.** When the reported behaviour is by-design, recommend triage-as-Working-As-Designed; when the real ask is "give me this behaviour where it is currently (correctly) off", recommend handling it as an ENHANCEMENT request, not a bug. Never convert a working-as-designed complaint into Confirmed - or fix-shaped Proposed - acceptance criteria.

## Ask-First Clarification Workflow

Root cause of recurring misses: the plan is authored on assumptions and unknowns are only *documented* in Open Questions after the fact. This workflow makes discovery active and makes asking a required step, not an afterthought. Run it after the BehaviorModel and coverage-hypotheses passes, and BEFORE writing acceptance criteria.

**1. Enumerate the dimension space.** For the ticket, list every axis that could change behaviour, not just the one the Jira names:
- VALUE_SET_CHANNEL - every way a written value/property can be set: authoring UI, config/preset, source map/topic file, repository node via CRX/DE (`jcr:content/metadata`), API/import, migration.
- CODE_PATH_CONSUMER - every consumer of a touched shared path (base class/method, each output type/engine/caller/surface).
- OUTPUT_PRESET - AEM Sites (new/legacy), HTML5, Native AEM Site, Native PDF, DITA-OT PDF; and DITA-OT processing ON vs OFF for publishing tickets.
- TOPIC_TYPE, TERMINAL_STATE, LIFECYCLE, CONFIG_BRANCH, PERMISSION_ROLE, MIGRATION_PATH as applicable.

**2. Mark materiality.** For each candidate decide `material: true/false` with a one-line reason. Non-material axes are recorded and dropped; they are not carried as questions.

**3. Resolve from evidence first.** For each material dimension, try to answer from code (grep the handler for where the value is read/written), RAG, historical Jira, or the diff. Record the resolving `file:line` or evidence id. Do not ask the user what the evidence can answer.

**4. Ask the residual blocking questions - and WAIT.** For every material dimension still unresolved that would change an AC's correctness or scope, surface a concise, decision-shaped question to the user in chat and STOP. Do not author the governed AC on an assumption. Only genuinely non-blocking gaps (they do not change any AC, only add nice-to-have coverage) may be deferred straight to Open Questions.

**When to ask vs. resolve silently vs. defer:**
- ASK the user when the answer changes an AC's correctness, an in/out-of-scope decision, or the pass/fail oracle, AND the evidence cannot settle it (e.g. which source file a preset reads; whether an old endpoint is removed or kept; the approved SLA/threshold for a cited workload).
- RESOLVE SILENTLY when code/RAG/history answers it - cite the evidence, no question.
- DEFER to Open Questions only when the gap is non-blocking (adds coverage but does not change any AC or scope call).

**5. Confirm assumptions before posting.** Show the assumptions made and the draft AC wording in chat for confirm/correct BEFORE posting anywhere (Jira/file). Corrections belong before the post, not after.

**6. Record it in the manifest** `clarification` block (`dimension_space`, `questions_surfaced_to_user`, `authoring_gated_on_answers`) so `clarification_gate` can enforce that no material dimension was left UNRESOLVED and no blocking question was left unanswered. Never fabricate a user answer to pass the gate; a `WAITING` blocking question means authoring has not started.

## Hard Rules

- Keep acceptance criteria in the plan.
- Always state the lifecycle stage and apply its evidence requirements consistently.
- Always inspect relevant available product clones for current implementation and automation clones for coverage before declaring code or automation evidence unavailable.
- Never write `no backend/Starling clone available`, `none found`, or `full coverage gap` after searching only the opened automation workspace. Such conclusions require the bounded clone discovery protocol, separate product and automation searches, exact searched terms, and resolved clone paths.
- Never treat missing PR, changed files, or line counts as a blocker in `Pre-Development UAC`.
- Never present current implementation found in a clone as changed code unless a real diff proves the change.
- Never abbreviate cited repository or file paths with `...`, and never describe a clone as current from wall-clock recency such as `last commit today`; report its exact revision and sync state.
- Never hide, discard, or silently restore developer changes. A successful dirty-repo sync must retain a named stash and expose the exact restore command; a blocked sync must leave the worktree unchanged.
- Never promote an approximate incident runtime, dataset size, or resource recommendation into a pass/fail requirement without an approved SLA or controlled benchmark contract.
- Never add a `Performance Analysis`, `Performance Assessment`, or equivalent output section. The analysis is mandatory but internal; only a justified Performance AC or conditional QA-impact Open Question appears in the existing sections.
- Never treat `terminal success/failure` as sufficient for a workflow whose acceptance contract requires successful output; test success, output integrity, and retry-exhaustion failure as distinct outcomes.
- The canonical `aem-guides-ac-v2` record uses exact labels `AC-## [Confirmed]` or `AC-## [Proposed]`, one controlled sphere, a plain-English criterion followed by `Evidence: <source>.` (no Given/When/Then labels or pipes), contiguous IDs, and terminal punctuation; long criteria may carry short indented sub-points. The legacy `aem-guides-ac-v1` Given/When/Then grammar is still parsed for saved plans but is never produced. Reject a human-facing projection supplied as source, plus decorated labels, missing evidence, extra fields, duplicate IDs, and evidence-free ACs.
- Never use the compact renderer's `- AC-##:` projection as durable plan input, automation input, or Jira-posting input.
- Acceptance criteria describe observable product outcomes, not implementation choices. Keep node deletion, tracker reconciliation, mandatory workflow-step placement, single-source-of-truth architecture, lock type, retry mechanism, serialization strategy, and concrete cleanup commands in scenarios, code-impact analysis, or open questions unless Jira explicitly approves that implementation contract.
- A configuration-backed list is never treated as permanently closed merely because a screenshot, current default file, or implementation branch shows a finite set. When extensibility is in scope, require observable behavior for another valid configured entry; keep replacement of a hardcoded allowlist as code-impact or regression evidence unless accepted UAC explicitly makes it part of the product contract.
- Every non-incident P0/P1/P2 scenario must contain at least one `[AC-##]` mapping. `Incident recovery validation` bullets are the only traceability exemption.
- `Not suitable for automation` applies only to the destructive one-time production operation itself. Repeatable post-recovery product behavior on a production-equivalent environment is `Covered`, `Partially covered`, or `Not covered`.
- When one Jira connector requires authorization but another connected Jira MCP succeeds, omit the failed-connector warning from the final plan and report only the evidence source actually used.
- Never mutate Jira from an unvalidated draft, a failed/non-postable/stale receipt, a compact projection, or a caller-supplied `passed` string. Jira writes require explicit user approval, `--apply`, a current hash-bound receipt, a successful fresh strict extraction/render check, and a successful fail-closed read/recheck of the current Jira AC field.

## Quality-Gate Audit Requests

- When the user asks to audit a previous answer, first read `references/quality-gate-checklist.md` and run `scripts/validate_test_plan.py` against the previous plan when its text is available.
- List every validator failure plus evidence-quality failures that static validation cannot detect. Do not stop after the first few failures.
- Regenerate a complete record only after the failure list. Validate it with the same gate, then return the corrected four-section projection and retain the corrected eleven-section artifact for explicit requests.
- Do not retain an obsolete Jira-authorization warning when live Jira evidence was subsequently fetched successfully.
- Do not add extra headings such as `What can break`, `Likely bugs`, `Fix safety`, `Important combinations`, or `Draft blockers` beyond the required output sections.
- Put likely bugs, fix-safety, automation, and blocker notes under `Test Scenarios`, `Regression Areas`, or the relevant evidence section.
- Never call a plan `proper RAG-backed` when evidence is generic, unrelated, unavailable, or only keyword-matched.
- Never mark a plan ready when evidence required for its declared lifecycle stage or a sign-off-critical decision is missing. Do not impose implementation-stage PR, diff, or line-count requirements on pre-development UAC work.

## Golden Benchmark Release Qualification

- For test-plan skill or evidence-pipeline releases, run the blinded golden benchmark from `references/golden-benchmark.md` for both Codex and Claude variants after their self-tests pass.
- Treat seeded goldens as development-only. Only an independently reviewed `approved` manifest may establish a production baseline, and no metric may regress from that baseline.
- A benchmark failure blocks release qualification only; it must not bypass, replace, or break the normal single-ticket test-plan workflow.
