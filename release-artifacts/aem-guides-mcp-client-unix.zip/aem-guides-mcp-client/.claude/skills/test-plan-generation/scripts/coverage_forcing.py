"""Signal-activated, fail-closed coverage forcing.

WHY THIS EXISTS
---------------
The skill already owns rich coverage machinery (performance_contract,
ui_surface_scope, ac_decidability, disposition_classifier). But every one of
those gates is OPT-IN: it validates a block only once the manifest DECLARES it.
So when a plan is authored by hand and simply never declares a
``performance_assessment`` block or a ``ui_surface_scope`` block, the gate stays
dormant and the dimension is silently missed - the recurring failure where a
reviewer has to add the performance AC and the UI-surface ACs after the fact.

This gate closes that hole. It is PROACTIVE and FAIL-CLOSED: it reads the ticket
signals present in the plan text (and manifest) and, when a signal demands a
dimension, it REQUIRES that dimension to be dispositioned - covered in an AC,
raised as an Open Question, or explicitly opted out with a concrete reason -
before the plan can pass. It does not author anything; it forces a decision.

Representative conservatively-activated checks include:

  1. PERFORMANCE - a scale / timeout / resource signal in the plan requires a
     performance disposition (a Performance AC, a performance_assessment block
     with decision required|conditional, or opt-out ``performance_not_applicable``).
  2. UI SURFACE - naming a cataloged UI feature (data/ui_feature_surface_catalog.json)
     requires each of that feature's surfaces to be addressed in the plan, or
     dispositioned, or opted out with ``ui_surface_coverage_not_applicable``.
  3. INVESTIGATION-AS-AC - an Acceptance Criterion phrased as an investigation
     task ("confirm whether ...", "check if ... shipped") is not a sign-off
     criterion; it must move to Open Questions.
  4. AC REDUNDANCY - near-duplicate ACs must be merged into one product outcome.
  5. CONTRACT PRESENCE - a behavioral plan must contain at least one AC.
  6. HISTORY ATTEMPT - declared history work must record its search outcome.

Signal-specific opt-outs remain available where documented. A non-behavioral plan
skips contract presence only when behaviour_matters is explicitly false. Generic
only. Standard library only.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

CATALOG_PATH = Path(__file__).with_name("data") / "ui_feature_surface_catalog.json"

# Keep these mechanical thresholds aligned with scripts/uac_eval/precision.py.
OVER_DECOMPOSITION_MAX = 10
REDUNDANCY_JACCARD = 0.6

_AC_LABEL_RE = re.compile(r"\bAC[-\s]?(\d+)\b", re.IGNORECASE)
_BULLET_RE = re.compile(r"^\s*(?:[-*]|\d+[.)])\s+(.*\S)\s*$")
_AC_REDUNDANCY_STOP_WORDS = frozenset(
    "the a an and or of to in on for is are be that this it with as by from at "
    "should must will shall verify ensure when then given user should_be able "
    "not no if into their its each any all both which while".split()
)

# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def _extract_ac_block(plan_text: str) -> tuple[str, bool]:
    """Return only the acceptance-contract section and whether it was found.

    This intentionally mirrors scripts/uac_eval/precision.py. Missing sections do
    not fall back to the whole plan because unrelated bullets and AC references are
    not acceptance criteria.
    """
    if not plan_text:
        return "", False
    match = re.search(
        r"(?:^|\n)\s*(?:#{1,4}\s*|\*\*)\s*"
        r"(?:Proposed acceptance contract|Acceptance contract|Acceptance criteria)\b.*?"
        r"(?=\n\s*(?:#{1,4}\s*|\*\*)\s*[A-Z][A-Za-z /]{2,40}\b|\Z)",
        plan_text,
        re.S | re.I,
    )
    if match:
        return match.group(0).strip(), True
    return "", False


def _ac_items(block: str) -> list[str]:
    """Return one single-line item per AC, preferring explicit AC labels."""
    labelled: list[str] = []
    for raw in block.splitlines():
        line = raw.strip()
        if line and _AC_LABEL_RE.search(line):
            labelled.append(line)
    if labelled:
        return labelled

    items: list[str] = []
    for raw in block.splitlines():
        match = _BULLET_RE.match(raw)
        if match:
            items.append(match.group(1).strip())
    return items


def _content_words(text: str) -> set[str]:
    tokens = re.findall(r"[a-zA-Z][a-zA-Z0-9_.]+", text.lower())
    return {
        token
        for token in tokens
        if token not in _AC_REDUNDANCY_STOP_WORDS and len(token) > 2
    }


def _jaccard(left: set[str], right: set[str]) -> float:
    if not left or not right:
        return 0.0
    return len(left & right) / len(left | right)


def _plain_ac_text(text: str) -> str:
    """Make an offending AC safe to show in a plain-text gate reason."""
    cleaned = re.sub(r"^\s*(?:[-*]|\d+[.)])\s*", "", text.strip())
    cleaned = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r"\1 (\2)", cleaned)
    cleaned = cleaned.translate(str.maketrans("", "", "`*_~[]<>"))
    return " ".join(cleaned.split())


def _acceptance_block(plan_text: str) -> str:
    block, found = _extract_ac_block(plan_text)
    return block if found else ""


def _ac_lines(plan_text: str) -> list[str]:
    return _ac_items(_acceptance_block(plan_text))


def _opt_out_reason(manifest, key: str) -> str:
    if not isinstance(manifest, dict):
        return ""
    val = manifest.get(key)
    if isinstance(val, dict):
        return str(val.get("reason", "")).strip()
    if isinstance(val, str):
        return val.strip()
    return ""


# ---------------------------------------------------------------------------
# 1. Performance forcing
# ---------------------------------------------------------------------------

# Signals that a change concerns scale / responsiveness / resource use. Kept
# specific so ordinary functional tickets are not swept in.
PERF_SIGNAL_TERMS = (
    "503", "service unavailable", "timeout", "timed out", "time out",
    "out of memory", "oom", "hangs", "hang ", "spinner never",
    "large map", "large file", "large dataset", "big map",
    "performance", "scalab", "slow", "latency", "throughput",
    "too long", "does not respond", "unresponsive", "gateway",
    # duration / concurrency / bulk-load signals (a long-running or concurrent job is a
    # performance factor even when nothing 503s - missed on a false-failure output ticket
    # where generation ran minutes and overlapping jobs collided).
    "minutes later", "still running", "already running", "in progress",
    "overlap", "concurrent", "concurrenc", "simultaneous", "parallel",
    "bulk publish", "bulk generation", "queue", "backlog", "long-running",
    "long running",
)
# A cited duration such as "5-10 minutes", "300 s", "11 minutes".
_PERF_DURATION_RE = re.compile(
    r"\b\d+\s*(?:-\s*\d+\s*)?(?:sec|secs|second|seconds|s|min|mins|minute|minutes|hour|hours)\b",
    re.IGNORECASE,
)
# A quantified-workload hint strengthens the signal but is not required.
_PERF_SCALE_RE = re.compile(
    r"\b(\d{2,}[\d,]*)\s*(topics?|topicrefs?|files?|maps?|assets?|nodes?|rows?|entries|users?)\b",
    re.I,
)


def _has_perf_signal(plan_text: str) -> bool:
    low = (plan_text or "").lower()
    if any(term in low for term in PERF_SIGNAL_TERMS):
        return True
    if _PERF_SCALE_RE.search(plan_text or ""):
        return True
    return bool(_PERF_DURATION_RE.search(plan_text or ""))


def _has_performance_disposition(manifest, plan_text: str) -> bool:
    # (a) a Performance AC or Performance section in the plan
    low = (plan_text or "").lower()
    if re.search(r"performance", low) and re.search(r"\bac[-\s]?\d", low):
        # a Performance AC line exists
        for line in _ac_lines(plan_text):
            if "perform" in line.lower() or "within" in line.lower() and "timeout" in low:
                return True
    if re.search(r"\*\*performance", low):  # a dedicated Performance section
        return True
    # (b) a declared performance_assessment with an active decision
    if isinstance(manifest, dict):
        pa = manifest.get("performance_assessment")
        if isinstance(pa, dict) and str(pa.get("decision", "")).strip() in ("required", "conditional"):
            return True
    # (c) a performance-conditional Open Question (the correct disposition when a workload
    # is cited but no approved SLA exists - conditional, not a faked numeric AC).
    for line in plan_text.splitlines() if plan_text else []:
        if re.search(r"\bOQ[-\s]?\d", line, re.I) and re.search(
            r"\b(?:performance|sla|workload|throughput|latency|duration|scale|"
            r"concurrent|baseline|response\s+time)\b", line, re.I):
            return True
    return False


def _validate_performance(manifest, plan_text: str) -> list[str]:
    if not _has_perf_signal(plan_text):
        return []
    if len(_opt_out_reason(manifest, "performance_not_applicable")) >= 12:
        return []
    if _has_performance_disposition(manifest, plan_text):
        return []
    return [
        "A scale / timeout / resource signal is present but performance is not "
        "dispositioned. Add a Performance AC (bind it to the enforced platform "
        "limit whose breach causes the failure; defer any numeric SLA to Open "
        "Questions), or declare a performance_assessment block with decision "
        "required|conditional, or set performance_not_applicable with a concrete reason."
    ]


# ---------------------------------------------------------------------------
# 2. UI surface forcing
# ---------------------------------------------------------------------------

def _load_feature_catalog(path=None):
    p = Path(path) if path is not None else CATALOG_PATH
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return data if isinstance(data, dict) else {}


def _feature_named(plan_text: str, entry: dict) -> bool:
    low = (plan_text or "").lower()
    names = [entry.get("label", "")] + list(entry.get("aliases", []))
    return any(n and n.lower() in low for n in names)


def _surface_addressed(plan_text: str, surface: dict) -> bool:
    low = (plan_text or "").lower()
    return any(term and term.lower() in low for term in surface.get("terms", []))


def _ui_dispositioned(manifest, feature_slug: str, surface_id: str) -> bool:
    if not isinstance(manifest, dict):
        return False
    cov = manifest.get("ui_surface_coverage")
    if not isinstance(cov, dict):
        return False
    feat = cov.get(feature_slug)
    if not isinstance(feat, dict):
        return False
    entry = feat.get(surface_id)
    if isinstance(entry, dict):
        return len(str(entry.get("reason", "")).strip()) >= 8 and bool(str(entry.get("disposition", "")).strip())
    return False


def _validate_ui_surface(manifest, plan_text: str, catalog_path=None) -> list[str]:
    catalog = _load_feature_catalog(catalog_path)
    if not catalog:
        return []
    if len(_opt_out_reason(manifest, "ui_surface_coverage_not_applicable")) >= 12:
        return []
    problems: list[str] = []
    for slug, entry in catalog.items():
        if not isinstance(entry, dict) or not _feature_named(plan_text, entry):
            continue
        for surface in entry.get("surfaces", []):
            sid = surface.get("id", "")
            if _surface_addressed(plan_text, surface):
                continue
            if _ui_dispositioned(manifest, slug, sid):
                continue
            problems.append(
                f"UI feature {entry.get('label', slug)!r}: surface "
                f"{surface.get('label', sid)!r} is not addressed. Cover it in an AC, "
                f"raise it as an Open Question, or disposition it in "
                f"ui_surface_coverage.{slug}.{sid} with a reason "
                f"(or set ui_surface_coverage_not_applicable for the whole feature)."
            )
    return problems


# ---------------------------------------------------------------------------
# 3. Investigation-as-AC
# ---------------------------------------------------------------------------

INVESTIGATION_RES = (
    re.compile(r"\bconfirm whether\b", re.I),
    re.compile(r"\b(check|verify|determine|establish)\s+(whether|if)\b", re.I),
    re.compile(r"\bfind out\b", re.I),
    re.compile(r"\binvestigate\b", re.I),
    re.compile(r"\bis (?:the |a )?(?:prior |previous )?fix (?:present|included|shipped)\b", re.I),
    re.compile(r"\b(did|whether)\b.*\b(ship|shipped|reach(?:ed)? this build|land(?:ed)?)\b", re.I),
    re.compile(r"\bresolve[d]? the .*claim\b", re.I),
)


def _validate_investigation(manifest, plan_text: str) -> list[str]:
    problems: list[str] = []
    for line in _ac_lines(plan_text):
        for rx in INVESTIGATION_RES:
            if rx.search(line):
                snippet = line[:80]
                problems.append(
                    "An Acceptance Criterion is phrased as an investigation task, not a "
                    f"decidable sign-off criterion: {snippet!r}. Move it to Open Questions."
                )
                break
    return problems


# An added/unit/automation/regression test passing or covering something is Automation
# Coverage EVIDENCE, never an acceptance criterion (non-negotiable). Flag the shape in AC
# lines. Scans only AC bullets, so a separate "Automation Coverage" verdict line is fine.
_TEST_AS_AC_RES = (
    re.compile(r"\b(?:added|unit|automation|new|regression|integration)\b[\w\s,'-]{0,30}\btests?\b", re.I),
    re.compile(r"\btests?\b[\w\s,'-]{0,30}\b(?:pass(?:es|ing)?|is green|are green|covers?|added)\b", re.I),
    re.compile(r"\b[\w/.-]+\.test\.(?:ts|js|py|java)\b|\btest\.(?:ts|js|py)\b", re.I),
    re.compile(r"\bautomation\s+(?:pr|test|suite)\b", re.I),
)


def _oq_lines(plan_text: str) -> list[str]:
    m = re.search(r"\*\*Open Questions\*\*(.*?)(?:\n\*\*|\Z)", plan_text or "", re.S)
    block = m.group(1) if m else ""
    lines = []
    for raw in block.splitlines():
        s = raw.strip()
        if s.startswith(("-", "*")) or re.match(r"^OQ[-\s]?\d", s, re.I):
            lines.append(s)
    return lines


# Only an OQ that cites an AC as its ANSWER/authority ("per AC-7", "see AC-7", "as
# decided in AC-7") contradicts a decided AC. An OQ that references an AC as the thing it
# BOUNDS/completes ("so AC-3 is testable") is a legitimate scope question, not a contradiction.
_AC_ANSWER_REF_RE = re.compile(
    r"\b(?:per|see|as (?:per|decided|stated|in)|answered by|already (?:in|decided in|covered by))\s+AC[-\s]?\d+\b",
    re.I,
)
_RESTATED_INSTANCE_RE = re.compile(
    r"\bthe (?:exact|specific|reported|above) (?:reported )?(?:case|scenario|example|bug)\b"
    r".{0,40}\b(?:pass(?:es)?|is fixed|works|resolves)\b",
    re.I,
)


def _validate_ac_oq_contradiction(manifest, plan_text: str) -> list[str]:
    # An Open Question that cites an AC is confirming something an AC already decides -
    # a decided AC and an open question about the same thing contradict. Decide it in the
    # AC or make it an OQ, not both (for example OQ-1 "per AC-7" vs AC-7).
    problems: list[str] = []
    for line in _oq_lines(plan_text):
        m = _AC_ANSWER_REF_RE.search(line)
        if m:
            ref = m.group(0)
            problems.append(
                f"An Open Question references {ref} ({line[:70]!r}). If that AC already "
                "decides the behaviour, the Open Question is redundant/contradictory - keep "
                "it decided in the AC and remove the OQ, or make it a genuine OQ and drop "
                "the AC's assertion."
            )
    return problems


def _validate_restated_instance_ac(manifest, plan_text: str) -> list[str]:
    # An AC phrased as "the exact reported case passes" usually just restates the specific
    # instance of a general behavioural AC - fold the example into the general AC instead.
    problems: list[str] = []
    for line in _ac_lines(plan_text):
        if _RESTATED_INSTANCE_RE.search(line):
            problems.append(
                f"An Acceptance Criterion restates the specific reported instance "
                f"({line[:70]!r}). Fold the concrete example into the general behavioural AC "
                "rather than keeping a separate 'the reported case passes' AC."
            )
    return problems


_XML_TAG_RE = re.compile(r"<[a-zA-Z][\w:-]*(?:\s|>|/)")


def _validate_no_markup_in_ac(manifest, plan_text: str) -> list[str]:
    # ACs are plain QE English: no code fences and no raw XML/DITA markup. Describe the
    # condition in words ("a key definition with a blank keys attribute"), not <keydef keys="">.
    block = _acceptance_block(plan_text)
    problems: list[str] = []
    if "```" in block:
        problems.append(
            "The Acceptance Criteria contain a code block (```). ACs must be plain English "
            "- describe the condition in words, not embedded markup or code."
        )
    m = _XML_TAG_RE.search(block)
    if m:
        problems.append(
            f"The Acceptance Criteria contain raw markup/XML ({block[m.start():m.start()+24]!r}). "
            "Describe it in plain English (e.g. 'a key definition with a blank keys attribute'), "
            "not literal tags."
        )
    return problems


def _validate_ac_over_decomposition(manifest, plan_text: str) -> list[str]:
    # One behaviour split into a separate AC per micro-variation (blank vs missing, per
    # surface, per edit transition, per structure) produces a bloated, unreadable UAC. A
    # high AC count is a strong over-decomposition signal; generalize into fewer ACs.
    nums = set(re.findall(r"\bAC[-\s]?(\d+)\b", _acceptance_block(plan_text), re.I))
    if len(nums) > OVER_DECOMPOSITION_MAX:
        return [
            f"{len(nums)} acceptance criteria - this is over-decomposed. Generalize "
            "micro-variations (blank vs missing, per surface, per edit transition, per "
            "structure) into fewer behavioural ACs; prefer the fewest ACs that cover the "
            "behaviour, with examples inside an AC rather than a new AC per case. Move "
            "path-divergence or surface-relevance uncertainties to Open Questions."
        ]
    return []


def _validate_no_test_as_ac(manifest, plan_text: str) -> list[str]:
    problems: list[str] = []
    for line in _ac_lines(plan_text):
        if any(rx.search(line) for rx in _TEST_AS_AC_RES):
            problems.append(
                "An Acceptance Criterion asserts that a test/automation passes or covers "
                f"something: {line[:80]!r}. A test is Automation Coverage evidence, never an "
                "AC (non-negotiable). State the observable product behaviour as the AC and "
                "record the test in an Automation Coverage line."
            )
    return problems


# ---------------------------------------------------------------------------
# 4. Mechanical acceptance-contract and history checks
# ---------------------------------------------------------------------------

def _ac_item_name(item: str, index: int) -> str:
    match = _AC_LABEL_RE.search(item)
    if match:
        return f"AC-{int(match.group(1)):02d}"
    return f"acceptance item {index}"


def _validate_ac_redundancy(combined: str) -> list[str]:
    """Fail when two acceptance items are lexical near-duplicates."""
    block, found = _extract_ac_block(combined)
    if not found:
        return []
    items = _ac_items(block)
    word_sets = [_content_words(item) for item in items]
    problems: list[str] = []
    for left_index, left in enumerate(items):
        for right_index in range(left_index + 1, len(items)):
            similarity = _jaccard(word_sets[left_index], word_sets[right_index])
            if similarity < REDUNDANCY_JACCARD:
                continue
            right = items[right_index]
            left_name = _ac_item_name(left, left_index + 1)
            right_name = _ac_item_name(right, right_index + 1)
            problems.append(
                f"{left_name} and {right_name} are near-duplicate acceptance criteria "
                f"(content-word overlap {similarity:.2f}; limit {REDUNDANCY_JACCARD:.2f}). "
                f"Merge them into one product outcome. {left_name} text: "
                f"{_plain_ac_text(left)}. {right_name} text: {_plain_ac_text(right)}."
            )
    return problems


def _validate_acceptance_contract_present(combined: str, manifest) -> list[str]:
    """Require a non-empty acceptance contract for behavioral plans."""
    if isinstance(manifest, dict) and manifest.get("behaviour_matters") is False:
        return []
    block, found = _extract_ac_block(combined)
    if not found:
        return [
            "This behavioral plan has no Acceptance contract or Acceptance criteria "
            "section. Add the product acceptance contract, or explicitly set "
            "behaviour_matters to false for a genuinely non-behavioral change."
        ]
    if not _ac_items(block):
        return [
            "The Acceptance contract or Acceptance criteria section contains no "
            "acceptance items. Add at least one observable product outcome."
        ]
    return []


_HISTORY_INTENT_KEYS = frozenset(
    {
        "evidence_lifecycle",
        "history_attempts",
        "indexed_history_run",
        "jira_history_queries",
        "jira_history_tool",
        "jira_history_unavailable_reason",
        "known_bugs",
        "known_bugs_intent",
        "known_bugs_search_intent",
        "known_jira_bugs",
        "known_jira_bugs_intent",
        "past_similar_tickets",
        "jira_history_intent",
    }
)
_KNOWN_BUG_COLLECTION_KEYS = (
    "known_bugs",
    "known_jira_bugs",
    "past_similar_tickets",
)
_HISTORY_RESULTS = frozenset({"ok", "unavailable", "empty"})


def _declares_history_intent(manifest) -> bool:
    return isinstance(manifest, dict) and any(
        key in manifest for key in _HISTORY_INTENT_KEYS
    )


def _declares_thin_history(manifest: dict) -> bool:
    queries = manifest.get("jira_history_queries")
    if isinstance(queries, list) and not queries:
        return True
    for key in _KNOWN_BUG_COLLECTION_KEYS:
        if key not in manifest:
            continue
        value = manifest.get(key)
        if value is None or value == "" or value == [] or value == {}:
            return True
    return False


def _validate_history_attempt_recorded(manifest) -> list[str]:
    """Require deterministic attempt records whenever history is in scope."""
    if not _declares_history_intent(manifest):
        return []

    attempts = manifest.get("history_attempts")
    if not isinstance(attempts, list) or not attempts:
        return [
            "History or Known Jira Bugs evidence is in scope, but history_attempts "
            "does not record any search. Add at least one attempt with source, query, "
            "result, and count; record unavailable or empty instead of leaving a silent gap."
        ]

    problems: list[str] = []
    valid_outcomes: list[str] = []
    for index, attempt in enumerate(attempts, start=1):
        prefix = f"history_attempts item {index}"
        if not isinstance(attempt, dict):
            problems.append(f"{prefix} must be an object.")
            continue
        source = attempt.get("source")
        query = attempt.get("query")
        result = attempt.get("result")
        count = attempt.get("count")
        if not isinstance(source, str) or not source.strip():
            problems.append(f"{prefix} must have a non-empty source.")
        if not isinstance(query, str) or not query.strip():
            problems.append(f"{prefix} must have a non-empty query.")
        if result not in _HISTORY_RESULTS:
            allowed = ", ".join(sorted(_HISTORY_RESULTS))
            problems.append(f"{prefix} result must be one of: {allowed}.")
        else:
            valid_outcomes.append(result)
        if isinstance(count, bool) or not isinstance(count, int) or count < 0:
            problems.append(f"{prefix} count must be a non-negative integer.")
        elif result == "ok" and count == 0:
            problems.append(f"{prefix} must use result empty when count is zero.")
        elif result in {"empty", "unavailable"} and count != 0:
            problems.append(f"{prefix} count must be zero when result is {result}.")

    if (
        _declares_thin_history(manifest)
        and valid_outcomes
        and not {"empty", "unavailable"}.intersection(valid_outcomes)
    ):
        problems.append(
            "The manifest records an empty history query or Known Jira Bugs result, "
            "but no history attempt is marked empty or unavailable. Record the visible "
            "reason for the thin result."
        )
    return problems


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# 4. No code identifiers in acceptance criteria (plain-English rule)
# ---------------------------------------------------------------------------
# An AC must read as plain QE English: no method/class/function/file identifiers.
# High-confidence code shapes only, so ordinary prose and legitimate product
# config keys (snake_case / dotted like postprocess.temporary.langcopies) are not
# flagged. Trace the code in the background; state the observable behaviour in the AC.
_CODE_CLASS_METHOD_RE = re.compile(r"\b[A-Z][A-Za-z0-9]+\.[a-z][A-Za-z0-9_]+")   # PublishWorkflowStep.handlePartialPublish
_CODE_CAMEL_RE = re.compile(r"\b[a-z][a-z0-9]*[A-Z][A-Za-z0-9]*\b")              # handlePartialPublish, filterListTopics
_CODE_PASCAL_RE = re.compile(r"\b(?:[A-Z][a-z0-9]+){3,}\b")                       # PublishWorkflowStep (3+ humps)
_CODE_FILE_RE = re.compile(r"\b[\w/]+\.(?:java|py|js|ts|tsx|jsx|xsl|xslt)\b", re.I)
_CODE_FILELINE_RE = re.compile(r"\b[\w./-]+:\d+\b")
# camelCase/Pascal tokens that are real product/brand terms, not code identifiers.
_CODE_ALLOWLIST = {
    "aemaacs", "javascript", "typescript", "github", "gitlab", "powershell",
    "nodejs", "jira", "devops", "ios", "macos", "openapi", "mathml", "svg",
}


def _validate_plain_language(plan_text: str) -> list[str]:
    problems: list[str] = []
    for line in _ac_lines(plan_text):
        hits: list[str] = []
        for rx in (_CODE_CLASS_METHOD_RE, _CODE_CAMEL_RE, _CODE_PASCAL_RE,
                   _CODE_FILE_RE, _CODE_FILELINE_RE):
            for m in rx.findall(line):
                tok = m if isinstance(m, str) else m[0]
                if tok.casefold() in _CODE_ALLOWLIST:
                    continue
                hits.append(tok)
        if hits:
            problems.append(
                "An Acceptance Criterion contains code identifiers "
                f"({', '.join(sorted(set(hits))[:4])}); ACs must be plain QE-readable "
                "English. Trace the code in the background, then state the observable "
                f"behaviour instead: {line[:70]!r}"
            )
    return problems


# ---------------------------------------------------------------------------
# 5. Current-status recency and error-surface UI dispositioning
# ---------------------------------------------------------------------------

# A recent comment/evidence saying the reported behaviour now works or is partly
# resolved. reproducibility_gate covers the CANNOT-reproduce case; this covers the
# opposite miss - drafting fix-ACs over behaviour a latest comment says already works
# (e.g. a recent comment reporting the operation now works on stage/prod while a fix-AC
# still asserts that operation must succeed).
_WORKS_NOW_RE = re.compile(
    r"\b(?:working\s+fine|works\s+fine|now\s+works|no\s+longer\s+reproduc|"
    r"already\s+(?:works|fixed)|is\s+working\s+(?:fine|now)|"
    r"resolved\s+(?:on|in)\s+(?:stage|prod|production|develop)|partially\s+resolved|"
    r"currently\s+works|fixed\s+in\s+(?:develop|the\s+latest))\b",
    re.IGNORECASE,
)
_STATUS_ACK_RE = re.compile(
    r"\b(?:no\s+longer\s+reproduc|now\s+works|works\s+now|already\s+works|"
    r"currently\s+works|partially\s+resolved|working\s+fine|resolved\s+on|"
    r"remaining\s+(?:issue|scope)|still\s+(?:fails|returns|503|errors))\b",
    re.IGNORECASE,
)
# A server-error surface the user actually sees.
_ERROR_SURFACE_RE = re.compile(
    r"\b(?:503|502|500|5xx|service\s+unavailable|gateway\s+timeout|"
    r"internal\s+server\s+error|File\s+is\s+not\s+valid)\b",
    re.IGNORECASE,
)
_ERROR_UI_CONTEXT_RE = re.compile(
    r"\b(?:editor|panel|dialog|screen|message|shows?|display(?:s|ed)?|surfaces?d?|"
    r"user|UI|notification|toast)\b",
    re.IGNORECASE,
)
_ERROR_UI_DISPOSITION_RE = re.compile(
    r"\b(?:unavailable|error\s+message|message\s+(?:shown|displayed|is)|"
    r"on\s+(?:failure|error|503|5xx)|behaviou?r\s+on\b|surface[sd]?\b|retry|"
    r"what\s+(?:the\s+)?(?:editor|ui|user)\s+(?:sees|should|does)|notify|"
    r"notification|warning|blocked\s+from|allowed\s+to\s+save)\b",
    re.IGNORECASE,
)


def _manifest_issue_text(manifest) -> str:
    """Flatten the manifest's issue summary/description/comments so a comment-borne
    signal (e.g. 'validatexml is working fine on stage and prod') is visible to gates."""
    if not isinstance(manifest, dict):
        return ""
    parts: list[str] = []
    issue = manifest.get("issue")
    if isinstance(issue, dict):
        for key in ("summary", "description"):
            parts.append(str(issue.get(key, "")))
        comments = issue.get("comments")
        if comments is None:
            comments = issue.get("comment")
        if isinstance(comments, dict):
            comments = comments.get("comments")
        if isinstance(comments, list):
            for entry in comments:
                parts.append(str(entry.get("body", "") if isinstance(entry, dict) else entry))
        elif isinstance(comments, str):
            parts.append(comments)
    for key in ("current_status_signals", "comments_text"):
        value = manifest.get(key)
        if isinstance(value, str):
            parts.append(value)
        elif isinstance(value, list):
            parts.append(" ".join(str(x) for x in value))
    return "\n".join(parts)


def _validate_current_status_recency(manifest, plan_text: str) -> list[str]:
    """Fail when evidence says the behaviour now works / is partly resolved but the plan
    neither reflects that current status nor raises it as an Open Question and still ships
    acceptance criteria. Forces the author to read the latest comments before drafting."""
    evidence = _manifest_issue_text(manifest)
    if not _WORKS_NOW_RE.search(evidence):
        return []
    reflected = bool(
        _WORKS_NOW_RE.search(plan_text)
        or _STATUS_ACK_RE.search(plan_text)
        or re.search(r"\bOQ[-\s]?\d+\b", plan_text)
    )
    has_acs = bool(re.search(r"\bAC[-\s]?\d+\b", _acceptance_block(plan_text), re.I))
    if has_acs and not reflected:
        return [
            "A recent comment/evidence says the reported behaviour now works or is "
            "partially resolved (works-now signal), but the plan neither reflects the "
            "current status nor raises it as an Open Question and still asserts acceptance "
            "criteria. Run the reproducibility / working-as-designed assessment: confirm "
            "what still reproduces, scope the plan to the remaining issue, and do not draft "
            "fix-ACs for behaviour a comment says already works."
        ]
    return []


def _validate_error_surface_open_question(manifest, plan_text: str) -> list[str]:
    """Fail when evidence shows a user-facing server error (503 / service unavailable /
    'File is not valid') but no AC or Open Question dispositions what the UI should do on
    that error (message, whether the action is blocked/allowed/retried, panel state)."""
    hay = (plan_text or "") + "\n" + _manifest_issue_text(manifest)
    if not (_ERROR_SURFACE_RE.search(hay) and _ERROR_UI_CONTEXT_RE.search(hay)):
        return []
    disposition_lines = [
        line for line in (plan_text or "").splitlines()
        if re.search(r"\b(?:OQ|AC)[-\s]?\d+\b", line)
    ]
    if any(_ERROR_UI_DISPOSITION_RE.search(line) for line in disposition_lines):
        return []
    return [
        "The evidence shows a user-facing server error surface (for example 503 / service "
        "unavailable / 'File is not valid'), but no Acceptance Criterion or Open Question "
        "dispositions what the UI should do on that error: the exact message shown to the "
        "user, whether the action is blocked, allowed, or retried, and the panel/error "
        "state. Add it as an Open Question (or an AC once the behaviour is decided)."
    ]


# ---------------------------------------------------------------------------
# 6. Status-mislabel anti-over-correction and concurrency isolation
# ---------------------------------------------------------------------------

# A status-reporting defect: a run's shown status is wrong (a success shown as a
# failure, a false/red/stale failure, "failed but the files were produced").
_STATUS_MISLABEL_RE = re.compile(
    r"(?:incorrectly|false(?:ly)?|wrong(?:ly)?|erroneous|mis(?:label|report)|appears?|"
    r"shown\s+as|flag(?:s|ged)?|red)\b[^.\n]{0,60}\bfail",
    re.IGNORECASE,
)
_STATUS_FALSEPOS_RE = re.compile(
    r"\bfail\w*\b[^.\n]{0,80}\b(?:but|even\s+though|while|although)\b[^.\n]{0,80}"
    r"(?:succe|produced|complete|generated|correct)",
    re.IGNORECASE,
)
# The anti-over-correction guard: fixing a false failure must not start masking real ones.
_ANTI_OVERCORRECT_RE = re.compile(
    r"\b(?:genuine|real|actual|true)\b[^.\n]{0,40}\bfail|"
    r"\bfail\w*\b[^.\n]{0,40}\b(?:remain|still|stay)\b|"
    r"cancell?ed\b[^.\n]{0,30}\b(?:remain|stay|still)|"
    r"warning\b[^.\n]{0,30}(?:retain|remain|kept|keep)",
    re.IGNORECASE,
)
# Concurrency / overlap signal.
_CONCURRENCY_RE = re.compile(
    r"\b(?:overlap|concurren|already\s+running|still\s+running|"
    r"previous\s+(?:job|run|execution)|in\s+progress|simultaneou|parallel\s+job|"
    r"same\s+map\s+and\s+preset)\b",
    re.IGNORECASE,
)
# Isolation disposition: a rejected/aborted request keeps its own status, and unrelated
# work is unaffected.
_ISOLATION_RE = re.compile(
    r"\b(?:isolat|does\s+not\s+(?:affect|change)|unaffected|not\s+(?:appear|be\s+shown)\s+"
    r"success|other\s+(?:maps?|presets?|jobs?|runs?)|rejected\s+request|independent(?:ly)?|"
    r"own\s+(?:status|result|state))\b",
    re.IGNORECASE,
)


def _validate_status_anti_overcorrection(manifest, plan_text: str) -> list[str]:
    """When the ticket is about a wrong/false run status (a success shown as Failed), the
    plan must also assert that GENUINE failures still show Failed - otherwise the fix can
    over-correct and mask real failures. Missed on a false-failure output-status ticket."""
    evidence = (plan_text or "") + "\n" + _manifest_issue_text(manifest)
    if not (_STATUS_MISLABEL_RE.search(evidence) or _STATUS_FALSEPOS_RE.search(evidence)):
        return []
    if any(_ANTI_OVERCORRECT_RE.search(line) for line in _ac_lines(plan_text)):
        return []
    return [
        "This is a wrong/false run-status ticket (a successful or in-progress run is shown "
        "as Failed), but no acceptance criterion guards against over-correcting: add an AC "
        "that genuine failures still show Failed (and cancelled runs stay Cancelled, "
        "successful-with-warnings keep their warning) so the fix does not start masking real "
        "failures."
    ]


def _validate_concurrency_isolation(manifest, plan_text: str) -> list[str]:
    """When the defect involves overlapping/concurrent runs, the plan must disposition
    isolation: a rejected/aborted overlapping request keeps its own correct status (it is
    not shown as the sibling run's success), and unrelated maps/presets/jobs are
    unaffected. Missed on a concurrent-output-generation ticket."""
    evidence = (plan_text or "") + "\n" + _manifest_issue_text(manifest)
    if not _CONCURRENCY_RE.search(evidence):
        return []
    lines = [
        line for line in (plan_text or "").splitlines()
        if re.search(r"\b(?:AC|OQ)[-\s]?\d+\b", line)
    ]
    if any(_ISOLATION_RE.search(line) for line in lines):
        return []
    return [
        "This defect involves overlapping/concurrent runs, but no acceptance criterion or "
        "Open Question dispositions isolation: assert that a rejected or aborted overlapping "
        "request keeps its own correct status (it is not shown as the other run's success), "
        "and that unrelated maps, presets, or jobs keep their own status, links, and logs."
    ]


# A vague collective surface reference ("both dashboards", "the dashboards", "both
# panels") instead of the exact screen names. plain-language-ac-writing requires the exact
# screen name; this makes it fail-closed so a plural collective cannot stand in for the
# named surfaces (missed by writing "both dashboards" where the ticket named the Map
# Dashboard Outputs tab and the Bulk Publish dashboard).
_VAGUE_SURFACE_RE = re.compile(
    r"\b(?:both|all|either|the)\s+(?:dashboards|panels|screens|views|tabs|surfaces|dialogs)\b",
    re.IGNORECASE,
)


def _validate_vague_surface_reference(manifest, plan_text: str) -> list[str]:
    """Fail an acceptance criterion that refers to a vague collective UI surface (e.g.
    'both dashboards', 'the panels') instead of naming each exact screen. Singular named
    surfaces such as 'the Map Dashboard Outputs tab' or 'the Bulk Publish dashboard' pass."""
    problems: list[str] = []
    for line in _ac_lines(plan_text):
        match = _VAGUE_SURFACE_RE.search(line)
        if match:
            problems.append(
                f"An acceptance criterion names a vague collective surface "
                f"({match.group(0)!r}): name each exact screen instead (for example the Map "
                f"Dashboard Outputs tab and the Bulk Publish dashboard). Line: {line[:70]!r}."
            )
    return problems


# A vague/underspecified qualifier in an acceptance criterion. The reviewer must spell out
# WHAT and WHERE in plain words instead of leaning on a placeholder qualifier the reader
# then has to decode. Example the user rejected: "the configured output folder" (spell it
# out: "the output folder set in that preset"). Kept narrow on purpose so it fires on genuine
# hand-waving, not on any use of the word "configured".
_UNDERSPECIFIED_TERM_RE = re.compile(
    r"\bthe\s+configured\s+(?:output\s+)?(?:folder|location|destination|path|directory)\b"
    r"|\b(?:appropriate|relevant|corresponding|respective)\s+"
    r"(?:folder|location|preset|dashboard|screen|status|value|setting|option)\b"
    r"|\bas\s+(?:applicable|appropriate)\b",
    re.IGNORECASE,
)


def _validate_underspecified_terms(manifest, plan_text: str) -> list[str]:
    """Fail an acceptance criterion that uses a vague placeholder qualifier ('the configured
    output folder', 'the appropriate preset', 'as applicable') instead of spelling out what
    and where in plain words. plain-language-ac-writing requires the concrete thing named."""
    problems: list[str] = []
    for line in _ac_lines(plan_text):
        match = _UNDERSPECIFIED_TERM_RE.search(line)
        if match:
            problems.append(
                f"An acceptance criterion uses a vague placeholder term "
                f"({match.group(0)!r}): spell out what and where in plain words instead "
                f"(for example write 'the output folder set in that preset' rather than "
                f"'the configured output folder'). Line: {line[:70]!r}."
            )
    return problems


# A translation/localization ticket names a specific reported language, but the fix is
# language-agnostic - the AC set must generalize across every supported target language
# (naming one language as the reported case only), or explicitly bound scope to one. This
# catches the recurring "customer wrote German, so I only wrote German" miss.
_LOCALIZATION_SIGNAL_RE = re.compile(
    r"\b(translat(?:e|ion|ing|ed)|locali[sz]ation|locali[sz]ed|xliff|multilingual|"
    r"target\s+language|source\s+language|translation\s+project)\b", re.IGNORECASE)
_LANGUAGE_NAME_RE = re.compile(
    r"\b(german|french|spanish|japanese|chinese|italian|portuguese|korean|russian|dutch|"
    r"polish|swedish|danish|norwegian|finnish|czech|hungarian|turkish|arabic|hebrew|thai|"
    r"vietnamese|hindi|greek|romanian|ukrainian)\b", re.IGNORECASE)
_LANG_GENERALIZATION_RE = re.compile(
    r"(all|every|each|any)\s+(supported\s+)?(target\s+)?languages?|"
    r"regardless\s+of\s+(the\s+)?(target\s+)?language|not\s+only\s+\w+|language[-\s]agnostic|"
    r"across\s+(all\s+)?languages|every\s+locale|all\s+locales|any\s+target\s+language", re.IGNORECASE)


def _validate_language_generalization(manifest, plan_text: str) -> list[str]:
    """On a translation/localization ticket, fail if the ACs name a specific language but
    never generalize across all supported target languages (the reported language is only an
    example). An explicit generalization phrase or a single-language scope bound satisfies it."""
    issue = (manifest or {}).get("issue", {}) if isinstance(manifest, dict) else {}
    ticket_text = " ".join(str(issue.get(k, "")) for k in ("summary", "description"))
    if not _LOCALIZATION_SIGNAL_RE.search(ticket_text) and not _LOCALIZATION_SIGNAL_RE.search(plan_text):
        return []
    ac_block = "\n".join(_ac_lines(plan_text))
    names_language = bool(_LANGUAGE_NAME_RE.search(ac_block) or _LANGUAGE_NAME_RE.search(ticket_text))
    if not names_language:
        return []
    if _LANG_GENERALIZATION_RE.search(plan_text):
        return []
    return [
        "This is a translation/localization ticket that cites a specific language, but no "
        "acceptance criterion generalizes the behaviour across all supported target languages "
        "(the reported language is only an example). Add an AC that the fix applies to every "
        "supported target language - not only the reported one - or explicitly bound the scope "
        "to a single language."
    ]


def _validate_guides_vocabulary(manifest, plan_text: str) -> list[str]:
    """Fail an acceptance criterion that names a non-existent AEM Guides product
    concept from the curated guides_vocabulary block list (e.g. 'stale preset').
    Advisories (correct-term nudges) are not returned here; run guides_vocabulary.py
    --check for those. Fail-open if the library module/file is unavailable."""
    try:
        import guides_vocabulary as gv  # noqa: PLC0415
    except Exception:  # noqa: BLE001
        return []
    try:
        return gv.validate(plan_text)
    except Exception:  # noqa: BLE001
        return []


# ---------------------------------------------------------------------------
# 7. Content-transformation (paste / import / convert) variant enumeration
# ---------------------------------------------------------------------------

# A content-transformation ticket: pasting, importing, converting, or clipboard/drag-drop.
_TRANSFORM_SIGNAL_RE = re.compile(
    r"\b(?:past(?:e|ing|ed|es)\w*|copy\s*past\w*|import\w*|convert\w*|conversion|"
    r"clipboard|drag\s+and\s+drop)\b",
    re.IGNORECASE,
)
# A table ticket.
_TABLE_SIGNAL_RE = re.compile(
    r"\b(?:table|thead|tgroup|cals|colspec|header\s+cell|header\s+row)\b", re.IGNORECASE,
)
# The predictable variant axes for a table paste/import/convert ticket. Each axis is
# "addressed" when any of its keywords appears anywhere in the plan (an AC, an Open
# Question, or scope) - so the author must at least disposition it, even to bound scope.
_TABLE_VARIANT_AXES = {
    "source apps (Word / Excel / Google Doc / HTML)":
        re.compile(r"\b(?:word|excel|google\s*doc|html|powerpoint|office\s+doc|clipboard)\b", re.I),
    "nested tables":
        re.compile(r"\bnested\b", re.I),
    "merged / spanned cells":
        re.compile(r"\b(?:merged|span(?:ned|s)?|colspan|morerows|namest|nameend)\b", re.I),
    "multiple / repeat header rows":
        re.compile(r"\b(?:multiple\s+header|repeat\s+header|header\s+rows|multiple\s+heading)\b", re.I),
    "simple table vs normal table":
        re.compile(r"\b(?:simple\s*table|simpletable|normal\s+table)\b", re.I),
    "topic types (concept / reference / task)":
        re.compile(r"\b(?:concept|reference|task|glossary|topic\s+type|bookmap)\b", re.I),
    "editor scope (new / old editor)":
        re.compile(r"\b(?:new\s+editor|old\s+editor|legacy\s+editor|both\s+editors)\b", re.I),
}


def _validate_transformation_variant_coverage(manifest, plan_text: str) -> list[str]:
    """For a table paste/import/convert ticket, force the predictable variant space to be
    enumerated: source apps, nested tables, merged cells, multiple/repeat header rows,
    simple-vs-normal table, topic types, and editor scope. Each axis must be addressed in
    an AC, an Open Question, or scope (even to bound it out); a missing axis fails closed.
    This is the non-negotiable dimension sweep for this recurring ticket class - missed on
    a Word-table-paste data-loss ticket where the human UAC enumerated all of these."""
    evidence = (plan_text or "") + "\n" + _manifest_issue_text(manifest)
    if not (_TRANSFORM_SIGNAL_RE.search(evidence) and _TABLE_SIGNAL_RE.search(evidence)):
        return []
    missing = [name for name, rx in _TABLE_VARIANT_AXES.items() if not rx.search(plan_text or "")]
    if not missing:
        return []
    return [
        "This is a table paste/import/convert ticket; the predictable variant space must be "
        "enumerated (each as an Acceptance Criterion, an Open Question, or an explicit scope "
        "bound). Missing axes: " + "; ".join(missing) + "."
    ]


# ---------------------------------------------------------------------------
# 8. Link / URL ticket -> protocol-scheme variant enumeration
# ---------------------------------------------------------------------------

# A link / URL / weblink / cross-reference ticket where the URL scheme matters.
_LINK_SIGNAL_RE = re.compile(
    r"\b(?:web\s*link|weblink|hyperlink|url|href|cross[-\s]?reference|xref|scope\s*=\s*[\"']?external)\b",
    re.IGNORECASE,
)
# Evidence that the plan addressed the protocol/scheme variant axis.
_LINK_SCHEME_RE = re.compile(
    r"\b(?:https?\b|ftps?\b|mailto|tel:|protocol|scheme|http/s|ftp/s|"
    r"link\s+type|url\s+type)\b",
    re.IGNORECASE,
)


def _validate_link_scheme_coverage(manifest, plan_text: str) -> list[str]:
    """For a weblink / URL / cross-reference ticket, force the URL protocol-scheme variant
    axis to be dispositioned (http, https, ftp, ftps, mailto, tel, ...). The observable
    behaviour can differ by scheme, so a plan that only names one path shape without
    addressing schemes is incomplete - missed on a weblink scope ticket where the human
    UAC required all web-link protocols. Satisfy it in an AC or an Open Question."""
    evidence = (plan_text or "") + "\n" + _manifest_issue_text(manifest)
    if not _LINK_SIGNAL_RE.search(evidence):
        return []
    if _LINK_SCHEME_RE.search(plan_text or ""):
        return []
    return [
        "This is a link/URL/cross-reference ticket, but the plan does not disposition the "
        "URL protocol-scheme variants (http, https, ftp, ftps, mailto, tel, and similar). "
        "Add an Acceptance Criterion or Open Question that names the supported schemes; the "
        "observable behaviour can differ by scheme."
    ]


# ---------------------------------------------------------------------------
# 9. Corpus-learned axes: negative/boundary (52% of human UACs) and topic types (16%)
# ---------------------------------------------------------------------------

# Mining 313 human UACs (scripts/uac_eval/mine_uac_dimensions.py) showed the two most
# common ungated axes: a negative/error/boundary criterion (51.8%) and topic-type
# enumeration (16.3%). These gates force them, data-driven rather than one-ticket-reactive.

# The ticket describes a defect / wrong behaviour (so a negative criterion is expected).
_DEFECT_SIGNAL_RE = re.compile(
    r"\b(?:bug|defect|incorrect(?:ly)?|wrong(?:ly)?|fails?|failed|failure|lost|losing|"
    r"broken|not\s+working|unexpected|empty|missing|data\s*loss|error|crash|regress)\b",
    re.IGNORECASE,
)
# A negative / error / boundary disposition in an AC, scenario, or Open Question.
_NEGATIVE_MARKER_RE = re.compile(
    r"\b(?:must\s+not|should\s+not|does\s+not|do\s+not|invalid|empty|missing|error|"
    r"fallback|boundary|negative|fails?\s+gracefully|broken|not\s+lost|without\s+loss|"
    r"no\s+(?:data\s+)?loss|reject|unsupported|malformed)\b",
    re.IGNORECASE,
)
# An authoring/content/element ticket where behaviour can vary by topic type. Scoped to
# actual DITA content constructs and edit/insert actions - deliberately NOT bare
# "author"/"metadata"/"content"/"render", which fire on unrelated publishing/status tickets.
_AUTHORING_CONTENT_RE = re.compile(
    r"\b(?:insert|paste|\btable\b|xref|conref|keyref|shortdesc|prolog|reltable|topicref|"
    r"indexterm|footnote|simpletable|tgroup|thead|colspec)\b",
    re.IGNORECASE,
)
_TOPIC_TYPE_RE = re.compile(
    r"\b(?:concept|reference|task|glossary|bookmap|topic\s+type|all\s+topic\s+types)\b",
    re.IGNORECASE,
)


def _validate_negative_boundary_present(manifest, plan_text: str) -> list[str]:
    """A defect/wrong-behaviour ticket must carry at least one negative/error/boundary
    criterion (must-not, invalid, empty, error, no-data-loss, fallback). 52% of human UACs
    include one; a bug UAC with only positive criteria is under-covered. Satisfy in an AC,
    a scenario, or an Open Question."""
    evidence = (plan_text or "") + "\n" + _manifest_issue_text(manifest)
    if not _DEFECT_SIGNAL_RE.search(evidence):
        return []
    if not re.search(r"\bAC[-\s]?\d", _acceptance_block(plan_text), re.I):
        return []  # no ACs to judge yet
    if _NEGATIVE_MARKER_RE.search(plan_text or ""):
        return []
    return [
        "This is a defect / wrong-behaviour ticket but the plan has no negative, error, or "
        "boundary criterion (for example must-not, invalid input, empty/missing, no data "
        "loss, error/fallback). Add at least one negative Acceptance Criterion, scenario, or "
        "Open Question - 52% of human UACs include one."
    ]


def _validate_topic_type_coverage(manifest, plan_text: str) -> list[str]:
    """An authoring/content/element ticket must disposition topic-type variance (concept,
    reference, task) - the behaviour can differ by topic type. 16% of human UACs enumerate
    them. Satisfy in an AC or an Open Question."""
    evidence = (plan_text or "") + "\n" + _manifest_issue_text(manifest)
    if not _AUTHORING_CONTENT_RE.search(evidence):
        return []
    if _TOPIC_TYPE_RE.search(plan_text or ""):
        return []
    return [
        "This is an authoring/content/element ticket but the plan does not disposition topic "
        "types (concept, reference, task). Add an Acceptance Criterion or Open Question that "
        "confirms the behaviour across topic types, or bounds the scope explicitly."
    ]


_SURFACE_RE = re.compile(
    r"\b([A-Z][A-Za-z0-9]+(?:\s+[A-Za-z0-9]+){0,3}?)\s+([Pp]anels?|[Dd]ashboards?)\b"
)
_SURFACE_STOP = frozenset({
    "the", "a", "an", "both", "various", "these", "those", "different", "other",
    "each", "all", "some", "this", "that", "and", "or", "in", "on", "to", "of",
    "same", "two", "three", "several", "any", "every", "its", "their",
})


def _plan_section(plan_text: str, name: str) -> str:
    """Return the body of a `**Heading**` section from the plan (empty if absent)."""
    lines = (plan_text or "").splitlines()
    out: list[str] = []
    in_section = False
    for line in lines:
        stripped = line.strip()
        heading = re.fullmatch(r"\*\*(.+?)\*\*", stripped)
        if heading:
            in_section = heading.group(1).strip().casefold() == name.casefold()
            continue
        if in_section:
            out.append(line)
    return "\n".join(out)


def _surface_subjects(text: str) -> set[str]:
    """Return the set of product-surface subject keys named with a Panel/Dashboard token.

    A subject is the significant word(s) before the Panel/Dashboard token, lowercased.
    Matching on the subject (not the full phrase) makes 'Baseline dashboard' and
    'Baseline Panel' resolve to the same surface, so the dashboard/panel wording
    difference does not create a false miss.
    """
    subjects: set[str] = set()
    for match in _SURFACE_RE.finditer(text or ""):
        words = [w for w in match.group(1).strip().lower().split() if w not in _SURFACE_STOP]
        if not words:
            continue
        subjects.add(words[-1])
        if len(words) >= 2:
            subjects.add(" ".join(words[-2:]))
    return subjects


def _validate_named_surface_parity(manifest, plan_text: str) -> list[str]:
    """Every product surface (Panel/Dashboard) the Jira names must be dispositioned in an
    Acceptance Criterion or Open Question - not paraphrased away or dropped.

    Root cause this closes: a ticket that names several surfaces (e.g. Baseline Panel,
    Translation Panel, Map dashboard) gets a plan that only names one and paraphrases the
    rest into a vague phrase ('baseline-based topic list'), silently dropping a stated
    surface. Comparison is by surface SUBJECT so the panel/dashboard wording difference is
    not a false miss. Fail-closed only when a named surface is entirely absent from the
    acceptance contract / Open Questions.
    """
    ac_block = _acceptance_block(plan_text)
    if not ac_block.strip():
        return []  # only behavioural plans that carry an acceptance contract
    named = _surface_subjects(
        _plan_section(plan_text, "Understanding From Jira")
        + "\n" + _plan_section(plan_text, "Expected Behaviour")
        + "\n" + _manifest_issue_text(manifest)
    )
    if not named:
        return []
    oq_text = "\n".join(_oq_lines(plan_text))
    dispositioned = _surface_subjects(ac_block + "\n" + oq_text)
    # Collapse: if a two-word subject is dispositioned, its single-word tail counts too.
    dispositioned |= {s.split()[-1] for s in dispositioned if " " in s}
    missing = sorted(
        s for s in named
        if s not in dispositioned and (" " in s or s not in {d.split()[-1] for d in named if " " in d})
    )
    if not missing:
        return []
    return [
        "NAMED_SURFACE_PARITY: the Jira names product surface(s) "
        f"{missing} (a Panel/Dashboard) that no Acceptance Criterion or Open Question "
        "disposition. Name each stated surface explicitly in an AC or Open Question - do "
        "not paraphrase it into a vague phrase or drop it. The Baseline, Translation, "
        "Map, Conditions, and Reports surfaces are Panels (not dashboards); use the exact "
        "product term."
    ]


# A shared backend collaborator: one implementation that several user-facing operations
# reach. Deliberately class-suffix shaped so it fires on inspected implementation evidence
# rather than on prose about a feature.
_SHARED_SERVICE_SYMBOL_RE = re.compile(
    r"\b[A-Z][A-Za-z0-9]*(?:Service|Servlet|Handler|Processor|Manager|Filter|Resolver|"
    r"Repository|Provider|Listener)\b"
)
_NEIGHBOURHOOD_SCHEMA = "aem-guides-changed-service-neighbourhood-v1"
_NEIGHBOURHOOD_DISPOSITIONS = frozenset({
    "COVERED_BY_AC", "OPEN_QUESTION", "OUT_OF_SCOPE", "NOT_APPLICABLE",
})
# Answers that assert nothing. An axis "answered" with one of these was not investigated.
_EMPTY_ASSERTION_RE = re.compile(
    r"^(?:n/?a|none|tbd|unknown|not\s+applicable|no|-+|\.+)$", re.IGNORECASE
)


def _is_empty_assertion(value) -> bool:
    text = str(value or "").strip()
    return not text or bool(_EMPTY_ASSERTION_RE.fullmatch(text))


def _validate_changed_service_neighbourhood(manifest, plan_text: str) -> list[str]:
    """When implementation evidence puts a SHARED backend collaborator in scope, the plan
    must have ENUMERATED that code's own neighbourhood and recorded the result.

    Root cause this closes: a plan is authored from the reported operation and the diff's
    target branch, so three things reliably go missing even though the evidence was in
    hand. (a) The OTHER user operations that reach the same shared code are never asked
    about, so a sibling entry point silently leaves the contract. (b) When the change makes
    an existing path conditional, the OTHER observable outcomes that path also produced are
    never asserted, so a fix-introduced regression has no guard. (c) When the code resolves
    or queries on the CALLER's behalf, results are permission-filtered, so a restricted
    user's outcome is never dispositioned and testing as an administrator hides the whole
    dimension.

    This is deliberately a MANIFEST contract, not a prose check. The signals live in the
    code, not in the plan's wording: an author who never noticed the caller-scoped lookup
    also never writes the word "session", and ordinary criteria mention "create" or "copy"
    incidentally, so counting vocabulary both misses real gaps and is satisfied by
    accident. Requiring an explicit enumeration record fails closed on the omission itself
    and cannot be satisfied by wording. Each axis must be answered; an empty assertion
    (n/a, none, tbd) is not an answer.
    """
    if not re.search(r"\bAC[-\s]?\d", _acceptance_block(plan_text), re.I):
        return []  # no acceptance contract to judge yet
    implementation = (
        _plan_section(plan_text, "Code Touched")
        + "\n" + _plan_section(plan_text, "Lines Changed")
        + "\n" + _plan_section(plan_text, "Scope From Git")
    )
    if not _SHARED_SERVICE_SYMBOL_RE.search(implementation):
        return []  # no inspected shared collaborator -> nothing to enumerate

    block = manifest.get("changed_service_neighbourhood") if isinstance(manifest, dict) else None
    if not isinstance(block, dict) or not block:
        return [
            "CHANGED_SERVICE_NEIGHBOURHOOD: implementation evidence puts a shared backend "
            "collaborator in scope but the manifest declares no "
            f"'changed_service_neighbourhood' block (schema {_NEIGHBOURHOOD_SCHEMA}). "
            "Enumerate the changed code's own neighbourhood and record it: every user "
            "operation that reaches the same collaborator, every observable outcome of a "
            "path the change now skips, and every lookup the code performs on the caller's "
            "behalf with its permission scope. Authoring from the reported operation and "
            "the diff's target branch alone is what drops a sibling entry point, a "
            "fix-introduced regression, and the restricted-user outcome."
        ]

    problems: list[str] = []
    if block.get("schema_version") != _NEIGHBOURHOOD_SCHEMA:
        problems.append(
            "CHANGED_SERVICE_NEIGHBOURHOOD: the block must declare "
            f"schema_version {_NEIGHBOURHOOD_SCHEMA!r}."
        )

    def _check_records(key: str, label: str, subject_field: str, extra_fields=()):
        records = block.get(key)
        if not isinstance(records, list):
            problems.append(
                f"CHANGED_SERVICE_NEIGHBOURHOOD: {key!r} must be a list of {label} records."
            )
            return
        for index, record in enumerate(records):
            where = f"{key}[{index}]"
            if not isinstance(record, dict):
                problems.append(f"CHANGED_SERVICE_NEIGHBOURHOOD: {where} must be a record.")
                continue
            if _is_empty_assertion(record.get(subject_field)):
                problems.append(
                    f"CHANGED_SERVICE_NEIGHBOURHOOD: {where} must name its {subject_field}."
                )
            disposition = str(record.get("disposition", "")).strip()
            if disposition not in _NEIGHBOURHOOD_DISPOSITIONS:
                problems.append(
                    f"CHANGED_SERVICE_NEIGHBOURHOOD: {where} needs a disposition from "
                    f"{sorted(_NEIGHBOURHOOD_DISPOSITIONS)}; omission is not a disposition."
                )
            elif disposition != "COVERED_BY_AC" and _is_empty_assertion(record.get("reason")):
                problems.append(
                    f"CHANGED_SERVICE_NEIGHBOURHOOD: {where} is {disposition} without a "
                    "concrete reason; an empty assertion (n/a, none, tbd) is not a reason."
                )
            for field in extra_fields:
                if _is_empty_assertion(record.get(field)):
                    problems.append(
                        f"CHANGED_SERVICE_NEIGHBOURHOOD: {where} must state its {field}."
                    )

    # (a) sibling entry points - always answered, and the enumeration must say where it
    # looked, so "only one caller" is a finding rather than an assumption.
    entry_points = block.get("entry_points")
    if not isinstance(entry_points, list) or not entry_points:
        problems.append(
            "CHANGED_SERVICE_NEIGHBOURHOOD: 'entry_points' must list every user operation "
            "that reaches the shared collaborator. A sibling entry point sharing the "
            "changed code is acceptance scope, not background regression."
        )
    else:
        _check_records("entry_points", "entry-point", "operation")
    if _is_empty_assertion(block.get("enumeration_evidence")):
        problems.append(
            "CHANGED_SERVICE_NEIGHBOURHOOD: 'enumeration_evidence' must state where the "
            "callers were actually enumerated (the inspected caller search), so a single "
            "entry point is an enumerated finding rather than an assumption."
        )

    # (b) outcomes of a path the change now skips
    skipped = block.get("skipped_branch_outcomes")
    if isinstance(skipped, list) and skipped:
        _check_records("skipped_branch_outcomes", "skipped-outcome", "outcome")
    elif _is_empty_assertion(block.get("no_conditional_skip_reason")):
        problems.append(
            "CHANGED_SERVICE_NEIGHBOURHOOD: list every observable outcome of a path the "
            "change now skips in 'skipped_branch_outcomes', or state in "
            "'no_conditional_skip_reason' why the change makes no existing path "
            "conditional. A path is rarely single purpose, and the outcomes incidental to "
            "the reported defect are what the change silently removes."
        )

    # (c) lookups performed on the caller's behalf
    lookups = block.get("caller_scoped_lookups")
    if isinstance(lookups, list) and lookups:
        _check_records(
            "caller_scoped_lookups", "caller-scoped-lookup", "lookup",
            extra_fields=("permission_scope",),
        )
    elif _is_empty_assertion(block.get("no_caller_scoped_lookup_reason")):
        problems.append(
            "CHANGED_SERVICE_NEIGHBOURHOOD: list every lookup the code performs on the "
            "caller's behalf in 'caller_scoped_lookups' with its permission scope and the "
            "restricted-user outcome, or state in 'no_caller_scoped_lookup_reason' why the "
            "code resolves nothing as the caller. Results filtered by the caller's "
            "permissions differ per user with no branch that mentions permissions, so "
            "testing as an administrator hides the dimension entirely."
        )

    return problems


def validate_by_check(manifest, plan_text: str = "", *, catalog_path=None) -> dict[str, list[str]]:
    """Every sub-check's problems by name, in the order validate() reports them (for the gate firing log)."""
    checks: dict[str, list[str]] = {}
    checks["performance"] = _validate_performance(manifest, plan_text)
    checks["named_surface_parity"] = _validate_named_surface_parity(manifest, plan_text)
    checks["ui_surface"] = _validate_ui_surface(manifest, plan_text, catalog_path=catalog_path)
    checks["investigation"] = _validate_investigation(manifest, plan_text)
    checks["no_test_as_ac"] = _validate_no_test_as_ac(manifest, plan_text)
    checks["ac_oq_contradiction"] = _validate_ac_oq_contradiction(manifest, plan_text)
    checks["restated_instance_ac"] = _validate_restated_instance_ac(manifest, plan_text)
    checks["no_markup_in_ac"] = _validate_no_markup_in_ac(manifest, plan_text)
    checks["ac_over_decomposition"] = _validate_ac_over_decomposition(manifest, plan_text)
    checks["plain_language"] = _validate_plain_language(plan_text)
    checks["ac_redundancy"] = _validate_ac_redundancy(plan_text)
    checks["acceptance_contract_present"] = _validate_acceptance_contract_present(plan_text, manifest)
    checks["history_attempt_recorded"] = _validate_history_attempt_recorded(manifest)
    checks["current_status_recency"] = _validate_current_status_recency(manifest, plan_text)
    checks["error_surface_open_question"] = _validate_error_surface_open_question(manifest, plan_text)
    checks["status_anti_overcorrection"] = _validate_status_anti_overcorrection(manifest, plan_text)
    checks["concurrency_isolation"] = _validate_concurrency_isolation(manifest, plan_text)
    checks["vague_surface_reference"] = _validate_vague_surface_reference(manifest, plan_text)
    checks["underspecified_terms"] = _validate_underspecified_terms(manifest, plan_text)
    checks["guides_vocabulary"] = _validate_guides_vocabulary(manifest, plan_text)
    checks["language_generalization"] = _validate_language_generalization(manifest, plan_text)
    checks["transformation_variant_coverage"] = _validate_transformation_variant_coverage(manifest, plan_text)
    checks["link_scheme_coverage"] = _validate_link_scheme_coverage(manifest, plan_text)
    checks["negative_boundary_present"] = _validate_negative_boundary_present(manifest, plan_text)
    checks["topic_type_coverage"] = _validate_topic_type_coverage(manifest, plan_text)
    checks["changed_service_neighbourhood"] = _validate_changed_service_neighbourhood(manifest, plan_text)
    return checks


def validate(manifest, plan_text: str = "", *, catalog_path=None) -> list[str]:
    problems: list[str] = []
    for found in validate_by_check(manifest, plan_text, catalog_path=catalog_path).values():
        problems += found
    return problems


def summarize(manifest, plan_text: str = "") -> str:
    problems = validate(manifest, plan_text)
    lines = [f"CoverageForcing: {'CLEAN' if not problems else 'ISSUES'}"]
    lines.extend(f"  {p}" for p in problems)
    return "\n".join(lines)


def run_self_tests() -> None:
    nl = chr(10)

    # --- performance forcing ---
    perf_missing = nl.join([
        "**Understanding**", "Find returns HTTP 503 on large maps.",
        "**Acceptance Criteria**", "- AC-01: results are returned.", ""])
    probs = validate({}, perf_missing)
    assert any("performance is not dispositioned" in p for p in probs), "503/large-map must force performance"

    perf_ac = nl.join([
        "**Understanding**", "Find returns HTTP 503 on large maps.",
        "**Acceptance Criteria**",
        "- AC-05: Find completes within the platform timeout budget so no 503 is returned (Performance).",
        ""])
    assert not any("performance is not dispositioned" in p for p in validate({}, perf_ac)), "Performance AC satisfies"

    assert not any("performance" in p for p in validate(
        {"performance_not_applicable": {"reason": "Pure static-label change, no workload dimension."}}, perf_missing)), "perf opt-out"

    plain = nl.join(["**Acceptance Criteria**", "- AC-01: the dialog opens on click.", ""])
    assert validate({}, plain) == [], "no signals -> no forcing"

    # --- ui surface forcing (uses the shipped catalog: find-and-replace) ---
    fr_missing = nl.join([
        "**Understanding**", "Find and Replace throws 503 on large maps.",
        "**Acceptance Criteria**",
        "- AC-05: search completes within the platform timeout budget (Performance).",
        ""])
    fr_probs = validate({}, fr_missing)
    assert any("Filters" in p or "filter" in p.lower() for p in fr_probs), "F&R filters surface must be forced"

    fr_covered = nl.join([
        "**Understanding**", "Find and Replace throws 503 on large maps.",
        "**Acceptance Criteria**",
        "- AC-05: search completes within the platform timeout budget (Performance).",
        "- AC-07: the Filters dialog (File Type, Document State, Last Modified) narrows results without a 503.",
        "- AC-08: Path scope and Use source mode work on a large map.",
        "- AC-09: Replace occurrence and Replace all complete via the async job.",
        "- AC-10: Replace settings (Replace unlocked files, Create new version, Version comments) are honored.",
        "- AC-11: the Enable Replace All workspace setting gates the feature.",
        ""])
    assert _validate_ui_surface({}, fr_covered) == [], f"all F&R surfaces covered must pass: {_validate_ui_surface({}, fr_covered)}"

    assert _validate_ui_surface(
        {"ui_surface_coverage_not_applicable": {"reason": "Backend-only change with no F&R panel behaviour."}},
        fr_missing) == [], "ui opt-out"

    # --- investigation-as-AC ---
    inv = nl.join([
        "**Acceptance Criteria**",
        "- AC-09: Confirm whether the 2026.08 fix is present in this build.",
        ""])
    assert any("investigation task" in p for p in validate({}, inv)), "investigation AC must fail"

    # --- no test/automation as an AC ---
    test_ac = nl.join([
        "**Acceptance Criteria**",
        "- AC-09: the added translation test covers the created-in-en / moved-to-en_us case across map and topic.",
        ""])
    assert any("Automation Coverage evidence" in p for p in validate({}, test_ac)), "added-test-as-AC must fail"
    testfile_ac = nl.join([
        "**Acceptance Criteria**",
        "- AC-08: The added topic.test.ts case passes.",
        ""])
    assert any("Automation Coverage evidence" in p for p in validate({}, testfile_ac)), "test-file-as-AC must fail"
    # a plain product-behaviour AC that merely contains the word 'test' must NOT trip it
    ok_test = nl.join([
        "**Acceptance Criteria**",
        "- AC-01: the user can use the Test Connection button and see a success message.",
        ""])
    assert not any("Automation Coverage evidence" in p for p in validate({}, ok_test)), "product 'Test Connection' must pass"

    # --- AC/OQ contradiction ---
    contra = nl.join([
        "**Acceptance Criteria**", "- AC-07: the output falls back to the generic value when no regional entry exists.",
        "**Open Questions**", "- OQ-1: confirm the approved behaviour when a regional entry is absent (fall back to generic, per AC-7).",
        ""])
    assert any("redundant/contradictory" in p for p in validate({}, contra)), "OQ referencing an AC must fail"
    # --- restated-instance AC ---
    restated = nl.join([
        "**Acceptance Criteria**", "- AC-02: The exact reported case passes: a map set to pt_br shows the regional text.",
        ""])
    assert any("restates the specific reported instance" in p for p in validate({}, restated)), "restated-instance AC must fail"
    # a genuine OQ with no AC reference must pass
    ok_oq = nl.join([
        "**Acceptance Criteria**", "- AC-01: the dialog opens on click.",
        "**Open Questions**", "- OQ-1: when the map language and preset language differ, which one wins?",
        ""])
    assert not any("redundant/contradictory" in p for p in validate({}, ok_oq)), "genuine OQ must pass"

    # --- no raw markup / code block in ACs ---
    markup = nl.join(["**Acceptance Criteria**", "- AC-01: When a keydef is written as <keydef keys=\"\" href=\"topic.dita\"/> the label is wrong.", ""])
    assert any("raw markup" in p for p in validate({}, markup)), "raw XML in AC must fail"
    fence = nl.join(["**Acceptance Criteria**", "- AC-01: the blank key must error.", "```", "<keydef keys=\"\"/>", "```", ""])
    assert any("code block" in p for p in validate({}, fence)), "code fence in AC must fail"
    # --- over-decomposition ---
    many = nl.join(["**Acceptance Criteria**"] + [f"- AC-{i:02d}: the entry behaves correctly in case {i}." for i in range(1, 14)] + [""])
    assert any("over-decomposed" in p for p in validate({}, many)), ">10 ACs must be flagged"
    few = nl.join(["**Acceptance Criteria**"] + [f"- AC-{i}: the entry behaves correctly." for i in range(1, 7)] + [""])
    assert not any("over-decomposed" in p for p in validate({}, few)), "6 ACs must pass"

    # --- no code identifiers in ACs ---
    codey = nl.join([
        "**Acceptance Criteria**",
        "- AC-03: The fix is applied in both PublishWorkflowStep.handlePartialPublish and "
        "PublishWorkflowGenerationAEMSiteRenditionStep.handlePartialPublish so filterListTopics does not drop the topic.",
        ""])
    assert any("code identifiers" in p for p in validate({}, codey)), "method names in AC must fail"
    # Plain-English AC with legitimate product/config terms must PASS.
    clean_ac = nl.join([
        "**Acceptance Criteria**",
        "- AC-01: Incremental publish of a selected topic with a no-baseline AEM Site preset completes and produces output.",
        "- AC-02: The result is the same whether Enable DITA-OT Processing is on or off.",
        "- AC-03: Verified on AEMaaCS and on-premise 6.5.1 LTS.",
        "- AC-04: The config property postprocess.temporary.langcopies set to false does not change the outcome.",
        ""])
    assert _validate_plain_language(clean_ac) == [], f"plain-English AC must pass: {_validate_plain_language(clean_ac)}"

    # --- scoped lexical AC redundancy ---
    distinct_acs = nl.join([
        "## Acceptance contract",
        "- AC-01: Translation succeeds for content moved to a regional folder.",
        "- AC-02: The move preserves the source asset identity.",
        "## Semantic coverage",
        "- AC-01 is mapped to the translation workflow.",
        ""])
    assert _validate_ac_redundancy(distinct_acs) == [], "distinct ACs must pass"
    duplicate_acs = nl.join([
        "## Acceptance criteria",
        "- AC-01: The cross reference label excludes the footnote callout text.",
        "- AC-02: The cross reference label must exclude footnote callout text.",
        ""])
    duplicate_problems = _validate_ac_redundancy(duplicate_acs)
    assert len(duplicate_problems) == 1, "near-duplicate ACs must fail"
    assert "AC-01 text:" in duplicate_problems[0] and "AC-02 text:" in duplicate_problems[0], (
        "redundancy failure must identify both ACs and their text"
    )
    assert _validate_ac_redundancy("## Semantic coverage\n- AC-01 is mentioned here.\n") == [], (
        "redundancy scan must not fall back to the whole plan"
    )

    # --- acceptance contract presence ---
    no_contract = "## Issue understanding\n- A visible behavior is broken.\n"
    assert _validate_acceptance_contract_present(no_contract, {"behaviour_matters": True}), (
        "behavioral plan without a contract must fail"
    )
    assert _validate_acceptance_contract_present(no_contract, {"behaviour_matters": False}) == [], (
        "explicit non-behavioral opt-out must pass"
    )
    assert _validate_acceptance_contract_present("## Acceptance contract\n", {}) != [], (
        "empty acceptance contract must fail"
    )
    assert _validate_acceptance_contract_present(distinct_acs, {}) == [], (
        "populated acceptance contract must pass"
    )

    # --- history-attempt recording ---
    assert _validate_history_attempt_recorded({}) == [], "manifest without history intent must pass"
    assert _validate_history_attempt_recorded({"evidence_lifecycle": []}) != [], (
        "history intent without an attempt must fail"
    )
    recorded_history = {
        "evidence_lifecycle": [],
        "history_attempts": [
            {
                "source": "search_jira_history",
                "query": "same failure mechanism",
                "result": "ok",
                "count": 2,
            }
        ],
    }
    assert _validate_history_attempt_recorded(recorded_history) == [], (
        "complete history attempt must pass"
    )
    unavailable_history = {
        "jira_history_queries": [],
        "history_attempts": [
            {
                "source": "search_jira_history",
                "query": "same failure mechanism",
                "result": "unavailable",
                "count": 0,
            }
        ],
    }
    assert _validate_history_attempt_recorded(unavailable_history) == [], (
        "an unavailable attempt must make a thin history result explicit"
    )
    thin_but_ok = {
        "known_jira_bugs": [],
        "history_attempts": [
            {
                "source": "search_jira_history",
                "query": "same failure mechanism",
                "result": "ok",
                "count": 1,
            }
        ],
    }
    assert any("empty or unavailable" in p for p in _validate_history_attempt_recorded(thin_but_ok)), (
        "empty Known Jira Bugs result needs an empty or unavailable attempt"
    )
    malformed_history = {
        "history_attempts": [
            {"source": "", "query": "", "result": "ok", "count": True}
        ]
    }
    malformed_problems = _validate_history_attempt_recorded(malformed_history)
    assert len(malformed_problems) >= 3, "malformed history attempt must fail closed"

    # --- current-status recency (works-now signal in a comment) ---
    works_now_manifest = {
        "issue": {
            "summary": "save-validation timeout",
            "comments": [{"body": "validatexml is working fine on stage and prod now."}],
        }
    }
    fix_ac_plan = nl.join([
        "**Acceptance Criteria**",
        "- AC-01: saving the high-fan-in topic completes and commits successfully.",
        ""])
    assert any("works-now signal" in p for p in _validate_current_status_recency(works_now_manifest, fix_ac_plan)), (
        "fix-ACs over behaviour a comment says now works must fail"
    )
    reflected_plan = nl.join([
        "**Understanding**", "Per the latest comment the save path now works; only the "
        "references panel still returns 503 (remaining scope).",
        "**Acceptance Criteria**",
        "- AC-01: the references panel loads for the high-fan-in topic.",
        "**Open Questions**",
        "- OQ-01: is save-validation still in scope? QA impact: sets scope.",
        ""])
    assert _validate_current_status_recency(works_now_manifest, reflected_plan) == [], (
        "a plan that reflects current status / raises an OQ must pass"
    )
    assert _validate_current_status_recency({}, fix_ac_plan) == [], "no works-now signal -> no forcing"

    # --- error-surface UI open question ---
    err_plan_missing = nl.join([
        "**Understanding**", "The editor shows 'File is not valid' and the references panel "
        "returns a 503.",
        "**Acceptance Criteria**",
        "- AC-01: the references panel loads for the high-fan-in topic.",
        ""])
    assert any("what the UI should do on that error" in p for p in _validate_error_surface_open_question({}, err_plan_missing)), (
        "a user-facing 503/File-is-not-valid surface with no error-UI disposition must fail"
    )
    err_plan_covered = err_plan_missing + nl.join([
        "**Open Questions**",
        "- OQ-01: on a 503 what message should the editor show and is save blocked or "
        "allowed with a warning? QA impact: the observable oracle for the error behaviour.",
        ""])
    assert _validate_error_surface_open_question({}, err_plan_covered) == [], (
        "an error-UI Open Question satisfies the gate"
    )
    backend_only_503 = nl.join([
        "**Understanding**", "Find returns HTTP 503 on large maps.",
        "**Acceptance Criteria**", "- AC-01: results are returned.", ""])
    assert _validate_error_surface_open_question({}, backend_only_503) == [], (
        "a 503 with no user-facing UI context must not force the error-UI question"
    )

    # --- status anti-over-correction ---
    mislabel_plan = nl.join([
        "**Understanding**", "The dashboard incorrectly shows a successful generation as Failed.",
        "**Acceptance Criteria**",
        "- AC-01: a run that produced its files shows success, not Failed.",
        ""])
    assert any("masking real" in p for p in _validate_status_anti_overcorrection({}, mislabel_plan)), (
        "a false-failure ticket needs an anti-over-correction AC"
    )
    mislabel_covered = mislabel_plan + nl.join([
        "- AC-09: genuine generation failures still show Failed and cancelled runs stay Cancelled.",
        ""])
    assert _validate_status_anti_overcorrection({}, mislabel_covered) == [], (
        "an anti-over-correction AC satisfies the gate"
    )
    assert _validate_status_anti_overcorrection({}, plain) == [], "no status-mislabel signal -> no forcing"

    # --- concurrency isolation ---
    overlap_plan = nl.join([
        "**Understanding**", "Fails when a second request runs while a previous job is still running.",
        "**Acceptance Criteria**",
        "- AC-01: the completed run shows success.",
        ""])
    assert any("isolation" in p for p in _validate_concurrency_isolation({}, overlap_plan)), (
        "a concurrency/overlap ticket needs an isolation AC/OQ"
    )
    overlap_covered = overlap_plan + nl.join([
        "- AC-04: a rejected overlapping request keeps its own status and does not appear "
        "successful; other maps and presets are unaffected.",
        ""])
    assert _validate_concurrency_isolation({}, overlap_covered) == [], (
        "an isolation AC satisfies the gate"
    )
    assert _validate_concurrency_isolation({}, plain) == [], "no concurrency signal -> no forcing"

    # --- vague collective surface reference ---
    vague_plan = nl.join([
        "**Acceptance Criteria**",
        "- AC-01: after a run completes, both dashboards show success.",
        ""])
    assert any("vague collective surface" in p for p in _validate_vague_surface_reference({}, vague_plan)), (
        "'both dashboards' must fail"
    )
    named_plan = nl.join([
        "**Acceptance Criteria**",
        "- AC-01: after a run completes, the Map Dashboard Outputs tab and the Bulk Publish "
        "dashboard show success.",
        ""])
    assert _validate_vague_surface_reference({}, named_plan) == [], (
        "named surfaces must pass"
    )
    assert _validate_vague_surface_reference({}, plain) == [], "no surface reference -> pass"

    # --- underspecified placeholder terms ---
    underspec_plan = nl.join([
        "**Acceptance Criteria**",
        "- AC-01: the generated file appears in the configured output folder and opens.",
        ""])
    assert any("vague placeholder term" in p for p in _validate_underspecified_terms({}, underspec_plan)), (
        "'the configured output folder' must fail"
    )
    spelled_plan = nl.join([
        "**Acceptance Criteria**",
        "- AC-01: the generated file appears in the output folder set in that preset and opens.",
        ""])
    assert _validate_underspecified_terms({}, spelled_plan) == [], (
        "spelled-out folder must pass"
    )
    assert _validate_underspecified_terms({}, plain) == [], "no placeholder term -> pass"

    # --- language generalization on translation tickets ---
    xl_manifest = {"issue": {"summary": "310 files In Progress after German translation",
                             "description": "map submitted for German translation stays in progress"}}
    only_german = nl.join([
        "**Acceptance Criteria**",
        "- AC-01: after the German translation job finishes, no topic stays In Progress.",
        ""])
    assert _validate_language_generalization(xl_manifest, only_german), (
        "translation ticket naming only German must fail without a generalization AC")
    generalized = nl.join([
        "**Acceptance Criteria**",
        "- AC-01: after the translation job finishes, no topic stays In Progress.",
        "- AC-02: the fix applies to every supported target language, not only German.",
        ""])
    assert _validate_language_generalization(xl_manifest, generalized) == [], (
        "a generalization AC (every supported target language) must pass")
    no_xl_plan = nl.join([
        "**Acceptance Criteria**",
        "- AC-01: after the German job finishes, no item stays In Progress.",
        ""])
    assert _validate_language_generalization({"issue": {"summary": "PDF status wrong",
                                                        "description": "output failed"}},
                                             no_xl_plan) == [], (
        "non-translation ticket and plan -> gate does not activate")

    # --- performance: duration/concurrency signal + conditional-OQ disposition ---
    dur_missing = nl.join([
        "**Understanding**", "Output is produced 5-10 minutes later while an overlapping job is still running.",
        "**Acceptance Criteria**", "- AC-01: the completed run shows success.", ""])
    assert any("performance is not dispositioned" in p for p in validate({}, dur_missing)), (
        "a duration/concurrency signal must force a performance disposition"
    )
    dur_oq = dur_missing + nl.join([
        "**Open Questions**",
        "- OQ-05: no approved SLA exists for generation duration under concurrent/bulk load; "
        "QA impact: whether a performance AC is needed and the required workload/baseline.",
        ""])
    assert not any("performance is not dispositioned" in p for p in validate({}, dur_oq)), (
        "a performance-conditional Open Question satisfies the disposition"
    )

    # --- table paste/import variant enumeration ---
    paste_thin = nl.join([
        "**Understanding**", "Pasting a Word table into the New Editor loses the header row content.",
        "**Acceptance Criteria**",
        "- AC-01: pasting a Word table keeps the header cell text with merged cells handled.",
        ""])
    tv = _validate_transformation_variant_coverage({}, paste_thin)
    assert tv and "nested tables" in tv[0] and "topic types" in tv[0], (
        "a thin table-paste plan must fail listing the missing variant axes"
    )
    paste_full = nl.join([
        "**Understanding**", "Pasting a Word table into the New Editor loses the header row content.",
        "**Acceptance Criteria**",
        "- AC-01: pasting from Word, Excel, Google Doc, or HTML keeps header cell text.",
        "- AC-02: merged and spanned cells, nested tables, and multiple/repeat header rows keep their text.",
        "- AC-03: simple table and normal table both paste without loss.",
        "**Open Questions**",
        "- OQ-01: confirm behaviour across topic types concept, reference, task, and in both new editor and old editor. QA impact: scope.",
        ""])
    assert _validate_transformation_variant_coverage({}, paste_full) == [], (
        f"a plan enumerating all variant axes must pass: {_validate_transformation_variant_coverage({}, paste_full)}"
    )
    assert _validate_transformation_variant_coverage({}, plain) == [], "no paste/table signal -> no forcing"

    # --- link/URL protocol-scheme enumeration ---
    link_thin = nl.join([
        "**Understanding**", "Authoring a weblink should always add scope external.",
        "**Acceptance Criteria**",
        "- AC-01: a weblink is inserted with scope external and the href unchanged.",
        ""])
    assert any("protocol-scheme" in p for p in _validate_link_scheme_coverage({}, link_thin)), (
        "a weblink ticket without a scheme axis must fail"
    )
    link_full = link_thin + nl.join([
        "- AC-02: http, https, ftp, and ftps links are all inserted as scope external unchanged.",
        ""])
    assert _validate_link_scheme_coverage({}, link_full) == [], "naming schemes satisfies the gate"
    assert _validate_link_scheme_coverage({}, plain) == [], "no link signal -> no forcing"

    # --- negative/boundary present (corpus: 52%) ---
    defect_positive_only = nl.join([
        "**Understanding**", "The header content is lost when pasted (data loss bug).",
        "**Acceptance Criteria**", "- AC-01: the header content is kept on paste.", ""])
    assert any("negative" in p for p in _validate_negative_boundary_present({}, defect_positive_only)), (
        "a defect ticket with only positive ACs must fail"
    )
    defect_with_negative = defect_positive_only + nl.join([
        "- AC-02: an invalid or empty header cell must not silently drop content.", ""])
    assert _validate_negative_boundary_present({}, defect_with_negative) == [], (
        "a negative AC satisfies the gate"
    )
    assert _validate_negative_boundary_present({}, plain) == [], "no defect signal -> no forcing"

    # --- topic-type coverage (corpus: 16%) ---
    authoring_no_types = nl.join([
        "**Understanding**", "Pasting a table into a DITA topic loses content.",
        "**Acceptance Criteria**", "- AC-01: the table content is kept on paste.", ""])
    assert any("topic types" in p for p in _validate_topic_type_coverage({}, authoring_no_types)), (
        "an authoring/content ticket without topic types must fail"
    )
    authoring_with_types = authoring_no_types + nl.join([
        "**Open Questions**",
        "- OQ-01: confirm behaviour across topic types concept, reference, and task. QA impact: scope.",
        ""])
    assert _validate_topic_type_coverage({}, authoring_with_types) == [], (
        "a topic-type Open Question satisfies the gate"
    )
    assert _validate_topic_type_coverage({}, plain) == [], "no authoring/content signal -> no forcing"

    # --- named-surface parity ---
    # Ticket names Baseline dashboard + Translation dashboard; plan only names Map dashboard
    # and paraphrases the rest -> the two stated surfaces must be flagged.
    surface_miss = nl.join([
        "**Understanding From Jira**",
        "- Issue understood: the Baseline dashboard and Translation dashboard show different topics.",
        "**Acceptance Criteria**",
        "- AC-01 [Proposed]: (Basic) The Metadata report matches the Map dashboard. Evidence: J.",
        "**Open Questions**",
        "- OQ-01: confirm the filter default. QA impact: scope.",
        ""])
    miss = _validate_named_surface_parity({}, surface_miss)
    assert any("NAMED_SURFACE_PARITY" in p for p in miss), "stated Baseline/Translation surfaces must be flagged"
    assert any("baseline" in p for p in miss) and any("translation" in p for p in miss), (
        "both dropped surfaces must be named in the finding"
    )
    # dashboard/panel wording difference must NOT be a false miss.
    surface_ok = nl.join([
        "**Understanding From Jira**",
        "- Issue understood: the Baseline dashboard and Translation dashboard show different topics.",
        "**Acceptance Criteria**",
        "- AC-01 [Proposed]: (Basic) The Metadata report matches the Baseline Panel. Evidence: J.",
        "- AC-02 [Proposed]: (Integration) The list matches the Translation Panel using Baseline. Evidence: J.",
        ""])
    assert _validate_named_surface_parity({}, surface_ok) == [], (
        "Baseline/Translation Panel in ACs satisfies parity despite the ticket saying dashboard"
    )
    # a surface named only via the manifest issue text is also enforced.
    manifest_named = {"issue": {"summary": "", "description": "The Subject Scheme Panel is wrong."}}
    only_ac = nl.join([
        "**Acceptance Criteria**",
        "- AC-01 [Proposed]: (Basic) The Metadata report matches the Baseline Panel. Evidence: J.",
        ""])
    assert any("subject scheme" in p for p in _validate_named_surface_parity(manifest_named, only_ac)), (
        "a surface named only in the manifest issue text must be enforced"
    )
    # no acceptance contract -> gate is inert.
    assert _validate_named_surface_parity({}, "**Understanding From Jira**\n- Baseline Panel issue.\n") == []
    # no Panel/Dashboard surface named anywhere -> no forcing.
    assert _validate_named_surface_parity({}, plain) == []

    # --- changed shared-service neighbourhood ---
    # A plan whose inspected implementation names a shared collaborator, authored from the
    # one reported operation. Ordinary criteria already mention create/copy/upload
    # incidentally, which is exactly why this is a manifest contract and not a prose check.
    neighbourhood_plan = nl.join([
        "**Expected Behaviour**",
        "- The overwrite now skips the heal step on an ignored path.",
        "**Code Touched**",
        "- FileConflictsService.findConflicts is the implicated collaborator.",
        "**Acceptance Criteria**",
        "- AC-01 [Proposed]: (Basic) Overwriting a file replaces its binary. Evidence: J.",
        "- AC-02 [Proposed]: (Basic) Creating a copy of the file keeps its name. Evidence: J.",
        ""])
    # No block at all -> fails closed, even though the ACs mention several operations.
    found = _validate_changed_service_neighbourhood({}, neighbourhood_plan)
    assert any("CHANGED_SERVICE_NEIGHBOURHOOD" in p for p in found), (
        "a shared collaborator with no enumeration block must fail closed"
    )
    assert any("declares no" in p for p in found), "the finding must name the missing block"

    def block(**overrides):
        base = {
            "schema_version": "aem-guides-changed-service-neighbourhood-v1",
            "collaborator": "the upload conflict collaborator",
            "enumeration_evidence": "callers of the conflict lookup in the inspected clone",
            "entry_points": [
                {"operation": "overwrite an existing file", "disposition": "COVERED_BY_AC"},
                {"operation": "create asset", "disposition": "COVERED_BY_AC"},
            ],
            "skipped_branch_outcomes": [
                {"outcome": "a version entry is still created",
                 "disposition": "COVERED_BY_AC"},
            ],
            "caller_scoped_lookups": [
                {"lookup": "identifier lookup run as the caller",
                 "permission_scope": "results filtered by the caller's read access",
                 "disposition": "COVERED_BY_AC"},
            ],
        }
        base.update(overrides)
        return {"changed_service_neighbourhood": base}

    assert _validate_changed_service_neighbourhood(block(), neighbourhood_plan) == [], (
        "a fully enumerated neighbourhood block passes"
    )
    # Each axis must actually be answered - an empty assertion is not an answer.
    for key, reason_key in (
        ("skipped_branch_outcomes", "no_conditional_skip_reason"),
        ("caller_scoped_lookups", "no_caller_scoped_lookup_reason"),
    ):
        missing = _validate_changed_service_neighbourhood(
            block(**{key: []}), neighbourhood_plan)
        assert any(key in p or reason_key in p for p in missing), (
            f"an unanswered {key} axis must fail"
        )
        excused = _validate_changed_service_neighbourhood(
            block(**{key: [], reason_key: "the change adds a new path and skips none"}),
            neighbourhood_plan)
        assert excused == [], f"a concrete {reason_key} answers the axis"
        hollow = _validate_changed_service_neighbourhood(
            block(**{key: [], reason_key: "N/A"}), neighbourhood_plan)
        assert hollow, f"an empty assertion must not satisfy {reason_key}"
    # A non-covered entry point needs a concrete reason.
    unreasoned = _validate_changed_service_neighbourhood(
        block(entry_points=[{"operation": "move", "disposition": "OUT_OF_SCOPE"}]),
        neighbourhood_plan)
    assert any("without a concrete reason" in p for p in unreasoned), (
        "an out-of-scope entry point must say why"
    )
    # Omission is not a disposition.
    undispositioned = _validate_changed_service_neighbourhood(
        block(entry_points=[{"operation": "move"}]), neighbourhood_plan)
    assert any("needs a disposition" in p for p in undispositioned)
    # The enumeration must say where it looked.
    assumed = _validate_changed_service_neighbourhood(
        block(enumeration_evidence=""), neighbourhood_plan)
    assert any("enumeration_evidence" in p for p in assumed), (
        "a single entry point must be an enumerated finding, not an assumption"
    )
    # A caller-scoped lookup must state its permission scope.
    unscoped = _validate_changed_service_neighbourhood(
        block(caller_scoped_lookups=[
            {"lookup": "identifier lookup", "disposition": "COVERED_BY_AC"}]),
        neighbourhood_plan)
    assert any("permission_scope" in p for p in unscoped)
    # No inspected shared collaborator -> gate is inert.
    no_service = nl.join([
        "**Code Touched**",
        "- No code changes yet - development has not started.",
        "**Acceptance Criteria**",
        "- AC-01 [Proposed]: (Basic) Overwriting a file replaces its binary. Evidence: J.",
        ""])
    assert _validate_changed_service_neighbourhood({}, no_service) == []
    # No acceptance contract -> inert.
    assert _validate_changed_service_neighbourhood(
        {}, "**Code Touched**\n- FileConflictsService.findConflicts.\n") == []
    assert _validate_changed_service_neighbourhood({}, plain) == []

    print("coverage_forcing self-tests: PASS")


if __name__ == "__main__":
    run_self_tests()
