#!/usr/bin/env bash
set -euo pipefail

CLIENT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
cd "$CLIENT_DIR"

mkdir -p "$HOME/.claude/commands"
mkdir -p "$HOME/.claude/skills"

rm -f \
  "$HOME/.claude/commands/ask-dita-expert.md" \
  "$HOME/.claude/commands/generate-dita-ot-output.md" \
  "$HOME/.claude/commands/guides-test-plan-generator.md" \
  "$HOME/.claude/commands/aem-data-upload-workflow.md" \
  "$HOME/.claude/commands/aem-generate-dita.md" \
  "$HOME/.claude/commands/aem-generate-dita-ot-output.md" \
  "$HOME/.claude/commands/aem-guides-test-plan.md" \
  "$HOME/.claude/commands/aem-guides-test-scenario-generator.md" \
  "$HOME/.claude/commands/aem-rag-status.md"

cp .claude/commands/aem-ask-dita-expert.md "$HOME/.claude/commands/"
cp .claude/commands/aem-upload-generated-to-aem.md "$HOME/.claude/commands/"

rm -rf "$HOME/.claude/skills/test-plan-generation"
rm -rf "$HOME/.claude/skills/aem-data-upload-workflow"
rm -rf "$HOME/.claude/skills/aem-guides-dita-qa-pipeline"
rm -rf "$HOME/.claude/skills/aem-guides-test-scenario-generator"
rm -rf "$HOME/.claude/skills/attribute-reference-answering"
rm -rf "$HOME/.claude/skills/dita-qa-pipeline"
rm -rf "$HOME/.claude/skills/explain-then-fix"
rm -rf "$HOME/.claude/skills/flakiness-detector"
rm -rf "$HOME/.claude/skills/indexed-automation-authoring"
rm -rf "$HOME/.claude/skills/jira-uac-testcase"
rm -rf "$HOME/.claude/skills/playwright-locator-inspector"
rm -rf "$HOME/.claude/skills/prod-error-test-gap"

cp -R .claude/skills/test-plan-generation "$HOME/.claude/skills/"

python3 - <<'PY'
import json
from pathlib import Path

path = Path.home() / ".claude.json"
deprecated = {
    "aem-upload",
    "dataset-studio",
    "dita-ot-tools",
    "aem-guides-mcp",
    "aem-guides-rag",
    "aem-guides-upload",
    "aem-dataset-studio",
    "aem-guides-test-plan",
}
if path.exists():
    data = json.loads(path.read_text(encoding="utf-8"))
    servers = data.get("mcpServers")
    if isinstance(servers, dict):
        changed = False
        for name in list(deprecated):
            if name in servers:
                servers.pop(name, None)
                changed = True
        if changed:
            path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
PY

echo "Installed Claude skill to:    $HOME/.claude/skills/test-plan-generation"
echo "Installed Claude slash commands:"
echo "  /aem-ask-dita-expert"
echo "  /aem-upload-generated-to-aem"
echo "Removed old AEM slash commands and deprecated AEM skills."
echo
echo "Recommended MCP registration:"
echo "  claude mcp add-json aem-guides-dataset-studio \"\$(cat \"$CLIENT_DIR/claude-mcp-server.json\")\""
echo
echo "Only AEM slash commands installed by this package: /aem-ask-dita-expert and /aem-upload-generated-to-aem"
