#!/usr/bin/env bash
set -euo pipefail

CLIENT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
cd "$CLIENT_DIR"

if [[ ! -x ".venv/bin/python" ]]; then
  echo "Missing .venv. Run ./install.sh first."
  exit 1
fi

".venv/bin/python" - <<'PY'
import json
import os
from pathlib import Path

import httpx

for raw in Path(".env").read_text(encoding="utf-8").splitlines():
    raw = raw.strip()
    if raw and not raw.startswith("#") and "=" in raw:
        key, value = raw.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip())

url = os.environ.get("AEM_STUDIO_URL", "").rstrip("/")
token = os.environ.get("AEM_STUDIO_TOKEN", "dev-bypass")
headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

if not url:
    raise SystemExit("AEM_STUDIO_URL missing in .env")

with httpx.Client(timeout=60) as client:
    health = client.get(f"{url}/health", headers=headers)
    health.raise_for_status()
    health_payload = health.json()
    print("health.status:", health_payload.get("status"))
    print("health.rag_ready:", health_payload.get("rag_ready"))

    rag = client.get(f"{url}/api/v1/ai/rag-status", headers=headers, params={"tenant_id": "default"})
    rag.raise_for_status()
    rag_payload = rag.json()
    print("rag.chroma_available:", rag_payload.get("chroma_available"))
    print("rag.aem_guides.chunk_count:", (rag_payload.get("aem_guides") or {}).get("chunk_count"))
    print("rag.dita_spec.chunk_count:", (rag_payload.get("dita_spec") or {}).get("chunk_count"))
    print("rag.jira_qa.chunk_count:", (rag_payload.get("jira_qa") or {}).get("chunk_count"))

    lookup = client.post(
        f"{url}/api/v1/mcp/lookup-aem-guides",
        headers=headers,
        json={"query": "AEM Guides postprocessing ignored paths enabled paths rules"},
    )
    lookup.raise_for_status()
    lookup_payload = lookup.json()
    print("lookup.count:", lookup_payload.get("count"))
    if lookup_payload.get("results"):
        first = lookup_payload["results"][0]
        print("lookup.first_source:", first.get("source"))

print("ok")
PY
