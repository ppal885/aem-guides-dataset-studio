---
description: Generate a plain-English AEM Guides test plan from Jira using VM RAG/MCP evidence.
argument-hint: GUIDES-48450 optionally with PR URL
---

Input:

```text
$ARGUMENTS
```

Steps:

1. Extract exactly one Jira key like `GUIDES-12345`. If missing, ask for it and stop.
2. If Adobe Jira MCP is available, fetch the Jira and run historical Jira searches using summary terms, components, workflow nouns, labels, error strings, and affected areas. Keep up to 5 relevant rows.
3. If a PR URL/branch/commit is present and GitHub/Git MCP is available, inspect changed files, changed functions, and line-level diffs. If not available, mark Git diff evidence as missing.
4. Call VM MCP tool `test_plan_pipeline` with:
   - `jira_key=<key>`
   - `tenant_id=kone`
   - `full_rag=true`
   - `include_repository_evidence=true`
   - `external_historical_jiras=<rows from Adobe Jira MCP if available>`
5. Use the returned evidence to write a manual-QA style test plan. Do not dump raw JSON.
6. Output only these sections as bullet points, not tables:
   - Acceptance Criteria
   - Expected Behaviour
   - Scope From Git
   - Code Touched
   - Lines Changed
   - Test Scenarios
   - Past Similar Tickets
   - Regression Areas
7. Keep the language plain, concise, and practical, like a manual QA engineer with 5+ years of experience.
8. If required evidence is missing, keep the plan in Draft/QE review state and clearly state the missing evidence.
