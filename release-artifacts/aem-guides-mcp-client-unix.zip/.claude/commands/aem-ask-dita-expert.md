---
description: Ask the VM-hosted AEM Guides/DITA expert using Live RAG evidence.
argument-hint: What are AEM Guides postprocessing ignored/enabled path rules?
---

Question:

```text
$ARGUMENTS
```

Steps:

1. If the question is empty, ask for a DITA, DITA-OT, or AEM Guides question and stop.
2. Call MCP tool `ask_dita_expert` with `question=$ARGUMENTS`.
3. Answer directly first in plain English.
4. Use only returned VM evidence for facts. Cite source titles/URLs when present.
5. If evidence is missing or weak, say what is unverified instead of guessing.
6. For generation or publishing requests, explain that this lightweight client can retrieve evidence and generate DITA bundles through VM tools, but DITA-OT publishing must be run on the VM/backend if enabled there.
