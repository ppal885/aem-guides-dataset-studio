---
description: Check the central VM backend and Live RAG readiness.
argument-hint: optional tenant id, for example kone
---

Use MCP tool `health_check`.

Input tenant id:

```text
$ARGUMENTS
```

Steps:

1. Use `tenant_id=$ARGUMENTS` if provided; otherwise use `default`.
2. Call `health_check`.
3. Report backend health, `rag_ready`, Chroma availability, and chunk counts for AEM Guides, DITA spec, DITA-OT GitHub, Jira QA, and learned QA.
4. If a count is zero or Chroma is unavailable, state the VM-side fix; do not suggest copying local corpus to the teammate laptop.
