# AEM Guides Test Plan Generator Claude Skill

This ZIP installs the canonical AEM Guides test-plan skill plus a declaration-only
legacy alias. Canonical execution still requires either the Dataset Studio backend
checkout (`--repo-root` / `AEM_STUDIO_REPO`) or the configured VM canonical-runtime
MCP endpoint described below.

## Install

Extract this ZIP, then copy:

- `skills/test-plan-generation/` to `~/.claude/skills/test-plan-generation/`
- `skills/aem-guides-test-scenario-generator/` to `~/.claude/skills/aem-guides-test-scenario-generator/` (legacy alias)

Windows paths:

- `%USERPROFILE%\.claude\skills\test-plan-generation\`
- `%USERPROFILE%\.claude\skills\aem-guides-test-scenario-generator\`

macOS/Linux paths:

- `~/.claude/skills/test-plan-generation/`
- `~/.claude/skills/aem-guides-test-scenario-generator/`

Restart Claude Code after copying.

## Use

Ask Claude to use the `test-plan-generation` skill for the Jira or supplied evidence.

## Required MCP/RAG/backend tools

This local skill does not contain the RAG index and does not replace Adobe Jira
MCP. Claude Code must be configured with:

- Adobe Jira MCP for live Jira reads
- local repo access for `xmleditor`, `starling`, `guides-ui-tests`, `dxml-it-tests`
- the existing VM-backed AEM Guides MCP/RAG tools, especially `guides_test_plan_generator`
- optional existing deterministic helper `test_plan_pipeline`

The Dataset Studio or VM backend provides Jira evidence, AEM Guides RAG/enriched behavior chunks,
DITA/DITA-OT evidence, repository analysis, and the canonical stage-owned
reasoning runtime. The canonical skill collects evidence and delegates final
reasoning/rendering to that runtime. The legacy skill is an alias only. Do not
create a second Jira client, RAG index, vector DB, repo scanner, reasoning
pipeline, or renderer.
