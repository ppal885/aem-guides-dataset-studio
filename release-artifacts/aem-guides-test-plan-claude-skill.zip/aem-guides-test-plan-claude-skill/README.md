# AEM Guides Test Plan Generator Claude Skill

This ZIP is for team members who should use the AEM Guides test-plan generator
without cloning the full VM repository.

## Install

Extract this ZIP, then copy:

- `skills/aem-guides-test-scenario-generator/` to `~/.claude/skills/aem-guides-test-scenario-generator/`
- `commands/guides-test-plan-generator.md` to `~/.claude/commands/guides-test-plan-generator.md`

Windows paths:

- `%USERPROFILE%\.claude\skills\aem-guides-test-scenario-generator\`
- `%USERPROFILE%\.claude\commands\guides-test-plan-generator.md`

macOS/Linux paths:

- `~/.claude/skills/aem-guides-test-scenario-generator/`
- `~/.claude/commands/guides-test-plan-generator.md`

Restart Claude Code after copying.

## Use

```text
/guides-test-plan-generator GUIDES-12345
```

## Required MCP/RAG/backend tools

This local skill does not contain the RAG index and does not replace Adobe Jira
MCP. Claude Code must be configured with:

- Adobe Jira MCP for live Jira reads
- local repo access for `xmleditor`, `starling`, `guides-ui-tests`, `dxml-it-tests`
- the existing VM-backed AEM Guides MCP/RAG tools, especially `guides_test_plan_generator`
- optional existing deterministic helper `test_plan_pipeline`

The VM backend provides Jira evidence, AEM Guides RAG/enriched behavior chunks,
DITA/DITA-OT evidence, and repository analysis. The skill only defines the
workflow, output structure, quality gates, and validation rules. Do not create a
second Jira client, RAG index, vector DB, repo scanner service, pipeline app, or
duplicate skill.
