$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$skillSource = Join-Path $root "skills\aem-guides-test-scenario-generator"
$commandSource = Join-Path $root "commands\guides-test-plan-generator.md"
$skillDest = Join-Path $env:USERPROFILE ".claude\skills\aem-guides-test-scenario-generator"
$commandDestDir = Join-Path $env:USERPROFILE ".claude\commands"
New-Item -ItemType Directory -Force -Path (Split-Path -Parent $skillDest) | Out-Null
New-Item -ItemType Directory -Force -Path $commandDestDir | Out-Null
if (Test-Path $skillDest) { Remove-Item -Recurse -Force $skillDest }
Copy-Item -Recurse -Force $skillSource $skillDest
Copy-Item -Force $commandSource (Join-Path $commandDestDir "guides-test-plan-generator.md")
Write-Host "Installed. Restart Claude Code, then run: /guides-test-plan-generator GUIDES-12345"
