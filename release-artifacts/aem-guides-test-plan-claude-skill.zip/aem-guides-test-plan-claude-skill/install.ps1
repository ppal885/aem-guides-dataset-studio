$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$canonicalSource = Join-Path $root "skills\test-plan-generation"
$aliasSource = Join-Path $root "skills\aem-guides-test-scenario-generator"
$canonicalDest = Join-Path $env:USERPROFILE ".claude\skills\test-plan-generation"
$aliasDest = Join-Path $env:USERPROFILE ".claude\skills\aem-guides-test-scenario-generator"
New-Item -ItemType Directory -Force -Path (Split-Path -Parent $canonicalDest) | Out-Null
if (Test-Path $canonicalDest) { Remove-Item -Recurse -Force $canonicalDest }
if (Test-Path $aliasDest) { Remove-Item -Recurse -Force $aliasDest }
Copy-Item -Recurse -Force $canonicalSource $canonicalDest
Copy-Item -Recurse -Force $aliasSource $aliasDest
Write-Host "Installed. Restart Claude Code, then request the test-plan-generation skill."
