#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CANONICAL_DEST="$HOME/.claude/skills/test-plan-generation"
ALIAS_DEST="$HOME/.claude/skills/aem-guides-test-scenario-generator"
mkdir -p "$(dirname "$CANONICAL_DEST")"
rm -rf "$CANONICAL_DEST" "$ALIAS_DEST"
cp -R "$ROOT/skills/test-plan-generation" "$CANONICAL_DEST"
cp -R "$ROOT/skills/aem-guides-test-scenario-generator" "$ALIAS_DEST"
echo "Installed. Restart Claude Code, then request the test-plan-generation skill."
