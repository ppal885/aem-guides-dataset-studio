#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILL_DEST="$HOME/.claude/skills/aem-guides-test-scenario-generator"
COMMAND_DEST="$HOME/.claude/commands/guides-test-plan-generator.md"
mkdir -p "$(dirname "$SKILL_DEST")" "$(dirname "$COMMAND_DEST")"
rm -rf "$SKILL_DEST"
cp -R "$ROOT/skills/aem-guides-test-scenario-generator" "$SKILL_DEST"
cp "$ROOT/commands/guides-test-plan-generator.md" "$COMMAND_DEST"
echo "Installed. Restart Claude Code, then run: /guides-test-plan-generator GUIDES-12345"
