@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install_claude_assets.ps1" %*
