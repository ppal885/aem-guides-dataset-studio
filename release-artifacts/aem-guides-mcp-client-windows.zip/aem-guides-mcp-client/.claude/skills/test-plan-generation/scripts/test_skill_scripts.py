"""Self-tests for the test-plan-generation enforcement scripts.

Run: python scripts/test_skill_scripts.py
Exit 0 = all pass. No third-party deps; stdlib only.

These protect the validator and evidence auditor from silent regressions when
their rules are edited. Every rule that can fail a plan has a positive and a
negative fixture here.
"""

from __future__ import annotations

import importlib.util
import json
import os
import re
import shutil
import tempfile
from pathlib import Path
from types import SimpleNamespace


def _load(module_name: str, filename: str):
    spec = importlib.util.spec_from_file_location(module_name, Path(__file__).with_name(filename))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _find_repo_root() -> Path:
    search_roots = [
        *Path(__file__).resolve().parents,
        Path.cwd().resolve(),
        *Path.cwd().resolve().parents,
    ]
    home = Path.home()
    try:
        home_children = [item for item in home.iterdir() if item.is_dir()]
    except OSError:
        home_children = []
    search_roots.extend(home_children)
    for container in home_children:
        try:
            search_roots.extend(
                item for item in container.iterdir() if item.is_dir()
            )
        except OSError:
            continue
    def _is_dir_safe(path):
        # A candidate walk can cross OS-restricted directories (e.g. macOS
        # /Users/<user>/Library/NGL): is_dir() raises PermissionError there
        # instead of returning False, which must not crash root discovery.
        try:
            return path.is_dir()
        except OSError:
            return False

    for candidate in dict.fromkeys(search_roots):
        if (
            _is_dir_safe(candidate / ".codex" / "skills" / "test-plan-generation")
            and _is_dir_safe(candidate / ".claude" / "skills" / "test-plan-generation")
            and _is_dir_safe(candidate / "skills" / "test-plan-generation")
        ):
            return candidate
    # No full repo layout (a teammate/standalone skill install, e.g. only
    # ~/.claude/skills/test-plan-generation): there are no sibling copies to
    # compare, so return None and let parity/fingerprint checks skip rather than
    # hard-failing run_gates on every teammate machine.
    return None


validate_mod = _load("validate_test_plan", "validate_test_plan.py")
jira_safe_text_mod = _load("jira_safe_text", "jira_safe_text.py")
verify_mod = _load("verify_evidence", "verify_evidence.py")
authoring_state_mod = _load("authoring_state_contract", "authoring_state_contract.py")
component_router_mod = _load("component_reference_router", "component_reference_router.py")
explorer_mod = _load("semantic_relationship_explorer", "semantic_relationship_explorer.py")
audit_mod = _load("anti_hardcoding_audit", "anti_hardcoding_audit.py")
production_hardcoding_mod = _load(
    "audit_production_hardcoding", "audit_production_hardcoding.py"
)
behavior_mod = _load("behavior_model", "behavior_model.py")
coverage_mod = _load("coverage_hypotheses", "coverage_hypotheses.py")
mq_mod = _load("missing_questions", "missing_questions.py")
verifier_mod = _load("hypothesis_verifier", "hypothesis_verifier.py")
coverage_gate_mod = _load("coverage_gate", "coverage_gate.py")
integration_mod = _load("uac_integration", "uac_integration.py")
relevance_mod = _load("relevance_prioritizer", "relevance_prioritizer.py")
disposition_mod = _load("disposition_classifier", "disposition_classifier.py")
oracle_mod = _load("test_oracle_builder", "test_oracle_builder.py")
state_compat_mod = _load("state_compatibility_explorer", "state_compatibility_explorer.py")
cross_surface_mod = _load("cross_surface_resolver", "cross_surface_resolver.py")
struct_equiv_mod = _load("structural_equivalence_verifier", "structural_equivalence_verifier.py")
scenario_reducer_mod = _load("scenario_reducer", "scenario_reducer.py")
authority_mod = _load("evidence_authority_resolver", "evidence_authority_resolver.py")
change_impact_mod = _load("change_impact_explorer", "change_impact_explorer.py")
critic_mod = _load("pre_uac_critic", "pre_uac_critic.py")
impl_grounding_mod = _load("implementation_grounding", "implementation_grounding.py")
cap_elig_mod = _load("capability_eligibility_explorer", "capability_eligibility_explorer.py")
scope_conflict_mod = _load("scope_conflict_resolver", "scope_conflict_resolver.py")
affected_surface_mod = _load("affected_surface_explorer", "affected_surface_explorer.py")
comment_claim_mod = _load("comment_claim_verifier", "comment_claim_verifier.py")
pr_supersession_mod = _load("pr_supersession_check", "pr_supersession_check.py")
concurrency_race_mod = _load("concurrency_race_explorer", "concurrency_race_explorer.py")
enumerated_coverage_mod = _load("enumerated_coverage", "enumerated_coverage.py")
source_requirement_fidelity_mod = _load(
    "source_requirement_fidelity", "source_requirement_fidelity.py"
)
ac_decidability_mod = _load("ac_decidability", "ac_decidability.py")
operational_contract_mod = _load("operational_contract", "operational_contract.py")
feature_class_mod = _load("feature_class_registry", "feature_class_registry.py")
relationship_traversal_mod = _load(
    "relationship_traversal", "relationship_traversal.py"
)
configuration_enumeration_mod = _load(
    "configuration_enumeration_scope", "configuration_enumeration_scope.py"
)
ui_surface_scope_mod = _load("ui_surface_scope", "ui_surface_scope.py")
role_provisioning_mod = _load("role_provisioning", "role_provisioning.py")
fluffyjaws_evidence_mod = _load("fluffyjaws_evidence", "fluffyjaws_evidence.py")
temporal_evidence_mod = _load("temporal_evidence", "temporal_evidence.py")
evidence_conflict_resolver_mod = _load("evidence_conflict_resolver", "evidence_conflict_resolver.py")
question_research_mod = _load("question_research", "question_research.py")
question_planner_mod = _load("question_planner", "question_planner.py")
question_resolver_mod = _load("question_resolver", "question_resolver.py")
coverage_reasoner_mod = _load("coverage_reasoner", "coverage_reasoner.py")
coverage_equivalence_mod = _load("coverage_equivalence", "coverage_equivalence.py")
requirement_lineage_mod = _load("requirement_lineage", "requirement_lineage.py")
historical_jira_safety_mod = _load("historical_jira_safety",
                                   "historical_jira_safety.py")
retrieval_admission_mod = _load("retrieval_admission", "retrieval_admission.py")
retrieval_benchmark_mod = _load("retrieval_benchmark", "retrieval_benchmark.py")
runtime_adapter_mod = _load("canonical_runtime_adapter",
                            "canonical_runtime_adapter.py")
run_gates_mod = _load("run_gates", "run_gates.py")
evidence_sufficiency_mod = _load("evidence_sufficiency", "evidence_sufficiency.py")
doc_research_mod = _load("doc_research_routing", "doc_research_routing.py")
behavior_classification_mod = _load("behavior_classification", "behavior_classification.py")
scope_applicability_mod = _load("scope_applicability", "scope_applicability.py")
ac_language_policy_mod = _load("ac_language_policy", "ac_language_policy.py")
publishing_scope_coverage_mod = _load("publishing_scope_coverage", "publishing_scope_coverage.py")
root_cause_fix_driven_mod = _load("root_cause_fix_driven", "root_cause_fix_driven.py")
reviewer_request_coverage_mod = _load("reviewer_request_coverage", "reviewer_request_coverage.py")
reproducibility_gate_mod = _load("reproducibility_gate", "reproducibility_gate.py")
probe_coverage_gate_mod = _load("probe_coverage_gate", "probe_coverage_gate.py")
dita_semantics_activation_mod = _load("dita_semantics_activation", "dita_semantics_activation.py")
dimension_synthesizer_mod = _load("dimension_synthesizer", "dimension_synthesizer.py")
miss_probe_library_mod = _load("miss_probe_library", "miss_probe_library.py")
feature_map_mod = _load("feature_map", "feature_map.py")
offline_retrieval_mod = _load("offline_retrieval", "offline_retrieval.py")
security_coverage_mod = _load("security_coverage", "security_coverage.py")
localization_regression_coverage_mod = _load(
    "localization_regression_coverage", "localization_regression_coverage.py"
)
upgrade_migration_coverage_mod = _load(
    "upgrade_migration_coverage", "upgrade_migration_coverage.py"
)
repro_dimension_matrix_mod = _load("repro_dimension_matrix", "repro_dimension_matrix.py")
acceptance_synthesizer_mod = _load("acceptance_synthesizer", "acceptance_synthesizer.py")
uac_linter_mod = _load("uac_linter", "uac_linter.py")
human_feedback_delta_mod = _load("human_feedback_delta", "human_feedback_delta.py")
feedback_capture_mod = _load("feedback_capture", "feedback_capture.py")
execution_outcome_mod = _load("execution_outcome", "execution_outcome.py")
entry_point_equivalence_mod = _load("entry_point_equivalence", "entry_point_equivalence.py")
value_provenance_coverage_mod = _load("value_provenance_coverage", "value_provenance_coverage.py")
state_partition_coverage_mod = _load("state_partition_coverage", "state_partition_coverage.py")
native_pdf_coverage_mod = _load("native_pdf_coverage", "native_pdf_coverage.py")
shared_path_regression_coverage_mod = _load("shared_path_regression_coverage", "shared_path_regression_coverage.py")
clarification_gate_mod = _load("clarification_gate", "clarification_gate.py")
qe_completeness_coverage_mod = _load(
    "qe_completeness_coverage", "qe_completeness_coverage.py"
)
manifest_completeness_gate_mod = _load(
    "manifest_completeness_gate", "manifest_completeness_gate.py"
)
skill_fingerprint_mod = _load(
    "skill_bundle_fingerprint_for_self_tests", "skill_bundle_fingerprint.py"
)
terminal_states_mod = _load("terminal_states", "terminal_states.py")
ac_contract_mod = _load("ac_contract_readability", "ac_contract.py")
ac_readability_mod = _load("ac_readability_review", "ac_readability.py")
ac_presentation_mod = _load("ac_presentation", "ac_presentation.py")
contract_fact_mod = _load("contract_fact_extractor", "contract_fact_extractor.py")
contract_integrity_mod = _load("contract_integrity_gate", "contract_integrity_gate.py")
domain_router_mod = _load("issue_domain_router", "issue_domain_router.py")
publishing_scope_mod = _load("publishing_scope", "publishing_scope.py")
behavior_graph_mod = _load("behavior_graph", "behavior_graph.py")
semantic_closure_mod = _load("semantic_closure", "semantic_closure.py")
generated_output_mod = _load("generated_output_contract", "generated_output_contract.py")
content_identity_mod = _load("content_identity_contract", "content_identity_contract.py")
acceptance_promotion_mod = _load("acceptance_promotion", "acceptance_promotion.py")
behavioral_completeness_mod = _load("behavioral_completeness", "behavioral_completeness.py")


GOOD_PLAN = """**Understanding From Jira**
- Issue understood: a thing is broken with a visible symptom.
- Why it matters: Customer context resolved from Jira: not identified; it hurts customers in a concrete way.
- Requested outcome: the thing should stop being broken.
- Lifecycle understood as: Pre-Development UAC with no PR yet.
- Evidence boundary: Evidence mode: full; facts are from live Jira and a backend clone.
**Acceptance Criteria**
- AC-01 [Proposed]: (Basic) Given an input | When the system runs | Then it produces the correct observable output | Evidence: Jira UAC GUIDES-100.
- AC-02 [Proposed]: (Negative) Given a second input | When the system runs | Then it retains valid prior state | Evidence: Jira description GUIDES-100.
**Expected Behaviour**
- Unknown from current evidence.
**Scope From Git**
- Lifecycle stage is Pre-Development UAC and readiness target is UAC-ready.
**Code Touched**
- No code changes yet — development has not started.
**Lines Changed**
- Not applicable — development has not started.
**Test Scenarios**
- Test data to prepare: create map M.ditamap and topic t.dita under /content/dam/sandbox; property foo on jcr:content holds value bar; config gate baz defaults to true; oracle is the observable correct output.
- P0 [AC-01]: Action: do the first thing. Expected: observe the correct output.
- P1 [AC-02]: Action: do the second thing. Expected: observe prior state retained.
**Known Jira Bugs / Past Similar Tickets**
- GUIDES-100 — Some bug. Similarity: strongest match — same failure shape of wrong output. Status: Closed. Resolution: Fixed. Affected version: not available in current evidence. Fix version: 2609. RCA: not available in current evidence. Test evidence: not available in current evidence. Impact: reuse its oracle.
- Search status: JQL by exact error text and workflow terms across the project.
**Regression Areas**
- Nearby reporting workflow that reads the same output should be re-run after the change to confirm it still resolves correctly and the fix does not regress the shared read path.
**Automation Coverage & Gaps**
- Main feature coverage: Partially covered - AC-01 has direct integration coverage while AC-02 is missing.
- AC-01: Covered by an existing API test at the integration layer.
- AC-02: Not covered. Gap recipe at the API layer: setup prior state, poll the async helper with its configured timeout, assert state retained, tag with the suite, and cleanup created assets.
**Open Questions**
- No open questions from current evidence
"""

PERFORMANCE_SIGNAL_CATEGORIES = (
    "data_volume_or_cardinality_growth",
    "concurrency_or_contention",
    "repetition_or_long_duration",
    "latency_timeout_or_throughput",
    "cpu_memory_gc_or_storage",
    "queue_backlog_or_external_dependency",
    "persistence_cleanup_or_stale_state",
)

NOT_REQUIRED_PERFORMANCE = {
    "schema_version": "aem-guides-performance-assessment-v1",
    "decision": "not_required",
    "risk_rating": "low",
    "signal_review": {
        category: {
            "status": "absent",
            "finding": "The reviewed Jira, product evidence, and historical evidence contain no signal for this risk category.",
            "evidence_refs": ["Jira description GUIDES-100"],
        }
        for category in PERFORMANCE_SIGNAL_CATEGORIES
    },
    "workload_model": {
        "operation": "Not applicable after reviewing the functional operation.",
        "cardinality": "Not applicable because no scale or cardinality risk was found.",
        "concurrency": "Not applicable because no concurrent execution risk was found.",
        "repetition": "Not applicable because no repeated-operation risk was found.",
        "duration": "Not applicable because no long-running workflow risk was found.",
    },
    "metrics": [],
    "oracle": {
        "status": "not_applicable",
        "source_ref": "Jira description GUIDES-100",
        "thresholds": [],
    },
    "test_types": [],
    "performance_ac_ids": [],
    "rationale": "No evidence-backed performance mechanism exists, so dedicated performance testing would add noise rather than risk coverage.",
}



def _replace(plan: str, old: str, new: str) -> str:
    assert old in plan, f"fixture anchor not found: {old!r}"
    return plan.replace(old, new)


def check(name: str, condition: bool) -> None:
    if not condition:
        raise AssertionError(f"FAILED: {name}")
    print(f"ok: {name}")


def test_validator() -> None:
    check("good plan passes", validate_mod.validate(GOOD_PLAN) == [])

    no_main_feature_verdict = _replace(
        GOOD_PLAN,
        "- Main feature coverage: Partially covered - AC-01 has direct integration coverage while AC-02 is missing.\n",
        "",
    )
    errs = validate_mod.validate(no_main_feature_verdict)
    check(
        "automation requires one main feature coverage verdict",
        any("Main feature coverage" in error for error in errs),
    )

    ac_without_source = _replace(
        GOOD_PLAN,
        " | Evidence: Jira UAC GUIDES-100.",
        "",
    )
    errs = validate_mod.validate(ac_without_source)
    check("acceptance criterion without source is rejected", any("machine-readable format" in e for e in errs))

    compact_source_line = _replace(
        GOOD_PLAN,
        "- AC-01 [Proposed]: (Basic) Given an input | When the system runs | Then it produces the correct observable output | Evidence: Jira UAC GUIDES-100.",
        "- AC-01\n  - Starting point: an input is available.\n  - Action: the system runs.\n  - Expected result: it produces the correct observable output.",
    )
    errs = validate_mod.validate(compact_source_line)
    check(
        "compact renderer AC syntax is rejected as a durable source record",
        any("machine-readable format" in error for error in errs),
    )

    paste_unsafe_cases = (
        ("`observable output`", "backticks/code spans"),
        ("~observable output~", "strikethrough"),
        ("**observable output**", "bold/italic markers"),
        ("*observable output*", "bold/italic markers"),
        ("[observable output](https://example.com/result)", "Markdown link"),
    )
    for unsafe_outcome, expected_error in paste_unsafe_cases:
        unsafe_plan = _replace(
            GOOD_PLAN,
            "Then it produces the correct observable output | Evidence:",
            f"Then it produces the correct {unsafe_outcome} | Evidence:",
        )
        check(
            f"paste-unsafe AC markup is rejected: {expected_error}",
            any(expected_error in error for error in validate_mod.validate(unsafe_plan)),
        )

    long_then_plan = _replace(
        GOOD_PLAN,
        "Then it produces the correct observable output | Evidence:",
        "Then " + " ".join(f"result{index}" for index in range(46)) + " | Evidence:",
    )
    check(
        "grossly overlong Then clause is rejected with rewrite guidance",
        any(
            "grossly long" in error
            for error in ac_readability_mod.review_plan(long_then_plan)[0]
        ),
    )

    ac_with_only_graph_path = _replace(
        GOOD_PLAN,
        "Evidence: Jira UAC GUIDES-100.",
        "Evidence: graph path path-123.",
    )
    errs = validate_mod.validate(ac_with_only_graph_path)
    check("graph path alone cannot support P0 acceptance", any("never only a graph path" in e for e in errs))

    graph_path_with_jira_shaped_token = _replace(
        GOOD_PLAN,
        "Evidence: Jira UAC GUIDES-100.",
        "Evidence: path:GUIDES-100.",
    )
    errs = validate_mod.validate(graph_path_with_jira_shaped_token)
    check("graph path containing a Jira key is still rejected", any("never only a graph path" in e for e in errs))

    missing_strength = _replace(
        GOOD_PLAN,
        "Similarity: strongest match — same failure shape of wrong output.",
        "Similarity: same version purge area and cleanup theme.",
    )
    errs = validate_mod.validate(missing_strength)
    check("area-only similarity (no match strength) is rejected", any("match strength" in e for e in errs))

    ac_no_sphere = _replace(
        GOOD_PLAN,
        "- AC-01 [Proposed]: (Basic) Given an input | When the system runs | Then it produces the correct observable output | Evidence: Jira UAC GUIDES-100.",
        "- AC-01 [Proposed]: Given an input | When the system runs | Then it produces the correct observable output | Evidence: Jira UAC GUIDES-100.",
    )
    errs = validate_mod.validate(ac_no_sphere)
    check("AC missing the sphere tag is rejected", any("machine-readable format" in e for e in errs))

    ac_invalid_sphere = _replace(
        GOOD_PLAN,
        "(Basic) Given an input",
        "(Security) Given an input",
    )
    errs = validate_mod.validate(ac_invalid_sphere)
    check("AC with an uncontrolled sphere is rejected", any("machine-readable format" in e for e in errs))

    ac_reordered = _replace(
        GOOD_PLAN,
        "Given a second input | When the system runs | Then it retains valid prior state",
        "When the system runs | Given a second input | Then it retains valid prior state",
    )
    errs = validate_mod.validate(ac_reordered)
    check("AC with reordered fields is rejected", any("machine-readable format" in e for e in errs))

    ac_embedded_label = _replace(
        GOOD_PLAN,
        "Given a second input | When the system runs",
        "Given a second input Then a hidden assertion | When the system runs",
    )
    errs = validate_mod.validate(ac_embedded_label)
    check("AC with an embedded field label is rejected", any("machine-readable format" in e for e in errs))

    ac_missing_period = _replace(
        GOOD_PLAN,
        "Evidence: Jira description GUIDES-100.",
        "Evidence: Jira description GUIDES-100",
    )
    errs = validate_mod.validate(ac_missing_period)
    check("AC without terminal punctuation is rejected", any("machine-readable format" in e for e in errs))

    ac_extra_field = _replace(
        GOOD_PLAN,
        " | Evidence: Jira description GUIDES-100.",
        " | Oracle: hidden | Evidence: Jira description GUIDES-100.",
    )
    errs = validate_mod.validate(ac_extra_field)
    check("AC with an extra field is rejected", any("machine-readable format" in e for e in errs))

    duplicate_id = _replace(GOOD_PLAN, "AC-02 [Proposed]", "AC-01 [Proposed]")
    errs = validate_mod.validate(duplicate_id)
    check("duplicate AC IDs are rejected", any("IDs must be unique" in e for e in errs))

    unquantified_performance = _replace(
        GOOD_PLAN,
        "- AC-02 [Proposed]: (Negative) Given a second input | When the system runs | Then it retains valid prior state | Evidence: Jira description GUIDES-100.",
        "- AC-02 [Proposed]: (Performance) Given a large dataset | When the system runs | Then it remains fast | Evidence: Jira comment GUIDES-100.",
    )
    errs = validate_mod.validate(unquantified_performance)
    check(
        "Performance AC without quantified workload is rejected",
        any("Performance AC must define a quantified workload" in e for e in errs),
    )
    check(
        "Performance AC without measurable oracle is rejected",
        any("Performance AC must define a measurable" in e for e in errs),
    )

    quantified_performance = _replace(
        GOOD_PLAN,
        "- AC-02 [Proposed]: (Negative) Given a second input | When the system runs | Then it retains valid prior state | Evidence: Jira description GUIDES-100.",
        "- AC-02 [Proposed]: (Performance) Given 10,000 topics with parent-map references | When the cleanup workflow runs | Then p95 cleanup latency remains at or below 2000 ms | Evidence: Jira comment GUIDES-100.",
    )
    quantified_performance = _replace(
        quantified_performance,
        "- P1 [AC-02]: Action: do the second thing. Expected: observe prior state retained.",
        "- P1 [AC-02]: Action: run the cleanup load benchmark for 10,000 topics. Expected: p95 latency is at or below 2000 ms.",
    )
    check(
        "quantified evidence-backed Performance AC passes",
        validate_mod.validate(quantified_performance) == [],
    )

    ac_no_scenario = _replace(
        GOOD_PLAN,
        "- P1 [AC-02]: Action: do the second thing. Expected: observe prior state retained.",
        "- P1 [AC-01]: Action: do a redundant first thing again. Expected: observe the first result.",
    )
    errs = validate_mod.validate(ac_no_scenario)
    check("AC with no scenario mapping is rejected", any("AC-02 has no Test Scenarios" in e for e in errs))

    ac_no_automation = _replace(
        GOOD_PLAN,
        "- AC-02: Not covered. Gap recipe at the API layer: setup prior state, poll the async helper with its configured timeout, assert state retained, tag with the suite, and cleanup created assets.",
        "- Note: nothing else to automate.",
    )
    errs = validate_mod.validate(ac_no_automation)
    check("AC with no automation verdict is rejected", any("AC-02 has no verdict" in e for e in errs))

    scenario_no_ac = _replace(
        GOOD_PLAN,
        "- P0 [AC-01]: Action: do the first thing. Expected: observe the correct output.",
        "- P0 Action: do the first thing. Expected: observe the correct output.",
    )
    errs = validate_mod.validate(scenario_no_ac)
    check("scenario without AC mapping is rejected", any("missing an AC mapping" in e for e in errs))

    no_test_data = _replace(
        GOOD_PLAN,
        "- Test data to prepare: create map M.ditamap and topic t.dita under /content/dam/sandbox; property foo on jcr:content holds value bar; config gate baz defaults to true; oracle is the observable correct output.\n",
        "",
    )
    errs = validate_mod.validate(no_test_data)
    check("Test Scenarios without a Test data to prepare bullet is rejected", any("Test data to prepare" in e for e in errs))

    no_customer_source = _replace(
        GOOD_PLAN,
        "- Why it matters: Customer context resolved from Jira: not identified; it hurts customers in a concrete way.",
        "- Why it matters: it hurts customers in a concrete way.",
    )
    errs = validate_mod.validate(no_customer_source)
    check("customer context source is required", any("Customer context resolved from Jira" in e for e in errs))

    no_action_expected = _replace(
        GOOD_PLAN,
        "- P0 [AC-01]: Action: do the first thing. Expected: observe the correct output.",
        "- P0 [AC-01]: do the first thing and observe the correct output.",
    )
    errs = validate_mod.validate(no_action_expected)
    check("scenario Action and Expected wording is required", any("Action:" in e and "Expected:" in e for e in errs))

    terse_regression = _replace(
        GOOD_PLAN,
        "- Nearby reporting workflow that reads the same output should be re-run after the change to confirm it still resolves correctly and the fix does not regress the shared read path.",
        "- Map Console reports.",
    )
    errs = validate_mod.validate(terse_regression)
    check("terse keyword-fragment Regression Areas bullet is rejected", any("too terse" in e for e in errs))

    oq_with_impact = _replace(
        GOOD_PLAN,
        "- No open questions from current evidence",
        "- OQ-01: Is the async path in scope? QA impact: if yes add a polling-oracle scenario, if no document the limitation and prove cleanup does not fire.",
    )
    check("open question stating QA impact passes", validate_mod.validate(oq_with_impact) == [])

    oq_no_impact = _replace(
        GOOD_PLAN,
        "- No open questions from current evidence",
        "- OQ-01: Is the fix synchronous or asynchronous on delete?",
    )
    errs = validate_mod.validate(oq_no_impact)
    check("open question without QA impact is rejected", any("Open Questions bullet must use" in e for e in errs))

    oq_duplicate = _replace(
        GOOD_PLAN,
        "- No open questions from current evidence",
        "- OQ-01: Is the async path in scope? QA impact: the answer changes async coverage.\n"
        "- OQ-01: Which timeout applies? QA impact: the answer changes the wait oracle.",
    )
    errs = validate_mod.validate(oq_duplicate)
    check("duplicate Open Question IDs are rejected", any("must be unique" in e for e in errs))

    oq_noncontiguous = _replace(
        GOOD_PLAN,
        "- No open questions from current evidence",
        "- OQ-02: Which timeout applies? QA impact: the answer changes the wait oracle.",
    )
    errs = validate_mod.validate(oq_noncontiguous)
    check(
        "non-contiguous Open Question IDs are rejected",
        any("contiguous and ordered starting at OQ-01" in e for e in errs),
    )

    no_questions_mixed = _replace(
        GOOD_PLAN,
        "- No open questions from current evidence",
        "- No open questions from current evidence\n"
        "- OQ-01: Which timeout applies? QA impact: the answer changes the wait oracle.",
    )
    errs = validate_mod.validate(no_questions_mixed)
    check(
        "no-open-questions declaration cannot coexist with a real question",
        any("cannot coexist" in e for e in errs),
    )

    stable_scenarios = _replace(
        GOOD_PLAN,
        "- P0 [AC-01]: Action: do the first thing. Expected: observe the correct output.\n"
        "- P1 [AC-02]: Action: do the second thing. Expected: observe prior state retained.",
        "- P0 [TS-01] [AC-01]: Action: do the first thing. Expected: observe the correct output.\n"
        "- P1 [TS-02] [AC-02]: Action: do the second thing. Expected: observe prior state retained.",
    )
    check("stable contiguous Test Scenario IDs pass", validate_mod.validate(stable_scenarios) == [])

    duplicate_scenarios = stable_scenarios.replace("[TS-02]", "[TS-01]")
    errs = validate_mod.validate(duplicate_scenarios)
    check("duplicate Test Scenario IDs are rejected", any("must be unique" in e for e in errs))

    clone_no_sync = _replace(
        GOOD_PLAN,
        "- Lifecycle stage is Pre-Development UAC and readiness target is UAC-ready.",
        "- Backend clone C:/starling inspected for current implementation.",
    )
    errs = validate_mod.validate(clone_no_sync)
    check("Scope From Git citing a clone without sync/SHA state is rejected", any("sync/SHA state" in e for e in errs))

    clone_provisional = _replace(
        GOOD_PLAN,
        "- Lifecycle stage is Pre-Development UAC and readiness target is UAC-ready.",
        "- Backend clone C:/starling inspected; revision SHA was not captured this pass so claims are provisional.",
    )
    check("Scope From Git citing a clone with a provisional SHA acknowledgment passes", validate_mod.validate(clone_provisional) == [])

    unvetted_regression_key = _replace(
        GOOD_PLAN,
        "does not regress the shared read path.",
        "does not regress the shared read path. See GUIDES-777.",
    )
    errs = validate_mod.validate(unvetted_regression_key)
    check("Regression Areas citing a Jira key absent from Known Bugs is rejected", any("GUIDES-777" in e for e in errs))


def test_ac_readability() -> None:
    ac = ac_contract_mod
    review = ac_readability_mod

    def readability_plan(outcome: str, *, given: str = "a topic is open", evidence: str = "reviewer feedback") -> str:
        return (
            "**Acceptance Criteria**\n"
            f"- AC-01 [Proposed]: (Basic) Given {given} | When the author checks the result | "
            f"Then {outcome} | Evidence: {evidence}.\n"
            "**Expected Behaviour**\n- Known."
        )

    simple = ac.parse_ac_line(
        "- AC-01 [Proposed]: (Basic) Given a DITA-OT publish returns a generation log | "
        "When the publish workflow completes | Then the logger records one generation-log payload | "
        "Evidence: Jira description GUIDES-44288."
    )
    check("short technical AC remains valid", simple is not None and ac.validate_ac_readability(simple) == [])

    technical_tokens = ac.parse_ac_line(
        "- AC-01 [Proposed]: (Basic) Given largeFileTagCount is 100 for map.ditamap in v2.0 | "
        "When POST /bin/fmdita/import runs | Then the GUIDES-44288 fixture creates one DITA-OT output | "
        "Evidence: Jira description GUIDES-44288."
    )
    check(
        "technical identifiers remain readable tokens",
        technical_tokens is not None and ac.validate_ac_readability(technical_tokens) == [],
    )
    technical_projection = ac_presentation_mod.project_ac_for_people(
        technical_tokens,
        include_status=False,
        header_bullet=False,
    )
    check(
        "plain presentation is one line and preserves technical token text exactly",
        technical_projection
        == (
            "AC-01: largeFileTagCount is 100 for map.ditamap in v2.0; "
            "when POST /bin/fmdita/import runs, "
            "the GUIDES-44288 fixture creates one DITA-OT output."
        ),
    )

    coupled_safety = ac.parse_ac_line(
        "- AC-01 [Proposed]: (Negative) Given an API request has an invalid path | "
        "When the caller submits the request | Then the API returns HTTP 409 and writes no partial state | "
        "Evidence: Jira description GUIDES-44288."
    )
    check(
        "one coupled safety result remains allowed",
        coupled_safety is not None and ac.validate_ac_readability(coupled_safety) == [],
    )

    complex_phrase = ac.parse_ac_line(
        "- AC-01 [Proposed]: (Negative) Given a publish job is active | "
        "When a failure occurs | Then in the event that metadata storage fails the logger records one payload | "
        "Evidence: Jira description GUIDES-44288."
    )
    check(
        "complex legal-style phrase is rejected with a simple replacement",
        complex_phrase is not None
        and any("use 'if' instead" in error for error in ac.validate_ac_readability(complex_phrase)),
    )

    stacked = ac.parse_ac_line(
        "- AC-01 [Proposed]: (Integration) Given a map and a preset and a custom logger and a Splunk sink and an archive are configured | "
        "When the user publishes the map | Then the application log and custom log and Splunk each receive the payload | "
        "Evidence: Jira description GUIDES-44288."
    )
    check(
        "ordinary clause density is reviewed instead of hard-failed by the legacy contract",
        stacked is not None and ac.validate_ac_readability(stacked) == [],
    )

    double_negative = ac.parse_ac_line(
        "- AC-01 [Proposed]: (Negative) Given a publish job has no generation log | "
        "When the job ends | Then the logger does not write an entry unless a payload exists | "
        "Evidence: Jira description GUIDES-44288."
    )
    check(
        "double-negative outcome is rejected",
        double_negative is not None
        and any("double negative" in error for error in ac.validate_ac_readability(double_negative)),
    )

    second_action = ac.parse_ac_line(
        "- AC-01 [Proposed]: (Basic) Given a map is open | "
        "When the author selects a preset and then starts publishing | Then the publish job starts | "
        "Evidence: Jira description GUIDES-44288."
    )
    check(
        "When cannot hide a second action after and then",
        second_action is not None
        and any("second action" in error for error in ac.validate_ac_readability(second_action)),
    )

    ambiguous_choice = ac.parse_ac_line(
        "- AC-01 [Proposed]: (Negative) Given a map and/or topic is selected | "
        "When publishing starts | Then one publish job starts | Evidence: Jira description GUIDES-44288."
    )
    check(
        "and/or is rejected in favor of an exact choice",
        ambiguous_choice is not None
        and any("and/or" in error for error in ac.validate_ac_readability(ambiguous_choice)),
    )

    semicolon = ac.parse_ac_line(
        "- AC-01 [Proposed]: (Basic) Given a publish job succeeds | "
        "When the job ends | Then the output remains valid; the history remains unchanged | "
        "Evidence: Jira description GUIDES-44288."
    )
    check(
        "semicolon-separated outcomes are rejected",
        semicolon is not None
        and any("semicolon" in error for error in ac.validate_ac_readability(semicolon)),
    )

    cross_ac_reference = ac.parse_ac_line(
        "- AC-01 [Proposed]: (Basic) Given a custom attribute has no mapping | "
        "When the author opens the Right Panel | Then the label uses the AC-04 fallback | "
        "Evidence: human review."
    )
    check(
        "AC clauses cannot depend on another AC reference",
        cross_ac_reference is not None
        and any(
            "state the product outcome directly" in error
            for error in ac.validate_ac_readability(cross_ac_reference)
        ),
    )

    review_29 = readability_plan(" ".join(f"word{index}" for index in range(29)))
    check(
        "29-word outcome emits a loud readability review",
        not review.review_plan(review_29)[0]
        and any("too long" in note for note in review.review_plan(review_29)[1]),
    )
    three_sentences = readability_plan("First result appears. Second result remains. Third result is visible.")
    check(
        "three-sentence outcome emits review without hard failure",
        not review.review_plan(three_sentences)[0]
        and any("too long" in note for note in review.review_plan(three_sentences)[1]),
    )
    clause_heavy = readability_plan(
        "the label appears, and the value remains, while the panel stays open, but the view updates, and focus remains"
    )
    check(
        "clause-heavy outcome emits review without hard failure",
        not review.review_plan(clause_heavy)[0]
        and any("too long" in note for note in review.review_plan(clause_heavy)[1]),
    )
    for token in (
        "Widget.render",
        "loadCurrentValue()",
        "C:/repo/Widget.java:42",
        "baseline-relative",
        "materialization",
        "p95",
        "heap",
        "GC",
        "suffix path",
        "render condition",
        "non-asset resource",
        "per-asset gating",
    ):
        plan = readability_plan(f"the named result appears with {token}")
        check(
            f"tester jargon emits review: {token}",
            any("Note for developer" in note for note in review.review_plan(plan)[1]),
        )
    evidence_only = readability_plan(
        "the named result appears", evidence="C:/repo/Widget.java:42 p95"
    )
    check(
        "code and jargon in Evidence do not trigger tester-text review",
        not any("Note for developer" in note for note in review.review_plan(evidence_only)[1]),
    )
    developer_note = readability_plan("the named result appears") + "\n- Note for developer: Widget.render uses p95."
    check(
        "developer note outside the AC is not treated as tester text",
        not any("Note for developer" in note for note in review.review_plan(developer_note)[1]),
    )
    vague = readability_plan("the label appears in the panel")
    check(
        "generic surface emits exact-screen review",
        any("name the exact screen" in note for note in review.review_plan(vague)[1]),
    )
    named = readability_plan(
        "the label appears in the panel", given="Full Tags View is open"
    )
    check(
        "declared exact screen suppresses vague-surface review",
        not any(
            "name the exact screen" in note
            for note in review.review_plan(
                named, named_surfaces=["Full Tags View"]
            )[1]
        ),
    )
    long_given = readability_plan(
        "the named result appears",
        given=" ".join(f"setup{index}" for index in range(29)),
    )
    check(
        "long Given clause emits the same first-read review as a long outcome",
        any("too long in Given" in note for note in review.review_plan(long_given)[1]),
    )
    recap_plan = (
        "**Acceptance Criteria**\n"
        "- AC-01 [Proposed]: (Basic) Given one file is selected | When the menu opens | "
        "Then View source is hidden for a non-DITA file after menu refresh | Evidence: Jira description.\n"
        "- AC-02 [Proposed]: (Basic) Given one file is selected | When the menu opens | "
        "Then Edit topics is hidden for a non-DITA file after selection changes | Evidence: Jira description.\n"
        "- AC-03 [Proposed]: (Basic) Given one file is selected | When the menu opens | "
        "Then View source and Edit topics are hidden for a non-DITA file | Evidence: Jira description.\n"
        "**Expected Behaviour**\n- Known."
    )
    check(
        "combined recap of two earlier outcomes is reviewed",
        any("summarizes outcomes" in note for note in review.review_plan(recap_plan)[1]),
    )


def test_verifier() -> None:
    check(
        "POSIX absolute source path is recognized",
        verify_mod.ABS_PATH_RE.search("/tmp/evidence/Real.java") is not None,
    )

    with tempfile.TemporaryDirectory() as tmp:
        real = Path(tmp) / "Real.java"
        real.write_text("line1\nline2\nline3\n", encoding="utf-8")
        real_posix = real.as_posix()  # drive-absolute with forward slashes

        good = f"**Code Touched**\n- Current implementation in {real_posix} (L2) defines a thing.\n"
        failures, _ = verify_mod.verify(good)
        check("existing file + valid line passes", failures == [])

        bad_line = f"**Code Touched**\n- Current implementation in {real_posix} (L99) defines a thing.\n"
        failures, _ = verify_mod.verify(bad_line)
        check("out-of-range line is failed", any("beyond end" in f for f in failures))

        # symbol-level check: a real file cited with an invented method is failed
        symfile = Path(tmp) / "Svc.java"
        symfile.write_text("class Svc {\n  void processParentMaps() {}\n}\n", encoding="utf-8")
        good_sym = f"- {symfile.as_posix()} exposes processParentMaps (L2).\n"
        failures, _ = verify_mod.verify(good_sym)
        check("real symbol next to a single file passes", failures == [])
        bad_sym = f"- {symfile.as_posix()} exposes invokeGhostMethod (L2).\n"
        failures, _ = verify_mod.verify(bad_sym)
        check("invented symbol next to a single file is failed", any("invokeGhostMethod" in f for f in failures))

        missing = f"**Code Touched**\n- Cited {Path(tmp).as_posix()}/Ghost.java as evidence.\n"
        failures, _ = verify_mod.verify(missing)
        check("missing source file is failed", any("does not exist" in f for f in failures))

        # unverifiable-by-design paths must NOT fail
        skip = "- Runtime path /var/dxml/btree and repo root C:/api automation/dxml-it-tests and file tests/foo/Bar.java.\n"
        failures, _ = verify_mod.verify(skip)
        check("runtime/relative/space-root paths are skipped, not failed", failures == [])

        # backtick-delimited path WITH SPACES is verified against disk
        spaced_dir = Path(tmp) / "api automation"
        spaced_dir.mkdir()
        spaced_file = spaced_dir / "Foo.java"
        spaced_file.write_text("x\n", encoding="utf-8")
        good_spaced = f"- Evidence in `{spaced_file.as_posix()}` proves the thing.\n"
        failures, _ = verify_mod.verify(good_spaced)
        check("backtick path with spaces is verified when it exists", failures == [])

        bad_spaced = f"- Evidence in `{(spaced_dir / 'Ghost.java').as_posix()}` proves nothing.\n"
        failures, _ = verify_mod.verify(bad_spaced)
        check("backtick path with spaces is failed when missing", any("does not exist" in f for f in failures))

        # jira manifest cross-check
        text = "- GUIDES-100 and GUIDES-999 are cited.\n"
        failures, _ = verify_mod.verify(text, jira_keys={"GUIDES-100"})
        check("invented Jira key is flagged against manifest", any("GUIDES-999" in f for f in failures))

        # covered/partial automation without code evidence must fail
        no_code = "**Automation Coverage & Gaps**\n- AC-01: Partially covered by an existing test.\n"
        failures, _ = verify_mod.verify(no_code)
        check("Partially covered without code evidence is failed", any("no fenced code evidence" in f for f in failures))

        with_code = "**Automation Coverage & Gaps**\n- AC-01: Partially covered.\n\n# Appendix A\n```python\ndef t(): pass\n```\n"
        failures, _ = verify_mod.verify(with_code)
        check("Partially covered with code evidence passes", failures == [])

        only_not_covered = "**Automation Coverage & Gaps**\n- AC-01: Not covered. Gap recipe here.\n"
        failures, _ = verify_mod.verify(only_not_covered)
        check("only Not-covered needs no code evidence", failures == [])


def test_attachment_manifest() -> None:
    import json

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        downloaded = tmp_path / "shot.png"
        downloaded.write_bytes(b"\x89PNG\r\n")

        def _manifest(entries) -> str:
            path = tmp_path / "manifest.json"
            path.write_text(json.dumps({"issue": "GUIDES-1", "attachments": entries}), encoding="utf-8")
            return str(path)

        good = _manifest([{"id": "1", "filename": "shot.png", "downloaded_to": downloaded.as_posix(), "analyzed": True}])
        failures, _ = verify_mod.verify_attachments(good)
        check("manifest with real download + analyzed passes", failures == [])

        missing = _manifest([{"id": "2", "filename": "ghost.png", "downloaded_to": (tmp_path / "ghost.png").as_posix(), "analyzed": True}])
        failures, _ = verify_mod.verify_attachments(missing)
        check("manifest with missing download is failed", any("not found on disk" in f for f in failures))

        not_analyzed = _manifest([{"id": "3", "filename": "shot.png", "downloaded_to": downloaded.as_posix(), "analyzed": False}])
        failures, _ = verify_mod.verify_attachments(not_analyzed)
        check("manifest entry not attested analyzed is failed", any("analyzed" in f for f in failures))

        def _manifest_rag(probes, behaviour_matters=True):
            path = tmp_path / "manifest_rag.json"
            payload = {"issue": "GUIDES-1", "attachments": [], "rag_probes": probes}
            if not behaviour_matters:
                payload["behaviour_matters"] = False
            path.write_text(json.dumps(payload), encoding="utf-8")
            return str(path)

        few = _manifest_rag(["only one probe"])
        failures, _ = verify_mod.verify_attachments(few)
        check("fewer than three RAG probes is failed when behaviour matters", any("RAG probe" in f for f in failures))

        enough = _manifest_rag(["q1", "q2", "q3"])
        failures, _ = verify_mod.verify_attachments(enough)
        check("three RAG probes passes", failures == [])

        na = _manifest_rag(["q1"], behaviour_matters=False)
        failures, _ = verify_mod.verify_attachments(na)
        check("one probe passes when behaviour_matters is false", failures == [])


def _full_preflight() -> dict:
    return {
        "mode": "full",
        "checked_at": "2026-08-08T15:30:00+05:30",
        "sources": {
            "product_rag": {
                "status": "available",
                "checked_via": "check_rag_status call and ask_dita_expert probes succeeded",
                "reason": "",
            },
            "jira_history": {
                "status": "available",
                "checked_via": "search_jira_history queries succeeded",
                "reason": "",
            },
            "live_jira": {
                "status": "available",
                "checked_via": "Jira issue fetch succeeded",
                "reason": "",
            },
            "git": {
                "status": "available",
                "checked_via": "local backend clone inspected after sync",
                "reason": "",
            },
            "figma": {
                "status": "not_applicable",
                "checked_via": "input inspection",
                "reason": "No design evidence is supplied or required.",
            },
        },
        "readiness_impact": "none",
        "readiness_impact_reason": "",
        "claim_restrictions": [],
    }


def _canonical_semantic_fixture() -> dict:
    closure_records = [
        {
            "closure_id": f"SC-{index:02d}",
            "entity_ref": "BGN-01",
            "dimension": dimension,
            "subject": "PRODUCT_CONTRACT",
            "applicability": "NOT_APPLICABLE",
            "status": "INVESTIGATED_AND_REJECTED",
            "reason": "No evidence makes this dimension applicable to the generic fixture.",
            "disposition_ref": "CD-03",
        }
        for index, dimension in enumerate(semantic_closure_mod.CLOSURE_DIMENSIONS, 1)
    ]
    non_acceptance_sources = ["BGN-01", *[item["closure_id"] for item in closure_records]]
    return {
        "issue": {
            "key": "GUIDES-100",
            "description": "The requested behavior produces correct observable output and retains valid prior state.",
        },
        "contract_facts": {
            "schema_version": "aem-guides-contract-facts-v1",
            "contract_state": "EVIDENCE_BACKED_PROPOSED_CONTRACT",
            "source_refs": ["Jira description GUIDES-100"],
            "facts": [
                {
                    "fact_id": "CF-01",
                    "category": "DIRECT_EXPECTED_BEHAVIOR",
                    "literal": "correct observable output",
                    "normalized": "correct observable output",
                    "source_ref": "Jira description GUIDES-100",
                    "subject": "PRODUCT_CONTRACT",
                    "authority": "JIRA_EXPECTED_BEHAVIOR",
                    "material": True,
                    "protected_terms": ["correct observable output"],
                    "integrity": "NORMALIZED_WITHOUT_SEMANTIC_CHANGE",
                    "destination": "ACCEPTANCE_CRITERION",
                    "ac_ref": "AC-01",
                },
                {
                    "fact_id": "CF-02",
                    "category": "COMPATIBILITY_REQUIREMENTS",
                    "literal": "retains valid prior state",
                    "normalized": "retains valid prior state",
                    "source_ref": "Jira description GUIDES-100",
                    "subject": "PRODUCT_CONTRACT",
                    "authority": "JIRA_EXPECTED_BEHAVIOR",
                    "material": True,
                    "protected_terms": ["retains valid prior state"],
                    "integrity": "PRESERVED",
                    "destination": "ACCEPTANCE_CRITERION",
                    "ac_ref": "AC-02",
                },
            ],
        },
        "issue_domains": {
            "schema_version": "aem-guides-issue-domains-v1",
            "primary_domain": "OTHER",
            "routes": [
                {
                    "domain": "OTHER",
                    "status": "ACTIVE",
                    "reason": "The generic fixture intentionally has no specialized domain.",
                    "evidence": ["Jira description GUIDES-100"],
                }
            ],
        },
        "behavior_model": {
            "trigger": ["the system runs"],
            "operations": ["produce the requested result"],
            "outputs": ["correct observable output"],
            "affected_state": ["valid prior state"],
            "confidence": 0.8,
        },
        "behavior_graph": {
            "schema_version": "aem-guides-behavior-graph-v1",
            "nodes": [
                {
                    "node_id": "BGN-01",
                    "kind": "PRODUCT_BEHAVIOR",
                    "label": "Requested observable behavior",
                    "material": True,
                    "provenance": ["Jira description GUIDES-100"],
                }
            ],
            "edges": [],
            "traversal_paths": [],
        },
        "semantic_closure": {
            "schema_version": "aem-guides-semantic-closure-v1",
            "records": closure_records,
        },
        "coverage_hypotheses": [],
        "missing_questions": [],
        "evidence_lifecycle": [],
        "verifications": [],
        "dispositions": [
            {
                "finding_id": "CD-01",
                "statement": "The requested observable output is proposed acceptance behavior.",
                "disposition": "PROPOSED_ACCEPTANCE_CONTRACT",
                "source_refs": ["CF-01"],
                "maps_to_ac": "AC-01",
            },
            {
                "finding_id": "CD-02",
                "statement": "Valid prior state remains intact.",
                "disposition": "PROPOSED_ACCEPTANCE_CONTRACT",
                "source_refs": ["CF-02"],
                "maps_to_ac": "AC-02",
            },
            {
                "finding_id": "CD-03",
                "statement": "The remaining generic closure dimensions were explicitly investigated.",
                "disposition": "INVESTIGATED_AND_REJECTED",
                "source_refs": non_acceptance_sources,
            },
        ],
        "acceptance_promotions": {
            "schema_version": "aem-guides-acceptance-promotions-v1",
            "records": [
                {
                    "promotion_id": "AP-01",
                    "candidate_ref": "CF-01",
                    "decision": "PROMOTED_PROPOSED",
                    "ac_ref": "AC-01",
                    "subject": "PRODUCT_CONTRACT",
                    "intended_behavior_authorities": ["JIRA_EXPECTED_BEHAVIOR"],
                    "scope_established": True,
                    "observable": True,
                    "testable": True,
                    "regression_only": False,
                    "implementation_only": False,
                    "conflicts_accepted_uac": False,
                    "unresolved_decision_refs": [],
                    "exact_value_fact_refs": [],
                    "disposition": "PROPOSED_ACCEPTANCE_CONTRACT",
                    "disposition_ref": "CD-01",
                },
                {
                    "promotion_id": "AP-02",
                    "candidate_ref": "CF-02",
                    "decision": "PROMOTED_PROPOSED",
                    "ac_ref": "AC-02",
                    "subject": "PRODUCT_CONTRACT",
                    "intended_behavior_authorities": ["JIRA_EXPECTED_BEHAVIOR"],
                    "scope_established": True,
                    "observable": True,
                    "testable": True,
                    "regression_only": False,
                    "implementation_only": False,
                    "conflicts_accepted_uac": False,
                    "unresolved_decision_refs": [],
                    "exact_value_fact_refs": [],
                    "disposition": "PROPOSED_ACCEPTANCE_CONTRACT",
                    "disposition_ref": "CD-02",
                },
            ],
        },
    }


def _publishing_scope_fixture() -> dict:
    stages = (
        "SOURCE_CONTENT", "MAP_ROOT_CONTEXT", "PRESET", "PROFILE_CONFIG",
        "FILTER_KEY_REFERENCE_RESOLUTION", "SEMANTIC_PROCESSING", "INTERMEDIATE_REPRESENTATION",
        "TRANSFORMER", "OUTPUT_BUILDER", "POST_GENERATION", "GENERATED_ARTIFACT",
        "PERSISTED_REPOSITORY_STATE", "ACTIVATION_PUBLICATION", "STATUS_HISTORY_LOGGING",
    )
    return {
        "schema_version": "aem-guides-publishing-scope-v1",
        "primary_publishing_mode": "AEM_SITES",
        "primary_preset_type": "AEM Sites",
        "enable_dita_ot_processing": "OFF",
        "aem_sites_implementation": "NATIVE",
        "deployment_mode": "CLOUD",
        "in_scope": ["AEM Sites output"],
        "out_of_scope": ["other output presets"],
        "shared_path_outputs": [],
        "shared_path_reason": "No shared output path was found.",
        "open_question_refs": [],
        "transformation_stages": [
            {
                "stage": stage,
                "applicability": "APPLICABLE",
                "reason": "The publishing path was inspected for this stage.",
            }
            for stage in stages
        ],
    }


def _generated_output_fixture() -> dict:
    return {
        "schema_version": "aem-guides-generated-output-contract-v2",
        "artifact_kind": "ARCHIVE",
        "entry_surface": "Output history",
        "delivery_in_scope": True,
        "download_surface": "Download archive action",
        "output_identity": "archive for the selected generation",
        "payload_inventory": [
            {"item_id": "GOI-01", "item": "generated intermediate content", "role": "PRIMARY_CONTENT", "disposition": "INCLUDED"},
            {"item_id": "GOI-02", "item": "generation log", "role": "DIAGNOSTIC", "disposition": "INCLUDED"},
        ],
        "structure": {
            "root": "single generation root",
            "hierarchy": "source hierarchy is preserved",
            "relative_path_policy": "paths remain relative to the generation root",
        },
        "oracles": [
            {
                "oracle_id": f"GO-{index:02d}",
                "oracle_type": oracle_type,
                "applicability": "APPLICABLE" if oracle_type in {"ARTIFACT_EXISTS", "CONTENT_CORRECT", "HIERARCHY_CORRECT", "OUTPUT_PATH_CORRECT", "NO_STALE_OUTPUT", "STATUS_MATCHES_REAL_OUTPUT", "DELIVERY_AVAILABLE"} else "NOT_APPLICABLE",
                "status": "COVERED" if oracle_type in {"ARTIFACT_EXISTS", "CONTENT_CORRECT", "HIERARCHY_CORRECT", "OUTPUT_PATH_CORRECT", "NO_STALE_OUTPUT", "STATUS_MATCHES_REAL_OUTPUT", "DELIVERY_AVAILABLE"} else "INVESTIGATED_AND_REJECTED",
                "expected": f"Explicit applicability decision for {oracle_type}.",
                "disposition_ref": "CD-GO",
            }
            for index, oracle_type in enumerate(generated_output_mod.ORACLE_TYPES, 1)
        ],
    }


def _content_identity_fixture() -> dict:
    return {
        "schema_version": "aem-guides-content-identity-contract-v1",
        "identity_source": "current repository asset identity",
        "selection_policy": "CURRENT",
        "fallback_policy": "NO_FALLBACK",
        "migration_behavior": "UNCHANGED",
        "lifecycle": [
            {
                "state_id": f"CI-{index:02d}",
                "operation": operation,
                "applicability": "APPLICABLE",
                "status": "COVERED",
                "expected_identity": "The current source asset identity is used.",
                "disposition_ref": "CD-CI",
            }
            for index, operation in enumerate(content_identity_mod.OPERATIONS, 1)
        ],
    }


def test_run_gates() -> None:
    import json

    run_gates = _load("run_gates", "run_gates.py")
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "m.json"

        check("run_gates requires a manifest", run_gates.check_manifest_completeness(None) != [])

        path.write_text(json.dumps({"issue": "X"}), encoding="utf-8")
        failures = run_gates.check_manifest_completeness(str(path))
        check("run_gates flags missing manifest keys", any("clones" in f for f in failures) and any("rag_probes" in f for f in failures))

        dual_source = {
            **_canonical_semantic_fixture(),
            "schema_version": "aem-guides-evidence-manifest-v3",
            "issue": {
                "key": "GUIDES-100",
                "description": "The requested behavior produces correct observable output and retains valid prior state.",
            },
            "attachments": [],
            "evidence_preflight": _full_preflight(),
            "rag_tool": "ask_dita_expert",
            "rag_probes": ["a", "b", "c"],
            "jira_history_tool": "search_jira_history",
            "jira_history_queries": [
                {"scope": "same_customer", "query": "failure shape", "component": "Schematron", "customer": "Acme"},
                {"scope": "cross_customer", "query": "failure shape", "component": "Schematron"},
            ],
            "indexed_history_run": True,
            "history_attempts": [
                {
                    "source": "search_jira_history",
                    "query": "failure shape",
                    "result": "ok",
                    "count": 1,
                }
            ],
            "evidence_graph": {
                "requested": True,
                "tool": "query_test_evidence_graph",
                "status": "ready",
                "influence_mode": "shadow",
                "used_for_plan": False,
                "generation_id": "generation-1",
                "queries": [
                    {
                        "query": "same error signature and output mechanism",
                        "duration_ms": 42,
                        "cache_hit": False,
                        "path_ids": ["path-1"],
                        "leaf_citations": [
                            {
                                "leaf_id": "jira_chroma:GUIDES-100:chunk-1:sha256:abc",
                                "source_type": "jira_chroma",
                                "source_ref": "GUIDES-100",
                                "trust_tier": "historical_verified",
                            }
                        ],
                    }
                ],
            },
            "performance_assessment": NOT_REQUIRED_PERFORMANCE,
            "accepted_uac_present": False,
            "open_questions": [],
            "enumerated_requirements": {
                "schema_version": "aem-guides-enumerated-requirements-v1",
                "active": False,
                "reason": "The issue contains no reporter-enumerated requirement list.",
            },
            "operational_contract": {
                "schema_version": "aem-guides-operational-contract-v1",
                "active": False,
                "reason": "The fixture is a synchronous non-operational behavior.",
            },
        }

        legacy_v2 = json.loads(json.dumps(dual_source))
        legacy_v2["schema_version"] = "aem-guides-evidence-manifest-v2"
        for key in run_gates.SEMANTIC_MANIFEST_KEYS:
            legacy_v2.pop(key, None)
        path.write_text(json.dumps(legacy_v2), encoding="utf-8")
        legacy_failures = run_gates.check_manifest_completeness(str(path))
        check(
            "legacy v2 base-schema check stays readable before signal completeness",
            not any(
                "missing required key" in failure
                and any(key in failure for key in run_gates.SEMANTIC_MANIFEST_KEYS)
                for failure in legacy_failures
            ),
        )

        non_behavior = json.loads(json.dumps(dual_source))
        non_behavior["behaviour_matters"] = False
        non_behavior["behaviour_not_applicable_reason"] = "This is a pure internal bookkeeping check."
        for key in run_gates.SEMANTIC_MANIFEST_KEYS:
            non_behavior.pop(key, None)
        path.write_text(json.dumps(non_behavior), encoding="utf-8")
        non_behavior_failures = run_gates.check_manifest_completeness(str(path))
        check(
            "behaviour_matters false waives v3 semantic manifest keys",
            not any(
                "missing required key" in failure
                and any(key in failure for key in run_gates.SEMANTIC_MANIFEST_KEYS)
                for failure in non_behavior_failures
            ),
        )

        proposed_enumerated = json.loads(json.dumps(dual_source))
        proposed_enumerated["enumerated_requirements"] = {
            "schema_version": "aem-guides-enumerated-requirements-v1",
            "active": True,
            "source_ref": "pasted numbered requirements",
            "source_item_count": 1,
            "source_complete": True,
            "items": [
                {
                    "id": "REQ-01",
                    "source_index": 1,
                    "text": "Preserve the named source behavior.",
                    "disposition": "COVERED_BY_AC",
                    "ac_refs": ["AC-01"],
                }
            ],
        }
        path.write_text(json.dumps(proposed_enumerated), encoding="utf-8")
        check(
            "run_gates requires source fidelity for Proposed enumerated requirements",
            any(
                "source_requirement_ledger" in failure
                for failure in run_gates.check_manifest_completeness(str(path))
            ),
        )

        check(
            "principal performance assessment accepts an evidence-backed not-required decision",
            run_gates.performance_mod.validate_performance_assessment(dual_source) == [],
        )
        check(
            "not-required performance assessment aligns with a plan containing no Performance AC",
            run_gates.performance_mod.validate_plan_alignment(dual_source, GOOD_PLAN) == [],
        )

        invalid_performance = json.loads(json.dumps(NOT_REQUIRED_PERFORMANCE))
        invalid_performance["signal_review"].pop("persistence_cleanup_or_stale_state")
        invalid_manifest = {
            **dual_source,
            "performance_assessment": invalid_performance,
            "clones": [],
        }
        path.write_text(json.dumps(invalid_manifest), encoding="utf-8")
        failures = run_gates.check_manifest_completeness(str(path))
        check(
            "run_gates rejects an incomplete principal performance risk review",
            any("seven canonical risk categories" in failure for failure in failures),
        )

        malformed_performance = json.loads(json.dumps(NOT_REQUIRED_PERFORMANCE))
        malformed_performance["metrics"] = [{}]
        malformed_performance["performance_ac_ids"] = [{}]
        malformed_performance["oracle"]["thresholds"] = [{}]
        malformed_failures = run_gates.performance_mod.validate_performance_assessment(
            {"performance_assessment": malformed_performance}
        )
        check(
            "malformed performance arrays fail closed without crashing",
            any("unsupported value" in failure for failure in malformed_failures)
            and any("invalid AC ID" in failure for failure in malformed_failures),
        )

        required_performance = json.loads(json.dumps(NOT_REQUIRED_PERFORMANCE))
        required_performance.update(
            {
                "decision": "required",
                "risk_rating": "high",
                "workload_model": {
                    "operation": "Delete maps and clean parent-map references from affected topics.",
                    "cardinality": "10,000 topics with accumulated parent-map references.",
                    "concurrency": "5 concurrent map-deletion jobs.",
                    "repetition": "10 cleanup iterations per dataset.",
                    "duration": "30 minutes of sustained cleanup activity.",
                },
                "metrics": ["latency_p95", "timeout_rate", "heap_usage", "reference_cardinality"],
                "oracle": {
                    "status": "quantified",
                    "source_ref": "Jira comment GUIDES-100",
                    "thresholds": [
                        "p95 cleanup latency <= 2000 ms",
                        "timeout error rate = 0%",
                    ],
                },
                "test_types": ["load", "soak", "concurrency"],
                "performance_ac_ids": ["AC-02"],
                "rationale": "The Jira reports unbounded parent-map reference growth and timeout risk on a cleanup path, creating a high-impact scalability and resource-retention mechanism.",
            }
        )
        required_performance["signal_review"]["persistence_cleanup_or_stale_state"] = {
            "status": "present",
            "finding": "Deleted maps leave stale parent-map references that increase reference cardinality over time.",
            "evidence_refs": ["Jira description GUIDES-100"],
        }
        required_performance["signal_review"]["latency_timeout_or_throughput"] = {
            "status": "present",
            "finding": "The Jira reports timeout risk on the cleanup and report-read paths.",
            "evidence_refs": ["Jira comment GUIDES-100"],
        }
        required_manifest = {
            **dual_source,
            "performance_assessment": required_performance,
        }
        check(
            "required principal performance assessment passes schema validation",
            run_gates.performance_mod.validate_performance_assessment(required_manifest) == [],
        )
        check(
            "required performance decision fails when the plan omits a Performance AC",
            any(
                "must exactly match visible Performance ACs" in failure
                or "must include a Performance AC" in failure
                for failure in run_gates.performance_mod.validate_plan_alignment(required_manifest, GOOD_PLAN)
            ),
        )

        performance_plan = _replace(
            GOOD_PLAN,
            "- AC-02 [Proposed]: (Negative) Given a second input | When the system runs | Then it retains valid prior state | Evidence: Jira description GUIDES-100.",
            "- AC-02 [Proposed]: (Performance) Given 10,000 topics with parent-map references | When the cleanup workflow runs | Then p95 cleanup latency remains at or below 2000 ms | Evidence: Jira comment GUIDES-100.",
        )
        performance_plan = _replace(
            performance_plan,
            "- P1 [AC-02]: Action: do the second thing. Expected: observe prior state retained.",
            "- P1 [AC-02]: Action: run a 30-minute cleanup load and concurrency benchmark for 10,000 topics. Expected: p95 latency remains at or below 2000 ms with a 0% timeout error rate.",
        )
        check(
            "required performance decision aligns with a quantitative Performance AC",
            run_gates.performance_mod.validate_plan_alignment(required_manifest, performance_plan) == [],
        )
        check(
            "not-required decision rejects an invented Performance AC",
            any(
                "no Performance AC may be emitted" in failure
                for failure in run_gates.performance_mod.validate_plan_alignment(dual_source, performance_plan)
            ),
        )

        passive_historical_performance = _replace(
            GOOD_PLAN,
            "- Nearby reporting workflow that reads the same output should be re-run after the change to confirm it still resolves correctly and the fix does not regress the shared read path.",
            "- GUIDES-37915's enumdefs API performance path on the shared SubjectScheme title-resolution file must not regress.",
        )
        check(
            "manager feedback fails when historical performance Jira is only a passive regression",
            any(
                "historical performance Jira GUIDES-37915" in failure
                and "historical_contracts" in failure
                for failure in run_gates.performance_mod.validate_plan_alignment(
                    dual_source, passive_historical_performance
                )
            ),
        )

        current_performance_issue = {
            **dual_source,
            "issue": "GUIDES-37915",
        }
        check(
            "current performance Jira is not misclassified as historical evidence",
            not any(
                "historical performance Jira GUIDES-37915" in failure
                for failure in run_gates.performance_mod.validate_plan_alignment(
                    current_performance_issue, passive_historical_performance
                )
            ),
        )

        subjectscheme_performance = json.loads(json.dumps(NOT_REQUIRED_PERFORMANCE))
        subjectscheme_performance.update(
            {
                "decision": "required",
                "risk_rating": "high",
                "workload_model": {
                    "operation": "Call GET /bin/aem/guides/xmleditor/subjectscheme/enumdefs through the inspected SubjectScheme title-resolution path.",
                    "cardinality": "1 production-equivalent SubjectScheme dataset with the recorded enumdefs cardinality.",
                    "concurrency": "200 concurrent users.",
                    "repetition": "Run controlled before-fix and after-fix benchmark iterations against the same dataset.",
                    "duration": "Use the GUIDES-37915 approved benchmark duration for each controlled run.",
                },
                "metrics": [
                    "latency_p50",
                    "latency_p90",
                    "latency_p95",
                    "latency_p99",
                    "throughput",
                    "error_rate",
                    "timeout_rate",
                    "cpu_utilization",
                    "memory_usage",
                    "gc_pause",
                ],
                "oracle": {
                    "status": "quantified",
                    "source_ref": "GUIDES-37915 comments dated 2026-01-27 and 2026-01-28",
                    "thresholds": [
                        "p95 response time improves by at least 2x versus the recorded before-fix same-dataset baseline"
                    ],
                },
                "test_types": ["load", "concurrency", "benchmark"],
                "performance_ac_ids": ["AC-02"],
                "historical_contracts": [
                    {
                        "jira_key": "GUIDES-37915",
                        "relationship": "shared_execution_path",
                        "retained": True,
                        "mechanism": "The current change and historical ticket execute the SubjectScheme enumdefs title-resolution request path.",
                        "workload": "200 concurrent users against the same production-equivalent SubjectScheme dataset.",
                        "oracle": "At least 2x p95 response-time improvement versus the recorded before-fix same-dataset baseline.",
                        "evidence_refs": [
                            "GUIDES-37915 comments dated 2026-01-27 and 2026-01-28",
                            "Inspected SubjectScheme enumdefs title-resolution path",
                        ],
                    }
                ],
                "rationale": "The current SubjectScheme title-resolution change uses the same enumdefs execution path as GUIDES-37915, whose comments define a controlled same-dataset benchmark, approximately 200 concurrent users, percentile metrics, and a 2x response-time improvement oracle.",
            }
        )
        subjectscheme_performance["signal_review"]["concurrency_or_contention"] = {
            "status": "present",
            "finding": "GUIDES-37915 defines an expected workload of approximately 200 concurrent users.",
            "evidence_refs": ["GUIDES-37915 comment dated 2026-01-28"],
        }
        subjectscheme_performance["signal_review"]["latency_timeout_or_throughput"] = {
            "status": "present",
            "finding": "GUIDES-37915 records before/after response-time percentiles and a claimed 2x gain.",
            "evidence_refs": ["GUIDES-37915 comment dated 2026-01-27"],
        }
        subjectscheme_manifest = {
            **dual_source,
            "performance_assessment": subjectscheme_performance,
        }
        check(
            "same-path historical SubjectScheme performance contract passes schema validation",
            run_gates.performance_mod.validate_performance_assessment(subjectscheme_manifest) == [],
        )

        subjectscheme_plan = _replace(
            GOOD_PLAN,
            "- AC-02 [Proposed]: (Negative) Given a second input | When the system runs | Then it retains valid prior state | Evidence: Jira description GUIDES-100.",
            "- AC-02 [Proposed]: (Performance) Given 200 concurrent users against the same production-equivalent SubjectScheme dataset | When clients call GET /bin/aem/guides/xmleditor/subjectscheme/enumdefs through the inspected title-resolution path | Then p95 response time improves by at least 2x versus the recorded before-fix same-dataset baseline | Evidence: GUIDES-37915 comments dated 2026-01-27 and 2026-01-28.",
        )
        subjectscheme_plan = _replace(
            subjectscheme_plan,
            "- P1 [AC-02]: Action: do the second thing. Expected: observe prior state retained.",
            "- P1 [AC-02]: Action: run the same-dataset load and concurrency benchmark with 200 concurrent users and capture p50, p90, p95, p99, throughput, error rate, timeout rate, CPU, memory, and GC. Expected: p95 response time improves by at least 2x versus the recorded before-fix baseline without added errors or timeouts.",
        )
        check(
            "retained historical SubjectScheme contract emits a mapped Performance AC",
            run_gates.performance_mod.validate_plan_alignment(
                subjectscheme_manifest, subjectscheme_plan
            )
            == [],
        )

        subjectscheme_without_scenario = _replace(
            subjectscheme_plan,
            "- P1 [AC-02]: Action: run the same-dataset load and concurrency benchmark with 200 concurrent users and capture p50, p90, p95, p99, throughput, error rate, timeout rate, CPU, memory, and GC. Expected: p95 response time improves by at least 2x versus the recorded before-fix baseline without added errors or timeouts.",
            "- P1 [AC-01]: Action: rerun the functional path. Expected: the functional result remains correct.",
        )
        check(
            "retained historical performance AC cannot omit its mapped benchmark scenario",
            any(
                "must map to a Test Scenarios bullet" in failure
                for failure in run_gates.performance_mod.validate_plan_alignment(
                    subjectscheme_manifest, subjectscheme_without_scenario
                )
            ),
        )

        wrong_historical_citation = _replace(
            subjectscheme_plan,
            "Evidence: GUIDES-37915 comments dated 2026-01-27 and 2026-01-28.",
            "Evidence: Jira comment GUIDES-100.",
        )
        check(
            "retained historical performance Jira must be cited by the Performance AC",
            any(
                "GUIDES-37915 must be cited" in failure
                for failure in run_gates.performance_mod.validate_plan_alignment(
                    subjectscheme_manifest, wrong_historical_citation
                )
            ),
        )

        area_only_history = json.loads(json.dumps(subjectscheme_performance))
        area_only_history["historical_contracts"][0]["relationship"] = "area_only"
        check(
            "area-only historical performance cannot be retained",
            any(
                "cannot retain area-only" in failure
                for failure in run_gates.performance_mod.validate_performance_assessment(
                    {"performance_assessment": area_only_history}
                )
            ),
        )

        not_required_with_retained_history = json.loads(json.dumps(subjectscheme_performance))
        not_required_with_retained_history.update(
            {
                "decision": "not_required",
                "risk_rating": "low",
                "metrics": [],
                "test_types": [],
                "performance_ac_ids": [],
                "oracle": {
                    "status": "not_applicable",
                    "source_ref": "GUIDES-37915 comments dated 2026-01-27 and 2026-01-28",
                    "thresholds": [],
                },
            }
        )
        for category in PERFORMANCE_SIGNAL_CATEGORIES:
            not_required_with_retained_history["signal_review"][category]["status"] = "absent"
        check(
            "retained same-path history cannot be classified not-required",
            any(
                "requires decision=required" in failure
                for failure in run_gates.performance_mod.validate_performance_assessment(
                    {"performance_assessment": not_required_with_retained_history}
                )
            ),
        )

        conditional_performance = json.loads(json.dumps(NOT_REQUIRED_PERFORMANCE))
        conditional_performance.update(
            {
                "decision": "conditional",
                "risk_rating": "medium",
                "workload_model": {
                    "operation": "Run the affected cleanup workflow.",
                    "cardinality": "Production-equivalent topic cardinality is not yet supplied.",
                    "concurrency": "Expected concurrent job count is not yet supplied.",
                    "repetition": "Expected repeated-operation count is not yet supplied.",
                    "duration": "Required soak duration is not yet supplied.",
                },
                "oracle": {
                    "status": "unresolved",
                    "source_ref": "Jira description GUIDES-100",
                    "thresholds": [],
                },
                "rationale": "A plausible scale-sensitive cleanup mechanism exists, but the production workload and approved pass-fail threshold are missing, so an AC would otherwise hallucinate its oracle.",
            }
        )
        conditional_performance["signal_review"]["persistence_cleanup_or_stale_state"] = {
            "status": "unknown",
            "finding": "The available evidence does not quantify whether stale-state growth is material at production scale.",
            "evidence_refs": ["Jira description GUIDES-100"],
        }
        conditional_manifest = {
            **dual_source,
            "performance_assessment": conditional_performance,
        }
        check(
            "conditional principal performance assessment passes schema validation",
            run_gates.performance_mod.validate_performance_assessment(conditional_manifest) == [],
        )
        check(
            "conditional performance decision requires a QA-impact Open Question",
            any(
                "requires an Open Questions bullet" in failure
                for failure in run_gates.performance_mod.validate_plan_alignment(conditional_manifest, GOOD_PLAN)
            ),
        )
        conditional_plan = _replace(
            GOOD_PLAN,
            "- No open questions from current evidence",
            "- OQ-01: Confirm production topic cardinality, concurrent cleanup jobs, and the approved p95 latency SLA. QA impact: without these values no Performance AC can be emitted safely; with them QA can define the load, soak, and pass-fail oracle.",
        )
        check(
            "conditional performance decision aligns after its QA-impact question is visible",
            run_gates.performance_mod.validate_plan_alignment(conditional_manifest, conditional_plan) == [],
        )

        path.write_text(json.dumps({**dual_source, "clones": [{"path": "C:/x"}]}), encoding="utf-8")
        failures = run_gates.check_manifest_completeness(str(path))
        check("run_gates flags a clone with no sha and not provisional", any("captured sha" in f for f in failures))

        wrong_tool = {**dual_source, "rag_tool": "search_jira_history", "clones": []}
        path.write_text(json.dumps(wrong_tool), encoding="utf-8")
        failures = run_gates.check_manifest_completeness(str(path))
        check("run_gates rejects Jira search as product-doc RAG", any("rag_tool" in f for f in failures))

        one_scope = {**dual_source, "jira_history_queries": dual_source["jira_history_queries"][:1], "clones": []}
        path.write_text(json.dumps(one_scope), encoding="utf-8")
        failures = run_gates.check_manifest_completeness(str(path))
        check("run_gates requires same and cross-customer Jira searches", any("both same_customer" in f for f in failures))

        invalid_component = {
            **dual_source,
            "jira_history_queries": [
                {**query, "component": "Platform and Integration"}
                for query in dual_source["jira_history_queries"]
            ],
            "clones": [],
        }
        path.write_text(json.dumps(invalid_component), encoding="utf-8")
        failures = run_gates.check_manifest_completeness(str(path))
        check(
            "run_gates rejects noncanonical Jira components",
            any("component must be one of" in failure for failure in failures),
        )

        paths_without_leaves = {
            **dual_source,
            "evidence_graph": {
                **dual_source["evidence_graph"],
                "queries": [{"query": "same mechanism", "duration_ms": 42, "cache_hit": False, "path_ids": ["path-1"], "leaf_citations": []}],
            },
            "clones": [],
        }
        path.write_text(json.dumps(paths_without_leaves), encoding="utf-8")
        failures = run_gates.check_manifest_completeness(str(path))
        check(
            "run_gates rejects graph paths without leaf citations",
            any("without underlying leaf citations" in failure for failure in failures),
        )

        shadow_influence = {
            **dual_source,
            "evidence_graph": {**dual_source["evidence_graph"], "used_for_plan": True},
            "clones": [],
        }
        path.write_text(json.dumps(shadow_influence), encoding="utf-8")
        failures = run_gates.check_manifest_completeness(str(path))
        check(
            "run_gates rejects shadow graph influence",
            any("must be false in shadow mode" in failure for failure in failures),
        )

        degraded_graph = {
            **dual_source,
            "evidence_graph": {
                "requested": True,
                "tool": "query_test_evidence_graph",
                "status": "degraded",
                "influence_mode": "shadow",
                "used_for_plan": False,
                "generation_id": None,
                "queries": [],
                "degraded_reason": "graph service unavailable; direct evidence retained",
            },
            "clones": [],
        }
        path.write_text(json.dumps(degraded_graph), encoding="utf-8")
        check(
            "run_gates allows explicit graph degraded mode",
            run_gates.check_manifest_completeness(str(path)) == [],
        )

        path.write_text(json.dumps({
            **dual_source,
            "clones": [{"path": "C:/x", "provisional": True, "note": "SHA not captured"}],
        }), encoding="utf-8")
        check("run_gates passes a complete manifest", run_gates.check_manifest_completeness(str(path)) == [])

        confirmed_without_authority = _replace(GOOD_PLAN, "[Proposed]", "[Confirmed]")
        check(
            "Confirmed ACs are forbidden when no accepted UAC exists",
            any(
                "every AC must remain [Proposed]" in problem
                for problem in run_gates.check_uac_plan_alignment(
                    {"accepted_uac_present": False}, confirmed_without_authority
                )
            ),
        )
        check(
            "manifest and visible Open Question IDs must match exactly",
            bool(
                run_gates.check_open_question_alignment(
                    {
                        "open_questions": [
                            {"id": "OQ-01", "question": "Which limit?", "qa_impact": "Changes the bound."}
                        ]
                    },
                    GOOD_PLAN,
                )
            ),
        )
        check(
            "combined artifact accepts only the exact plan plus Appendix A",
            run_gates.check_combined_binding(
                GOOD_PLAN, GOOD_PLAN.rstrip("\n") + "\n\n# Appendix A - Automation Evidence\n- Evidence.\n"
            ) == [],
        )
        check(
            "combined artifact rejects a mutated plan body",
            bool(run_gates.check_combined_binding(GOOD_PLAN, GOOD_PLAN.replace("a thing", "another thing"))),
        )

        compact_source = _replace(
            GOOD_PLAN,
            "- AC-01 [Proposed]: (Basic) Given an input | When the system runs | Then it produces the correct observable output | Evidence: Jira UAC GUIDES-100.",
            "- AC-01\n  - Starting point: an input is available.\n  - Action: the system runs.\n  - Expected result: it produces the correct observable output.",
        )
        plan_path = Path(tmp) / "plan.md"
        combined_path = Path(tmp) / "combined.md"
        plan_path.write_text(compact_source, encoding="utf-8")
        combined_path.write_text(compact_source, encoding="utf-8")
        full_manifest = {
            **dual_source,
            "clones": [{"path": "C:/x", "provisional": True, "note": "SHA not captured"}],
            "reviewer_comments": [],
            "reviewer_comments_checked": True,
        }
        path.write_text(json.dumps(full_manifest), encoding="utf-8")
        end_to_end_failures, _ = run_gates.run(
            str(plan_path), str(combined_path), str(path), None, True
        )
        check(
            "full run gate rejects compact source AC syntax",
            any("[validate]" in problem and "machine-readable" in problem for problem in end_to_end_failures),
        )

        fix_plan = _replace(
            GOOD_PLAN,
            "- Lifecycle understood as: Pre-Development UAC with no PR yet.",
            "- Lifecycle understood as: Post-Fix Validation with an inspected candidate fix.",
        )
        fix_plan = _replace(
            fix_plan,
            "- Lifecycle stage is Pre-Development UAC and readiness target is UAC-ready.",
            "- Lifecycle stage is Post-Fix Validation and readiness target is QE sign-off.",
        )
        fix_plan = _replace(
            fix_plan,
            "- No code changes yet — development has not started.",
            "- The inspected fix narrows the resolver while preserving valid prior state.",
        )
        fix_plan = _replace(
            fix_plan,
            "- Not applicable — development has not started.",
            "- The inspected change is recorded in the linked implementation evidence.",
        )
        fix_manifest = json.loads(json.dumps(full_manifest))
        fix_manifest["root_cause_fix"] = {
            "requirement_oracle": "The ticket asks that the resolver accept exactly the intended input set while preserving valid prior state.",
            "fix_fully_covers_requirement": True,
            "fix_fully_covers_reason": "The inspected diff narrows eligibility to exactly the requirement's intended input set with no requirement left out.",
            "scope_delta": [],
            "root_cause": "The resolver accepted an overly broad input set.",
            "fix_contract": "Narrow eligible input processing without changing valid prior state.",
            "fix_adds": ["Eligible inputs now produce the requested observable output."],
            "fix_preserves": ["AC-01: The requested observable output remains correct."],
            "fix_introduced_risks": [
                {
                    "risk": "The narrower selection could discard valid prior state.",
                    "mapped_ac": "AC-02",
                    "open_question_ref": None,
                }
            ],
            "added_tests": [
                {
                    "path": "tests/unit/resolver-test",
                    "layer": "unit",
                    "proves": "The resolver accepts the intended input set.",
                }
            ],
            "verification_performed": "One local build and the added unit test.",
            "verification_gap": [
                "End-to-end execution",
                "Configuration variants",
                "Shared consumers",
            ],
            "lifecycle_stage": "Post-Fix Validation",
        }

        def run_fix_fixture(plan_text: str, manifest_data: dict) -> list[str]:
            plan_path.write_text(plan_text, encoding="utf-8")
            combined_path.write_text(plan_text, encoding="utf-8")
            path.write_text(json.dumps(manifest_data), encoding="utf-8")
            fixture_failures, _ = run_gates.run(
                str(plan_path), str(combined_path), str(path), None, True
            )
            return fixture_failures

        positive_fix_failures = run_fix_fixture(fix_plan, fix_manifest)
        check(
            "run_gates adds no root-cause/fix failure for the complete fixture",
            not any(
                problem.startswith(root_cause_fix_driven_mod.PREFIX)
                for problem in positive_fix_failures
            ),
        )

        pre_development_fix = json.loads(json.dumps(fix_manifest))
        pre_development_fix["root_cause_fix"]["lifecycle_stage"] = "Pre-Development"
        preserve_missing_fix = json.loads(json.dumps(fix_manifest))
        preserve_missing_fix["root_cause_fix"]["fix_preserves"] = [
            "The requested observable output remains correct."
        ]
        unmapped_risk_fix = json.loads(json.dumps(fix_manifest))
        unmapped_risk_fix["root_cause_fix"]["fix_introduced_risks"] = [
            {
                "risk": "The narrower selection could discard valid prior state.",
                "mapped_ac": None,
                "open_question_ref": None,
            }
        ]
        not_covered_fix_plan = _replace(
            fix_plan,
            "Main feature coverage: Partially covered",
            "Main feature coverage: Not covered",
        )
        integration_negatives = (
            ("Pre-Development", fix_plan, pre_development_fix),
            ("unguarded preserved invariant", fix_plan, preserve_missing_fix),
            ("unmapped fix-introduced risk", fix_plan, unmapped_risk_fix),
            ("added test reported Not covered", not_covered_fix_plan, fix_manifest),
        )
        for label, fixture_plan, fixture_manifest in integration_negatives:
            fixture_failures = run_fix_fixture(fixture_plan, fixture_manifest)
            check(
                f"run_gates rejects fix-driven fixture: {label}",
                any(
                    problem.startswith(root_cause_fix_driven_mod.PREFIX)
                    for problem in fixture_failures
                ),
            )

        base = {
            **dual_source,
            "clones": [{"path": "C:/x", "provisional": True, "note": "SHA not captured"}],
            "accepted_uac_present": True,
        }
        path.write_text(json.dumps(base), encoding="utf-8")
        failures = run_gates.check_manifest_completeness(str(path))
        check("accepted UAC requires fidelity audit", any("uac_fidelity" in failure for failure in failures))

        contract = {
            "schema_version": "aem-guides-uac-fidelity-v1",
            "source_ref": "Jira GUIDES-38333 final accepted UAC",
            "accepted_clause_ids": ["UAC-01", "UAC-02"],
            "out_of_scope_clause_ids": ["OOS-01"],
            "clause_to_ac": {"UAC-01": ["AC-01"], "UAC-02": ["AC-02"]},
            "confirmed_ac_to_clause": {"AC-01": ["UAC-01"], "AC-02": ["UAC-02"]},
            "proposed_ac_ids": ["AC-03"],
            "unresolved_clause_ids": [],
            "contradictions": [],
            "scope_expansions": [],
            "status": "pass",
        }
        base["uac_fidelity"] = contract
        path.write_text(json.dumps(base), encoding="utf-8")
        check("complete UAC fidelity audit passes", run_gates.check_manifest_completeness(str(path)) == [])

        contract["clause_to_ac"].pop("UAC-02")
        path.write_text(json.dumps(base), encoding="utf-8")
        failures = run_gates.check_manifest_completeness(str(path))
        check(
            "unmapped accepted UAC clause is rejected",
            any("UAC-02" in failure and "no Confirmed AC" in failure for failure in failures),
        )
        contract["clause_to_ac"]["UAC-02"] = ["AC-02"]

        contract["scope_expansions"] = ["DITA-OT output added despite OOS-01"]
        path.write_text(json.dumps(base), encoding="utf-8")
        failures = run_gates.check_manifest_completeness(str(path))
        check("passing audit cannot hide scope expansion", any("scope expansions" in failure for failure in failures))

        contract["scope_expansions"] = []
        contract["unresolved_clause_ids"] = ["UAC-02"]
        contract["status"] = "blocked"
        path.write_text(json.dumps(base), encoding="utf-8")
        failures = run_gates.check_manifest_completeness(str(path))
        check("blocked UAC fidelity audit cannot pass final gate", any("status is blocked" in failure for failure in failures))

        configured_only = json.loads(json.dumps(dual_source))
        configured_only["clones"] = []
        configured_only["evidence_preflight"]["sources"]["live_jira"]["checked_via"] = "Jira MCP configured"
        path.write_text(json.dumps(configured_only), encoding="utf-8")
        failures = run_gates.check_manifest_completeness(str(path))
        check(
            "preflight rejects configuration as proof of availability",
            any("configuration alone" in failure for failure in failures),
        )

        failed_but_available = json.loads(json.dumps(dual_source))
        failed_but_available["clones"] = []
        failed_but_available["evidence_preflight"]["sources"]["live_jira"]["checked_via"] = (
            "Jira issue fetch returned HTTP 403"
        )
        path.write_text(json.dumps(failed_but_available), encoding="utf-8")
        failures = run_gates.check_manifest_completeness(str(path))
        check(
            "preflight rejects a failed call labelled available",
            any("records a failed check" in failure for failure in failures),
        )

        naive_timestamp = json.loads(json.dumps(dual_source))
        naive_timestamp["clones"] = []
        naive_timestamp["evidence_preflight"]["checked_at"] = "2026-08-08T15:30:00"
        path.write_text(json.dumps(naive_timestamp), encoding="utf-8")
        failures = run_gates.check_manifest_completeness(str(path))
        check(
            "preflight rejects a timestamp without timezone",
            any("timezone-aware" in failure for failure in failures),
        )

        missing_reason = json.loads(json.dumps(dual_source))
        missing_reason["clones"] = []
        missing_reason["evidence_preflight"]["sources"]["figma"]["reason"] = ""
        path.write_text(json.dumps(missing_reason), encoding="utf-8")
        failures = run_gates.check_manifest_completeness(str(path))
        check(
            "preflight requires a not-applicable reason",
            any("figma.reason" in failure for failure in failures),
        )

        false_full = json.loads(json.dumps(dual_source))
        false_full["clones"] = []
        false_full["evidence_preflight"]["sources"]["live_jira"] = {
            "status": "unavailable",
            "checked_via": "Jira issue fetch returned HTTP 403",
            "reason": "The authenticated user lacks Browse permission.",
        }
        false_full["evidence_preflight"]["claim_restrictions"] = [
            "Current Jira status, resolution, and fix version remain unverified."
        ]
        path.write_text(json.dumps(false_full), encoding="utf-8")
        failures = run_gates.check_manifest_completeness(str(path))
        check(
            "preflight rejects full mode when a source is unavailable",
            any("mode must be 'degraded'" in failure for failure in failures),
        )

        degraded = json.loads(json.dumps(false_full))
        degraded["evidence_preflight"]["mode"] = "degraded"
        path.write_text(json.dumps(degraded), encoding="utf-8")
        check(
            "preflight accepts a complete degraded manifest",
            run_gates.check_manifest_completeness(str(path)) == [],
        )

        no_restrictions = json.loads(json.dumps(degraded))
        no_restrictions["evidence_preflight"]["claim_restrictions"] = []
        path.write_text(json.dumps(no_restrictions), encoding="utf-8")
        failures = run_gates.check_manifest_completeness(str(path))
        check(
            "degraded preflight requires claim restrictions",
            any("requires at least one claim restriction" in failure for failure in failures),
        )

        check(
            "full preflight aligns with the visible evidence boundary",
            run_gates._validate_preflight_plan_alignment(dual_source, GOOD_PLAN) == [],
        )
        failures = run_gates._validate_preflight_plan_alignment(degraded, GOOD_PLAN)
        check(
            "degraded preflight rejects a falsely full evidence boundary",
            any("Evidence mode: degraded" in failure for failure in failures),
        )
        degraded_plan = _replace(
            GOOD_PLAN,
            "- Evidence boundary: Evidence mode: full; facts are from live Jira and a backend clone.",
            "- Evidence boundary: Evidence mode: degraded; live Jira is unavailable after HTTP 403, so current status and resolution remain unverified; indexed Jira and backend clone evidence were used.",
        )
        check(
            "degraded preflight aligns when unavailable sources and limits are visible",
            run_gates._validate_preflight_plan_alignment(degraded, degraded_plan) == [],
        )

        unnamed_source_plan = _replace(
            GOOD_PLAN,
            "- Evidence boundary: Evidence mode: full; facts are from live Jira and a backend clone.",
            "- Evidence boundary: Evidence mode: degraded; one source is unavailable, so current status remains unverified.",
        )
        failures = run_gates._validate_preflight_plan_alignment(degraded, unnamed_source_plan)
        check(
            "degraded evidence boundary must name each unavailable source",
            any("live_jira" in failure for failure in failures),
        )

        git_degraded = json.loads(json.dumps(dual_source))
        git_degraded["evidence_preflight"]["mode"] = "degraded"
        git_degraded["evidence_preflight"]["sources"]["git"] = {
            "status": "unavailable",
            "checked_via": "local clone inspection failed",
            "reason": "No clone, diff, branch, commit, or GitHub connection was available.",
        }
        git_degraded["evidence_preflight"]["claim_restrictions"] = [
            "Current implementation, changed files, changed lines, and fix impact remain unverified."
        ]
        implementation_plan = _replace(
            GOOD_PLAN,
            "- Lifecycle understood as: Pre-Development UAC with no PR yet.",
            "- Lifecycle understood as: Implementation Review with a claimed fix.",
        )
        implementation_plan = _replace(
            implementation_plan,
            "- Evidence boundary: Evidence mode: full; facts are from live Jira and a backend clone.",
            "- Evidence boundary: Evidence mode: degraded; Git is unavailable, so implementation and changed-code claims remain unverified.",
        )
        failures = run_gates._validate_preflight_plan_alignment(git_degraded, implementation_plan)
        check(
            "implementation review cannot stay ready when Git is unavailable",
            any("draft_only or blocked" in failure for failure in failures),
        )

        git_degraded["evidence_preflight"]["readiness_impact"] = "draft_only"
        git_degraded["evidence_preflight"]["readiness_impact_reason"] = "Implementation evidence is unavailable."
        check(
            "implementation review accepts explicit degraded readiness",
            run_gates._validate_preflight_plan_alignment(git_degraded, implementation_plan) == [],
        )

        post_fix_plan = implementation_plan.replace(
            "Lifecycle understood as: Implementation Review with a claimed fix.",
            "Lifecycle understood as: Post-Fix Validation for candidate sign-off.",
        )
        failures = run_gates._validate_preflight_plan_alignment(git_degraded, post_fix_plan)
        check(
            "post-fix validation is blocked when Git fix evidence is unavailable",
            any("blocked readiness impact" in failure for failure in failures),
        )



def test_extract_acs() -> None:
    extract_mod = _load("extract_acs", "extract_acs.py")
    criteria, problems = extract_mod.extract(GOOD_PLAN)
    check("extract_acs parses both canonical ACs", len(criteria) == 2 and problems == [])
    check(
        "extract_acs maps stable automation fields",
        criteria[0]["schema_version"] == "aem-guides-ac-v1"
        and criteria[0]["id"] == "AC-01"
        and criteria[0]["sphere"] == "Basic"
        and criteria[0]["given"]
        and criteria[0]["when"]
        and criteria[0]["then"]
        and criteria[0]["evidence"] == "Jira UAC GUIDES-100",
    )
    malformed = _replace(
        GOOD_PLAN,
        "- AC-02 [Proposed]: (Negative) Given a second input | When the system runs | Then it retains valid prior state | Evidence: Jira description GUIDES-100.",
        "- AC-02 [Proposed]: the system retains prior state | Evidence: Jira description GUIDES-100.",
    )
    _, malformed_problems = extract_mod.extract(malformed)
    check("extract_acs fails closed on malformed input", any("unparseable" in p for p in malformed_problems))
    compact_source = _replace(
        GOOD_PLAN,
        "- AC-01 [Proposed]: (Basic) Given an input | When the system runs | Then it produces the correct observable output | Evidence: Jira UAC GUIDES-100.",
        "- AC-01\n  - Starting point: an input is available.\n  - Action: the system runs.\n  - Expected result: it produces the correct observable output.",
    )
    compact_criteria, compact_problems = extract_mod.extract(compact_source)
    check(
        "extract_acs emits no partial payload for compact display syntax",
        compact_criteria == [] and any("unparseable" in problem for problem in compact_problems),
    )
    paste_unsafe = _replace(
        GOOD_PLAN,
        "Then it produces the correct observable output | Evidence:",
        "Then it produces the correct `observable output` | Evidence:",
    )
    unsafe_criteria, unsafe_problems = extract_mod.extract(paste_unsafe)
    check(
        "extract_acs emits no payload for paste-unsafe AC markup",
        unsafe_criteria == [] and any("backticks/code spans" in problem for problem in unsafe_problems),
    )
    unreadable = _replace(
        GOOD_PLAN,
        "Then it produces the correct observable output | Evidence:",
        "Then the system produces the correct output for every selected map and every linked topic while also preserving all metadata, references, permissions, versions, history entries, unrelated files, audit records, workflow states, and generated assets across every supported output preset after processing completes | Evidence:",
    )
    unreadable_criteria, unreadable_problems = extract_mod.extract(unreadable)
    readability_failures, readability_notes = ac_readability_mod.review_plan(unreadable)
    check(
        "extract_acs leaves non-gross clarity review to the readability gate",
        len(unreadable_criteria) == 2
        and unreadable_problems == []
        and readability_failures == []
        and any("too long" in note for note in readability_notes),
    )


def test_compact_view() -> None:
    compact_mod = _load("render_compact_view", "render_compact_view.py")
    compact, problems = compact_mod.project(GOOD_PLAN)
    check("compact view renders without problems", problems == [])
    check(
        "compact view exposes exactly the requested headings",
        [line for line in compact.splitlines() if line.startswith("**")]
        == [
            "**Acceptance Criteria**",
            "**Test Scenarios**",
            "**Jira Tickets Worth Checking**",
            "**Automation Coverage**",
        ],
    )
    check(
        "compact view keeps analysis in the durable artifact",
        "What I understood from Jira" not in compact and "Why it matters" not in compact,
    )
    check(
        "compact view does not leak hidden record sections",
        all(
            hidden not in compact
            for hidden in (
                "Understanding From Jira",
                "Expected Behaviour",
                "Scope From Git",
                "Code Touched",
                "Lines Changed",
                "Automation Coverage & Gaps",
                "**Regression Areas**",
            )
        ),
    )
    check(
        "compact view keeps validated Test Scenarios",
        "**Test Scenarios**" in compact
        and "Test data to prepare:" in compact
        and "P0 [AC-01]" in compact
        and "P3 [Regression]" in compact
        and "Action:" in compact
        and "Expected:" in compact,
    )
    acceptance_block = compact.split("**Test Scenarios**", 1)[0]
    check(
        "compact ACs use one plain line and hide internal record labels",
        (
            "- AC-01: an input; when the system runs, "
            "it produces the correct observable output."
        )
        in acceptance_block
        and "Given " not in acceptance_block
        and "Then " not in acceptance_block
        and "Starting point:" not in acceptance_block
        and " | " not in acceptance_block
        and "[Proposed]" not in acceptance_block
        and "Evidence:" not in acceptance_block,
    )
    check(
        "compact Jira list keeps only key and title",
        "- GUIDES-100 - Some bug." in compact
        and "Similarity:" not in compact
        and "Status:" not in compact
        and "Worth checking because" not in compact,
    )
    check(
        "compact automation states main coverage and high-level target",
        "Main feature coverage: Partially covered" in compact
        and "integration/API test automation" in compact,
    )
    check(
        "compact view hides Open Questions but durable record keeps them",
        "**Open Questions**" not in compact
        and "No open questions from current evidence" not in compact
        and "**Open Questions**" in GOOD_PLAN,
    )

    invalid_source = _replace(
        GOOD_PLAN,
        "- AC-01 [Proposed]: (Basic) Given an input | When the system runs | Then it produces the correct observable output | Evidence: Jira UAC GUIDES-100.",
        "- AC-01: the feature works",
    )
    invalid_compact, invalid_problems = compact_mod.project(invalid_source)
    check(
        "compact renderer emits nothing for a noncanonical source AC",
        invalid_compact == "" and bool(invalid_problems),
    )

    no_match_plan = _replace(
        GOOD_PLAN,
        "- GUIDES-100 — Some bug. Similarity: strongest match — same failure shape of wrong output. Status: Closed. Resolution: Fixed. Affected version: not available in current evidence. Fix version: 2609. RCA: not available in current evidence. Test evidence: not available in current evidence. Impact: reuse its oracle.\n",
        "",
    )
    no_match_compact, no_match_problems = compact_mod.project(no_match_plan)
    check(
        "compact view renders a deterministic no-Jira result",
        no_match_problems == []
        and "No same-mechanism Jira ticket is worth checking" in no_match_compact,
    )


def test_authoring_state_contract() -> None:
    authoring = authoring_state_mod.derive_contract(
        "In Author view, editing deep inside a large topic or inserting a reference link "
        "unexpectedly scrolls the editing screen to the top and hides the active cursor."
    )
    check(
        "large-topic authoring issue routes to viewport stability",
        authoring["route"] == "authoring_viewport_stability",
    )
    authoring_text = "\n".join(
        [*authoring["acceptance_criteria"], *authoring["test_scenarios"]]
    )
    for marker in (
        "active caret or selected element deep in the document",
        "cross-reference or reference link",
        "focus returns to the intended insertion location",
        "relative to the active element rather than to an exact prior pixel offset",
        "type, paste",
        "cancel it repeatedly",
        "no reference or duplicate content is inserted",
    ):
        check(f"authoring viewport contract contains {marker}", marker in authoring_text)
    for unsupported in (
        "left map tree",
        "save/reopen",
        "old editor",
        "milliseconds",
        "data loss",
    ):
        check(
            f"authoring viewport contract does not invent {unsupported}",
            unsupported.lower() not in authoring_text.lower(),
        )

    preview = authoring_state_mod.derive_contract(
        "Map Preview scroll position, selected topic, refresh, and condition panel state "
        "must survive Edit-return behavior."
    )
    check("map preview remains a separate route", preview["route"] == "map_preview_state")
    preview_text = "\n".join(
        [*preview["acceptance_criteria"], *preview["test_scenarios"]]
    )
    check("map preview retains condition state", "condition state" in preview_text)
    check("map preview does not inherit caret behavior", "caret" not in preview_text.lower())

    cals = authoring_state_mod.derive_contract(
        "Delete two selected columns from a 6 row and 5 column CALS table."
    )
    check("CALS deletion gets the structural route", cals["route"] == "cals_multi_column_delete")
    cals_text = "\n".join([*cals["acceptance_criteria"], *cals["test_scenarios"]])
    for marker in (
        "source-defined row and column count",
        "visible column count decreases by the number of distinct deleted columns",
        "ghost column",
        "span metadata",
    ):
        check(f"CALS deletion contract contains {marker}", marker in cals_text)

    large_file = authoring_state_mod.derive_contract(
        "Ctrl+Z changes after the configured boundary; largeFileTagCount controls the large-file safeguard."
    )
    check(
        "large-file safeguard is configuration-driven working-as-designed behavior",
        large_file["route"] == "large_file_configuration"
        and large_file["classification"] == "working_as_designed_configuration",
    )
    large_file_text = "\n".join(
        [*large_file["acceptance_criteria"], *large_file["test_scenarios"]]
    )
    check("large-file contract uses parsed tag threshold", "parsed-tag threshold" in large_file_text)
    check(
        "large-file contract does not create an observed-count AC",
        all("observed count" not in criterion for criterion in large_file["acceptance_criteria"]),
    )
    key_only = authoring_state_mod.derive_contract("Historical issue GUIDES-35437")
    check(
        "historical issue key alone cannot activate the large-file route",
        key_only["route"] is None,
    )


def test_uac_fidelity_reference() -> None:
    skill_root = Path(__file__).resolve().parents[1]
    skill_text = (skill_root / "SKILL.md").read_text(encoding="utf-8")
    reference_path = skill_root / "references" / "uac-reference-examples.md"
    reference_text = reference_path.read_text(encoding="utf-8")
    checklist_text = (skill_root / "references" / "quality-gate-checklist.md").read_text(encoding="utf-8")

    for marker in (
        "#### Accepted UAC Fidelity Gate",
        "aem-guides-uac-fidelity-v1",
        "bidirectional traceability",
        "configuration truth table",
        "Do not convert a working-as-designed complaint into Confirmed AC",
        "Do not treat a configuration-gated control as removed or deprecated",
        "Respect investigation chronology",
        "Do not equate `Resolution: Fixed` with a verified product-code fix",
        "Never merge a mainline accepted UAC into a hotfix ticket",
        "Collapse repeated identical UAC blocks deterministically",
        "Incident workload observations are not performance SLAs",
        "Product-fix chronology without accepted UAC remains candidate regression evidence",
        "jira_comment_accepted_scope",
        "Preserve contradictory automation labels",
        "### Deterministic Authoring-State Routing",
        "scripts/authoring_state_contract.py",
        "references/authoring-state-uac.md",
        "references/component-routing.md",
        "scripts/component_reference_router.py",
        "references/component-authoring.md",
        "references/component-integration.md",
        "When a later accepted scope conflicts with an older description",
        "For map-Xref display labels, separate visible text from destination semantics",
        "For hierarchy-selection counts, derive the expected selected set and count from the current fixture",
        "For Explorer sorting, keep display label, sort key, sort direction",
        "For asset CRUD API requests",
    ):
        check(f"skill retains UAC fidelity marker {marker}", marker in skill_text)
    for marker in (
        "non-authoritative regression and evaluator catalog",
        "must never activate or authorize that rule for a new issue",
        "## What Good UAC Looks Like",
        "## Gold Reference:",
        "## Caution Reference:",
        "[Proposed]",
        "[Confirmed]",
        "Open Question",
    ):
        check(f"regression catalog retains generic fixture boundary {marker}", marker in reference_text)
    check(
        "quality gate enforces accepted UAC fidelity",
        "Final accepted UAC exists but its fidelity audit is missing" in checklist_text,
    )

    # Host delegation protocol: one UAC request = exactly one user-visible
    # conversation.  Researchers stay parallel but run as hidden `task`
    # subagents; `create_session` would create a sidebar thread per leaf.
    check(
        "host protocol delegates research through the task tool",
        "call the `task` tool with `agent_type`" in skill_text,
    )
    check(
        "host protocol forbids user-visible sessions for research",
        "NEVER use `create_session` (or any `open_*_session` tool) to run "
        "research" in skill_text,
    )
    check(
        "host protocol keeps researchers parallel",
        '`mode: "background"`' in skill_text
        and "BEFORE reading any result" in skill_text,
    )
    check(
        "host protocol collects results through read_agent exactly once",
        "with `read_agent`" in skill_text
        and "consumed exactly once" in skill_text,
    )
    check(
        "host protocol keeps no user-visible leaf conversation",
        "creates NO user-visible conversation" in skill_text,
    )

    # Terminal-event discipline: lifecycle events are internal, emit nothing,
    # and can never re-enter orchestration.
    check(
        "host protocol treats lifecycle events as internal terminal events",
        "INTERNAL TERMINAL EVENTS" in skill_text,
    )
    check(
        "host protocol forbids recursive response cycles",
        "must never recursively trigger another response cycle" in skill_text,
    )
    check(
        "host protocol emits no user-visible message for terminal events",
        "emit NO user-visible message for any of these events" in skill_text,
    )
    check(
        "host protocol never re-enters orchestration for a stale leaf",
        "never re-enter orchestration for it" in skill_text,
    )
    check(
        "host protocol locks the debug-mode exception",
        "AGENT_RESEARCH_DEBUG" in skill_text,
    )
    check(
        "host protocol posts exactly one research status line",
        "Researching relevant Jira evidence, documentation, attachments and "
        "implementation" in skill_text,
    )

    authoring_reference = (
        skill_root / "references" / "authoring-state-uac.md"
    ).read_text(encoding="utf-8")
    for marker in (
        "## Route 1 - Authoring Viewport Stability",
        "## Route 2 - Map Preview State Restoration",
        "## Route 3 - CALS Multi-Column Deletion",
        "## Route 4 - Configuration-Driven Large-File Safeguard",
        "Derive the starting row/column count",
        "largeFileTagCount",
        "Screenshot-only and pasted examples",
    ):
        check(
            f"authoring-state reference retains marker {marker}",
            marker in authoring_reference,
        )

    repo_root = Path(__file__).resolve().parents[4]
    counterpart_root = (
        repo_root
        / (".claude" if skill_root.parts[-3] == ".codex" else ".codex")
        / "skills"
        / "test-plan-generation"
    )
    counterpart = counterpart_root / "references" / "uac-reference-examples.md"
    if counterpart.is_file():
        check("Codex and Claude UAC references stay identical", reference_path.read_bytes() == counterpart.read_bytes())


def test_agent_registrations() -> None:
    """A5 role registrations must be byte-loadable by the Copilot host.

    The host registers a custom agent only when its file begins with exactly
    "---\\n".  A BOM or a CRLF newline silently unregisters the role, which
    strands the coordinator with no researcher to delegate to and pushes it
    back onto user-visible sessions.
    """
    sync = _load("sync_agent_registrations", "sync_agent_registrations.py")
    for name in sorted(sync.ROLES):
        path = sync.REGISTRATIONS / f"{name}.agent.md"
        check(f"registration exists for {name}", path.exists())
        if not path.exists():
            continue
        raw = path.read_bytes()
        check(
            f"{name} registration starts with exactly '---\\n'",
            raw.startswith(b"---\n"),
        )
        check(
            f"{name} registration carries no BOM",
            not raw.startswith(b"\xef\xbb\xbf"),
        )
        check(f"{name} registration carries no CR byte", b"\r" not in raw)
        check(
            f"{name} registration declares no session-messaging tool",
            b"send_session_message" not in raw,
        )

    source = (
        Path(__file__).resolve().parents[1]
        / "scripts"
        / "sync_agent_registrations.py"
    ).read_text(encoding="utf-8")
    check(
        "registration writer emits raw bytes, never Windows text mode",
        'write_bytes(expected.encode("utf-8"))' in source,
    )
    check(
        "registration drift guard compares raw bytes",
        'read_bytes() != expected.encode("utf-8")' in source,
    )

    attributes = sync.REGISTRATIONS.parents[1] / ".gitattributes"
    if attributes.exists():
        rules = attributes.read_text(encoding="utf-8")
        check(
            "checkout pins .agent.md registrations to LF",
            any(
                line.split("#", 1)[0].strip().startswith("*.agent.md")
                and "eol=lf" in line
                for line in rules.splitlines()
            ),
        )


def test_component_reference_routing() -> None:
    thumbnail = component_router_mod.route_references(
        summary="Thumbnail display for multimedia on homepage repo and new search result panel",
        description=(
            "Multi-selection is not possible when applying an image to a topic. "
            "Multi-selection should only be possible within a specific folder."
        ),
        acceptance_criteria=(
            "Thumbnail should be shown for valid image files in Home Repository content view, "
            "Search panel, and Bottom search panel. PNG, JPG, and SVG thumbnails should match "
            "the latest image version and load with lazy-loading without layout jank."
        ),
        resolution="Fixed",
        labels=["UAC_Done", "Customer-A"],
    )
    check("thumbnail scope routes to Authoring", thumbnail["primary_component"] == "Authoring")
    check(
        "accepted thumbnail scope excludes stale multi-selection mechanism",
        thumbnail["mechanisms"] == ["asset_browser_thumbnail"],
    )
    check(
        "thumbnail scope pivot emits a deterministic warning",
        "stale_multi_selection_request_is_not_thumbnail_uac" in thumbnail["warnings"],
    )
    check(
        "Authoring route avoids the full UAC catalog",
        thumbnail["references"]
        == ["references/component-routing.md", "references/component-authoring.md"]
        and thumbnail["load_full_uac_reference"] is False,
    )

    map_xref = component_router_mod.route_references(
        summary="Display Title Instead of File Name for MAP References in Xref",
        description=(
            "Topics display the Title in Xref, but MAP files display the file name. "
            "MAP references should display the Title."
        ),
        resolution="Duplicate",
    )
    check("map Xref routes to Authoring", map_xref["primary_component"] == "Authoring")
    check(
        "map Xref receives the exact mechanism",
        map_xref["mechanisms"] == ["xref_map_display_label"],
    )
    check("duplicate without UAC is Proposed-only", map_xref["scope_mode"] == "proposed_only")
    check(
        "duplicate warning is explicit",
        "caution_resolution_without_uac_is_proposed_only" in map_xref["warnings"],
    )

    configured_conditional_attribute = component_router_mod.route_references(
        component="Editor",
        summary="Friendly names for conditional attributes in Full Tags and Right Panel",
        description=(
            "Discover attributes from /libs/fmdita/config/condAttrList.csv. A newly configured "
            "conditional attribute must use its friendly name or the approved fallback label."
        ),
        acceptance_criteria=(
            "Configured conditional attributes appear in Full Tags, Condition Attributes, and "
            "the Right Panel without freezing the current values into a hardcoded list."
        ),
        labels=["UAC_Done"],
    )
    check(
        "explicit Editor conditional-attribute scope preserves its Jira component",
        configured_conditional_attribute["primary_component"] == "Editor",
    )
    check(
        "conditional-attribute configuration receives the exact mechanism",
        configured_conditional_attribute["mechanisms"]
        == ["config_driven_conditional_attribute_labels"],
    )
    check(
        "conditional-attribute configuration uses the focused Authoring and enumeration packs",
        configured_conditional_attribute["references"]
        == [
            "references/component-routing.md",
            "references/component-authoring.md",
            "references/configuration-driven-enumerations.md",
        ]
        and configured_conditional_attribute["load_full_uac_reference"] is False,
    )
    check(
        "conditional-attribute matrix warning is required",
        "configuration_driven_conditional_attribute_matrix_required"
        in configured_conditional_attribute["warnings"],
    )

    semantic_conditional_attribute = component_router_mod.route_references(
        summary="Dynamically configured conditional attributes need friendly names",
        description=(
            "Use friendly display labels for configured conditional attributes and a raw fallback "
            "when a mapping is absent."
        ),
    )
    check(
        "semantic conditional-attribute wording activates the same route without a path",
        semantic_conditional_attribute["mechanisms"]
        == ["config_driven_conditional_attribute_labels"]
        and "references/configuration-driven-enumerations.md"
        in semantic_conditional_attribute["references"],
    )

    generic_ditaval_filter = component_router_mod.route_references(
        summary="Use DITAVAL conditional filtering for AEM Sites output",
        description="The output preset offers None and Using DITAVAL filtering modes.",
    )
    check(
        "generic DITAVAL filtering does not activate conditional-attribute label learning",
        "config_driven_conditional_attribute_labels"
        not in generic_ditaval_filter["mechanisms"],
    )

    generic_right_panel = component_router_mod.route_references(
        summary="Review task details in the Right Panel",
        description="The Right Panel shows the selected review task and its status.",
    )
    check(
        "generic Right Panel wording does not activate conditional-attribute label learning",
        "config_driven_conditional_attribute_labels" not in generic_right_panel["mechanisms"],
    )

    map_selection = component_router_mod.route_references(
        component="Authoring",
        summary="Incorrect selected items in Map View",
        acceptance_criteria=(
            "In a fresh Map View, selecting root-map for the first time must immediately "
            "display 9 selected rather than 2 selected. The selected set includes root-map "
            "and every child node named by this fixture; later correct selections cannot mask "
            "the first failure."
        ),
        resolution="Fixed",
        labels=["Authoring", "UAC_Done"],
    )
    check(
        "Map View hierarchy count routes to Authoring",
        map_selection["primary_component"] == "Authoring",
    )
    check(
        "Map View hierarchy count receives the exact mechanism",
        map_selection["mechanisms"] == ["map_view_hierarchy_selection_count"],
    )
    check(
        "accepted Map View count uses accepted scope",
        map_selection["scope_mode"] == "accepted_field_primary",
    )

    explorer_sorting = component_router_mod.route_references(
        summary="Enable filename-based or user-selectable sorting in Web Editor Explorer",
        description=(
            "User Preferences Display File name changes the Explorer label, but the folder-level "
            "Assets sort order remains unchanged. The requested outcome either honours the display "
            "preference as the default sort key or exposes explicit sort controls for Name or Title "
            "with ascending and descending direction plus a per-user session override."
        ),
        resolution="Working as Designed",
        labels=["Customer-B"],
    )
    check(
        "Explorer filename/title sorting routes to Authoring",
        explorer_sorting["primary_component"] == "Authoring",
    )
    check(
        "Explorer sorting receives the exact mechanism",
        explorer_sorting["mechanisms"] == ["explorer_filename_title_sorting"],
    )
    check(
        "working-as-designed Explorer request stays Proposed-only",
        explorer_sorting["scope_mode"] == "proposed_only",
    )
    for warning in (
        "accepted_uac_missing",
        "caution_resolution_without_uac_is_proposed_only",
        "explorer_sort_request_without_accepted_uac_is_proposed_only",
        "explorer_sort_interaction_model_is_unresolved",
    ):
        check(f"Explorer sorting warning is retained: {warning}", warning in explorer_sorting["warnings"])

    explorer_sorting_with_mockup = component_router_mod.route_references(
        summary="Enable filename-based or user-selectable sorting in Web Editor Explorer",
        description=(
            "The requested outcome either honours the display preference as the default sort key "
            "or exposes explicit sort controls for Name or Title with ascending and descending."
        ),
        design_evidence=(
            "The inspected mockup shows a dedicated sort action in the Explorer header to the right "
            "of Search and Add. Feature flag states must be tested with the flag OFF and ON, and the "
            "default state of the button must be validated. The flag key, configured default value, "
            "OFF-state presentation, menu, keys, direction behavior, and persistence are not shown."
        ),
        resolution="Working as Designed",
    )
    check(
        "Explorer mockup selects the explicit sort-control direction",
        explorer_sorting_with_mockup["design_resolution"] == "explicit_sort_control",
    )
    check(
        "Explorer mockup removes the unresolved interaction-model warning",
        "explorer_sort_interaction_model_is_unresolved"
        not in explorer_sorting_with_mockup["warnings"],
    )
    check(
        "Explorer mockup records its design-backed resolution",
        "explorer_sort_explicit_control_selected_by_design"
        in explorer_sorting_with_mockup["warnings"],
    )
    check(
        "Explorer feature flag requires an OFF/ON matrix",
        explorer_sorting_with_mockup["feature_flag_matrix_required"] is True,
    )
    check(
        "Explorer sort control requires default-state validation",
        explorer_sorting_with_mockup["default_control_state_required"] is True,
    )
    for warning in (
        "explorer_sort_feature_flag_state_matrix_required",
        "explorer_sort_feature_flag_key_unresolved",
        "explorer_sort_feature_flag_default_value_unresolved",
        "explorer_sort_flag_off_presentation_unresolved",
        "explorer_sort_button_default_state_required",
        "explorer_sort_button_default_state_unresolved",
    ):
        check(
            f"Explorer flag/default warning is retained: {warning}",
            warning in explorer_sorting_with_mockup["warnings"],
        )
    check(
        "Explorer OFF/ON evidence completes the requested state matrix",
        "explorer_sort_feature_flag_state_matrix_incomplete"
        not in explorer_sorting_with_mockup["warnings"],
    )

    explorer_label_only = component_router_mod.route_references(
        summary="Explorer displays file name instead of title",
        description="The visible Explorer label should follow the selected display preference.",
    )
    check(
        "generic Explorer label wording does not trigger sorting learning",
        "explorer_filename_title_sorting" not in explorer_label_only["mechanisms"],
    )

    folder_deletion = component_router_mod.route_references(
        summary="Request to add folder deletion feature in Guides",
        description=(
            "Guides has no folder delete action and users currently use Assets UI. "
            "The customer also asks for restore or trash behavior."
        ),
        labels=["Customer-C"],
    )
    check(
        "folder deletion routes to Authoring",
        folder_deletion["primary_component"] == "Authoring",
    )
    check(
        "folder deletion receives the exact mechanism",
        folder_deletion["mechanisms"] == ["folder_deletion"],
    )
    check(
        "folder deletion without accepted UAC stays Proposed-only",
        folder_deletion["scope_mode"] == "proposed_only",
    )
    for warning in (
        "folder_deletion_without_accepted_uac_is_proposed_only",
        "folder_deletion_surface_and_version_must_be_verified",
        "folder_restore_is_separate_from_delete_contract",
    ):
        check(
            f"folder deletion warning is retained: {warning}",
            warning in folder_deletion["warnings"],
        )

    generic_file_deletion = component_router_mod.route_references(
        summary="Delete a DITA file",
        description="An authorized user deletes one topic from the repository.",
    )
    check(
        "generic file deletion does not trigger folder-deletion learning",
        "folder_deletion" not in generic_file_deletion["mechanisms"],
    )

    crud_api = component_router_mod.route_references(
        summary="External-system asset CREATE and UPDATE CRUD APIs",
        description=(
            "The CREATE API must accept caller fileContent, metadata, a desired GUID independent "
            "of the human-readable filename, and the UPDATE call must work like UPSERT with an "
            "opt-in force creation control."
        ),
        resolution="",
        labels=["ABS", "CrownEquipment"],
    )
    check("asset CRUD API routes to Integration", crud_api["primary_component"] == "Integration")
    check(
        "asset CRUD API receives the exact mechanism",
        crud_api["mechanisms"] == ["asset_crud_api_contract"],
    )
    check(
        "asset CRUD API uses the focused Integration pack",
        crud_api["references"]
        == ["references/component-routing.md", "references/component-integration.md"]
        and crud_api["load_full_uac_reference"] is False,
    )
    check(
        "asset CRUD request without accepted UAC stays Proposed",
        crud_api["scope_mode"] == "description_candidate"
        and "crud_api_request_without_accepted_uac_is_proposed_only" in crud_api["warnings"],
    )

    generic_api = component_router_mod.route_references(
        summary="API returns an error",
        description="A generic API call fails without an asset CRUD payload contract.",
    )
    check(
        "generic API wording does not trigger asset CRUD learning",
        "asset_crud_api_contract" not in generic_api["mechanisms"]
        and generic_api["load_full_uac_reference"] is False
        and generic_api["references"] == ["references/component-routing.md"]
        and "no_focused_component_pack" in generic_api["warnings"],
    )

    bulk_overwrite = component_router_mod.route_references(
        summary="Abnormal behavior when overwriting a batch of assets",
        description=(
            "The initial bulk upload succeeds, but re-uploading the same-name asset batch "
            "through /bin/fmdita/import can remain stuck on a loader or show a generic error "
            "and redirect the authenticated author to login after repeated CSRF token requests."
        ),
        resolution="Cannot Reproduce",
        labels=["Customer-D"],
    )
    check(
        "bulk overwrite/session failure routes to Platform",
        bulk_overwrite["primary_component"] == "Platform",
    )
    check(
        "bulk overwrite/session failure receives the exact mechanism",
        bulk_overwrite["mechanisms"] == ["bulk_asset_overwrite_session"],
    )
    check(
        "bulk overwrite/session failure uses the focused Platform pack",
        bulk_overwrite["references"]
        == ["references/component-routing.md", "references/component-platform.md"]
        and bulk_overwrite["load_full_uac_reference"] is False,
    )
    for warning in (
        "accepted_uac_missing",
        "caution_resolution_without_uac_is_proposed_only",
        "bulk_overwrite_without_accepted_uac_is_proposed_only",
    ):
        check(
            f"bulk overwrite caution warning is retained: {warning}",
            warning in bulk_overwrite["warnings"],
        )

    generic_upload = component_router_mod.route_references(
        summary="Large asset upload is slow",
        description="A generic DAM upload takes a long time without overwrite or session evidence.",
    )
    check(
        "generic upload wording does not trigger bulk overwrite learning",
        "bulk_asset_overwrite_session" not in generic_upload["mechanisms"],
    )
    historical_count_only = component_router_mod.route_references(
        summary="Overwrite 200 with a stuck loader",
        description="A remembered count and symptom are provided without the required mechanism context.",
    )
    check(
        "historical count cannot replace mechanism context in routing",
        "bulk_asset_overwrite_session" not in historical_count_only["mechanisms"],
    )

    skill_root = Path(__file__).resolve().parents[1]
    authoring_reference = (skill_root / "references" / "component-authoring.md").read_text(
        encoding="utf-8"
    )
    for marker in (
        "## Asset-Browser Thumbnail Contract",
        "does not authorize new multi-selection behavior",
        "## Map-Xref Display Label Contract",
        "`href`, `format`, `scope`, `type`",
        '`scope="external"`',
        "## Map View Hierarchy Selection-Count Contract",
        "Derive the expected selected-node set",
        "cold first selection and a repeat selection separately",
        "Do not import a count, map name, file-type list, or version from another issue",
        "## SubjectScheme Title Resolution and Enumdefs Performance",
        "shared execution path",
        "Without all of those, performance is conditional",
        "## Explorer Filename/Title Sorting Contract",
        "display label, sort key, sort direction, folder default, per-user override",
        "A historical or static mockup cannot select the interaction",
        "## Folder Deletion Contract",
        "File deletion documentation does not prove folder deletion",
        "Historical feature requests are product-evolution context only",
        "## Configuration-Driven Conditional Attribute Discovery and Label Contract",
        "canary conditional attribute",
        "absent from inspected hardcoded allowlists",
        "raw XML attribute name or value",
        "added, renamed, and removed entries",
        "actual schema/DTD/specialization and profile gates",
        "Require live updates only when accepted evidence defines them",
    ):
        check(f"Authoring component pack retains marker {marker}", marker in authoring_reference)

    enumeration_reference = (
        skill_root / "references" / "configuration-driven-enumerations.md"
    ).read_text(encoding="utf-8")
    for marker in (
        "## Minimum Coverage Matrix",
        "Newly added valid entry with a configured friendly/display name",
        "Newly added valid entry without a mapping",
        "active DTD/schema, element, profile, permission, or deployment scope",
        "hardcoded arrays, enums, switch branches, label maps",
        "supported configuration activation or reload boundary",
        "stored raw attribute/key/value",
    ):
        check(
            f"Configuration-driven enumeration reference retains marker {marker}",
            marker in enumeration_reference,
        )

    integration_reference = (skill_root / "references" / "component-integration.md").read_text(
        encoding="utf-8"
    )
    for marker in (
        "## Asset CRUD API Import Contract",
        "Historical tickets and supplied-document examples are regression fixtures only",
        "The word `API`, a historical issue key, or an old API document alone is insufficient",
        "Keep filename, repository path, product identity/GUID, version identity",
        "Keep CREATE, READ/download, UPDATE, DELETE, and UPSERT controls independent",
        "Discover and record each current endpoint, HTTP method, content type",
        "never copy an endpoint, parameter, default, or status from a historical example",
        "test existing and missing targets",
        "no duplicate identity appears",
        "Keep version/revision creation on an existing target separate from missing-target creation",
        "Keep delete reference-bypass/force behavior separate from UPDATE creation behavior",
        "Transport success alone is not a business-success oracle",
        "What identifies an UPDATE target",
        "Historical evidence may create a hypothesis only after same-mechanism verification",
    ):
        check(f"Integration component pack retains marker {marker}", marker in integration_reference)

    platform_reference = (skill_root / "references" / "component-platform.md").read_text(
        encoding="utf-8"
    )
    for marker in (
        "## Bulk Same-Name Asset Overwrite and Session Contract",
        "no historical-ticket authority",
        "A ticket key, customer name, old batch count, or old release cannot activate",
        "import endpoint traffic as failure signatures",
        "not a supported maximum, SLA, timeout, or resource ceiling",
        "observable terminal success, partial-success, or failure state",
        "verified by reading back every targeted asset",
        "Do not import counts from historical examples",
        "Historical evidence may propose a retrieval hypothesis",
        "Do not claim data loss",
    ):
        check(f"Platform component pack retains marker {marker}", marker in platform_reference)

    repo_root = _find_repo_root()
    if repo_root is None:
        print("test_component_reference_routing: SKIP parity (standalone/teammate install, no full repo)")
        return
    canonical_root = repo_root / ".codex" / "skills" / "test-plan-generation"
    copy_roots = (
        ("repository Claude", repo_root / ".claude" / "skills" / "test-plan-generation"),
        ("repository public", repo_root / "skills" / "test-plan-generation"),
        (
            "Windows bundle",
            repo_root / "release-artifacts" / "aem-guides-mcp-client-windows"
            / ".claude" / "skills" / "test-plan-generation",
        ),
        (
            "Unix bundle",
            repo_root / "release-artifacts" / "aem-guides-mcp-client-unix"
            / ".claude" / "skills" / "test-plan-generation",
        ),
    )
    for copy_label, variant_root in copy_roots:
        for relative_path in (
            "SKILL.md",
            "references/chat-deliverable.md",
            "references/plain-language-ac-writing.md",
            "references/output-template.md",
            "references/quality-gate-checklist.md",
            "references/clarification-gate.md",
            "references/manifest-completeness.md",
            "references/localization-regression-coverage.md",
            "references/upgrade-migration-coverage.md",
            "references/root-cause-fix-driven.md",
            "references/security-coverage.md",
            "references/execution-outcome-loop.md",
            "references/shared-human-uac-learning.md",
            "scripts/ac_presentation.py",
            "scripts/ac_contract.py",
            "scripts/clarification_gate.py",
            "scripts/extract_acs.py",
            "scripts/manifest_completeness_gate.py",
            "scripts/localization_regression_coverage.py",
            "scripts/upgrade_migration_coverage.py",
            "scripts/execution_outcome.py",
            "scripts/feedback_capture.py",
            "scripts/publishing_scope_coverage.py",
            "scripts/render_compact_view.py",
            "scripts/root_cause_fix_driven.py",
            "scripts/reviewer_request_coverage.py",
            "scripts/reproducibility_gate.py",
            "scripts/probe_coverage_gate.py",
            "scripts/dita_semantics_activation.py",
            "scripts/dimension_synthesizer.py",
            "scripts/discovery_disposition.py",
            "scripts/recorded_neighbor_discovery.py",
            "scripts/test_discovery_disposition.py",
            "scripts/test_discovery_pipeline.py",
            "scripts/test_recorded_neighbor_discovery.py",
            "scripts/test_native_pdf_feature_discovery.py",
            "references/discovery-disposition.md",
            "references/dimension-synthesizer.md",
            "references/v3-reasoning-authoring.md",
            "scripts/miss_probe_library.py",
            "data/miss_probes.json",
            "data/dita_constructs.json",
            "scripts/feature_map.py",
            "data/aem_feature_map.json",
            "references/aem-feature-map.md",
            "scripts/offline_retrieval.py",
            "references/offline-authoring-rag.md",
            "scripts/run_gates.py",
            "scripts/security_coverage.py",
            "scripts/shared_path_regression_coverage.py",
            "scripts/validate_test_plan.py",
            "scripts/jira_safe_text.py",
            "scripts/value_provenance_coverage.py",
            "scripts/test_skill_scripts.py",
        ):
            check(
                f"{copy_label} skill copy matches .codex source: {relative_path}",
                (variant_root / relative_path).read_bytes()
                == (canonical_root / relative_path).read_bytes(),
            )
        check(
            f"{copy_label} component router matches .codex source",
            (variant_root / "scripts" / "component_reference_router.py").read_bytes()
            == (canonical_root / "scripts" / "component_reference_router.py").read_bytes(),
        )
        check(
            f"{copy_label} Authoring pack matches .codex source",
            (variant_root / "references" / "component-authoring.md").read_bytes()
            == (canonical_root / "references" / "component-authoring.md").read_bytes(),
        )
        check(
            f"{copy_label} configuration enumeration pack matches .codex source",
            (variant_root / "references" / "configuration-driven-enumerations.md").read_bytes()
            == (canonical_root / "references" / "configuration-driven-enumerations.md").read_bytes(),
        )
        check(
            f"{copy_label} Integration pack matches .codex source",
            (variant_root / "references" / "component-integration.md").read_bytes()
            == (canonical_root / "references" / "component-integration.md").read_bytes(),
        )
        check(
            f"{copy_label} Platform pack matches .codex source",
            (variant_root / "references" / "component-platform.md").read_bytes()
            == (canonical_root / "references" / "component-platform.md").read_bytes(),
        )

    for variant in (".codex", ".claude"):
        global_root = Path.home() / variant / "skills" / "test-plan-generation"
        fingerprint_ok, drifted_files = skill_fingerprint_mod.verify(global_root)
        check(
            f"global {variant} enforced fingerprint matches .codex source",
            fingerprint_ok and drifted_files == [],
        )


def _relation(**over):
    base = {
        "source_construct": "navtitle", "target_construct": "locktitle",
        "relation": "CONTROLS", "dita_version": "1.3", "authority": "DITA_SPEC",
        "evidence": ["ask_dita_expert spec probe"], "material": True,
        "states": ["locked", "unlocked", "absent"], "status": "CONFIRMED",
        "behavioral_branch": "locked map title vs unlocked href title",
    }
    base.update(over)
    return base


def _semantics(relations, **over):
    block = {
        "active": True, "primary_constructs": ["topicref", "navtitle"],
        "dita_versions": ["1.3"], "governing_spec_retrieved": True,
        "product_implementation_checked": True, "automation_semantic_paths_checked": True,
        "unresolved": [], "relations": relations,
    }
    block.update(over)
    return block


def test_semantic_explorer() -> None:
    ex = explorer_mod
    SR = ex.SemanticRelation

    # --- relation-level evidence discipline ---
    missing_ev = SR.from_dict(_relation(evidence=[]))
    check("material relation with no evidence is rejected",
          any("no evidence" in p for p in ex.validate_relation(missing_ev)))
    bad_rel = SR.from_dict(_relation(relation="MODIFIES"))
    check("unknown relation type is rejected",
          any("not in the supported vocabulary" in p for p in ex.validate_relation(bad_rel)))
    check("well-formed relation validates clean", ex.validate_relation(SR.from_dict(_relation())) == [])
    # immaterial relations need no evidence (they are not asserted dependencies)
    check("immaterial relation without evidence is allowed",
          ex.validate_relation(SR.from_dict(_relation(material=False, evidence=[]))) == [])

    # --- neighbourhood bucketing (by relation TYPE, not construct name) ---
    nb = ex.build_neighborhood("navtitle", "ATTRIBUTE", [SR.from_dict(_relation())])
    check("CONTROLS lands in controlling_constructs bucket",
          any(e["construct"] == "locktitle" for e in nb["controlling_constructs"]))

    # --- coverage hypotheses exclude rejected / immaterial ---
    hyps = ex.generate_coverage_hypotheses([
        SR.from_dict(_relation()),
        SR.from_dict(_relation(target_construct="href", relation="CHANGES_PROCESSING_OF", authority="DITA_OT")),
        SR.from_dict(_relation(target_construct="chunk", status="REJECTED")),
        SR.from_dict(_relation(target_construct="props", material=False, evidence=[])),
    ])
    deps = {h["dependent_construct"] for h in hyps}
    check("hypotheses include material non-rejected deps", {"locktitle", "href"} <= deps)
    check("hypotheses exclude rejected and immaterial", "chunk" not in deps and "props" not in deps)

    # --- Cartesian-explosion protection: equivalent branches collapse ---
    dup = [
        {"relationship": "CONTROLS", "behavioral_branch": "locked", "dependent_construct": "locktitle"},
        {"relationship": "CONTROLS", "behavioral_branch": "locked", "dependent_construct": "locktitle"},
        {"relationship": "CONTROLS", "behavioral_branch": "unlocked", "dependent_construct": "locktitle"},
    ]
    kept, collapsed = ex.collapse_equivalent_paths(dup)
    check("equivalent hypotheses collapse to representatives", len(kept) == 2 and len(collapsed) == 1)

    # --- regression fixture: the navtitle Jira, run WITHOUT a locktitle hint ---
    # The exploration procedure (LLM) discovers locktitle from spec evidence and
    # records it; the gate PROVES that discovery was investigated to a terminal
    # status. Here it is CONFIRMED + the no-href/locktitle-absent branch is exposed.
    navtitle_fixture = _semantics(
        [
            _relation(),  # navtitle CONTROLS locktitle
            _relation(target_construct="href", relation="CHANGES_PROCESSING_OF",
                      authority="DITA_OT", states=["present", "absent"],
                      behavioral_branch="href present vs absent title source"),
        ],
        unresolved=["no-href + locktitle=absent navigation-title source undocumented in New AEM Sites"],
    )
    overall, dims, fails = ex.evaluate_semantic_gate(navtitle_fixture)
    check("navtitle fixture passes the semantic gate", overall == "PASSED" and fails == [])
    check("navtitle fixture exposes unresolved semantics",
          dims["UNRESOLVED_SEMANTICS_EXPOSED"] == "UNRESOLVED_AND_EXPOSED")

    # governing dependency discovered but left uninvestigated -> NEEDS_REVIEW
    uninvestigated = _semantics([_relation(status="INVESTIGATION_CANDIDATE")])
    o2, _d2, f2 = ex.evaluate_semantic_gate(uninvestigated)
    check("uninvestigated governing dependency makes the gate NEEDS_REVIEW",
          o2 == "NEEDS_REVIEW" and any("CONTROLLING_DEPENDENCIES_EXPLORED" in x for x in f2))

    # --- generalization: works for OTHER constructs with no navtitle involved ---
    conref_fixture = _semantics(
        [_relation(source_construct="conref", target_construct="conkeyref",
                   relation="FALLS_BACK_TO", authority="DITA_SPEC",
                   states=["direct", "indirect"], behavioral_branch="href vs keyref resolution")],
        primary_constructs=["conref"],
    )
    oc, _dc, fc = ex.evaluate_semantic_gate(conref_fixture)
    check("conref fixture passes the gate (generalizes beyond navtitle)", oc == "PASSED" and fc == [])

    keyref_fixture = _semantics(
        [_relation(source_construct="keyref", target_construct="keyscope",
                   relation="SCOPED_BY", authority="DITA_SPEC",
                   states=["in-scope", "out-of-scope"], behavioral_branch="key scope resolution")],
        primary_constructs=["keyref"],
    )
    ok, _dk, fk = ex.evaluate_semantic_gate(keyref_fixture)
    check("keyref fixture passes the gate (generalizes beyond navtitle)", ok == "PASSED" and fk == [])

    # inactive block is skipped, not failed
    overall_off, _do, _fo = ex.evaluate_semantic_gate({"active": False})
    check("inactive DITA semantics gate is SKIPPED", overall_off == "SKIPPED")


def test_anti_hardcoding() -> None:
    import tempfile
    aud = audit_mod
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)

        def _py(name, body):
            p = tmp_path / name
            p.write_text(body, encoding="utf-8")
            return p

        clean = _py("clean.py", "def f(data):\n    if data:\n        return status_of(data)\n")
        failures, _ = aud.audit_paths([clean])
        check("clean production code passes the audit", failures == [])

        banned = _py("banned.py", "def run(node):\n    if navtitle:\n        add_locktitle_tests()\n")
        failures, _ = aud.audit_paths([banned])
        check("`if navtitle:` production guard is flagged", any("navtitle" in f for f in failures))

        exempt = _py("exempt.py", "# illustrative example only, not a production rule\ndef run():\n    if navtitle:\n        pass\n")
        failures, _ = aud.audit_paths([exempt])
        check("construct guard with an example/provenance marker is exempt", failures == [])

        pair = _py("pair.py", 'RULES = {"keyref": "keyscope"}\n')
        failures, _ = aud.audit_paths([pair])
        check("construct->construct pair literal is flagged", any("keyref" in f and "keyscope" in f for f in failures))

        # ambiguous-only pair must NOT fail (coincidental generic words)
        amb = _py("amb.py", 'CFG = {"type": "format"}\nif data:\n    pass\n')
        failures, _ = aud.audit_paths([amb])
        check("ambiguous-only literals / `if data:` are not flagged", failures == [])

        # markdown: bare rule-arrow is flagged, but an example-marked one is exempt
        bad_md = _py("bad.md", "The mapping is navtitle -> locktitle for all cases.\n")
        failures, _ = aud.audit_paths([bad_md])
        check("bare construct rule-arrow in a prompt is flagged", any("navtitle" in f for f in failures))

        ok_md = _py("ok.md", "Example only: navtitle -> locktitle is discovered from evidence.\n")
        failures, _ = aud.audit_paths([ok_md])
        check("example-marked rule-arrow in a prompt is exempt", failures == [])

        # test_ files are skipped (regression fixtures may hold the anti-pattern)
        tf = _py("test_x.py", "def t():\n    if navtitle:\n        add_locktitle()\n")
        failures, _ = aud.audit_paths([tf])
        check("test_*.py files are skipped by the audit", failures == [])

    # regression guard: the real skill dir must stay clean
    skill_root = Path(__file__).resolve().parent.parent
    failures, _ = aud.audit_paths([skill_root])
    check("the real skill directory passes the anti-hardcoding audit", failures == [])


def test_production_jira_hardcoding_audit() -> None:
    audit = production_hardcoding_mod
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        (root / "references").mkdir()
        (root / "scripts").mkdir()
        (root / "SKILL.md").write_text(
            "For GUIDES-99999, always require the remembered workload.", encoding="utf-8"
        )
        failures = audit.audit(root)
        check(
            "a concrete historical issue key in production instructions fails",
            any("concrete GUIDES issue key" in failure for failure in failures),
        )
        (root / "SKILL.md").write_text(
            "Route from current mechanism evidence; issue identity is not authority.",
            encoding="utf-8",
        )
        (root / "references" / "uac-reference-examples.md").write_text(
            "Regression fixture GUIDES-99999 with an old observed workload.",
            encoding="utf-8",
        )
        check(
            "explicit regression fixture catalog is excluded from production audit",
            audit.audit(root) == [],
        )

    skill_root = Path(__file__).resolve().parents[1]
    check(
        "active skill has no historical Jira identity or fixture threshold",
        audit.audit(skill_root) == [],
    )


def test_behavior_model() -> None:
    bm = behavior_mod
    F = lambda **k: dict(k)  # noqa: E731 - tiny fact builder for fixtures

    # A valid model for each ticket family the phase must support.
    ui = {"trigger": ["user clicks Generate in Map dashboard"], "operations": ["render toc"],
          "consumers": ["Map dashboard UI", "Editor toc panel"],
          "facts": [F(fact="both surfaces read the same toc model", evidence_ids=["E1"], authority="CURRENT_IMPLEMENTATION", confidence=0.7)]}
    backend = {"trigger": ["POST publish job"], "operations": ["build output"], "inputs": ["map path"],
               "outputs": ["site nodes"], "processors": ["PublishingJob"]}
    config = {"trigger": ["preset toggled"], "operations": ["branch on setting"],
              "configuration_branches": ["dita processing on", "dita processing off"], "outputs": ["toc"]}
    publishing = {"trigger": ["generate output"], "operations": ["transform"], "outputs": ["pdf"],
                  "publishing_modes": ["Native PDF", "DITA-OT PDF", "Native AEM Site"]}
    dita = {"trigger": ["publish map"], "operations": ["resolve toc"], "affected_state": ["navigation title"],
            "facts": [F(fact="no-href navtitle yields null path", evidence_ids=["E2"], authority="CURRENT_IMPLEMENTATION", confidence=0.8)]}
    # persistence model that CORRECTLY identifies the writer of the state it removes
    persistence_ok = {"trigger": ["delete topic"], "operations": ["cleanup parent-map property"],
                      "remove_paths": ["remove parentMaps entry"], "write_paths": ["writer adds parentMaps on add-to-map"],
                      "affected_state": ["parentMaps property"]}

    for name, m in (("ui", ui), ("backend", backend), ("config", config),
                    ("publishing", publishing), ("dita", dita), ("persistence_ok", persistence_ok)):
        check(f"behavior_model valid for {name} ticket", bm.validate_behavior_model(m) == [])

    # empty / shapeless model is rejected
    check("empty behavior_model is rejected", any("effectively empty" in p for p in bm.validate_behavior_model({})))

    # a fact without evidence is inference -> rejected
    no_ev = {"trigger": ["x"], "operations": ["y"], "facts": [F(fact="claim", evidence_ids=[], authority="JIRA")]}
    check("fact without evidence_ids is rejected", any("no evidence_ids" in p for p in bm.validate_behavior_model(no_ev)))

    # bad authority rejected
    bad_auth = {"trigger": ["x"], "operations": ["y"], "facts": [F(fact="c", evidence_ids=["E1"], authority="VIBES")]}
    check("fact with unknown authority is rejected", any("authority" in p for p in bm.validate_behavior_model(bad_auth)))

    # confidence out of range rejected
    bad_conf = {"trigger": ["x"], "operations": ["y"], "confidence": 1.7}
    check("confidence out of range is rejected", any("confidence" in p for p in bm.validate_behavior_model(bad_conf)))

    # list field given a non-list rejected
    bad_type = {"trigger": "click", "operations": ["y"]}
    check("non-list model field is rejected", any("must be a list" in p for p in bm.validate_behavior_model(bad_type)))

    # persistence rule: removes state but never identifies the writer -> rejected
    persistence_gap = {"trigger": ["delete topic"], "operations": ["cleanup"],
                       "remove_paths": ["remove parentMaps entry"], "affected_state": ["parentMaps"]}
    check("state removal without a writer path is rejected",
          any("what WRITES that state" in p for p in bm.validate_behavior_model(persistence_gap)))

    # same gap is acceptable if the missing writer is explicitly flagged unknown
    persistence_flagged = dict(persistence_gap, unknowns=["who writes parentMaps is not yet identified"])
    check("state removal passes when the missing writer is flagged in unknowns",
          bm.validate_behavior_model(persistence_flagged) == [])

    # run_gates skips the check when no block is present (backward compatible)
    check("behavior_model absent is not a failure", bm.is_present({"issue": "X"}) is False)


def test_coverage_hypotheses() -> None:
    cov = coverage_mod

    def H(**k):
        base = {"hypothesis_id": "H", "dimension": "CONSUMER", "candidate": "another surface reads the model",
                "reason": "shared model", "technical_basis": ["behavior_model.consumers has 2 surfaces"],
                "status": "INVESTIGATION_CANDIDATE", "requires_more_evidence": True, "confidence": 0.4}
        base.update(k)
        return base

    # a relevant, evidence-justified candidate validates
    check("valid coverage candidate passes", cov.validate_coverage_block([H()]) == [])

    # candidate defaults to INVESTIGATION_CANDIDATE (never an AC at this stage)
    check("candidate status is INVESTIGATION_CANDIDATE by default",
          coverage_mod.CoverageHypothesis().status == "INVESTIGATION_CANDIDATE")

    # speculation (no technical_basis) is rejected -> enforces "evidence -> candidate"
    check("candidate with no technical_basis is rejected",
          any("no technical_basis" in p for p in cov.validate_coverage_block([H(technical_basis=[])])))

    # unknown dimension rejected (irrelevant/invented dimension does not slip in)
    check("unknown dimension is rejected",
          any("is not one of" in p for p in cov.validate_coverage_block([H(dimension="VIBES")])))

    # bad status rejected
    check("invalid status is rejected",
          any("status" in p for p in cov.validate_coverage_block([H(status="MAYBE")])))

    # confidence range enforced
    check("confidence out of range is rejected",
          any("confidence" in p for p in cov.validate_coverage_block([H(confidence=2.0)])))

    # Cartesian-explosion guard: two equivalent candidates must collapse
    dup = [H(hypothesis_id="H1", candidate="type A reaches path", dimension="TYPE_ABSTRACTION", equivalence_key="reaches-path"),
           H(hypothesis_id="H2", candidate="type B reaches path", dimension="TYPE_ABSTRACTION", equivalence_key="reaches-path")]
    check("equivalent candidates are flagged for collapse",
          any("collapse" in p for p in cov.validate_coverage_block(dup)))
    kept, collapsed = cov.collapse_hypotheses([coverage_mod.CoverageHypothesis.from_dict(x) for x in dup])
    check("collapse keeps one representative of an equivalent family", len(kept) == 1 and len(collapsed) == 1)

    # distinct dimensions/candidates do NOT collapse (no false merging)
    distinct = [H(hypothesis_id="H1", dimension="CONSUMER", candidate="surface X"),
                H(hypothesis_id="H2", dimension="NFR_RISK", candidate="large hierarchy traversal",
                  technical_basis=["deep map traversal per reference"])]
    check("distinct candidates both pass and do not collapse", cov.validate_coverage_block(distinct) == [])

    # absent block is not a failure (backward compatible; irrelevant explorers just do not activate)
    check("coverage_hypotheses absent is not a failure", cov.is_present({"issue": "X"}) is False)


def test_missing_questions() -> None:
    mq = mq_mod

    def Q(**k):
        base = {"question_id": "Q-01", "question": "Who originally writes this state?",
                "why_it_matters": "a cleanup fix must not leave the writer producing bad state",
                "hypothesis_id": "H-01", "preferred_sources": ["current repository"],
                "search_concepts": ["what writes the parent-map property"], "blocking": True,
                "if_unresolved": "OPEN_QUESTION"}
        base.update(k)
        return base

    def E(p="initial", **k):
        base = {"evidence_id": "E1", "source": "current repository", "query": "initial jira keywords",
                "pass": p, "status": "RETRIEVED", "question_id": ""}
        base.update(k)
        return base

    # a well-formed question validates
    check("valid missing_question passes", mq.check_retrieval_discipline([Q()], [
        E(), E("second", evidence_id="E2", query="what writes the parent-map property", status="USED", question_id="Q-01")]) == [])

    # (1) second retrieval is required only when a material question exists
    check("material question requires a second pass", mq.requires_second_pass([mq.MissingQuestion.from_dict(Q(blocking=True))]) is True)
    check("no material question -> no second pass required", mq.requires_second_pass([mq.MissingQuestion.from_dict(Q(blocking=False))]) is False)
    # a blocking question with NO second-pass evidence is flagged
    check("material question without a second pass is rejected",
          any("no second-pass retrieval" in p for p in mq.check_retrieval_discipline([Q()], [E()])))

    # (2) second query must differ from the initial Jira keyword query
    same = [E("initial", query="native aem site navtitle"),
            E("second", evidence_id="E2", query="native aem site navtitle", question_id="Q-01")]
    check("second query identical to initial is rejected",
          any("must be derived from the missing question" in p for p in mq.check_retrieval_discipline([Q()], same)))
    diff_items = [mq.EvidenceItem.from_dict(E("initial", query="A")),
                  mq.EvidenceItem.from_dict(E("second", evidence_id="E2", query="B"))]
    check("a genuinely new second-pass query is detected", mq.new_second_pass_queries(diff_items) == ["b"])

    # (3) evidence can resolve a candidate (a USED item for its question)
    used = [mq.EvidenceItem.from_dict(E("second", evidence_id="E2", status="USED", question_id="Q-01"))]
    check("USED evidence resolves the question", mq.is_resolved("Q-01", used) is True)

    # (4) missing/rejected evidence leaves it unresolved, and it must stay an Open Question
    unresolved = [mq.EvidenceItem.from_dict(E("second", evidence_id="E2", status="REJECTED", question_id="Q-01"))]
    check("REJECTED-only evidence leaves the question unresolved", mq.is_resolved("Q-01", unresolved) is False)
    check("unresolved question must declare if_unresolved OPEN_QUESTION",
          any("OPEN_QUESTION" in p for p in mq.check_retrieval_discipline([Q(if_unresolved="GUESS")], [E(), E("second", evidence_id="E9", query="new q")])))

    # (5) duplicate retrieval loops are prevented
    dup = [E("second", evidence_id="E1", query="repeat", source="rag"),
           E("second", evidence_id="E2", query="repeat", source="rag")]
    check("duplicate (query,source) retrieval is flagged",
          any("duplicate retrieval" in p for p in mq.check_retrieval_discipline([Q()], dup)))

    # schema guards
    check("question without search_concepts is rejected",
          any("search_concepts" in p for p in mq.check_retrieval_discipline([Q(search_concepts=[])], [E(), E("second", evidence_id="E2", query="new")])))
    check("evidence with unknown status is rejected",
          any("status" in p for p in mq.check_retrieval_discipline([Q(blocking=False)], [E(status="MAYBE")])))
    check("evidence with out-of-bound pass is rejected",
          any("pass" in p for p in mq.check_retrieval_discipline([Q(blocking=False)], [E("fourth")])))

    # Adversarial referential integrity: a retrieved fact must be linked to a
    # declared reasoning object, and its source must be authoritative for the
    # missing question's subject.
    contract_q = Q(
        subject="PRODUCT_CONTRACT", material=True, source_ref="CF-01",
        open_question_ref="OQ-01", preferred_sources=["linked jira"],
    )
    wrong_source = [
        E(),
        E(
            "second", evidence_id="E2", query="approved intended behavior",
            source="current repository", status="USED", question_id="Q-01",
            subject="PRODUCT_CONTRACT",
        ),
    ]
    check(
        "implementation retrieval cannot resolve a product-contract question",
        any(
            "cannot resolve" in p
            for p in mq.check_retrieval_discipline(
                [contract_q], wrong_source, open_question_ids={"OQ-01"}
            )
        ),
    )
    unlinked_used = [E(status="USED", question_id="", hypothesis_id="")]
    check(
        "USED evidence must reference a question or hypothesis",
        any(
            "question_id or hypothesis_id" in p
            for p in mq.check_retrieval_discipline([], unlinked_used)
        ),
    )
    unknown_question = [E(status="USED", question_id="Q-GHOST")]
    check(
        "evidence cannot reference an undeclared question",
        any(
            "unknown question" in p
            for p in mq.check_retrieval_discipline([], unknown_question)
        ),
    )
    unknown_hypothesis = [E(status="USED", hypothesis_id="H-GHOST")]
    check(
        "evidence cannot reference an undeclared hypothesis",
        any(
            "unknown hypothesis" in p
            for p in mq.check_retrieval_discipline(
                [], unknown_hypothesis, hypothesis_ids=set()
            )
        ),
    )
    check(
        "a missing question cannot reference an undeclared hypothesis",
        any(
            "unknown hypothesis" in p
            for p in mq.check_retrieval_discipline(
                [Q(blocking=False)], [], hypothesis_ids=set()
            )
        ),
    )
    duplicate_ids = [E(), E(evidence_id="E1", query="different query")]
    check(
        "duplicate evidence ids are rejected",
        any(
            "evidence_id duplicates" in p
            for p in mq.check_retrieval_discipline([], duplicate_ids)
        ),
    )

    # absent blocks are backward-compatible
    check("missing_questions/evidence absent is not a failure", mq.is_present({"issue": "X"}) is False)


def test_hypothesis_verifier() -> None:
    hv = verifier_mod

    def V(**k):
        base = {"hypothesis_id": "H-01", "verdict": "CONFIRMED",
                "supporting_authorities": ["JIRA_EXPECTED_BEHAVIOR"], "supporting_evidence": ["E5"],
                "disposition": "ACCEPTANCE_CRITERION", "subject": "PRODUCT_CONTRACT"}
        base.update(k)
        return base

    # (1) a plausible hypothesis is CONFIRMED on authoritative evidence -> AC
    check("plausible hypothesis confirmed on authoritative evidence", hv.validate_verification(hv.Verification.from_dict(V())) == [])
    code_only_ac = V(supporting_authorities=["CURRENT_IMPLEMENTATION"])
    check(
        "current implementation alone cannot authorize an AC",
        any("cannot authorize" in p for p in hv.validate_verification(hv.Verification.from_dict(code_only_ac))),
    )

    # (2) a plausible hypothesis is REJECTED with disproving evidence -> excluded
    rej = V(verdict="REJECTED", disproving_evidence=["E7"], disposition="EXCLUDED", supporting_authorities=[])
    check("hypothesis rejected with disproving evidence", hv.validate_verification(hv.Verification.from_dict(rej)) == [])
    # REJECTED cannot be routed into an AC
    rej_ac = V(verdict="REJECTED", disproving_evidence=["E7"], disposition="ACCEPTANCE_CRITERION")
    check("REJECTED cannot enter an AC", any("cannot have disposition" in p for p in hv.validate_verification(hv.Verification.from_dict(rej_ac))))

    # (3) conflicting evidence becomes UNRESOLVED
    conf = V(verdict="CONFIRMED", conflict=True)
    check("conflicting evidence cannot be CONFIRMED", any("must be UNRESOLVED" in p for p in hv.validate_verification(hv.Verification.from_dict(conf))))
    unres = V(verdict="UNRESOLVED", conflict=True, disposition="OPEN_QUESTION", open_question_ref="OQ-1", supporting_authorities=[])
    check("conflict resolved as UNRESOLVED->Open Question passes", hv.validate_verification(hv.Verification.from_dict(unres)) == [])

    # (4) specification and implementation differ -> conflict -> UNRESOLVED (same rule as (3), spec/impl framing)
    spec_impl = V(verdict="INFERRED_HIGH_CONFIDENCE", conflict=True, supporting_evidence=["E1", "E2"], disposition="INFERRED_AC")
    check("spec-vs-impl divergence forces UNRESOLVED", any("must be UNRESOLVED" in p for p in hv.validate_verification(hv.Verification.from_dict(spec_impl))))

    # (5) an existing test alone is insufficient for CONFIRMED
    test_only = V(verdict="CONFIRMED", supporting_authorities=["EXISTING_AUTOMATION"])
    check("existing test alone cannot CONFIRM current contract",
          any("not the current product contract" in p or "authoritative source" in p for p in hv.validate_verification(hv.Verification.from_dict(test_only))))
    # similarity alone is not proof
    sim = V(verdict="CONFIRMED", similarity_only=True, supporting_authorities=[])
    check("embedding similarity alone cannot CONFIRM", any("similarity" in p for p in hv.validate_verification(hv.Verification.from_dict(sim))))

    # UNRESOLVED must be routed to an Open Question, never an AC
    unres_ac = V(verdict="UNRESOLVED", conflict=True, disposition="ACCEPTANCE_CRITERION", open_question_ref="OQ-2")
    check("UNRESOLVED cannot become an AC", any("cannot have disposition" in p for p in hv.validate_verification(hv.Verification.from_dict(unres_ac))))
    unres_no_oq = V(verdict="UNRESOLVED", insufficient=True, disposition="OPEN_QUESTION", supporting_authorities=[])
    check("UNRESOLVED without an open_question_ref is rejected", any("open_question_ref" in p for p in hv.validate_verification(hv.Verification.from_dict(unres_no_oq))))

    # INFERRED_HIGH_CONFIDENCE stays inferred (a product decision means it should be CONFIRMED)
    inferred_ok = V(verdict="INFERRED_HIGH_CONFIDENCE", supporting_evidence=["E1", "E2"], disposition="REGRESSION", supporting_authorities=["CURRENT_IMPLEMENTATION"], subject="ACTUAL_IMPLEMENTATION")
    check("inferred-high-confidence with 2+ facts and no product decision passes", hv.validate_verification(hv.Verification.from_dict(inferred_ok)) == [])
    inferred_pd = V(verdict="INFERRED_HIGH_CONFIDENCE", supporting_evidence=["E1", "E2"], product_decision=True, disposition="INFERRED_AC")
    check("inferred verdict with an explicit product decision is rejected", any("should be CONFIRMED" in p for p in hv.validate_verification(hv.Verification.from_dict(inferred_pd))))

    # (6) an unsupported candidate never reaches UAC: an unverified coverage hypothesis is flagged
    cov = [{"hypothesis_id": "H-01", "status": "INVESTIGATION_CANDIDATE"},
           {"hypothesis_id": "H-02", "status": "INVESTIGATION_CANDIDATE"}]
    verifs = [V(hypothesis_id="H-01")]
    problems = hv.verify_all(cov, verifs)
    check("every coverage hypothesis must be verified (unverified is flagged)",
          any("H-02" in p and "no verification" in p for p in problems))
    check("verified hypothesis is not flagged", not any("H-01" in p and "no verification" in p for p in problems))

    # Adversarial joins: a verdict cannot cite a globally known but
    # subject-ineligible authority, an unknown hypothesis, duplicate terminal
    # verdicts, or evidence owned by another hypothesis.
    wrong_subject_authority = V(
        verdict="CONFIRMED", disposition="REGRESSION",
        supporting_authorities=["CURRENT_IMPLEMENTATION"],
        subject="PRODUCT_CONTRACT",
    )
    check(
        "authority is validated against the hypothesis subject",
        any(
            "not valid for subject" in p
            for p in hv.validate_verification(
                hv.Verification.from_dict(wrong_subject_authority)
            )
        ),
    )
    no_evidence = V(supporting_evidence=[])
    check(
        "CONFIRMED requires a concrete evidence reference",
        any(
            "requires supporting_evidence" in p
            for p in hv.validate_verification(hv.Verification.from_dict(no_evidence))
        ),
    )
    check(
        "verification cannot target an undeclared hypothesis",
        any(
            "unknown hypothesis" in p
            for p in hv.verify_all([], [V(hypothesis_id="H-GHOST")])
        ),
    )
    check(
        "a hypothesis cannot have two terminal verifications",
        any(
            "more than one verification" in p
            for p in hv.verify_all(
                [{"hypothesis_id": "H-01", "status": "INVESTIGATION_CANDIDATE"}],
                [V(), V()],
            )
        ),
    )
    evidence = [{
        "evidence_id": "E5", "status": "USED", "subject": "PRODUCT_CONTRACT",
        "authority": "JIRA_EXPECTED_BEHAVIOR", "hypothesis_id": "H-01",
    }]
    check(
        "verification passes when evidence, authority, subject, and hypothesis agree",
        hv.verify_all(
            [{"hypothesis_id": "H-01", "status": "INVESTIGATION_CANDIDATE"}],
            [V()], evidence_lifecycle=evidence,
        ) == [],
    )
    wrong_owner = json.loads(json.dumps(evidence))
    wrong_owner[0]["hypothesis_id"] = "H-02"
    check(
        "verification rejects evidence owned by another hypothesis",
        any(
            "not bound to hypothesis" in p
            for p in hv.verify_all(
                [{"hypothesis_id": "H-01", "status": "INVESTIGATION_CANDIDATE"}],
                [V()], evidence_lifecycle=wrong_owner,
            )
        ),
    )

    # absent block is backward compatible
    check("verifications absent is not a failure", hv.is_present({"issue": "X"}) is False)


def test_coverage_gate() -> None:
    cg = coverage_gate_mod

    def hyp(dim, hid, status="INVESTIGATION_CANDIDATE"):
        return {"hypothesis_id": hid, "dimension": dim, "candidate": "c", "reason": "r",
                "technical_basis": ["t"], "status": status}

    def verif(hid, verdict, **k):
        base = {"hypothesis_id": hid, "verdict": verdict}
        base.update(k)
        return base

    # a fully-explored plan: covered + rejected + unresolved-but-exposed -> PASS
    good = {
        "coverage_hypotheses": [hyp("CONSUMER", "H1"), hyp("STATE_PARTITION", "H2"), hyp("NFR_RISK", "H3")],
        "verifications": [verif("H1", "CONFIRMED", disposition="ACCEPTANCE_CRITERION"),
                          verif("H2", "REJECTED", disposition="EXCLUDED"),
                          verif("H3", "UNRESOLVED", disposition="OPEN_QUESTION", open_question_ref="OQ-1")],
        "open_questions": ["OQ-1"],
    }
    r = cg.evaluate(good)
    check("fully explored plan passes the coverage gate", r["semantic_gate"] == "PASS")
    check("covered dimension marked COVERED", r["dimensions"]["CONSUMER_EXPLORATION"] == "COVERED")
    check("rejected candidate marked INVESTIGATED_AND_REJECTED", r["dimensions"]["STATE_PARTITIONS"] == "INVESTIGATED_AND_REJECTED")
    check("exposed unresolved marked UNRESOLVED_AND_EXPOSED", r["dimensions"]["NFR"] == "UNRESOLVED_AND_EXPOSED")

    # adversarial 1: discovered abstraction/consumer NOT explored (candidate, no verification) -> NEEDS_REVIEW
    a1 = {"coverage_hypotheses": [hyp("CONTRACT_BOUNDARY", "H1"), hyp("CONSUMER", "H2")], "verifications": []}
    r1 = cg.evaluate(a1)
    check("discovered-but-unexplored contract/consumer -> NEEDS_REVIEW", r1["semantic_gate"] == "NEEDS_REVIEW"
          and r1["dimensions"]["CONTRACT_BOUNDARY"] == "NEEDS_REVIEW")
    with tempfile.TemporaryDirectory() as tmp:
        manifest_path = Path(tmp) / "coverage.json"
        manifest_path.write_text(json.dumps(a1), encoding="utf-8")
        gate = _load("run_gates_for_coverage_test", "run_gates.py")
        gate_failures, _ = gate.check_coverage_gate(str(manifest_path))
        check(
            "NEEDS_REVIEW blocks final delivery",
            any("unresolved review" in problem for problem in gate_failures),
        )

    # adversarial 2: meaningful state hypothesis UNRESOLVED but HIDDEN from Open Questions -> FAIL
    a2 = {"coverage_hypotheses": [hyp("STATE_PARTITION", "H1")],
          "verifications": [verif("H1", "UNRESOLVED", disposition="OPEN_QUESTION", open_question_ref="OQ-9")],
          "open_questions": []}  # OQ-9 not present -> hidden
    r2 = cg.evaluate(a2)
    check("hidden unresolved hypothesis -> FAIL", r2["semantic_gate"] == "FAIL"
          and any("Open Question" in b for b in r2["blocking_reasons"]))

    # adversarial 3: strong large-data signal (NFR) discovered but never evaluated -> NEEDS_REVIEW
    a3 = {"coverage_hypotheses": [hyp("NFR_RISK", "H1")], "verifications": []}
    check("unevaluated NFR signal -> NEEDS_REVIEW", cg.evaluate(a3)["semantic_gate"] == "NEEDS_REVIEW")

    # adversarial 4: material question but no new second-pass query -> NEEDS_REVIEW
    a4 = {"behavior_model": {"trigger": ["t"], "operations": ["o"]},
          "missing_questions": [{"question_id": "Q1", "question": "q", "why_it_matters": "w",
                                 "preferred_sources": ["rag"], "search_concepts": ["s"], "blocking": True,
                                 "if_unresolved": "OPEN_QUESTION"}],
          "evidence_lifecycle": [{"evidence_id": "E1", "source": "rag", "query": "same", "pass": "initial", "status": "RETRIEVED"},
                                 {"evidence_id": "E2", "source": "rag", "query": "same", "pass": "second", "status": "RETRIEVED"}]}
    check("material question without a new second pass -> NEEDS_REVIEW", cg.evaluate(a4)["dimensions"]["SECOND_PASS_RETRIEVAL"] == "NEEDS_REVIEW")

    # candidate investigated and proven irrelevant -> PASS
    a5 = {"coverage_hypotheses": [hyp("LIFECYCLE", "H1")],
          "verifications": [verif("H1", "REJECTED", disposition="EXCLUDED")]}
    check("investigated-and-rejected candidate -> PASS", cg.evaluate(a5)["semantic_gate"] == "PASS")

    # DITA semantics folded in: active DITA gate with uninvestigated dep -> NEEDS_REVIEW
    a6 = {"behavior_model": {"trigger": ["t"], "operations": ["o"]},
          "dita_semantics": {"active": True, "primary_constructs": ["topicref"], "dita_versions": ["1.3"],
                             "governing_spec_retrieved": True, "product_implementation_checked": True,
                             "automation_semantic_paths_checked": True,
                             "relations": [{"source_construct": "href", "target_construct": "navtitle",
                                            "relation": "CONTROLS", "dita_version": "1.3", "authority": "DITA_SPEC",
                                            "evidence": ["x"], "material": True, "states": ["a"],
                                            "status": "INVESTIGATION_CANDIDATE"}]}}
    check("active DITA dep left uninvestigated folds into NEEDS_REVIEW", cg.evaluate(a6)["dimensions"]["DITA_SEMANTICS"] == "NEEDS_REVIEW")

    # backward compatibility: no reasoning blocks -> gate does not activate
    check("coverage gate not present without reasoning blocks", cg.is_present({"issue": "X", "dita_semantics": {"active": True}}) is False)
    check("coverage gate present with a reasoning block", cg.is_present({"coverage_hypotheses": [hyp("CONSUMER", "H1")]}) is True)


def test_uac_integration() -> None:
    ig = integration_mod

    plan_with_oq = (
        "**Acceptance Criteria**\n"
        "- AC-01 [Confirmed]: (Basic) Given x | When y | Then z.\n"
        "**Open Questions**\n"
        "- Cleanup timing decision: is it synchronous on delete or async via a job? QA impact: changes the oracle.\n"
    )

    # UNRESOLVED surfaced in the plan Open Questions -> passes
    m_ok = {
        "coverage_hypotheses": [{"hypothesis_id": "H1", "dimension": "STATE_PARTITION", "candidate": "c",
                                 "reason": "r", "technical_basis": ["t"], "status": "UNRESOLVED"}],
        "verifications": [{"hypothesis_id": "H1", "verdict": "UNRESOLVED", "disposition": "OPEN_QUESTION",
                           "open_question_ref": "OQ-1", "insufficient": True}],
        "open_questions": [{"id": "OQ-1", "question": "Cleanup timing decision: is it synchronous on delete"}],
    }
    f, _ = ig.check_integration(m_ok, plan_with_oq)
    check("unresolved surfaced in plan Open Questions passes integration", f == [])

    # UNRESOLVED NOT surfaced in the plan Open Questions -> fails
    plan_missing_oq = "**Acceptance Criteria**\n- AC-01 [Confirmed]: (Basic) Given x | When y | Then z.\n**Open Questions**\n- Something unrelated.\n"
    f2, _ = ig.check_integration(m_ok, plan_missing_oq)
    check("unresolved missing from plan Open Questions fails integration", any("not surfaced" in p for p in f2))

    # evidence_trace: happy path (AC present, confirmed, evidence, links to confirmed verification)
    m_trace = {
        "coverage_hypotheses": [{"hypothesis_id": "H1", "dimension": "CONSUMER", "candidate": "c", "reason": "r", "technical_basis": ["t"], "status": "CONFIRMED"}],
        "verifications": [{"hypothesis_id": "H1", "verdict": "CONFIRMED", "disposition": "ACCEPTANCE_CRITERION"}],
        "evidence_trace": [{"ac_id": "AC-01", "hypothesis_id": "H1", "evidence_ids": ["E1"], "status": "CONFIRMED",
                            "activated_pattern": "CONSUMER"}],
    }
    f3, _ = ig.check_integration(m_trace, plan_with_oq)
    check("valid evidence_trace passes integration", f3 == [])

    # evidence_trace: ac_id not in plan -> fails
    m_bad_ac = dict(m_trace, evidence_trace=[{"ac_id": "AC-99", "hypothesis_id": "H1", "evidence_ids": ["E1"], "status": "CONFIRMED"}])
    f4, _ = ig.check_integration(m_bad_ac, plan_with_oq)
    check("evidence_trace with unknown ac_id fails", any("not present in the plan" in p for p in f4))

    # evidence_trace: AC traces to a REJECTED hypothesis -> fails (rejected never becomes AC)
    m_rej = {
        "coverage_hypotheses": [{"hypothesis_id": "H1", "dimension": "CONSUMER", "candidate": "c", "reason": "r", "technical_basis": ["t"], "status": "REJECTED"}],
        "verifications": [{"hypothesis_id": "H1", "verdict": "REJECTED", "disposition": "EXCLUDED", "disproving_evidence": ["E2"]}],
        "evidence_trace": [{"ac_id": "AC-01", "hypothesis_id": "H1", "evidence_ids": ["E1"], "status": "CONFIRMED"}],
    }
    f5, _ = ig.check_integration(m_rej, plan_with_oq)
    check("AC tracing to a REJECTED hypothesis fails", any("never become an Acceptance Criterion" in p for p in f5))

    # evidence_trace with no evidence_ids -> fails
    m_noev = dict(m_trace, evidence_trace=[{"ac_id": "AC-01", "hypothesis_id": "H1", "evidence_ids": [], "status": "CONFIRMED"}])
    f6, _ = ig.check_integration(m_noev, plan_with_oq)
    check("evidence_trace without evidence_ids fails", any("cite evidence_ids" in p for p in f6))

    # backward-compat: no reasoning blocks -> integration skipped
    f7, notes7 = ig.check_integration({"issue": "X"}, plan_with_oq)
    check("integration skipped without reasoning blocks", f7 == [] and any("skipped" in n for n in notes7))


def test_reasoning_required() -> None:
    run_gates = _load("run_gates", "run_gates.py")

    def _write(tmp, payload):
        p = Path(tmp) / "m.json"
        p.write_text(json.dumps(payload), encoding="utf-8")
        return str(p)

    bm = {"trigger": ["t"], "operations": ["o"]}
    cov = [{"hypothesis_id": "H1", "dimension": "CONSUMER", "candidate": "c", "reason": "r", "technical_basis": ["t"], "status": "CONFIRMED"}]
    verif = [{"hypothesis_id": "H1", "verdict": "CONFIRMED", "supporting_authorities": ["CURRENT_IMPLEMENTATION"], "supporting_evidence": ["E1"], "disposition": "ACCEPTANCE_CRITERION"}]

    with tempfile.TemporaryDirectory() as tmp:
        # behaviour_matters true (default) but no behavior_model -> required failure
        f = run_gates.check_reasoning_required(_write(tmp, {"issue": "X"}))[0]
        check("behavior_model mandatory when behaviour_matters", any("behavior_model block is mandatory" in x for x in f))

        # behaviour_matters false -> requirement waived
        f = run_gates.check_reasoning_required(_write(tmp, {"issue": "X", "behaviour_matters": False}))[0]
        check("behaviour_matters false waives the reasoning requirement", f == [])

        # behavior_model alone is no longer semantic completeness
        f = run_gates.check_reasoning_required(_write(tmp, {"issue": "X", "behavior_model": bm}))[0]
        check(
            "behavior_model alone cannot satisfy the canonical pipeline",
            any("contract_facts" in x for x in f) and any("semantic_closure" in x for x in f),
        )

        # coverage declared without verifications -> required failure
        f = run_gates.check_reasoning_required(_write(tmp, {"issue": "X", "behavior_model": bm, "coverage_hypotheses": cov}))[0]
        check("coverage hypotheses without verifications is rejected", any("no verifications block" in x for x in f))

        # full canonical reasoning set -> satisfied
        f = run_gates.check_reasoning_required(_write(tmp, {"issue": "X", **_canonical_semantic_fixture()}))[0]
        check("full reasoning set satisfies the requirement", f == [])


def test_relevance_prioritizer() -> None:
    rp = relevance_mod

    direct = {"hypothesis_id": "H1", "candidate": "controlling attribute governs the value",
              "behavioral_distance": "DIRECT", "priority_reason": "directly controls the affected value",
              "status": "INVESTIGATION_CANDIDATE"}
    generic = {"hypothesis_id": "H2", "candidate": "analogous construct in another output",
               "behavioral_distance": "GENERIC_REGRESSION", "status": "INVESTIGATION_CANDIDATE"}

    # ranking puts DIRECT before GENERIC (not keyword/confidence order)
    ordered = rp.prioritize([generic, direct])
    check("prioritizer ranks DIRECT before GENERIC", [h["hypothesis_id"] for h in ordered] == ["H1", "H2"])

    # distance inferred from boolean signals when not explicit
    check("direct_semantic_dependency infers DIRECT",
          rp.effective_distance({"direct_semantic_dependency": True}) == "DIRECT")
    check("same_code_path infers ONE_HOP", rp.effective_distance({"same_code_path": True}) == "ONE_HOP")
    check("no signal defaults to GENERIC_REGRESSION", rp.effective_distance({}) == "GENERIC_REGRESSION")
    check("DIRECT is high relevance", rp.is_high_relevance(direct) is True)
    check("GENERIC is not high relevance", rp.is_high_relevance(generic) is False)

    # the core rule: a HIGH-relevance dependency left unexplored is flagged...
    blocked = rp.high_relevance_unresolved([direct, generic], verifications=[])
    check("unexplored HIGH-relevance hypothesis is flagged", [h["hypothesis_id"] for h in blocked] == ["H1"])
    # ...and clears once it reaches a terminal verdict
    verifs = [{"hypothesis_id": "H1", "verdict": "CONFIRMED"}]
    check("verified HIGH-relevance hypothesis clears the flag", rp.high_relevance_unresolved([direct, generic], verifs) == [])

    # a HIGH-relevance hypothesis must justify its priority
    check("HIGH-relevance without priority_reason is flagged",
          any("priority_reason" in p for p in rp.validate_prioritization([{"hypothesis_id": "H3", "behavioral_distance": "DIRECT"}])))
    check("invalid behavioral_distance is flagged",
          any("invalid" in p for p in rp.validate_prioritization([{"hypothesis_id": "H4", "behavioral_distance": "SORTA"}])))

    # gate integration: a DIRECT candidate left unexplored -> RELEVANCE_PRIORITIZATION NEEDS_REVIEW
    # even though a GENERIC one is CONFIRMED (breadth cannot compensate for the direct miss)
    cov = [dict(direct), {"hypothesis_id": "H2", "dimension": "DOWNSTREAM_REGRESSION", "candidate": "c",
                          "reason": "r", "technical_basis": ["t"], "status": "CONFIRMED", "behavioral_distance": "GENERIC_REGRESSION"}]
    cov[0]["dimension"] = "DITA_SEMANTIC_DEPENDENCY"
    cov[0]["reason"] = "r"
    cov[0]["technical_basis"] = ["t"]
    r = coverage_gate_mod.evaluate({"coverage_hypotheses": cov,
                                    "verifications": [{"hypothesis_id": "H2", "verdict": "CONFIRMED", "disposition": "REGRESSION"}]})
    check("unexplored DIRECT dependency blocks the gate via RELEVANCE_PRIORITIZATION",
          r["dimensions"].get("RELEVANCE_PRIORITIZATION") == "NEEDS_REVIEW" and r["semantic_gate"] == "NEEDS_REVIEW")


def test_disposition_classifier() -> None:
    dc = disposition_mod

    # WHAT (observable) is not implementation-level; HOW (internal mechanism) is
    check("observable outcome is not implementation-level",
          dc.is_implementation_level("generation completes SUCCESS and the site navigation shows the grouping node") is False)
    check("class.method reference is implementation-level",
          dc.is_implementation_level("null must be guarded before PathUtils.appendUnixSlash") is True)
    check("camelCase method call is implementation-level",
          dc.is_implementation_level("the null path is not passed into appendUnixSlash()") is True)
    check("naming a property/output alone is not implementation-level",
          dc.is_implementation_level("the guides-navigation property is present and well-formed after each run") is False)

    # an implementation-level statement cannot be an ACCEPTANCE_CONTRACT
    bad = [{"finding_id": "F1", "statement": "null must be guarded before PathUtils.appendUnixSlash", "disposition": "ACCEPTANCE_CONTRACT"}]
    check("impl-level ACCEPTANCE_CONTRACT is rejected", any("describes WHAT" in p for p in dc.validate_dispositions(bad)))
    # ...unless the internal contract itself is the requirement
    ok = [dict(bad[0], internal_contract_is_requirement=True)]
    check("impl-level AC allowed when internal contract IS the requirement", dc.validate_dispositions(ok) == [])
    # the same statement is fine as an IMPLEMENTATION_ORACLE
    oracle = [{"finding_id": "F1", "statement": "null must be guarded before PathUtils.appendUnixSlash", "disposition": "IMPLEMENTATION_ORACLE"}]
    check("impl-level statement is fine as IMPLEMENTATION_ORACLE", dc.validate_dispositions(oracle) == [])
    # an IMPLEMENTATION_ORACLE must not map to an AC
    mapped = [dict(oracle[0], maps_to_ac="AC-03")]
    check("IMPLEMENTATION_ORACLE mapped to an AC is rejected", any("must not map" in p for p in dc.validate_dispositions(mapped)))
    # unknown disposition rejected
    check("unknown disposition rejected", any("must be one of" in p for p in dc.validate_dispositions([{"statement": "x", "disposition": "MAYBE"}])))

    # plan-body scan: an implementation-mechanism AC is flagged; an observable one is not
    bad_plan = ("**Acceptance Criteria**\n"
                "- AC-01 [Confirmed]: (Basic) Given a map | When published | Then the null path is guarded before PathUtils.appendUnixSlash.\n"
                "**Expected Behaviour**\n- x\n")
    check("implementation-mechanism AC in the plan is flagged", any("AC-01" in p for p in dc.check_plan_acceptance_criteria(bad_plan)))
    good_plan = ("**Acceptance Criteria**\n"
                 "- AC-01 [Confirmed]: (Basic) Given a map | When published | Then generation completes SUCCESS and the grouping node appears in the site navigation.\n"
                 "**Expected Behaviour**\n- x\n")
    check("observable AC in the plan is not flagged", dc.check_plan_acceptance_criteria(good_plan) == [])


def test_oracle_builder() -> None:
    ob = oracle_mod

    # classification
    check("observable outcome is a product oracle",
          ob.classify_oracle("the site navigation shows the grouping entry") == "PRIMARY_PRODUCT_ORACLE")
    check("property outcome is a state oracle",
          ob.classify_oracle("the guides-navigation property is well-formed") == "SECONDARY_STATE_ORACLE")
    check("no-exception is a diagnostic signal",
          ob.classify_oracle("no NullPointerException is thrown") == "DIAGNOSTIC_SIGNAL")

    # diagnostic-only detection: "no exception / job success" alone is insufficient
    check("no-exception-only is diagnostic-only", ob.is_diagnostic_only("the job completes successfully with no NullPointerException") is True)
    check("success + observable output is not diagnostic-only",
          ob.is_diagnostic_only("generation succeeds and the navigation shows the grouping entry") is False)
    check("state oracle counts as observable", ob.is_diagnostic_only("no error and the guides-navigation property is intact") is False)
    check(
        "delivery availability is a product-visible oracle when delivery is in scope",
        ob.classify_oracle("the download is available to the author") == "PRIMARY_PRODUCT_ORACLE"
        and ob.is_diagnostic_only("the download is available to the author") is False,
    )
    check(
        "bare internal archive existence remains diagnostic-only",
        ob.is_diagnostic_only("the archive exists") is True,
    )

    # manifest scenario_oracles: a P0/P1 needs a PRIMARY_PRODUCT_ORACLE
    bad = [{"scenario_id": "P0-1", "priority": "P0", "oracles": [{"type": "DIAGNOSTIC_SIGNAL", "statement": "no NPE"}]}]
    check("P0 with only a diagnostic oracle is rejected", any("PRIMARY_PRODUCT_ORACLE" in p for p in ob.validate_scenario_oracles(bad)))
    good = [{"scenario_id": "P0-1", "priority": "P0", "oracles": [
        {"type": "DIAGNOSTIC_SIGNAL", "statement": "no NPE"},
        {"type": "PRIMARY_PRODUCT_ORACLE", "statement": "navigation shows the grouping entry"}]}]
    check("P0 with a product oracle passes", ob.validate_scenario_oracles(good) == [])

    # plan-body scan: a diagnostic-only P0 scenario is flagged; an observable one is not
    bad_plan = ("**Test Scenarios**\n- P0 [AC-01]: publish the map -> the job completes SUCCESS with no NullPointerException.\n"
                "**Known Jira Bugs / Past Similar Tickets**\n- none\n")
    check("diagnostic-only P0 scenario is flagged", any("P0" in p for p in ob.check_plan_scenarios(bad_plan)))
    good_plan = ("**Test Scenarios**\n- P0 [AC-01]: publish the map -> the job succeeds and the site navigation shows the grouping entry with its two child topics.\n"
                 "**Known Jira Bugs / Past Similar Tickets**\n- none\n")
    check("observable P0 scenario is not flagged", ob.check_plan_scenarios(good_plan) == [])


def test_state_compatibility() -> None:
    sc = state_compat_mod

    # activation: a first-run/subsequent-run persisted-state ticket activates
    active_manifest = {"behavior_model": {"trigger": ["publish map"], "operations": ["generate"],
                       "update_paths": ["rewrite state"], "unknowns": ["fails until nodes deleted on subsequent run"]}}
    check("persisted/subsequent-run signals activate the explorer", sc.is_active(active_manifest) is True)
    # a plain stateless UI ticket does not activate
    check("stateless UI ticket does not activate", sc.is_active({"behavior_model": {"trigger": ["click"], "operations": ["open dialog"]}}) is False)
    # remove/recompute paths are a structural signal on their own
    check("remove_paths is a structural activation signal",
          sc.is_active({"behavior_model": {"trigger": ["delete"], "operations": ["x"], "remove_paths": ["remove entry"]}}) is True)

    def block(**over):
        base = {"active": True,
                "states": {o: {"behavior": "described"} for o in sc.STATE_ORIGINS},
                "recovery_of_old_state": {"required": "unknown", "evidence": [], "disposition": "OPEN_QUESTION"}}
        base.update(over)
        return base

    check("well-formed state_compatibility passes", sc.validate_state_compatibility(block()) == [])
    # missing one of the three state origins is flagged
    partial = block(states={"CLEAN_PRE_FIX_STATE": {}, "STATE_CREATED_BY_FIXED_CODE": {}})
    check("missing BUGGY-old state origin is flagged", any("STATE_CREATED_BY_BUGGY_OLD_CODE" in p for p in sc.validate_state_compatibility(partial)))
    # recovery-of-old-state as AC without evidence is rejected
    as_ac = block(recovery_of_old_state={"required": True, "evidence": [], "disposition": "ACCEPTANCE_CONTRACT"})
    check("recovery-of-old-state AC without evidence is rejected", any("without product/engineering evidence" in p for p in sc.validate_state_compatibility(as_ac)))
    # recovery-of-old-state as AC WITH evidence is allowed
    as_ac_ev = block(recovery_of_old_state={"required": True, "evidence": ["eng decision: fix self-heals"], "disposition": "ACCEPTANCE_CONTRACT"})
    check("recovery-of-old-state AC with evidence is allowed", sc.validate_state_compatibility(as_ac_ev) == [])
    # unknown recovery requirement must be an OPEN_QUESTION
    unknown_ac = block(recovery_of_old_state={"required": "unknown", "evidence": [], "disposition": "ACCEPTANCE_CONTRACT"})
    check("unknown recovery requirement forced to OPEN_QUESTION", any("must be OPEN_QUESTION" in p for p in sc.validate_state_compatibility(unknown_ac)))


def test_cross_surface_resolver() -> None:
    cs = cross_surface_mod

    # a comparison baseline (semantic equivalence) is fine as a REFERENCE_ORACLE
    ref = [{"surface": "Native PDF", "impact_class": "SEMANTIC_EQUIVALENCE_ONLY", "role": "REFERENCE_ORACLE"}]
    check("semantic-equivalence surface as REFERENCE_ORACLE passes", cs.validate_cross_surface(ref) == [])

    # ...but semantic equivalence alone cannot make it a REGRESSION_TARGET
    bad = [{"surface": "HTML5", "impact_class": "SEMANTIC_EQUIVALENCE_ONLY", "role": "REGRESSION_TARGET", "evidence": ["shows same semantics"]}]
    check("semantic-equivalence-only REGRESSION_TARGET is rejected", any("not proof of impact" in p for p in cs.validate_cross_surface(bad)))

    # no-evidence-of-impact cannot be a regression target
    none_ev = [{"surface": "DITA-OT PDF", "impact_class": "NO_EVIDENCE_OF_IMPACT", "role": "REGRESSION_TARGET", "evidence": ["x"]}]
    check("no-evidence-of-impact REGRESSION_TARGET is rejected", any("not proof of impact" in p for p in cs.validate_cross_surface(none_ev)))

    # a shared-path surface with evidence is a valid REGRESSION_TARGET
    good = [{"surface": "Legacy AEM Sites", "impact_class": "SHARED_AFFECTED_PATH", "role": "REGRESSION_TARGET", "evidence": ["shares TOC path helper"]}]
    check("shared-path REGRESSION_TARGET with evidence passes", cs.validate_cross_surface(good) == [])
    # ...but the same shared-path target with no evidence is rejected
    good_no_ev = [{"surface": "Legacy AEM Sites", "impact_class": "SHARED_AFFECTED_PATH", "role": "REGRESSION_TARGET", "evidence": []}]
    check("shared-path REGRESSION_TARGET without evidence is rejected", any("must cite evidence" in p for p in cs.validate_cross_surface(good_no_ev)))

    # vocab guards
    check("invalid impact_class rejected", any("impact_class" in p for p in cs.validate_cross_surface([{"surface": "X", "impact_class": "SORTA", "role": "REFERENCE_ORACLE"}])))
    check("invalid role rejected", any("role" in p for p in cs.validate_cross_surface([{"surface": "X", "impact_class": "NO_EVIDENCE_OF_IMPACT", "role": "MAYBE"}])))

    # multi-output signal detection
    check("two+ publishing modes is a multi-output signal",
          cs.multi_output_signal({"behavior_model": {"publishing_modes": ["Native PDF", "New AEM Site"]}}) is True)
    check("single publishing mode is not a multi-output signal",
          cs.multi_output_signal({"behavior_model": {"publishing_modes": ["New AEM Site"]}}) is False)


def test_structural_equivalence() -> None:
    se = struct_equiv_mod
    allchecks = {d: True for d in se.VERIFICATION_DIMENSIONS}

    # fully-verified equivalence may drive regression
    ok = [{"construct_a": "topichead", "construct_b": "topicref", "classification": "EQUIVALENT_PATH",
           "checks": allchecks, "evidence": ["same parser + nav model + transform, product-supported"],
           "disposition": "REGRESSION", "generates_regression": True}]
    check("fully-verified EQUIVALENT_PATH passes", se.validate_structural_equivalence(ok) == [])

    # EQUIVALENT_PATH missing a verified dimension is rejected
    partial_checks = dict(allchecks)
    partial_checks["transformation"] = False
    bad = [{"construct_a": "topichead", "construct_b": "topicref", "classification": "EQUIVALENT_PATH",
            "checks": partial_checks, "evidence": ["x"]}]
    check("EQUIVALENT_PATH with an unverified dimension is rejected", any("requires all verification dimensions" in p for p in se.validate_structural_equivalence(bad)))

    # asserting equivalence without evidence is rejected
    no_ev = [{"construct_a": "a", "construct_b": "b", "classification": "EQUIVALENT_PATH", "checks": allchecks, "evidence": []}]
    check("EQUIVALENT_PATH without evidence is rejected", any("must cite evidence" in p for p in se.validate_structural_equivalence(no_ev)))

    # the GUIDES-53707 case: unverified -> UNKNOWN -> Open Question, no regression
    unknown_ok = [{"construct_a": "topichead", "construct_b": "topicref", "classification": "UNKNOWN",
                   "disposition": "OPEN_QUESTION", "generates_regression": False}]
    check("UNKNOWN equivalence as Open Question passes", se.validate_structural_equivalence(unknown_ok) == [])
    unknown_bad = [{"construct_a": "topichead", "construct_b": "topicref", "classification": "UNKNOWN",
                    "disposition": "REGRESSION", "generates_regression": True}]
    check("UNKNOWN equivalence asserted as regression is rejected",
          any("must be an OPEN_QUESTION" in p or "must not generate regression" in p for p in se.validate_structural_equivalence(unknown_bad)))

    # PARTIALLY_EQUIVALENT needs a verified dimension, evidence, and a stated boundary
    part_ok = [{"construct_a": "a", "construct_b": "b", "classification": "PARTIALLY_EQUIVALENT",
                "checks": {"navigation_model": True}, "evidence": ["same nav model"], "boundary": "transformation differs",
                "generates_regression": True}]
    check("well-formed PARTIALLY_EQUIVALENT passes", se.validate_structural_equivalence(part_ok) == [])
    part_bad = [{"construct_a": "a", "construct_b": "b", "classification": "PARTIALLY_EQUIVALENT",
                 "checks": {"navigation_model": True}, "evidence": ["x"]}]
    check("PARTIALLY_EQUIVALENT without a boundary is rejected", any("must state the boundary" in p for p in se.validate_structural_equivalence(part_bad)))

    # DIFFERENT_PATH cannot generate regression
    diff = [{"construct_a": "a", "construct_b": "b", "classification": "DIFFERENT_PATH", "generates_regression": True}]
    check("DIFFERENT_PATH generating regression is rejected", any("only EQUIVALENT_PATH or a materially relevant" in p for p in se.validate_structural_equivalence(diff)))

    check("invalid classification rejected", any("classification" in p for p in se.validate_structural_equivalence([{"construct_a": "a", "construct_b": "b", "classification": "SAMEISH"}])))


def test_scenario_reducer() -> None:
    sr = scenario_reducer_mod

    def scn(sid, decision, branch, transition, contract, factors=None, representative=True, collapsed_into=None):
        e = {"scenario_id": sid,
             "signature": {"semantic_decision": decision, "implementation_branch": branch,
                           "state_transition": transition, "resulting_contract": contract},
             "distinguishing_factors": factors or [], "representative": representative}
        if collapsed_into:
            e["collapsed_into"] = collapsed_into
        return e

    # two scenarios with the same signature and no distinguishing factor: one rep, one collapsed
    rep = scn("S1", "publish grouping", "fallback branch", "state written", "navigation shows group")
    dup = scn("S2", "publish grouping", "fallback branch", "state written", "navigation shows group",
              representative=False, collapsed_into="S1")
    check("equivalent scenario collapses cleanly", sr.validate_reduction([rep, dup]) == [])
    reps, collapsed = sr.reduce([rep, dup])
    check("reduce keeps one representative", len(reps) == 1 and len(collapsed) == 1)

    # a collapsed scenario whose signature differs from its representative is rejected
    diff = scn("S3", "publish grouping", "LOCKED branch", "state written", "navigation shows group",
               representative=False, collapsed_into="S1")
    check("collapsing across different signatures is rejected", any("signatures differ" in p for p in sr.validate_reduction([rep, diff])))

    # a scenario carrying a distinguishing factor cannot be collapsed
    factored = scn("S4", "publish grouping", "fallback branch", "state written", "navigation shows group",
                   factors=["different_lifecycle_transition"], representative=False, collapsed_into="S1")
    check("scenario with a distinguishing factor cannot be collapsed", any("cannot be collapsed" in p for p in sr.validate_reduction([rep, factored])))
    # ...but it is fine as its own representative
    factored_rep = scn("S4", "publish grouping", "fallback branch", "remove then republish", "navigation updates",
                       factors=["different_lifecycle_transition"], representative=True)
    check("distinguishing scenario is fine as a representative", sr.validate_reduction([rep, factored_rep]) == [])

    # two representatives with identical signature and no distinguishing factor -> redundancy flag
    rep2 = scn("S5", "publish grouping", "fallback branch", "state written", "navigation shows group")
    check("redundant representatives are flagged", any("collapse them" in p for p in sr.validate_reduction([rep, rep2])))

    # signature completeness and factor vocab
    incomplete = {"scenario_id": "S6", "signature": {"semantic_decision": "x"}, "representative": True}
    check("incomplete signature is rejected", any("is required" in p for p in sr.validate_reduction([incomplete])))
    badf = scn("S7", "d", "b", "t", "c", factors=["random"], representative=True)
    check("invalid distinguishing factor is rejected", any("must be one of" in p for p in sr.validate_reduction([badf])))


def test_evidence_authority() -> None:
    ea = authority_mod

    items = [
        {"evidence_id": "E1", "statement": "spec requires X", "status": "CONFIRMED", "authority": "SPECIFICATION_AUTHORITY"},
        {"evidence_id": "E2", "statement": "current code does Y", "status": "IMPLEMENTED", "authority": "IMPLEMENTATION_AUTHORITY"},
        {"evidence_id": "E3", "statement": "old design proposed Z", "status": "SUPERSEDED", "authority": "PRODUCT_REQUIREMENT_AUTHORITY"},
    ]

    # a spec-vs-implementation conflict preserved as an Open Question passes
    oq = {"items": items, "conflicts": [{"between": ["E1", "E2"], "resolution_method": "NONE", "disposition": "OPEN_QUESTION"}]}
    check("spec-vs-impl conflict preserved as Open Question passes", ea.validate_evidence_authority(oq) == [])

    # resolving by recency / similarity is forbidden
    recency = {"items": items, "conflicts": [{"between": ["E1", "E2"], "resolution_method": "LATEST_COMMENT", "disposition": "RESOLVED", "resolved_by": "E2", "note": "newer"}]}
    check("latest-comment resolution is forbidden", any("must not be resolved by recency" in p for p in ea.validate_evidence_authority(recency)))
    sim = {"items": items, "conflicts": [{"between": ["E1", "E2"], "resolution_method": "HIGHEST_SIMILARITY", "disposition": "RESOLVED", "resolved_by": "E1", "note": "closer"}]}
    check("highest-similarity resolution is forbidden", any("forbidden" in p for p in ea.validate_evidence_authority(sim)))

    # a valid explicit resolution passes
    valid = {"items": items, "conflicts": [{"between": ["E1", "E2"], "resolution_method": "EXPLICIT_FINAL_DECISION", "disposition": "RESOLVED", "resolved_by": "E1", "note": "product decided to follow the spec"}]}
    check("explicit-decision resolution passes", ea.validate_evidence_authority(valid) == [])

    # cannot resolve in favour of superseded/rejected evidence
    stale = {"items": items, "conflicts": [{"between": ["E1", "E3"], "resolution_method": "AUTHORITY_ORDERING", "disposition": "RESOLVED", "resolved_by": "E3", "note": "old design"}]}
    check("resolving toward superseded evidence is rejected", any("cannot be the current truth" in p for p in ea.validate_evidence_authority(stale)))

    # a RESOLVED conflict without resolved_by is rejected
    noby = {"items": items, "conflicts": [{"between": ["E1", "E2"], "resolution_method": "AUTHORITY_ORDERING", "disposition": "RESOLVED", "note": "x"}]}
    check("RESOLVED without resolved_by is rejected", any("must state resolved_by" in p for p in ea.validate_evidence_authority(noby)))

    # vocab + reference guards
    check("bad status rejected", any("status" in p for p in ea.validate_evidence_authority({"items": [{"evidence_id": "E9", "statement": "x", "status": "MAYBE", "authority": "SPECIFICATION_AUTHORITY"}]})))
    check("bad authority rejected", any("authority" in p for p in ea.validate_evidence_authority({"items": [{"evidence_id": "E9", "statement": "x", "status": "CONFIRMED", "authority": "VIBES"}]})))
    check("conflict referencing unknown id rejected", any("unknown evidence_id" in p for p in ea.validate_evidence_authority({"items": items, "conflicts": [{"between": ["E1", "E99"], "resolution_method": "NONE", "disposition": "OPEN_QUESTION"}]})))


def test_change_impact() -> None:
    ci = change_impact_mod

    def block(**over):
        base = {"changed": ["PathUtils.appendUnixSlash"], "callers": ["getTocItemUsingMap"],
                "shared_models": ["MapTOCEntry"], "state_paths": {"written": ["guides-navigation"], "read": ["guides-navigation"]},
                "downstream_consumers": ["New AEM Site preset"], "outputs": ["site navigation"],
                "can_affect": ["New AEM Site TOC building"], "cannot_affect": ["Native PDF pipeline"],
                "regression_targets": [{"target": "New AEM Site TOC", "shared_path_evidence": ["shares appendPath helper"]}],
                "tests_exercising_change": ["AemSiteApiIT"],
                "product_contract_considered": True, "semantic_behavior_considered": True}
        base.update(over)
        return base

    check("well-formed change_impact passes", ci.validate_change_impact(block()) == [])
    check("missing changed is rejected", any("changed must list" in p for p in ci.validate_change_impact(block(changed=[]))))
    check("missing cannot_affect is rejected", any("cannot_affect" in p for p in ci.validate_change_impact(block(cannot_affect=[]))))
    check("missing can_affect is rejected", any("can_affect" in p for p in ci.validate_change_impact(block(can_affect=[]))))

    # a regression target without shared-path evidence is rejected
    no_ev = block(regression_targets=[{"target": "HTML5", "shared_path_evidence": []}])
    check("regression target without shared-path evidence is rejected", any("shared_path_evidence" in p for p in ci.validate_change_impact(no_ev)))
    # a regression target also in cannot_affect is a contradiction
    contra = block(cannot_affect=["Native PDF pipeline"], regression_targets=[{"target": "Native PDF pipeline", "shared_path_evidence": ["x"]}])
    check("regression target in cannot_affect is a contradiction", any("contradiction" in p for p in ci.validate_change_impact(contra)))

    # code impact must be combined with product contract + semantic behaviour, not replace them
    check("product_contract_considered false is rejected", any("does not replace the product contract" in p for p in ci.validate_change_impact(block(product_contract_considered=False))))
    check("semantic_behavior_considered false is rejected", any("semantic behaviour" in p for p in ci.validate_change_impact(block(semantic_behavior_considered=False))))

    # change signal detection
    check("change_impact block is a change signal", ci.has_change_signal({"change_impact": block()}) is True)
    check("fix_available flag is a change signal", ci.has_change_signal({"fix_available": True}) is True)
    check("no fix signal without a diff/PR/fix", ci.has_change_signal({"issue": "X"}) is False)


def test_implementation_grounding() -> None:
    ig = impl_grounding_mod

    # activation: a ticket naming a REST/servlet API artifact activates
    api_manifest = {"issue": {"summary": "API to track output generation status",
                    "description": "The /bin/publishlistener servlet operation returns no job id"}}
    check("named API/servlet artifact activates implementation grounding", ig.is_active(api_manifest) is True)
    # a plain UI/DITA ticket does not activate
    check("plain UI ticket does not activate", ig.is_active({"issue": {"summary": "Show a warning dialog on save"}}) is False)

    # asserts_current_behavior: Expected Behaviour claiming what the API does today
    plan_asserting = ("Acceptance Criteria\n- AC-01\nExpected Behaviour\n"
                      "- The /bin/publishlistener endpoint currently returns no job id in its response.")
    check("current-behaviour assertion about an API is detected", ig.asserts_current_behavior(plan_asserting) is True)
    check("no assertion when API not mentioned", ig.asserts_current_behavior("Expected Behaviour\n- The dialog shows a warning.") is False)

    # block validation
    def art(**over):
        base = {"artifact": "/bin/publishlistener GENERATEOUTPUT", "kind": "operation",
                "inspected": True, "evidence": ["PublishOutputService.java:182"], "material": True}
        base.update(over)
        return base

    def block(**over):
        base = {"active": True, "named_artifacts": [art()]}
        base.update(over)
        return base

    check("well-formed implementation_grounding passes", ig.validate_implementation_grounding(block()) == [])
    # a material artifact not inspected is rejected
    check("material artifact not inspected is rejected",
          any("not inspected" in p for p in ig.validate_implementation_grounding(block(named_artifacts=[art(inspected=False)]))))
    # a material artifact without cited evidence is rejected
    check("material artifact without file:line evidence is rejected",
          any("file:line" in p for p in ig.validate_implementation_grounding(block(named_artifacts=[art(evidence=[])]))))
    # a stated ticket premise not verified against code is rejected
    unverified = art(premise="the generate call returns no job id", premise_verified=False)
    check("unverified ticket premise is rejected",
          any("premise_verified" in p for p in ig.validate_implementation_grounding(block(named_artifacts=[unverified]))))
    # a verified premise (recording that code contradicts the ticket) is allowed
    verified = art(premise="the generate call returns no job id", premise_verified=True, premise_holds=False)
    check("verified premise (code contradicts ticket) is allowed", ig.validate_implementation_grounding(block(named_artifacts=[verified])) == [])
    # empty artifact list is rejected
    check("empty named_artifacts is rejected", any("non-empty" in p for p in ig.validate_implementation_grounding(block(named_artifacts=[]))))
    # bad kind is rejected
    check("invalid artifact kind is rejected", any("kind must be one of" in p for p in ig.validate_implementation_grounding(block(named_artifacts=[art(kind="widget")]))))

    # config-key provenance: a reporter/ticket-supplied key must be verified or made an Open Question.
    # (Backported from the dev-copy suite - the validator already enforced this in both
    # copies, but this copy's self-tests never got matching coverage.)
    def cfg(**over):
        return art(artifact="duplicate.uuid.move.old.file", kind="config_key",
                   evidence=["ConfigManager.java:195"], **over)
    check("config_key with verified provenance passes",
          ig.validate_implementation_grounding(block(named_artifacts=[cfg(key_provenance="CODE")])) == [])
    check("config_key UNVERIFIED provenance without OQ is rejected",
          any("UNVERIFIED provenance" in p for p in ig.validate_implementation_grounding(block(named_artifacts=[cfg(key_provenance="REPORTER")]))))
    check("config_key UNVERIFIED provenance with OQ ref passes",
          ig.validate_implementation_grounding(block(named_artifacts=[cfg(key_provenance="REPORTER", verification_open_question_ref="OQ-3")]), open_question_ids=["OQ-3"]) == [])
    check("empty known Open Question set rejects implementation-grounding reference",
          any("not in the plan's open_questions" in p for p in ig.validate_implementation_grounding(
              block(named_artifacts=[cfg(key_provenance="REPORTER", verification_open_question_ref="OQ-3")]),
              open_question_ids=[])))
    check("config_key invalid provenance rejected",
          any("key_provenance must be one of" in p for p in ig.validate_implementation_grounding(block(named_artifacts=[cfg(key_provenance="RUMOR")]))))
    check("config_key missing provenance is review-only, not a validate failure",
          ig.validate_implementation_grounding(block(named_artifacts=[cfg()])) == []
          and ig.config_key_artifacts_missing_provenance(block(named_artifacts=[cfg()])) == ["duplicate.uuid.move.old.file"])

    # premise_holds tri-state: 'unresolved' is allowed only with a premise_note explaining the gap.
    unresolved_no_note = art(premise="friendly names update live", premise_verified=True, premise_holds="unresolved")
    check("premise_holds 'unresolved' without a note is rejected",
          any("premise_note is empty" in p for p in ig.validate_implementation_grounding(block(named_artifacts=[unresolved_no_note]))))
    unresolved_with_note = art(premise="friendly names update live", premise_verified=True, premise_holds="unresolved",
                                premise_note="dependency package source not reachable; searched local clone and GitHub MCP, both absent")
    check("premise_holds 'unresolved' with a note passes",
          ig.validate_implementation_grounding(block(named_artifacts=[unresolved_with_note])) == [])
    bad_holds = art(premise="friendly names update live", premise_verified=True, premise_holds="maybe")
    check("premise_holds invalid string value is rejected",
          any("must be true, false, or 'unresolved'" in p for p in ig.validate_implementation_grounding(block(named_artifacts=[bad_holds]))))

    # dependency_resolution: optional sub-field, validated only when declared.
    dep_ok = art(dependency_resolution={"status": "RESOLVED_LOCAL_CLONE", "external_package": "@rh/jui-app"})
    check("dependency_resolution with valid status passes", ig.validate_implementation_grounding(block(named_artifacts=[dep_ok])) == [])
    dep_bad_status = art(dependency_resolution={"status": "GUESSED"})
    check("dependency_resolution invalid status is rejected",
          any("dependency_resolution.status must be one of" in p for p in ig.validate_implementation_grounding(block(named_artifacts=[dep_bad_status]))))
    dep_unresolved_no_note = art(dependency_resolution={"status": "UNRESOLVED_NO_ACCESS"})
    check("dependency_resolution UNRESOLVED_NO_ACCESS without a note is rejected",
          any("UNRESOLVED_NO_ACCESS but has no 'note'" in p for p in ig.validate_implementation_grounding(block(named_artifacts=[dep_unresolved_no_note]))))
    dep_unresolved_with_note = art(dependency_resolution={
        "status": "UNRESOLVED_NO_ACCESS", "external_package": "@rh/jui-app",
        "note": "no local clone and GitHub MCP unavailable"})
    check("dependency_resolution UNRESOLVED_NO_ACCESS with a note passes",
          ig.validate_implementation_grounding(block(named_artifacts=[dep_unresolved_with_note])) == [])


def test_capability_eligibility() -> None:
    ce = cap_elig_mod
    check("multi-action toolbar activates", ce.is_active({"issue": {"description": "the toolbar shows View source, Edit topics and Share buttons"}}) is True)
    check("single-action ticket does not activate (Case A)", ce.is_active({"issue": {"summary": "fix the export dialog title"}}) is False)

    def term(**o):
        b = {"dimension": "ENTITY_TYPE", "operator": "in", "expected_value": "dita", "evidence_ids": ["E1"], "material": True}
        b.update(o)
        return b

    def cap(name="Cap A", **o):
        b = {"capability": name, "predicate_terms": [term()]}
        b.update(o)
        return b

    def block(**o):
        b = {"active": True, "capabilities": [cap("Cap A"), cap("Cap B", predicate_terms=[term(dimension="METADATA", expected_value="uuid present")])]}
        b.update(o)
        return b

    check("distinct per-capability predicates pass (Case C)", ce.validate_capability_eligibility(block()) == [])
    check("material predicate without evidence rejected",
          any("evidence" in p for p in ce.validate_capability_eligibility(block(capabilities=[cap(predicate_terms=[term(evidence_ids=[])])]))))
    check("invalid predicate dimension rejected",
          any("dimension" in p for p in ce.validate_capability_eligibility(block(capabilities=[cap(predicate_terms=[term(dimension="VIBES")])]))))
    check("empty capabilities rejected", any("non-empty" in p for p in ce.validate_capability_eligibility({"active": True, "capabilities": []})))
    grouped_ok = block(shared_predicate_groups=[{"capabilities": ["Cap A", "Cap B"], "shared_predicate": "content type is dita", "evidence": ["E9"]}])
    check("shared predicate group with evidence passes (Case B)", ce.validate_capability_eligibility(grouped_ok) == [])
    grouped_no_ev = block(shared_predicate_groups=[{"capabilities": ["Cap A", "Cap B"], "shared_predicate": "same", "evidence": []}])
    check("shared group without evidence is flagged for review", ce.bundled_groups_without_evidence(grouped_no_ev) == ["Cap A, Cap B"])
    check("group with unknown capability rejected",
          any("not decomposed" in p for p in ce.validate_capability_eligibility(block(shared_predicate_groups=[{"capabilities": ["Cap A", "Cap Z"], "evidence": ["E1"]}]))))
    check("no multiselect -> no selection requirement (Case D)", ce.validate_capability_eligibility(block(), multiselect=False) == [])
    ms_unknown = block(capabilities=[cap(selection_policy="UNKNOWN")])
    check("multiselect UNKNOWN without open question rejected", any("selection_policy" in p for p in ce.validate_capability_eligibility(ms_unknown, multiselect=True)))
    ms_ref = block(capabilities=[cap(selection_policy="UNKNOWN", selection_open_question_ref="OQ-1")])
    check("multiselect UNKNOWN with open-question ref allowed", ce.validate_capability_eligibility(ms_ref, multiselect=True, open_question_ids=["OQ-1"]) == [])
    check("empty known Open Question set rejects capability reference",
          any("not in the plan's open_questions" in p for p in
              ce.validate_capability_eligibility(ms_ref, multiselect=True, open_question_ids=[])))
    coll = block(capabilities=[cap(eligibility_evidence=[{"capability_match": "SEMANTIC_COLLISION", "supports_predicate": True}])])
    check("semantic-collision evidence cannot support predicate", any("SEMANTIC_COLLISION" in p for p in ce.validate_capability_eligibility(coll)))

    # Item 17: behavior_model capabilities[] block validates (optional, per-capability).
    bm_caps = {"trigger": ["open toolbar"], "operations": ["render actions"],
               "capabilities": [{"name": "View source", "inputs": ["asset"], "surfaces": ["ASSET_DETAILS"]},
                                {"name": "Share UUID", "eligibility": ["has uuid"]}]}
    check("behavior_model with capabilities[] validates", behavior_mod.validate_behavior_model(bm_caps) == [])
    check("behavior_model capability missing name rejected",
          any("missing 'name'" in p for p in behavior_mod.validate_behavior_model({"trigger": ["x"], "operations": ["y"], "capabilities": [{"inputs": []}]})))

    # Item 18: a direct capability predicate outranks a historical-similarity item.
    ranked = relevance_mod.prioritize([
        {"relevance_kind": "HISTORICAL_SIMILARITY", "relevance_score": 0.99},
        {"relevance_kind": "CAPABILITY_PREDICATE", "relevance_score": 0.10},
    ])
    check("capability predicate outranks historical similarity (Item 18)", ranked[0]["relevance_kind"] == "CAPABILITY_PREDICATE")

    # Item 19: coverage_gate emits the named capability/scope dimensions and FAILs a hidden scope mismatch.
    gate_ok = coverage_gate_mod.evaluate({"open_questions": ["OQ-1"],
        "capability_eligibility": {"active": True, "capabilities": [{"capability": "A", "predicate_terms": [{"dimension": "ENTITY_TYPE", "evidence_ids": ["E1"], "material": True}]}]},
        "scope_conflict": {"active": True, "problem_threads": [{"thread_id": "T1", "problem_statement": "p", "status": "CONFIRMED"}], "alignment": "FULL_SCOPE_FIX"}})
    check("coverage_gate emits AFFECTED_CAPABILITIES_DECOMPOSED", gate_ok["dimensions"].get("AFFECTED_CAPABILITIES_DECOMPOSED") == "COVERED")
    check("coverage_gate emits JIRA_SCOPE_VS_FIX_RECONCILED", gate_ok["dimensions"].get("JIRA_SCOPE_VS_FIX_RECONCILED") == "COVERED")
    gate_fail = coverage_gate_mod.evaluate({
        "scope_conflict": {"active": True, "problem_threads": [{"thread_id": "T1", "problem_statement": "p", "status": "CONFIRMED"}], "alignment": "PARTIAL_SCOPE_FIX", "open_question_refs": []}})
    check("coverage_gate FAILs a hidden scope mismatch (Item 19)", gate_fail["semantic_gate"] == "FAIL")

    # Entry-point / render-form consistency (responsive direct-button vs overflow-menu).
    def ep_cap(**o):
        b = {"capability": "Insert Keyword", "predicate_terms": [term()],
             "entry_points": [
                 {"form": "DIRECT_BUTTON", "dispatch": "AUTHOR_INSERT_ELEMENT", "evidence_ids": ["E1"]},
                 {"form": "OVERFLOW_MENU", "dispatch": "AUTHOR_INSERT_KEYWORD", "evidence_ids": ["E2"]}],
             "entry_point_consistency": "VERIFIED_SAME", "entry_point_consistency_evidence": ["fix unifies dispatch"]}
        b.update(o)
        return b
    check("entry points with resolved consistency pass", ce.validate_capability_eligibility({"active": True, "capabilities": [ep_cap()]}) == [])
    check("multiple entry points without consistency rejected",
          any("entry_point_consistency" in p for p in ce.validate_capability_eligibility({"active": True, "capabilities": [ep_cap(entry_point_consistency="")]})))
    check("VERIFIED_SAME without evidence rejected",
          any("needs evidence" in p for p in ce.validate_capability_eligibility({"active": True, "capabilities": [ep_cap(entry_point_consistency_evidence=[])]})))
    ep_open = {"active": True, "capabilities": [ep_cap(
        entry_point_consistency="OPEN_QUESTION",
        entry_point_consistency_evidence=[],
        entry_point_open_question_ref="OQ-7",
    )]}
    check("entry-point Open Question reference passes when declared",
          ce.validate_capability_eligibility(ep_open, open_question_ids=["OQ-7"]) == [])
    check("empty known Open Question set rejects entry-point reference",
          any("not in the plan's open_questions" in p for p in
              ce.validate_capability_eligibility(ep_open, open_question_ids=[])))
    check("invalid entry-point form rejected",
          any("form must be one of" in p for p in ce.validate_capability_eligibility({"active": True, "capabilities": [ep_cap(entry_points=[{"form": "WIDGET", "evidence_ids": ["E1"]}, {"form": "OVERFLOW_MENU", "evidence_ids": ["E2"]}])]})))
    resp_manifest = {"issue": {"description": "the keyword shows as a direct button at 50% zoom; in the overflow menu it works"}}
    under = ce.entrypoint_underexplored({"capabilities": [{"capability": "Insert Keyword", "predicate_terms": [term()]}]}, resp_manifest)
    check("responsive signals + <2 entry points is under-explored", under == ["Insert Keyword"])
    check("no responsive signals -> not under-explored", ce.entrypoint_underexplored({"capabilities": [{"capability": "X"}]}, {"issue": {"summary": "plain dialog title fix"}}) == [])

    # CONFIG predicate must cite a real config key, not a paraphrased mode name.
    no_key = {"capabilities": [{"capability": "Save under lock", "predicate_terms": [
        {"dimension": "CONFIG", "expected_value": "explicit-lock mode enabled", "evidence_ids": ["Jira AC field"], "material": True}]}]}
    check("CONFIG term without a config key is flagged", ce.config_terms_missing_key(no_key) == ["Save under lock"])
    with_key = {"capabilities": [{"capability": "Save under lock", "predicate_terms": [
        {"dimension": "CONFIG", "expected_value": "xmleditor.autocheckout (Disable edit without locking the file) enabled", "evidence_ids": ["XmlEditorConfig"], "material": True}]}]}
    check("CONFIG term citing xmleditor.autocheckout is not flagged", ce.config_terms_missing_key(with_key) == [])

    # Config PREREQUISITE product decision must be surfaced as an Open Question.
    prereq_cap = {"active": True, "capabilities": [{"capability": "Save under lock", "predicate_terms": [
        {"dimension": "CONFIG", "config_key": "xmleditor.autocheckout", "expected_value": "xmleditor.autocheckout enabled", "evidence_ids": ["XmlEditorConfig"], "material": True, "prerequisite": True}]}]}
    check("CONFIG prerequisite without an open-question ref is rejected",
          any("prerequisite" in p for p in ce.validate_capability_eligibility(prereq_cap)))
    prereq_ok = {"active": True, "capabilities": [{"capability": "Save under lock", "predicate_terms": [
        {"dimension": "CONFIG", "config_key": "xmleditor.autocheckout", "expected_value": "xmleditor.autocheckout enabled", "evidence_ids": ["XmlEditorConfig"], "material": True, "prerequisite": True, "prerequisite_open_question_ref": "OQ-5"}]}]}
    check("CONFIG prerequisite surfaced as an open question passes",
          ce.validate_capability_eligibility(prereq_ok, open_question_ids=["OQ-5"]) == [])


def test_scope_conflict() -> None:
    sc = scope_conflict_mod
    check("fix + multi-problem activates", sc.is_active({"issue": {"description": "the PR fixes the button; also there is a separate font preview problem"}}) is True)
    check("no fix signal does not activate", sc.is_active({"issue": {"summary": "buttons show on wrong assets"}}) is False)
    check(
        "pre-development plan text does not create a false fix-scope conflict",
        sc.is_active(
            {"issue": {"description": "the future fix should cover the button and another problem"}},
            "Lifecycle is Pre-Development UAC; development has not started and no pull request exists.",
        ) is False,
    )

    def thread(**o):
        b = {"thread_id": "T1", "problem_statement": "buttons wrong", "status": "CONFIRMED"}
        b.update(o)
        return b

    def block(**o):
        b = {"active": True, "problem_threads": [thread()], "alignment": "FULL_SCOPE_FIX", "open_question_refs": []}
        b.update(o)
        return b

    check("full alignment passes with no open question (Case E)", sc.validate_scope_conflict(block()) == [])
    check("partial alignment without open question rejected",
          any("surfaced as an Open Question" in p for p in sc.validate_scope_conflict(block(alignment="PARTIAL_SCOPE_FIX"))))
    check("partial alignment with open question passes",
          sc.validate_scope_conflict(block(alignment="PARTIAL_SCOPE_FIX", open_question_refs=["OQ-2"]), open_question_ids=["OQ-2"]) == [])
    check("empty known Open Question set rejects scope-conflict reference",
          any("not present" in p for p in sc.validate_scope_conflict(
              block(alignment="PARTIAL_SCOPE_FIX", open_question_refs=["OQ-2"]),
              open_question_ids=[])))
    check("unresolved_scope_without_open_question detects hidden mismatch",
          sc.unresolved_scope_without_open_question(block(alignment="UNKNOWN_FIX_SCOPE")) is True)
    check("unresolved scope rejects undeclared Open Question reference",
          sc.unresolved_scope_without_open_question(
              block(alignment="PARTIAL_SCOPE_FIX", open_question_refs=["OQ-2"]),
              open_question_ids=[],
          ) is True)
    check("unresolved scope accepts declared Open Question reference",
          sc.unresolved_scope_without_open_question(
              block(alignment="PARTIAL_SCOPE_FIX", open_question_refs=["OQ-2"]),
              open_question_ids=["OQ-2"],
          ) is False)
    check("secondary-defect thread mapped to AC rejected (Case F)",
          any("must NOT map" in p for p in sc.validate_scope_conflict(block(problem_threads=[thread(status="SECONDARY_DEFECT", maps_to_ac=True)]))))
    check("invalid thread status rejected", any("status" in p for p in sc.validate_scope_conflict(block(problem_threads=[thread(status="MAYBE")]))))
    check("invalid alignment rejected", any("alignment" in p for p in sc.validate_scope_conflict(block(alignment="SORTA"))))

    implementation_only_plan = (
        "**Acceptance Criteria**\n"
        "- AC-01 [Proposed]: (Negative) Given a request lacks an identifier | "
        "When the action runs | Then a clear error is shown | "
        "Evidence: commit abcdef1 and implementation diff.\n"
        "**Expected Behaviour**\n- Known."
    )
    candidates = sc.implementation_scope_candidates(implementation_only_plan)
    check(
        "PR-only extra behavior is detected generically",
        [item["ac_ref"] for item in candidates] == ["AC-01"],
    )
    jira_authorized_plan = implementation_only_plan.replace(
        "commit abcdef1 and implementation diff",
        "Jira UAC and commit abcdef1",
    )
    check(
        "Jira-authorized behavior is not treated as implementation-only",
        sc.implementation_scope_candidates(jira_authorized_plan) == [],
    )
    authority_block = {
        "schema_version": sc.IMPLEMENTATION_SCOPE_SCHEMA,
        "items": [
            {
                "ac_ref": "AC-01",
                "decision": "OPEN_QUESTION",
                "open_question_ref": "OQ-01",
            }
        ],
    }
    check(
        "implementation-only AC requires a real scope Open Question",
        any(
            "real open_question_ref" in problem
            for problem in sc.validate_implementation_scope_authority(
                authority_block, candidates=candidates, open_question_ids=set()
            )
        ),
    )
    check(
        "implementation-only Proposed AC passes with a declared scope question",
        sc.validate_implementation_scope_authority(
            authority_block, candidates=candidates, open_question_ids={"OQ-01"}
        )
        == [],
    )
    approved_candidates = [dict(candidates[0], status="Confirmed")]
    approved_block = {
        "schema_version": sc.IMPLEMENTATION_SCOPE_SCHEMA,
        "items": [
            {
                "ac_ref": "AC-01",
                "decision": "PRODUCT_APPROVED",
                "authority_source": "accepted UAC approved by product",
            }
        ],
    }
    check(
        "named product authority can approve implementation-discovered scope",
        sc.validate_implementation_scope_authority(
            approved_block,
            candidates=approved_candidates,
            open_question_ids=set(),
        )
        == [],
    )


def test_pre_uac_critic() -> None:
    cr = critic_mod

    # a clean, fully-reasoned plan: primary + governing dep explored+verified, unresolved
    # surfaced, observable oracle -> PASS
    good_manifest = {
        "behaviour_matters": True,
        "coverage_hypotheses": [{"hypothesis_id": "H1", "dimension": "DITA_SEMANTIC_DEPENDENCY", "candidate": "locktitle governs navtitle",
                                  "reason": "r", "technical_basis": ["setTocItemTitle"], "status": "CONFIRMED",
                                  "behavioral_distance": "DIRECT", "priority_reason": "directly controls the title"}],
        "verifications": [{"hypothesis_id": "H1", "verdict": "CONFIRMED", "supporting_authorities": ["CURRENT_IMPLEMENTATION"],
                            "supporting_evidence": ["E1"], "disposition": "ACCEPTANCE_CRITERION"}],
        "dita_semantics": {"active": True, "relations": [{"source_construct": "locktitle", "target_construct": "navtitle",
                            "relation": "CONTROLS", "dita_version": "1.3", "authority": "DITA_SPEC", "evidence": ["x"],
                            "material": True, "states": ["yes"], "status": "CONFIRMED"}]},
    }
    good_plan = ("**Acceptance Criteria**\n- AC-01 [Confirmed]: (Basic) Given a map | When published | Then the navigation shows the grouping node.\n"
                 "**Test Scenarios**\n- P0 [AC-01]: publish -> the site navigation shows the grouping entry.\n"
                 "**Open Questions**\n- No open questions from current evidence\n")
    r = cr.critique(good_manifest, good_plan)
    check("clean reasoned plan passes the critic", r["verdict"] == "PASS")

    relationship_only = dict(good_manifest)
    relationship_only.pop("coverage_hypotheses", None)
    relationship_only.pop("verifications", None)
    relationship_only["construct_relationships"] = {
        "edges": [
            {
                "relation_type": "CONSUMER",
                "neighbor": "navigation renderer",
            }
        ]
    }
    check(
        "relationship umbrella satisfies breadth exploration in the critic",
        cr.critique(relationship_only, good_plan)["questions"]["only_the_noun"][0]
        == "CLEAN",
    )

    # an unexplored HIGH-relevance dependency (candidate, no verification) -> NEEDS_REFINEMENT (Q3)
    unexplored_cov = [dict(good_manifest["coverage_hypotheses"][0], status="INVESTIGATION_CANDIDATE")]
    nr = dict(good_manifest, coverage_hypotheses=unexplored_cov, verifications=[])
    check("unexplored direct dependency -> NEEDS_REFINEMENT", cr.critique(nr, good_plan)["verdict"] == "NEEDS_REFINEMENT")
    check("Q3 flags the unexplored direct dependency", cr.critique(nr, good_plan)["questions"]["prioritized_direct_first"][0] == "CONCERN")

    # an implementation-detail AC -> NEEDS_REFINEMENT (Q4)
    impl_plan = ("**Acceptance Criteria**\n- AC-01 [Confirmed]: (Basic) Given a map | When published | Then null is guarded before PathUtils.appendUnixSlash.\n"
                 "**Open Questions**\n- No open questions from current evidence\n")
    check("Q4 flags an implementation-detail AC", cr.critique(good_manifest, impl_plan)["questions"]["impl_detail_as_ac"][0] == "CONCERN")

    # a diagnostic-only scenario -> Q10 concern
    diag_plan = ("**Acceptance Criteria**\n- AC-01 [Confirmed]: (Basic) Given a map | When published | Then the navigation shows the group.\n"
                 "**Test Scenarios**\n- P0 [AC-01]: publish -> the job completes SUCCESS with no NullPointerException.\n"
                 "**Open Questions**\n- No open questions from current evidence\n")
    check("Q10 flags a diagnostic-only scenario", cr.critique(good_manifest, diag_plan)["questions"]["scenario_oracles"][0] == "CONCERN")

    # a hidden unresolved verdict -> FAIL (Q8 MISSING)
    hidden = dict(good_manifest, verifications=good_manifest["verifications"] + [
        {"hypothesis_id": "H2", "verdict": "UNRESOLVED", "disposition": "OPEN_QUESTION", "open_question_ref": "OQ-9", "insufficient": True}],
        open_questions=[{"id": "OQ-9", "question": "some unresolved item not written into the plan"}])
    check("hidden unresolved decision -> critic FAIL", cr.critique(hidden, good_plan)["verdict"] == "FAIL")

    # bounded repair: at most one repair pass
    check("first repair pass is allowed", cr.can_repair(0) is True)
    check("second repair pass is refused", cr.can_repair(1) is False)
    check("repair_passes over the limit is rejected", any("bounded limit" in p for p in cr.validate_repair_bound({"critic": {"repair_passes": 2}})))
    check("repair_passes within the limit passes", cr.validate_repair_bound({"critic": {"repair_passes": 1}}) == [])


def test_affected_surface() -> None:
    asf = affected_surface_mod

    def block(**o):
        b = {"active": True, "dimensions": [{
            "name": "uuid_conflict_op", "kind": "OPERATION_ENUM", "source": "ImportServlet.java:124",
            "values": ["OVERWRITE", "MOVE"],
            "coverage": {"OVERWRITE": {"disposition": "COVERED", "ac": "AC-02"},
                         "MOVE": {"disposition": "COVERED", "ac": "AC-05"}}}]}
        b.update(o)
        return b

    check("well-formed affected_surface passes",
          asf.validate_affected_surface(block(), ac_ids={"AC-02", "AC-05"}) == [])
    bad = block()
    bad["dimensions"][0]["coverage"].pop("MOVE")
    check("uncovered enum value is rejected",
          any("no coverage entry" in p for p in asf.validate_affected_surface(bad, ac_ids={"AC-02", "AC-05"})))
    noac = block()
    noac["dimensions"][0]["coverage"]["MOVE"] = {"disposition": "COVERED"}
    check("COVERED without an ac is rejected",
          any("names no acceptance criterion" in p for p in asf.validate_affected_surface(noac, ac_ids={"AC-02", "AC-05"})))
    check("ac not defined in the plan is rejected",
          any("not an AC defined" in p for p in asf.validate_affected_surface(block(), ac_ids={"AC-02"})))
    oos = block()
    oos["dimensions"][0]["coverage"]["MOVE"] = {"disposition": "OUT_OF_SCOPE"}
    check("OUT_OF_SCOPE without a reason is rejected",
          any("no reason" in p for p in asf.validate_affected_surface(oos, ac_ids={"AC-02", "AC-05"})))
    oos2 = block()
    oos2["dimensions"][0]["coverage"]["MOVE"] = {"disposition": "OUT_OF_SCOPE", "reason": "name-conflict only"}
    check("OUT_OF_SCOPE with a reason passes",
          asf.validate_affected_surface(oos2, ac_ids={"AC-02", "AC-05"}) == [])
    open_ref = block()
    open_ref["dimensions"][0]["coverage"]["MOVE"] = {
        "disposition": "OPEN_QUESTION", "open_question_ref": "OQ-01"
    }
    check("empty known Open Question set rejects affected-surface reference",
          any("not in the plan's open_questions" in p for p in asf.validate_affected_surface(
              open_ref, ac_ids={"AC-02", "AC-05"}, open_question_ids=[])))
    bk = block()
    bk["dimensions"][0]["kind"] = "STUFF"
    check("invalid dimension kind is rejected",
          any("kind must be one of" in p for p in asf.validate_affected_surface(bk, ac_ids={"AC-02", "AC-05"})))
    check("empty dimensions is rejected",
          any("non-empty list" in p for p in asf.validate_affected_surface({"active": True, "dimensions": []})))
    grounded = {"behaviour_matters": True, "implementation_grounding": {"active": True, "named_artifacts": [
        {"artifact": "k", "kind": "config_key", "inspected": True, "evidence": ["x"], "material": True}]}}
    check("grounded config_key activates affected-surface", asf.is_active(grounded) is True)
    check("no grounding does not activate affected-surface", asf.is_active({"behaviour_matters": True}) is False)


def test_comment_claims() -> None:
    cc = comment_claim_mod

    check("comment_claims absent is not a failure", cc.validate_comment_claims(None) == [])
    check("comment_claims wrong type is rejected", cc.validate_comment_claims({"a": 1}) == ["comment_claims must be a list"])

    def claim(**o):
        base = {"claim": "there is no DB-mode gate here", "comment_source": "author_rca",
                "verification_status": "VERIFIED_FALSE", "evidence_ids": ["E4"]}
        base.update(o)
        return base

    check("well-formed VERIFIED_FALSE claim passes", cc.validate_comment_claims([claim()]) == [])
    check("missing claim text is rejected",
          any("missing 'claim'" in p for p in cc.validate_comment_claims([claim(claim="")])))
    check("invalid comment_source is rejected",
          any("comment_source must be one of" in p for p in cc.validate_comment_claims([claim(comment_source="hearsay")])))
    check("invalid verification_status is rejected",
          any("verification_status must be one of" in p for p in cc.validate_comment_claims([claim(verification_status="PROBABLY")])))
    check("VERIFIED_TRUE without evidence_ids is rejected",
          any("must cite evidence_ids" in p for p in cc.validate_comment_claims([claim(verification_status="VERIFIED_TRUE", evidence_ids=[])])))
    check("UNVERIFIABLE without open_question_ref is rejected",
          any("open_question_ref" in p for p in cc.validate_comment_claims([claim(verification_status="UNVERIFIABLE", evidence_ids=[])])))
    check("UNVERIFIABLE with a known open_question_ref passes",
          cc.validate_comment_claims([claim(verification_status="UNVERIFIABLE", evidence_ids=[], open_question_ref="OQ-1")], open_question_ids=["OQ-1"]) == [])
    check("UNVERIFIABLE with an unknown open_question_ref is rejected",
          any("is not in the plan's open_questions" in p for p in cc.validate_comment_claims(
              [claim(verification_status="UNVERIFIABLE", evidence_ids=[], open_question_ref="OQ-9")], open_question_ids=["OQ-1"])))
    check("empty known Open Question set rejects comment-claim reference",
          any("is not in the plan's open_questions" in p for p in cc.validate_comment_claims(
              [claim(verification_status="UNVERIFIABLE", evidence_ids=[], open_question_ref="OQ-9")],
              open_question_ids=[])))

    hits = cc.likely_claims_in_comments({"issue": {"comments": [{"body": "there is no gate for this in the code today"}]}})
    check("current-behaviour phrasing is detected in comment text", len(hits) == 1)
    check("plain comment text has no hits", cc.likely_claims_in_comments({"issue": {"comments": [{"body": "looks good to me"}]}}) == [])


def test_pr_supersession() -> None:
    prs = pr_supersession_mod

    check("pr_references absent is not a failure", prs.validate_pr_references(None) == [])
    check("single PR needs no reconciliation",
          prs.validate_pr_references([{"pr_ref": "#8098", "status": "AUTHORITATIVE", "comparison_note": "only PR linked"}]) == [])

    two_prs_unreconciled = [
        {"pr_ref": "#8098", "status": "SUPERSEDED"},
        {"pr_ref": "#8135", "status": "SUPERSEDED"},
    ]
    check("two PRs with no AUTHORITATIVE entry is rejected",
          any("does not mark exactly one AUTHORITATIVE" in p for p in prs.validate_pr_references(two_prs_unreconciled)))

    two_prs_ok = [
        {"pr_ref": "#8098", "status": "SUPERSEDED"},
        {"pr_ref": "#8135", "status": "AUTHORITATIVE",
         "comparison_note": "8135 supersedes 8098 with a full V1+V2 fix; diff --stat shows 8098's files as a subset"},
    ]
    check("two PRs with exactly one AUTHORITATIVE + comparison_note passes", prs.validate_pr_references(two_prs_ok) == [])

    authoritative_no_note = [
        {"pr_ref": "#8098", "status": "SUPERSEDED"},
        {"pr_ref": "#8135", "status": "AUTHORITATIVE"},
    ]
    check("AUTHORITATIVE without comparison_note is rejected",
          any("comparison_note" in p for p in prs.validate_pr_references(authoritative_no_note)))

    unresolved_no_oq = [
        {"pr_ref": "#8098", "status": "UNRESOLVED"},
        {"pr_ref": "#8135", "status": "UNRESOLVED"},
    ]
    check("UNRESOLVED without open_question_ref is rejected",
          any("open_question_ref" in p for p in prs.validate_pr_references(unresolved_no_oq)))
    unresolved_with_oq = [
        {"pr_ref": "#8098", "status": "UNRESOLVED", "open_question_ref": "OQ-1"},
        {"pr_ref": "#8135", "status": "UNRESOLVED", "open_question_ref": "OQ-1"},
    ]
    check("all-UNRESOLVED with a known open_question_ref passes",
          prs.validate_pr_references(unresolved_with_oq, open_question_ids=["OQ-1"]) == [])
    check("empty known Open Question set rejects PR reference",
          any("is not in the plan's open_questions" in p for p in
              prs.validate_pr_references(unresolved_with_oq, open_question_ids=[])))
    check("invalid status is rejected",
          any("status must be one of" in p for p in prs.validate_pr_references([{"pr_ref": "#8098", "status": "MERGED"}])))
    check("missing pr_ref is rejected",
          any("missing 'pr_ref'" in p for p in prs.validate_pr_references([{"status": "AUTHORITATIVE", "comparison_note": "x"}])))


def test_concurrency_race() -> None:
    cr = concurrency_race_mod
    good = {
        "schema_version": cr.SCHEMA_VERSION,
        "active": True,
        "triggers": ["Sling job consumer"],
        "patterns": [
            {"pattern": "CREATE_THEN_DELETE_RACE", "disposition": "COVERED_BY_AC", "ac_ref": "AC-01"},
            {"pattern": "RESTART_MID_PROCESSING_RACE", "disposition": "OPEN_QUESTION", "open_question_ref": "OQ-01"},
            {"pattern": "DUPLICATE_EVENT_RACE", "disposition": "OUT_OF_SCOPE", "reason": "The evidence proves exactly-once dispatch."},
        ],
    }
    check(
        "versioned concurrency race contract passes with real references",
        cr.validate_concurrency_race_analysis(
            good, ac_ids={"AC-01"}, open_question_ids={"OQ-01"}
        ) == [],
    )
    check(
        "empty known AC set rejects a concurrency AC reference",
        any(
            "valid ac_ref" in problem
            for problem in cr.validate_concurrency_race_analysis(
                good, ac_ids=set(), open_question_ids={"OQ-01"}
            )
        ),
    )
    check(
        "inactive concurrency contract requires a reason",
        any(
            "reason" in problem
            for problem in cr.validate_concurrency_race_analysis(
                {"schema_version": cr.SCHEMA_VERSION, "active": False}
            )
        ),
    )
    check(
        "event-driven behavior is detected",
        bool(
            cr.likely_event_driven(
                {"behavior_model": {"operations": ["A Sling job consumer updates content"]}}
            )
        ),
    )


def test_enumerated_coverage() -> None:
    ec = enumerated_coverage_mod
    block = {
        "schema_version": ec.SCHEMA_VERSION,
        "active": True,
        "source_ref": "Jira description GUIDES-100",
        "source_item_count": 3,
        "source_complete": True,
        "items": [
            {"id": "REQ-01", "source_index": 1, "text": "First", "disposition": "COVERED_BY_AC", "ac_refs": ["AC-01"]},
            {"id": "REQ-02", "source_index": 2, "text": "Second", "disposition": "OPEN_QUESTION", "open_question_ref": "OQ-01"},
            {"id": "REQ-03", "source_index": 3, "text": "Third", "disposition": "OUT_OF_SCOPE", "reason": "Explicitly excluded by the accepted scope."},
        ],
    }
    check(
        "complete enumerated source disposition passes",
        ec.validate_enumerated_requirements(
            block, ac_ids={"AC-01"}, open_question_ids={"OQ-01"}, detected_count=3
        ) == [],
    )
    check(
        "empty known Open Question set rejects an enumerated reference",
        any(
            "not declared" in problem
            for problem in ec.validate_enumerated_requirements(
                block, ac_ids={"AC-01"}, open_question_ids=set(), detected_count=3
            )
        ),
    )
    incomplete = json.loads(json.dumps(block))
    incomplete["items"].pop()
    check(
        "missing enumerated source item is a hard failure",
        any(
            "source_item_count" in problem
            for problem in ec.validate_enumerated_requirements(
                incomplete, ac_ids={"AC-01"}, open_question_ids={"OQ-01"}, detected_count=3
            )
        ),
    )
    overloaded = json.loads(json.dumps(block))
    overloaded["items"][1] = {
        "id": "REQ-02", "source_index": 2, "text": "Second",
        "disposition": "COVERED_BY_AC", "ac_refs": ["AC-01"],
    }
    check(
        "independent enumerated items cannot silently overload one AC",
        any(
            "shared_contract_justification" in problem
            for problem in ec.validate_enumerated_requirements(
                overloaded, ac_ids={"AC-01"}, open_question_ids=set(), detected_count=3
            )
        ),
    )
    bullet_issue = {"issue": {"description": "- first\n- second\n- third\n- fourth"}}
    check("ordinary Markdown bullets activate enumerated coverage", ec.likely_enumerated(bullet_issue) == 4)
    inactive = {"schema_version": ec.SCHEMA_VERSION, "active": False, "reason": "No list."}
    check(
        "detected source list cannot be bypassed with active false",
        any(
            "cannot be inactive" in problem
            for problem in ec.validate_enumerated_requirements(inactive, detected_count=4)
        ),
    )


def test_source_requirement_fidelity() -> None:
    srf = source_requirement_fidelity_mod
    first = "Friendly names are a user-level setting for the logged-in user."
    second = (
        "The feature supports any valid conditional attribute added to "
        "/libs/fmdita/config/condAttrList.csv."
    )
    raw_text = f"- {first}\n- {second}"
    source_capture = tempfile.TemporaryDirectory()
    source_artifact = Path(source_capture.name).resolve() / "human-feedback.txt"
    source_artifact.write_bytes(raw_text.encode("utf-8"))
    enumerated = {
        "schema_version": "aem-guides-enumerated-requirements-v1",
        "active": True,
        "source_ref": "pasted human feedback",
        "source_item_count": 2,
        "source_complete": True,
        "items": [
            {
                "id": "REQ-01",
                "source_index": 1,
                "text": first,
                "disposition": "COVERED_BY_AC",
                "ac_refs": ["AC-01"],
            },
            {
                "id": "REQ-02",
                "source_index": 2,
                "text": second,
                "disposition": "COVERED_BY_AC",
                "ac_refs": ["AC-02"],
            },
        ],
    }
    source = {
        "id": "SRC-01",
        "type": "human_feedback",
        "locator": "pasted feedback, first list",
        "raw_text": raw_text,
        "sha256": srf.sha256_text(raw_text),
        "artifact_path": str(source_artifact),
        "artifact_sha256": srf.sha256_bytes(source_artifact.read_bytes()),
    }
    ledger = {
        "schema_version": srf.SCHEMA_VERSION,
        "sources": [source],
        "items": [
            {
                "id": "REQ-01",
                "source_id": "SRC-01",
                "source_index": 1,
                "verbatim_text": first,
                "text": first,
                "authority": "Proposed",
                "disposition": "AC",
                "ac_refs": ["AC-01"],
                "semantic_atoms": [
                    {
                        "id": "ATOM-01",
                        "text": first,
                        "required_terms_all": [
                            "Friendly names",
                            "user-level setting",
                            "logged-in user",
                        ],
                    }
                ],
            },
            {
                "id": "REQ-02",
                "source_id": "SRC-01",
                "source_index": 2,
                "verbatim_text": second,
                "text": second,
                "authority": "Proposed",
                "disposition": "AC",
                "ac_refs": ["AC-02"],
                "semantic_atoms": [
                    {
                        "id": "ATOM-02",
                        "text": second,
                        "required_terms_all": [
                            "any valid conditional attribute",
                            "added",
                            "/libs/fmdita/config/condAttrList.csv",
                        ],
                    }
                ],
            },
        ],
    }
    manifest = {
        "accepted_uac_present": False,
        "enumerated_requirements": enumerated,
        "source_requirement_ledger": ledger,
    }
    full_ac_text = {
        "AC-01": "AC-01 [Proposed]: Friendly names are a user-level setting for the logged-in user.",
        "AC-02": (
            "AC-02 [Proposed]: Any valid conditional attribute added to "
            "/libs/fmdita/config/condAttrList.csv is supported."
        ),
    }

    missing = {
        "accepted_uac_present": False,
        "enumerated_requirements": enumerated,
    }
    check(
        "Proposed-only enumerated source still requires the fidelity ledger",
        any(
            "accepted_uac_present is false" in problem
            for problem in srf.validate_manifest(missing)
        ),
    )

    rewritten = json.loads(json.dumps(manifest))
    rewritten_text = "Friendly names use the active folder-profile mapping."
    rewritten["enumerated_requirements"]["items"][0]["text"] = rewritten_text
    rewritten["source_requirement_ledger"]["items"][0]["text"] = rewritten_text
    check(
        "rewritten enumerated text cannot pass beside the original verbatim source",
        any(
            "must exactly equal verbatim_text" in problem
            for problem in srf.validate_manifest(rewritten)
        ),
    )

    invented_atom = json.loads(json.dumps(manifest))
    invented_atom["source_requirement_ledger"]["items"][0]["semantic_atoms"][0][
        "text"
    ] = "tenant-level setting"
    check(
        "invented semantic atom text is rejected",
        any(
            "atom" in problem and "exact substring" in problem
            for problem in srf.validate_manifest(invented_atom)
        ),
    )

    omitted_scope_atom = json.loads(json.dumps(manifest))
    omitted_scope_atom["source_requirement_ledger"]["items"][0]["semantic_atoms"] = [
        {
            "id": "ATOM-01",
            "text": "Friendly names",
            "required_terms_all": ["Friendly names"],
        }
    ]
    check(
        "automatic scope protection blocks user-level loss even when its atom is omitted",
        any(
            "user-level" in problem and "protected exact" in problem
            for problem in srf.validate_manifest(
                omitted_scope_atom,
                ac_text_by_id={
                    "AC-01": "Friendly names use the active folder-profile mapping.",
                    "AC-02": full_ac_text["AC-02"],
                },
                open_question_text_by_id={},
            )
        ),
    )
    protected_scope, protected_scope_problems = srf._protected_exact(
        "Keep the per-user value and workspace-level fallback.", None
    )
    check(
        "automatic scope protection recognizes per-user and hyphenated level terms",
        protected_scope_problems == []
        and "per-user" in protected_scope
        and "workspace-level" in protected_scope,
    )

    substitution_failures = srf.validate_manifest(
        manifest,
        ac_text_by_id={
            "AC-01": "Friendly names use the active folder-profile mapping.",
            "AC-02": full_ac_text["AC-02"],
        },
        open_question_text_by_id={},
    )
    check(
        "user-level to folder-profile substitution fails semantic fidelity",
        any("logged-in user" in problem for problem in substitution_failures),
    )

    conflict_manifest = json.loads(json.dumps(manifest))
    conflict_atom = conflict_manifest["source_requirement_ledger"]["items"][0][
        "semantic_atoms"
    ][0]
    conflict_atom["evidence_conflict"] = True
    conflict_atom["open_question_ref"] = "OQ-01"
    check(
        "an evidence conflict passes only when a real Open Question preserves the atom",
        srf.validate_manifest(
            conflict_manifest,
            ac_text_by_id=full_ac_text,
            open_question_text_by_id={
                "OQ-01": (
                    "Are friendly names a user-level setting for the logged-in user or the active "
                    "folder profile? QA impact: the answer changes user-isolation coverage."
                )
            },
        )
        == [],
    )

    path_failures = srf.validate_manifest(
        manifest,
        ac_text_by_id={
            "AC-01": full_ac_text["AC-01"],
            "AC-02": "Any valid conditional attribute is supported.",
        },
        open_question_text_by_id={},
    )
    check(
        "dropping an exact configuration path fails fidelity",
        any(
            "/libs/fmdita/config/condAttrList.csv" in problem
            for problem in path_failures
        ),
    )

    bad_hash = json.loads(json.dumps(manifest))
    bad_hash["source_requirement_ledger"]["sources"][0]["sha256"] = "0" * 64
    check(
        "source raw-text hash mismatch fails closed",
        any("does not match" in problem for problem in srf.validate_manifest(bad_hash)),
    )

    check(
        "complete Proposed source ledger passes independently of acceptance authority",
        srf.validate_manifest(
            manifest,
            ac_text_by_id=full_ac_text,
            open_question_text_by_id={},
        )
        == [],
    )

    skill_root = Path(__file__).resolve().parents[1]
    skill_text = (skill_root / "SKILL.md").read_text(encoding="utf-8")
    checklist_text = (
        skill_root / "references" / "quality-gate-checklist.md"
    ).read_text(encoding="utf-8")
    for marker in (
        "aem-guides-source-requirement-ledger-v1",
        "source_requirement_ledger",
        "accepted_uac_present=false",
    ):
        check(f"skill retains source-fidelity marker {marker}", marker in skill_text)
    check(
        "quality checklist requires source requirement fidelity",
        "Every active enumerated requirement list has a hash-bound source requirement ledger"
        in checklist_text,
    )


def test_ac_decidability() -> None:
    ad = ac_decidability_mod

    def plan(then: str, *, given: str = "an operational run", when: str = "the worker executes", evidence: str = "Jira description GUIDES-100") -> str:
        return (
            "**Acceptance Criteria**\n"
            f"- AC-01 [Proposed]: (Negative) Given {given} | When {when} | Then {then} | Evidence: {evidence}.\n"
            "**Expected Behaviour**\n- The criterion is deterministic.\n"
        )

    failures, notes = ad.evaluate_plan(plan("the limit is applied once agreed"))
    check("unresolved decision marker is a hard AC failure", bool(failures) and notes == [])
    failures, _ = ad.evaluate_plan(plan("after 2 retries the total logs remain bounded"))
    check("unrelated retry number does not make a vague log bound measurable", bool(failures))
    failures, _ = ad.evaluate_plan(plan("the total error log is bounded to 3 entries"))
    check("explicitly bound outcome is decidable", failures == [])
    failures, _ = ad.evaluate_plan(plan("the implementation uses an index, keyset paging, or a custom index"))
    check("implementation-choice menu is a hard AC failure", any("alternative mechanisms" in item for item in failures))
    failures, _ = ad.evaluate_plan(plan("the run reports a failed or aborted result"))
    check("ambiguous terminal result is a hard AC failure", any("ambiguous terminal" in item for item in failures))
    failures, _ = ad.evaluate_plan(plan("the worker does not continue forever"))
    check("non-finite negative is a hard AC failure", any("non-finite" in item for item in failures))
    failures, _ = ad.evaluate_plan(
        plan(
            "the run reports failure",
            evidence="Jira comment says the implementation choice is to be decided GUIDES-100",
        )
    )
    check("unresolved prose in Evidence does not poison parsed behavior fields", failures == [])


def test_operational_contract() -> None:
    oc = operational_contract_mod
    dimensions = [
        {
            "dimension": dimension,
            "disposition": "OUT_OF_SCOPE",
            "reason": f"Evidence-backed exclusion for {dimension}.",
        }
        for dimension in oc.REQUIRED_DIMENSIONS
    ]
    block = {
        "schema_version": oc.SCHEMA_VERSION,
        "active": True,
        "reason": "The issue concerns a restart-sensitive background job.",
        "dimensions": dimensions,
    }
    check(
        "complete operational contract passes",
        oc.validate_operational_contract(
            block, ac_ids=set(), open_question_ids=set(), scenario_ids=set()
        ) == [],
    )
    missing_shutdown = json.loads(json.dumps(block))
    missing_shutdown["dimensions"] = [
        item for item in missing_shutdown["dimensions"]
        if item["dimension"] != "SHUTDOWN_TERMINAL_OUTCOME"
    ]
    check(
        "shutdown must be dispositioned separately from cancellation",
        any(
            "SHUTDOWN_TERMINAL_OUTCOME" in problem
            for problem in oc.validate_operational_contract(
                missing_shutdown, ac_ids=set(), open_question_ids=set(), scenario_ids=set()
            )
        ),
    )
    referenced = json.loads(json.dumps(block))
    referenced["dimensions"][0] = {
        "dimension": "TRIGGER_AND_DEPLOYMENT_SCOPE",
        "disposition": "COVERED_BY_AC",
        "ac_refs": ["AC-99"],
    }
    check(
        "empty AC set rejects invented operational references",
        any(
            "AC-99" in problem
            for problem in oc.validate_operational_contract(
                referenced, ac_ids=set(), open_question_ids=set(), scenario_ids=set()
            )
        ),
    )
    signalled = {"issue": {"description": "A Sling job retries after a partial write."}}
    check(
        "strong operational signal requires the contract",
        any("required" in problem for problem in oc.validate_manifest(signalled)),
    )
    signalled["operational_contract"] = {
        "schema_version": oc.SCHEMA_VERSION,
        "active": False,
        "reason": "Claimed non-operational.",
    }
    check(
        "operational signal cannot be bypassed by active false",
        any("cannot be false" in problem for problem in oc.validate_manifest(signalled)),
    )
    config_activation = {
        "issue": {
            "description": (
                "The supported configuration activation boundary may require "
                "a profile reselect, cache refresh, or service restart."
            )
        },
        "operational_contract": {
            "schema_version": oc.SCHEMA_VERSION,
            "active": False,
            "reason": "This is synchronous configuration activation, not recurring work.",
        },
    }
    check(
        "configuration activation restart does not imply an async operational contract",
        oc.likely_operational(config_activation) == []
        and not any(
            "cannot be false" in problem
            for problem in oc.validate_manifest(config_activation)
        ),
    )
    restart_job = {
        "issue": {
            "description": "A background job must recover after a service restart."
        }
    }
    check(
        "restart remains operational when recurring job evidence is present",
        "restart" in oc.likely_operational(restart_job),
    )


def test_skill_bundle_fingerprint() -> None:
    fp = skill_fingerprint_mod
    repo_root = _find_repo_root()
    if repo_root is None:
        print("test_skill_bundle_fingerprint: SKIP (standalone/teammate install, no full repo)")
        return
    canonical_root = repo_root / ".codex" / "skills" / "test-plan-generation"
    sync_destinations = (
        ("repository Claude", repo_root / ".claude" / "skills" / "test-plan-generation"),
        ("repository public", repo_root / "skills" / "test-plan-generation"),
        (
            "Windows bundle",
            repo_root / "release-artifacts" / "aem-guides-mcp-client-windows"
            / ".claude" / "skills" / "test-plan-generation",
        ),
        (
            "Unix bundle",
            repo_root / "release-artifacts" / "aem-guides-mcp-client-unix"
            / ".claude" / "skills" / "test-plan-generation",
        ),
        ("global Claude", Path.home() / ".claude" / "skills" / "test-plan-generation"),
        ("global Codex", Path.home() / ".codex" / "skills" / "test-plan-generation"),
    )
    check(
        "sync contract covers seven canonical and executing copies",
        len(sync_destinations) + 1 == 7,
    )

    enforced = fp.enforced_relative_paths(canonical_root)
    check("fingerprint has a non-empty enforced file set", bool(enforced))
    for relative in fp.CODEX_ONLY_EXTENSIONS:
        check(
            f"Codex-only file is excluded from cross-copy fingerprint: {relative}",
            relative not in enforced,
        )
    canonical_record = fp.fingerprint(canonical_root)
    check(
        "fingerprint exposes one hash per enforced file",
        canonical_record["file_count"] == len(enforced)
        and len(canonical_record["files"]) == len(enforced),
    )

    for label, copy_root in sync_destinations:
        ok, drifted = fp.verify(copy_root)
        check(f"{label} enforced fingerprint matches canonical", ok and drifted == [])

    with tempfile.TemporaryDirectory() as tmp:
        injected_copy = Path(tmp) / "test-plan-generation"
        for relative in enforced:
            source = canonical_root / Path(relative)
            target = injected_copy / Path(relative)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)

        ok, drifted = fp.verify(injected_copy)
        check("fresh enforced-file copy verifies", ok and drifted == [])

        drift_relative = "scripts/run_gates.py"
        drift_path = injected_copy / Path(drift_relative)
        drift_path.write_bytes(drift_path.read_bytes() + b"\n# injected fingerprint drift\n")
        ok, drifted = fp.verify(injected_copy)
        check(
            "injected drift is detected by relative file name",
            not ok and drifted == [drift_relative],
        )

        gate = _load("run_gates_for_drift_test", "run_gates.py")
        notes = gate.check_executing_copy_drift(injected_copy)
        check(
            "run_gates emits the required executing-copy REVIEW note",
            len(notes) == 1
            and notes[0].startswith("REVIEW EXECUTING COPY DRIFT:")
            and drift_relative in notes[0],
        )
        check(
            "executing-copy drift makes a receipt non-postable without a gate failure",
            gate._postability_review_present(notes),
        )

    print("test_skill_bundle_fingerprint: OK")


def test_gate_receipt_and_adapter() -> None:
    gate = _load("run_gates_for_receipt_test", "run_gates.py")
    adapter = _load("canonical_runtime_adapter_for_test", "canonical_runtime_adapter.py")
    check(
        "readability REVIEW prevents a postable receipt",
        gate._postability_review_present(
            ["REVIEW ac-readability: AC-01 too long; split into short sentences"]
        ),
    )
    check(
        "scope-authority REVIEW prevents a postable receipt",
        gate._postability_review_present(
            ["REVIEW scope-authority: implementation-only evidence found for AC-01"]
        ),
    )
    check(
        "semantic advisory notes also block posting",
        gate._postability_review_present(["REVIEW feature-classification: inspect"]),
    )
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        plan = root / "plan.md"
        combined = root / "combined.md"
        manifest = root / "manifest.json"
        receipt = root / "gate-receipt.json"
        fake_skill = root / "skill"
        (fake_skill / "scripts").mkdir(parents=True)
        (fake_skill / "SKILL.md").write_text("---\nname: test\n---\n", encoding="utf-8")
        (fake_skill / "scripts" / "gate.py").write_text("PASS = True\n", encoding="utf-8")
        plan.write_text(GOOD_PLAN, encoding="utf-8")
        combined.write_text(GOOD_PLAN, encoding="utf-8")
        manifest.write_text(json.dumps({"issue": "GUIDES-100"}), encoding="utf-8")
        gate.write_gate_receipt(
            receipt_path=str(receipt),
            plan_path=str(plan),
            combined_path=str(combined),
            manifest_path=str(manifest),
            passed=True,
            postable=True,
            skill_root=fake_skill,
        )
        adapter.verify_receipt(
            receipt,
            jira_key="GUIDES-100",
            plan_path=plan,
            manifest_path=manifest,
            skill_root=fake_skill,
        )
        check("hash-bound receipt authorizes the exact current artifacts", True)

        plan.write_text(GOOD_PLAN + "\n", encoding="utf-8")
        try:
            adapter.verify_receipt(
                receipt,
                jira_key="GUIDES-100",
                plan_path=plan,
                manifest_path=manifest,
                skill_root=fake_skill,
            )
        except ValueError as exc:
            check("stale receipt is rejected after plan mutation", "hash mismatch" in str(exc))
        else:
            check("stale receipt is rejected after plan mutation", False)

        plan.write_text(GOOD_PLAN, encoding="utf-8")
        (fake_skill / "scripts" / "gate.py").write_text("PASS = False\n", encoding="utf-8")
        try:
            adapter.verify_receipt(
                receipt,
                jira_key="GUIDES-100",
                plan_path=plan,
                manifest_path=manifest,
                skill_root=fake_skill,
            )
        except ValueError as exc:
            check(
                "stale receipt is rejected after validator mutation",
                "validator fingerprint hash mismatch" in str(exc),
            )
        else:
            check("stale receipt is rejected after validator mutation", False)

        (fake_skill / "scripts" / "gate.py").write_text("PASS = True\n", encoding="utf-8")
        gate.write_gate_receipt(
            receipt_path=str(receipt),
            plan_path=str(plan),
            combined_path=str(combined),
            manifest_path=str(manifest),
            passed=True,
            postable=False,
            skill_root=fake_skill,
        )
        try:
            adapter.verify_receipt(
                receipt,
                jira_key="GUIDES-100",
                plan_path=plan,
                manifest_path=manifest,
                skill_root=fake_skill,
            )
        except ValueError as exc:
            check("skip-self-test style non-postable receipt is rejected", "postable" in str(exc))
        else:
            check("skip-self-test style non-postable receipt is rejected", False)


def test_remote_approved_pattern_resolver() -> None:
    adapter = _load(
        "canonical_runtime_adapter_for_remote_resolver_test",
        "canonical_runtime_adapter.py",
    )

    class Mode:
        DISABLED = "DISABLED"
        SHADOW = "SHADOW"
        ENABLED = "ENABLED"

    class Envelope:
        def __init__(self, **values):
            self.__dict__.update(values)

    class Baseline:
        def __init__(self, marker="LOCAL_TRAIN", shared_learning=None):
            self.marker = marker
            self.shared_learning = shared_learning

        def model_copy(self, *, update):
            return Baseline(self.marker, update.get("shared_learning"))

    class BaselineResolver:
        def resolve(self, request):
            return Baseline()

    remote_envelope = Envelope(
        mode=Mode.ENABLED,
        status="SUCCESS",
        publication_id="a" * 64,
        pattern_count=2,
        matched_patterns=[
            SimpleNamespace(pattern=SimpleNamespace(pattern_id="SHARED_" + "A" * 32))
        ],
        suppressed_patterns=[SimpleNamespace(pattern_id="SHARED_" + "B" * 32)],
        shadow_pattern_ids=[],
        shadow_suppressed_pattern_ids=[],
        authoring_guidance=[SimpleNamespace(lesson_id="lesson-language")],
        shadow_authoring_guidance_ids=[],
        excluded_pattern_counts={"CURRENT_CASE": 1},
        warnings=[],
        error_code=None,
    )

    class ResponseModel:
        @classmethod
        def model_validate(cls, value):
            check("remote resolver received JSON object", isinstance(value, dict))
            return SimpleNamespace(
                marker="REMOTE_BASELINE_MUST_NOT_REPLACE_LOCAL",
                shared_learning=remote_envelope,
            )

    class Response:
        def __enter__(self):
            return self

        def __exit__(self, *args):
            return False

        def read(self, _limit):
            return b'{"remote": true}'

    class Opener:
        def __init__(self):
            self.calls = []

        def open(self, request, timeout):
            self.calls.append((request, timeout))
            return Response()

    class Request:
        def model_dump(self, *, mode):
            check("remote resolver serializes canonical request as JSON", mode == "json")
            return {"domain": "Publishing", "current_jira_key": "PROJECT-123"}

    opener = Opener()
    resolver = adapter.RemoteApprovedPatternResolver(
        baseline_resolver=BaselineResolver(),
        response_model=ResponseModel,
        envelope_model=Envelope,
        mode_enum=Mode,
        tenant_id="kone",
        base_url="http://127.0.0.1:4502",
        token="personal-test-token",
        opener=opener,
    )
    previous_mode = os.environ.get("SHARED_UAC_LEARNING_MODE")
    try:
        os.environ["SHARED_UAC_LEARNING_MODE"] = "SHADOW"
        result = resolver.resolve_for_runtime(
            Request(),
            SimpleNamespace(
                tenant_id="kone",
                cutoff_at=None,
                excluded_source_case_ids={"PROJECT-123"},
                benchmark_isolation=False,
                mode=Mode.SHADOW,
            ),
        )
        check("local TRAIN baseline survives remote lookup", result.marker == "LOCAL_TRAIN")
        check("local shadow ceiling strips remote influence", result.shared_learning.mode == Mode.SHADOW)
        check("shadow ceiling removes shared matches", result.shared_learning.matched_patterns == [])
        check("shadow ceiling removes authoring guidance", result.shared_learning.authoring_guidance == [])
        check(
            "shadow ceiling preserves trace-only shared pattern IDs",
            result.shared_learning.shadow_pattern_ids == ["SHARED_" + "A" * 32],
        )
        check(
            "shadow ceiling preserves trace-only guidance IDs",
            result.shared_learning.shadow_authoring_guidance_ids == ["lesson-language"],
        )
        check("remote shared resolver called once", len(opener.calls) == 1)
        request_url = opener.calls[0][0].full_url
        check("remote resolver passes tenant context", "tenant_id=kone" in request_url)
        check(
            "remote resolver passes current-case exclusion",
            "excluded_source_case_ids=PROJECT-123" in request_url,
        )

        os.environ["SHARED_UAC_LEARNING_MODE"] = "ENABLED"
        enabled = resolver.resolve_for_runtime(
            Request(),
            SimpleNamespace(
                tenant_id="kone",
                cutoff_at=None,
                excluded_source_case_ids={"PROJECT-123"},
                benchmark_isolation=False,
                mode=Mode.ENABLED,
            ),
        )
        check("explicit enabled mode retains server-authorized envelope", enabled.shared_learning is remote_envelope)
        check("enabled shared resolver made a second call", len(opener.calls) == 2)

        legacy = resolver.resolve(Request())
        check("contextless resolver keeps local baseline", legacy.marker == "LOCAL_TRAIN")
        check("contextless resolver disables shared lookup", legacy.shared_learning.status == "DISABLED")
        check("contextless resolver makes no remote call", len(opener.calls) == 2)

        os.environ["SHARED_UAC_LEARNING_MODE"] = "DISABLED"
        disabled = resolver.resolve_for_runtime(
            Request(), SimpleNamespace(benchmark_isolation=False, mode=Mode.SHADOW)
        )
        check("local client disable skips remote lookup", len(opener.calls) == 2)
        check("disabled shared envelope is explicit", disabled.shared_learning.status == "DISABLED")

        os.environ["SHARED_UAC_LEARNING_MODE"] = "SHADOW"
        benchmark = resolver.resolve_for_runtime(
            Request(), SimpleNamespace(benchmark_isolation=True, mode=Mode.SHADOW)
        )
        check("benchmark isolation skips remote shared learning", len(opener.calls) == 2)
        check("benchmark shared envelope is disabled", benchmark.shared_learning.status == "DISABLED")

        missing_token = adapter.RemoteApprovedPatternResolver(
            baseline_resolver=BaselineResolver(),
            response_model=ResponseModel,
            envelope_model=Envelope,
            mode_enum=Mode,
            tenant_id="kone",
            base_url="http://127.0.0.1:4502",
            token="dev-bypass",
            opener=opener,
        ).resolve_for_runtime(
            Request(), SimpleNamespace(benchmark_isolation=False, mode=Mode.SHADOW)
        )
        check("shared lookup needs personal token", missing_token.shared_learning.status == "UNAVAILABLE")
        check("missing personal token preserves local baseline", missing_token.marker == "LOCAL_TRAIN")
        check("credential failure does not call remote", len(opener.calls) == 2)
    finally:
        if previous_mode is None:
            os.environ.pop("SHARED_UAC_LEARNING_MODE", None)
        else:
            os.environ["SHARED_UAC_LEARNING_MODE"] = previous_mode

    print("test_remote_approved_pattern_resolver: OK")


def _ui_scope_fixture():
    surfaces = [
        "Full Tags View",
        "Condition Attributes panel",
        "Right Panel",
        "condition presets",
        "DITAVAL attribute dropdown",
        "Preview",
    ]
    return {
        "schema_version": "aem-guides-ui-surface-scope-v1",
        "construct_type": "attribute-label",
        "render_surfaces": [
            {"surface": surface, "disposition": "COVERED_BY_AC", "ac_ref": "AC-01"}
            for surface in surfaces
        ],
        "config_scope": {
            "scope": "USER",
            "disposition": "COVERED_BY_AC",
            "ac_ref": "AC-01",
        },
        "upgrade_persistence": {
            "disposition": "COVERED_BY_AC",
            "ac_ref": "AC-01",
        },
        "sibling_regression": {
            "disposition": "COVERED_BY_AC",
            "sibling_construct": "element-label",
            "ac_ref": "AC-01",
        },
        "surfaces_grounding": ["C:/repo/rendering.ts:42"],
    }


def test_feature_class_registry() -> None:
    registry = feature_class_mod
    failures, notes = registry.validate_feature_classification(
        {"issue": {"summary": "ordinary content change"}},
        "ordinary content change",
        ac_ids={"AC-01"},
        open_question_ids=set(),
    )
    check("feature registry cleanly skips without signals", failures == [] and notes == [])

    failures, notes = registry.validate_feature_classification(
        {},
        "A friendly name is shown as a label in workspace settings.",
        ac_ids={"AC-01"},
        open_question_ids=set(),
    )
    check(
        "detected feature class without declaration is REVIEW only",
        failures == [] and any("REVIEW" in note for note in notes),
    )

    missing_dimension = {
        "feature_classification": {
            "schema_version": "aem-guides-feature-classification-v1",
            "classes": ["ui_display_label"],
            "rationale": "The change controls a rendered label.",
            "evidence": ["C:/repo/rendering.ts:42"],
        }
    }
    failures, _ = registry.validate_feature_classification(
        missing_dimension,
        "friendly name label",
        ac_ids={"AC-01"},
        open_question_ids=set(),
    )
    check(
        "declared feature class requires its dimension block",
        any("ui_surface_scope" in problem for problem in failures),
    )

    complete = dict(missing_dimension)
    complete["ui_surface_scope"] = _ui_scope_fixture()
    failures, _ = registry.validate_feature_classification(
        complete,
        "friendly name label",
        ac_ids={"AC-01"},
        open_question_ids=set(),
    )
    check("complete feature class contract passes", failures == [])
    check(
        "every registry dimension has a validator",
        all(
            dimension in registry.DIMENSION_VALIDATORS
            for config in registry.REGISTRY.values()
            for dimension in config["required_dimensions"]
        ),
    )
    check(
        "seeded class-to-dimension mappings stay exact",
        {
            name: config["required_dimensions"]
            for name, config in registry.REGISTRY.items()
        }
        == {
            "ui_display_label": ["ui_surface_scope"],
            "access_control": ["role_provisioning"],
            "async_job": ["concurrency_race_analysis", "terminal_states"],
            "configuration_driven_enumeration": [
                "configuration_enumeration_scope",
            ],
            "generated_artifact_delivery": ["generated_output_contract"],
            "content_identity_lifecycle": ["content_identity_contract"],
        },
    )
    for class_name, signal in (
        ("ui_display_label", "friendly name"),
        ("access_control", "authorization"),
        ("async_job", "sling job"),
        ("configuration_driven_enumeration", "configured attribute"),
        ("generated_artifact_delivery", "download archive"),
        ("content_identity_lifecycle", "latest asset"),
    ):
        check(
            f"registry detects {class_name} from a seeded signal",
            class_name in registry.classify({}, signal),
        )
    check(
        "registry detects plural and inflected UI display-label signals",
        "ui_display_label"
        in registry.classify({}, "Friendly Names are Displayed in the editor."),
    )
    check(
        "ordinary grouping language does not imply access control",
        "access_control"
        not in registry.classify({}, "Group captured log entries by job and map."),
    )
    self_describing_manifest = {
        "operational_contract": {
            "active": False,
            "reason": "This does not change a Sling job or queue.",
        },
        "construct_relationships": {
            "cross_dimensions": {
                "PERMISSIONS": {
                    "applicable": False,
                    "reason": "No authorization branch changes.",
                }
            }
        },
    }
    check(
        "validator decision text cannot self-activate a feature class",
        registry.classify(self_describing_manifest, "A duplicate log entry is removed.")
        == [],
    )


def test_configuration_enumeration_scope() -> None:
    failures = configuration_enumeration_mod.run_self_tests()
    check("configuration enumeration dimensions self-test", failures == [])


def test_relationship_traversal() -> None:
    relationship_traversal_mod.run_self_tests()
    check("relationship traversal umbrella self-test", True)


def test_ui_surface_scope() -> None:
    ui = ui_surface_scope_mod
    good = _ui_scope_fixture()
    failures, _ = ui.validate_ui_surface_scope(
        good, ac_ids={"AC-01"}, open_question_ids=set()
    )
    check("catalog-complete UI surface scope passes", failures == [])

    missing = dict(good)
    missing["render_surfaces"] = good["render_surfaces"][:-1]
    failures, _ = ui.validate_ui_surface_scope(
        missing, ac_ids={"AC-01"}, open_question_ids=set()
    )
    check(
        "missed catalog surface is a hard failure",
        any("Preview" in problem for problem in failures),
    )

    unknown = dict(good)
    unknown["construct_type"] = "new-construct"
    unknown["render_surfaces"] = [good["render_surfaces"][0]]
    failures, notes = ui.validate_ui_surface_scope(
        unknown, ac_ids={"AC-01"}, open_question_ids=set()
    )
    check(
        "unknown construct requests catalog review without failing",
        failures == [] and any("REVIEW" in note for note in notes),
    )

    bad_ref = _ui_scope_fixture()
    bad_ref["render_surfaces"] = [dict(item) for item in bad_ref["render_surfaces"]]
    bad_ref["render_surfaces"][0]["ac_ref"] = "AC-99"
    failures, _ = ui.validate_ui_surface_scope(
        bad_ref, ac_ids={"AC-01"}, open_question_ids=set()
    )
    check("UI surface scope rejects unknown AC references", bool(failures))

    jira_only_grounding = _ui_scope_fixture()
    jira_only_grounding["surfaces_grounding"] = ["Jira: GUIDES-49507"]
    failures, _ = ui.validate_ui_surface_scope(
        jira_only_grounding, ac_ids={"AC-01"}, open_question_ids=set()
    )
    check(
        "UI surface scope rejects Jira-only rendering grounding",
        any("surfaces_grounding" in problem for problem in failures),
    )

    with tempfile.TemporaryDirectory() as directory:
        catalog = Path(directory) / "catalog.json"
        catalog.write_text("{}\n", encoding="utf-8")
        added = ui.add_catalog_surface("topic-title", "Map Preview", catalog_path=catalog)
        repeated = ui.add_catalog_surface("topic-title", "map preview", catalog_path=catalog)
        check("catalog helper is append-only and idempotent", added is True and repeated is False)


def _role_fixture():
    return {
        "schema_version": "aem-guides-role-provisioning-v1",
        "actors": [
            {
                "actor_id": "delegated-admin",
                "label": "delegated admin user",
                "privilege_class": "DELEGATED",
                "grant_groups": ["profile-admins"],
                "withhold_groups": ["system-admins"],
                "auto_added_groups": ["profile-members"],
                "grounding": ["C:/repo/auth.java:20"],
                "maps_to_acs": ["AC-01"],
            },
            {
                "actor_id": "local-administrator",
                "label": "local administrator",
                "privilege_class": "FULL_ADMIN",
                "grant_groups": ["administrators"],
                "withhold_groups": [],
                "auto_added_groups": "none",
                "grounding": ["C:/repo/auth.java:21"],
                "maps_to_acs": ["AC-02"],
            },
            {
                "actor_id": "unauthorized-user",
                "label": "unauthorized user",
                "privilege_class": "NON_ADMIN",
                "grant_groups": ["authors"],
                "withhold_groups": ["profile-admins", "system-admins"],
                "auto_added_groups": "none",
                "grounding": ["C:/repo/auth.java:22"],
                "maps_to_acs": ["AC-03"],
            },
        ],
    }


def test_role_provisioning() -> None:
    roles = role_provisioning_mod
    plan = "\n".join(
        [
            "- AC-01 [Proposed]: (Basic) Given a delegated admin user | When access changes | Then the change persists | Evidence: code.",
            "- AC-02 [Proposed]: (Basic) Given a member of administrators group | When access changes | Then the change persists | Evidence: code.",
            "- AC-03 [Proposed]: (Negative) Given an unauthorized user | When access changes | Then access is denied | Evidence: code.",
        ]
    )
    good = _role_fixture()
    failures = roles.validate_role_provisioning(
        good, ac_ids={"AC-01", "AC-02", "AC-03"}, plan_text=plan
    )
    check("grounded three-actor provisioning matrix passes", failures == [])

    missing_privilege = _role_fixture()
    missing_privilege["actors"] = [dict(actor) for actor in missing_privilege["actors"]]
    missing_privilege["actors"][0].pop("privilege_class")
    failures = roles.validate_role_provisioning(
        missing_privilege, ac_ids={"AC-01", "AC-02", "AC-03"}, plan_text=plan
    )
    check(
        "actor requires an explicit privilege class",
        any("privilege_class" in problem for problem in failures),
    )

    invalid_privilege = _role_fixture()
    invalid_privilege["actors"] = [dict(actor) for actor in invalid_privilege["actors"]]
    invalid_privilege["actors"][0]["privilege_class"] = "SUPER_ADMIN"
    failures = roles.validate_role_provisioning(
        invalid_privilege, ac_ids={"AC-01", "AC-02", "AC-03"}, plan_text=plan
    )
    check(
        "actor rejects an unknown privilege class",
        any("privilege_class" in problem for problem in failures),
    )

    bad_grounding = _role_fixture()
    bad_grounding["actors"] = [dict(actor) for actor in bad_grounding["actors"]]
    bad_grounding["actors"][0]["grounding"] = ["implementation says so"]
    failures = roles.validate_role_provisioning(
        bad_grounding, ac_ids={"AC-01", "AC-02", "AC-03"}, plan_text=plan
    )
    check(
        "actor grounding requires a checkable citation",
        any("grounding" in problem for problem in failures),
    )

    jira_only_grounding = _role_fixture()
    jira_only_grounding["actors"] = [
        dict(actor) for actor in jira_only_grounding["actors"]
    ]
    jira_only_grounding["actors"][0]["grounding"] = ["Jira: GUIDES-50144"]
    failures = roles.validate_role_provisioning(
        jira_only_grounding, ac_ids={"AC-01", "AC-02", "AC-03"}, plan_text=plan
    )
    check(
        "actor grounding rejects a Jira-only citation",
        any("grounding" in problem for problem in failures),
    )

    missing_withhold = _role_fixture()
    missing_withhold["actors"] = [dict(actor) for actor in missing_withhold["actors"]]
    missing_withhold["actors"][0]["withhold_groups"] = []
    failures = roles.validate_role_provisioning(
        missing_withhold, ac_ids={"AC-01", "AC-02", "AC-03"}, plan_text=plan
    )
    check(
        "delegated actor requires withheld groups",
        any("withhold_groups" in problem for problem in failures),
    )

    non_admin_without_withhold = _role_fixture()
    non_admin_without_withhold["actors"] = [
        dict(actor) for actor in non_admin_without_withhold["actors"]
    ]
    non_admin_without_withhold["actors"][2]["withhold_groups"] = []
    failures = roles.validate_role_provisioning(
        non_admin_without_withhold,
        ac_ids={"AC-01", "AC-02", "AC-03"},
        plan_text=plan,
    )
    check(
        "non-admin actor requires withheld groups",
        any("withhold_groups" in problem for problem in failures),
    )

    missing_auto = _role_fixture()
    missing_auto["actors"] = [dict(actor) for actor in missing_auto["actors"]]
    missing_auto["actors"][2].pop("auto_added_groups")
    failures = roles.validate_role_provisioning(
        missing_auto, ac_ids={"AC-01", "AC-02", "AC-03"}, plan_text=plan
    )
    check(
        "actor requires explicit auto-added group disposition",
        any("auto_added_groups" in problem for problem in failures),
    )

    empty_auto = _role_fixture()
    empty_auto["actors"] = [dict(actor) for actor in empty_auto["actors"]]
    empty_auto["actors"][1]["auto_added_groups"] = []
    failures = roles.validate_role_provisioning(
        empty_auto, ac_ids={"AC-01", "AC-02", "AC-03"}, plan_text=plan
    )
    check(
        "no automatic group uses explicit none instead of an empty list",
        any("auto_added_groups" in problem for problem in failures),
    )

    unmapped = _role_fixture()
    unmapped["actors"] = [dict(actor) for actor in unmapped["actors"]]
    unmapped["actors"][0]["maps_to_acs"] = ["AC-02"]
    failures = roles.validate_role_provisioning(
        unmapped, ac_ids={"AC-01", "AC-02", "AC-03"}, plan_text=plan
    )
    check(
        "actor named by an AC must map back to that AC",
        any("AC-01" in problem for problem in failures),
    )

    contributor_plan = (
        "- AC-04 [Proposed]: (Negative) Given a contributor | When access changes | "
        "Then access is denied | Evidence: code."
    )
    failures = roles.validate_role_provisioning(
        _role_fixture(),
        ac_ids={"AC-01", "AC-02", "AC-03", "AC-04"},
        plan_text=contributor_plan,
    )
    check(
        "generic contributor actor cannot bypass the provisioning matrix",
        any("AC-04 has no role_provisioning actor" in problem for problem in failures),
    )


def test_terminal_states() -> None:
    terminal = terminal_states_mod
    good = {
        "schema_version": "aem-guides-terminal-states-v1",
        "states": [
            {"state": state, "disposition": "COVERED_BY_AC", "ac_ref": "AC-01"}
            for state in terminal.REQUIRED_STATES
        ],
    }
    check(
        "all terminal states with valid references pass",
        terminal.validate_terminal_states(good, ac_ids={"AC-01"}, open_question_ids=set()) == [],
    )
    missing = dict(good)
    missing["states"] = good["states"][:-1]
    check(
        "missing terminal state fails",
        any(
            "retry_exhausted" in problem
            for problem in terminal.validate_terminal_states(
                missing, ac_ids={"AC-01"}, open_question_ids=set()
            )
        ),
    )
    invalid = dict(good)
    invalid["states"] = [dict(item) for item in good["states"]]
    invalid["states"][0]["ac_ref"] = "AC-99"
    check(
        "terminal state rejects unknown AC reference",
        bool(
            terminal.validate_terminal_states(
                invalid, ac_ids={"AC-01"}, open_question_ids=set()
            )
        ),
    )


def _publishing_semantic_manifest() -> dict:
    manifest = _canonical_semantic_fixture()
    manifest["issue"] = {
        "key": "GUIDES-100",
        "description": (
            "Retain temporary files and provide a download archive after AEM Sites publishing. "
            "The requested behavior produces correct observable output and retains valid prior state."
        ),
    }
    manifest["issue_domains"] = {
        "schema_version": "aem-guides-issue-domains-v1",
        "primary_domain": "PUBLISHING",
        "routes": [
            {
                "domain": "PUBLISHING",
                "status": "ACTIVE",
                "reason": "The requested behavior creates a publishing artifact.",
                "evidence": ["Jira description GUIDES-100"],
            }
        ],
    }
    manifest["publishing_scope"] = _publishing_scope_fixture()
    manifest["generated_output_contract"] = _generated_output_fixture()
    output_ids = generated_output_mod.material_item_ids(manifest["generated_output_contract"])
    manifest["dispositions"].append(
        {
            "finding_id": "CD-GO",
            "statement": "Generated output inventory and output-fidelity oracles are validated.",
            "disposition": "GENERATED_OUTPUT_VALIDATION",
            "source_refs": output_ids,
        }
    )
    return manifest


def _asset_identity_semantic_manifest() -> dict:
    manifest = _canonical_semantic_fixture()
    manifest["issue"] = {
        "key": "GUIDES-100",
        "description": (
            "Publishing a referenced image asset must use the current asset version after update, move, or rename. "
            "The requested behavior produces correct observable output and retains valid prior state."
        ),
    }
    manifest["issue_domains"] = {
        "schema_version": "aem-guides-issue-domains-v1",
        "primary_domain": "ASSETS",
        "routes": [
            {
                "domain": "ASSETS",
                "status": "ACTIVE",
                "reason": "The behavior is controlled by DAM asset identity and lifecycle.",
                "evidence": ["Jira description GUIDES-100"],
            },
            {
                "domain": "PUBLISHING",
                "status": "ACTIVE",
                "reason": "The current asset identity must reach the generated publishing output.",
                "evidence": ["Jira description GUIDES-100"],
            }
        ],
    }
    manifest["publishing_scope"] = _publishing_scope_fixture()
    manifest["generated_output_contract"] = _generated_output_fixture()
    manifest["content_identity_contract"] = _content_identity_fixture()
    output_ids = generated_output_mod.material_item_ids(manifest["generated_output_contract"])
    manifest["dispositions"].append(
        {
            "finding_id": "CD-GO",
            "statement": "Generated output is compared with the current source asset identity.",
            "disposition": "GENERATED_OUTPUT_VALIDATION",
            "source_refs": output_ids,
        }
    )
    identity_ids = content_identity_mod.material_item_ids(manifest["content_identity_contract"])
    manifest["dispositions"].append(
        {
            "finding_id": "CD-CI",
            "statement": "Current content identity is validated across lifecycle operations.",
            "disposition": "LIFECYCLE_COVERAGE",
            "source_refs": identity_ids,
        }
    )
    return manifest


def test_contract_facts_and_integrity() -> None:
    block = _canonical_semantic_fixture()["contract_facts"]
    check(
        "source-bound contract facts validate",
        contract_fact_mod.validate_contract_facts(block, open_question_ids=set()) == [],
    )
    check(
        "contract facts must quote their canonical source exactly",
        any(
            "exact excerpt" in problem
            for problem in contract_fact_mod.validate_contract_facts(
                block,
                open_question_ids=set(),
                source_texts={"Jira description GUIDES-100": "different source text"},
            )
        ),
    )
    check(
        "protected exact source terms survive in their ACs",
        contract_integrity_mod.validate_integrity(block, GOOD_PLAN) == [],
    )
    lost = GOOD_PLAN.replace("correct observable output", "a result")
    check(
        "silently dropped contract wording fails integrity",
        any("silently lost" in p for p in contract_integrity_mod.validate_integrity(block, lost)),
    )
    ambiguous = json.loads(json.dumps(block))
    ambiguous["facts"][0]["integrity"] = "EXPLICITLY_FLAGGED_AS_AMBIGUOUS"
    check(
        "ambiguous contract fact cannot be routed directly to an AC",
        any("ambiguous facts" in p for p in contract_fact_mod.validate_contract_facts(ambiguous)),
    )


def test_issue_domain_routing_and_publishing_scope() -> None:
    manifest = _publishing_semantic_manifest()
    check(
        "publishing evidence activates the publishing domain",
        domain_router_mod.classify(manifest) == ["PUBLISHING"],
    )
    check(
        "inflected publishing, API delivery, and bulk scale activate independent routes",
        domain_router_mod.classify({
            "issue": {
                "description": "Users publish in bulk through APIs, with 2k or 3k documents in one action."
            }
        }) == ["PUBLISHING", "PERFORMANCE", "API"],
    )
    check(
        "published and singular API wording are recognized",
        domain_router_mod.classify({
            "issue": {"description": "Documents are published using an API."}
        }) == ["PUBLISHING", "API"],
    )
    check(
        "negated and explicitly unaffected domains do not self-activate",
        domain_router_mod.classify({
            "issue": {
                "description": "Publishing and performance are not in scope; the output preset is unaffected."
            }
        }) == [],
    )
    check(
        "a negative performance instruction does not activate a performance route",
        domain_router_mod.classify({
            "issue": {"description": "Output generation must not be tested for performance."}
        }) == [],
    )
    check(
        "structured out-of-scope values cannot activate a domain",
        domain_router_mod.classify({
            "issue": {
                "description": "The authoring label changes.",
                "out_of_scope": ["publishing", "API", "bulk performance"],
            }
        }) == ["AUTHORING"],
    )
    check(
        "a positive clause after a negated clause remains discoverable",
        domain_router_mod.classify({
            "issue": {
                "description": "Performance is not affected, but documents are published through APIs."
            }
        }) == ["PUBLISHING", "API"],
    )
    publishing_route = {
        "schema_version": "aem-guides-issue-domains-v1",
        "primary_domain": "PUBLISHING",
        "routes": [{
            "domain": "PUBLISHING", "status": "ACTIVE", "reason": "Publishing is explicit.",
            "evidence": ["ticket description"],
        }],
    }
    check(
        "publishing configuration does not imply a generated-download contract",
        domain_router_mod.required_blocks(publishing_route) == ["publishing_scope"]
        and "GENERATED_OUTPUT" not in domain_router_mod.required_dimensions(publishing_route),
    )
    check(
        "publishing domain and scope validate",
        domain_router_mod.validate_issue_domains(
            manifest["issue_domains"], manifest=manifest, open_question_ids=set()
        ) == []
        and publishing_scope_mod.validate_publishing_scope(
            manifest["publishing_scope"], open_question_ids=set()
        ) == [],
    )
    missing_scope = dict(manifest)
    missing_scope.pop("publishing_scope")
    check(
        "active publishing route requires its scope contract",
        any(
            "publishing_scope" in p
            for p in domain_router_mod.validate_issue_domains(
                missing_scope["issue_domains"], manifest=missing_scope
            )
        ),
    )
    unresolved = json.loads(json.dumps(manifest["publishing_scope"]))
    unresolved["enable_dita_ot_processing"] = "UNRESOLVED"
    check(
        "unresolved DITA-OT state requires an Open Question",
        any(
            "open_question_refs" in p
            for p in publishing_scope_mod.validate_publishing_scope(unresolved)
        ),
    )
    unresolved["open_question_refs"] = ["OQ-99"]
    check(
        "an empty Open Question registry rejects invented references",
        any(
            "undeclared Open Question" in p
            for p in publishing_scope_mod.validate_publishing_scope(
                unresolved, open_question_ids=set()
            )
        ),
    )


def test_behavior_graph_relation_ontology() -> None:
    def graph(relation):
        return {
            "schema_version": "aem-guides-behavior-graph-v1",
            "nodes": [
                {"node_id": "BGN-01", "kind": "PRODUCT_BEHAVIOR", "label": "source", "material": True, "provenance": ["source:1"]},
                {"node_id": "BGN-02", "kind": "PROCESSOR", "label": "target", "material": True, "provenance": ["source:2"]},
            ],
            "edges": [
                {
                    "edge_id": "BGE-01", "source": "BGN-01", "target": "BGN-02",
                    "relation_type": relation, "provenance": ["source:3"],
                    "subject": "ACTUAL_IMPLEMENTATION", "authority": "CURRENT_IMPLEMENTATION",
                    "currentness": "CURRENT", "applicability": "APPLICABLE", "confidence": 0.8,
                    "verification_state": "CONFIRMED", "material": True,
                }
            ],
            "traversal_paths": [{"path_id": "P-01", "edge_refs": ["BGE-01"]}],
        }

    check(
        "every canonical relation family is accepted",
        all(behavior_graph_mod.validate_behavior_graph(graph(rel)) == [] for rel in behavior_graph_mod.RELATION_TYPES),
    )
    inferred = graph("READ_BY")
    inferred["edges"][0]["authority"] = "INFERENCE"
    check(
        "graph inference cannot silently become confirmed",
        any("inference" in p for p in behavior_graph_mod.validate_behavior_graph(inferred)),
    )
    wrong_subject = graph("READ_BY")
    wrong_subject["edges"][0]["subject"] = "UNKNOWN_SUBJECT"
    wrong_subject["edges"][0]["authority"] = "CURRENT_IMPLEMENTATION"
    check(
        "graph authority is validated against a declared subject policy",
        any(
            ".subject must be one of" in p
            for p in behavior_graph_mod.validate_behavior_graph(wrong_subject)
        ),
    )
    fake_provenance = graph("READ_BY")
    check(
        "graph provenance must resolve in the canonical evidence registry",
        any(
            "unknown evidence reference" in p
            for p in behavior_graph_mod.validate_behavior_graph(
                fake_provenance, evidence_ids=set()
            )
        ),
    )
    unresolved_graph = graph("READ_BY")
    unresolved_graph["edges"][0].update({
        "verification_state": "UNRESOLVED", "open_question_ref": "OQ-GHOST",
    })
    check(
        "unresolved graph edges cannot invent Open Question references",
        any(
            "declared open_question_ref" in p
            for p in behavior_graph_mod.validate_behavior_graph(
                unresolved_graph, open_question_ids=set()
            )
        ),
    )
    too_deep = graph("READ_BY")
    too_deep["traversal_paths"][0]["edge_refs"] = ["BGE-01"] * 5
    check(
        "behavior traversal is bounded",
        any("four-hop" in p for p in behavior_graph_mod.validate_behavior_graph(too_deep)),
    )


def test_semantic_closure_required() -> None:
    manifest = _canonical_semantic_fixture()
    run_gates = _load("run_gates_semantic_closure", "run_gates.py")
    check(
        "complete canonical semantic pipeline passes",
        run_gates.validate_canonical_semantic_pipeline(
            manifest, plan_text=GOOD_PLAN, include_plan_checks=True
        ) == [],
    )
    check(
        "behavior model alone cannot pass semantic coverage",
        coverage_gate_mod.evaluate(
            {"behavior_model": {"trigger": ["publish"], "operations": ["generate"]}}
        )["semantic_gate"] == "NEEDS_REVIEW",
    )
    check(
        "complete applicability matrix passes",
        semantic_closure_mod.validate_semantic_closure(
            manifest["semantic_closure"],
            material_entity_ids=["BGN-01"],
            required_dimensions=["DIRECT_CONSUMERS", "NEGATIVE_STATE"],
        ) == [],
    )
    for key in ("contract_facts", "behavior_graph", "semantic_closure"):
        malformed = json.loads(json.dumps(manifest))
        malformed[key] = []
        check(
            f"wrong-typed {key} fails gracefully",
            isinstance(
                run_gates.validate_canonical_semantic_pipeline(malformed), list
            ),
        )
    incomplete = json.loads(json.dumps(manifest["semantic_closure"]))
    incomplete["records"] = incomplete["records"][:-1]
    check(
        "a silently omitted semantic dimension fails",
        any(
            "silently omits" in p
            for p in semantic_closure_mod.validate_semantic_closure(
                incomplete, material_entity_ids=["BGN-01"]
            )
        ),
    )
    wildcard = json.loads(json.dumps(manifest["semantic_closure"]))
    wildcard["records"][0]["entity_ref"] = "*"
    check(
        "wildcard closure cannot hide per-entity applicability gaps",
        any(
            "is not accepted" in p
            for p in semantic_closure_mod.validate_semantic_closure(
                wildcard, material_entity_ids=["BGN-01"]
            )
        ),
    )


def test_missing_question_directed_retrieval_by_subject() -> None:
    manifest = _canonical_semantic_fixture()
    record = manifest["semantic_closure"]["records"][0]
    record.update(
        {
            "applicability": "UNRESOLVED",
            "status": "UNRESOLVED_AND_EXPOSED",
            "open_question_ref": "OQ-01",
        }
    )
    record.pop("disposition_ref")
    manifest["open_questions"] = [
        {"id": "OQ-01", "question": "What is the intended product behavior?", "qa_impact": "Changes the expected result."}
    ]
    check(
        "unresolved closure automatically requires a question",
        any("did not generate" in p for p in mq_mod.validate_required_questions(manifest)),
    )
    stub = mq_mod.derive_missing_question_stubs(manifest)[0]
    check(
        "missing-question stub preserves subject, dimension, and visible Open Question",
        stub["subject"] == "PRODUCT_CONTRACT"
        and stub["dimension"] == record["dimension"]
        and stub["open_question_ref"] == "OQ-01",
    )
    manifest["missing_questions"] = [
        {
            "question_id": "MQ-01", "question": "What is the intended product behavior?",
            "why_it_matters": "It changes the acceptance oracle.", "preferred_sources": ["linked jira"],
            "search_concepts": ["approved intended behavior"], "blocking": True,
            "material": True, "source_ref": record["closure_id"], "subject": "PRODUCT_CONTRACT",
            "dimension": record["dimension"], "open_question_ref": "OQ-01",
            "if_unresolved": "OPEN_QUESTION",
        }
    ]
    manifest["evidence_lifecycle"] = [
        {"evidence_id": "E-01", "source": "linked jira", "query": "original ticket keywords", "pass": "initial", "status": "INSPECTED", "question_id": ""},
        {"evidence_id": "E-02", "source": "linked jira", "query": "approved intended behavior", "pass": "second", "status": "REJECTED", "question_id": "MQ-01"},
    ]
    check("generated material question is linked", mq_mod.validate_required_questions(manifest) == [])
    check(
        "directed subject-specific retrieval is recorded even when no answer is found",
        mq_mod.check_retrieval_discipline(
            manifest["missing_questions"], manifest["evidence_lifecycle"]
        ) == [],
    )


def test_coverage_disposition_completeness() -> None:
    base = {"dispositions": []}
    check(
        "undispositioned material candidate fails",
        any(
            "no coverage disposition" in p
            for p in behavioral_completeness_mod.validate_behavioral_completeness(
                base, material_item_ids=["CF-01"]
            )
        ),
    )
    one = {
        "dispositions": [
            {"finding_id": "CD-01", "statement": "covered", "disposition": "TECHNICAL_NOTE", "source_refs": ["CF-01"]}
        ]
    }
    check(
        "exactly-once disposition passes",
        behavioral_completeness_mod.validate_behavioral_completeness(
            one, material_item_ids=["CF-01"]
        ) == [],
    )
    duplicate = json.loads(json.dumps(one))
    duplicate["dispositions"].append(
        {"finding_id": "CD-02", "statement": "again", "disposition": "TECHNICAL_NOTE", "source_refs": ["CF-01"]}
    )
    check(
        "duplicate disposition fails",
        any(
            "more than once" in p
            for p in behavioral_completeness_mod.validate_behavioral_completeness(
                duplicate, material_item_ids=["CF-01"]
            )
        ),
    )


def test_acceptance_promotion_authority() -> None:
    manifest = _canonical_semantic_fixture()
    record = manifest["acceptance_promotions"]["records"][0]
    block = {"schema_version": "aem-guides-acceptance-promotions-v1", "records": [record]}
    kwargs = {
        "ac_ids": {"AC-01"}, "known_candidate_ids": {"CF-01"},
        "contract_fact_ids": {"CF-01"},
        "candidate_authorities": {"CF-01": {"JIRA_EXPECTED_BEHAVIOR"}},
        "candidate_subjects": {"CF-01": "PRODUCT_CONTRACT"},
        "dispositions": [manifest["dispositions"][0]],
        "ac_status_by_id": {"AC-01": "Proposed"},
        "accepted_uac_present": False,
    }
    check(
        "Jira expected behavior can support a Proposed AC",
        acceptance_promotion_mod.validate_acceptance_promotions(block, **kwargs) == [],
    )
    code_only = json.loads(json.dumps(block))
    code_only["records"][0]["intended_behavior_authorities"] = ["PR_IMPLEMENTATION"]
    check(
        "PR implementation alone cannot promote an AC",
        any("cannot authorize" in p for p in acceptance_promotion_mod.validate_acceptance_promotions(code_only, **kwargs)),
    )
    regression = json.loads(json.dumps(block))
    regression["records"][0]["regression_only"] = True
    check(
        "regression-only candidate cannot promote",
        any("regression-only" in p for p in acceptance_promotion_mod.validate_acceptance_promotions(regression, **kwargs)),
    )
    duplicate = json.loads(json.dumps(block))
    duplicate_record = json.loads(json.dumps(record))
    duplicate_record["promotion_id"] = "AP-02"
    duplicate["records"].append(duplicate_record)
    check(
        "a candidate and AC cannot be promoted more than once",
        any(
            "promoted more than once" in p
            for p in acceptance_promotion_mod.validate_acceptance_promotions(
                duplicate, **kwargs
            )
        ),
    )
    unbound_authority = json.loads(json.dumps(block))
    unbound_authority["records"][0]["intended_behavior_authorities"] = [
        "APPROVED_PRODUCT_DECISION"
    ]
    check(
        "a promotion cannot borrow authority from another candidate",
        any(
            "not bound to candidate" in p
            for p in acceptance_promotion_mod.validate_acceptance_promotions(
                unbound_authority, **kwargs
            )
        ),
    )
    wrong_candidate_subject_kwargs = dict(kwargs)
    wrong_candidate_subject_kwargs["candidate_subjects"] = {
        "CF-01": "ACTUAL_IMPLEMENTATION"
    }
    check(
        "product acceptance cannot relabel an implementation candidate",
        any(
            "does not match candidate" in p
            for p in acceptance_promotion_mod.validate_acceptance_promotions(
                block, **wrong_candidate_subject_kwargs
            )
        ),
    )
    wrong_disposition = json.loads(json.dumps(block))
    wrong_disposition["records"][0]["disposition_ref"] = "CD-02"
    wrong_disposition_kwargs = dict(kwargs)
    wrong_disposition_kwargs["dispositions"] = manifest["dispositions"][:2]
    check(
        "promotion disposition must cover the same candidate and AC",
        any(
            "does not cover candidate" in p or "different AC" in p
            for p in acceptance_promotion_mod.validate_acceptance_promotions(
                wrong_disposition, **wrong_disposition_kwargs
            )
        ),
    )
    unaccepted_confirmed = json.loads(json.dumps(block))
    unaccepted_confirmed["records"][0].update({
        "decision": "PROMOTED_CONFIRMED",
        "disposition": "ACCEPTANCE_CONTRACT",
        "intended_behavior_authorities": ["HUMAN_ACCEPTED_AC"],
    })
    confirmed_disposition = json.loads(json.dumps(manifest["dispositions"][0]))
    confirmed_disposition["disposition"] = "ACCEPTANCE_CONTRACT"
    confirmed_kwargs = dict(kwargs)
    confirmed_kwargs.update({
        "candidate_authorities": {"CF-01": {"HUMAN_ACCEPTED_AC"}},
        "dispositions": [confirmed_disposition],
        "ac_status_by_id": {"AC-01": "Confirmed"},
        "accepted_uac_present": False,
    })
    check(
        "Confirmed promotion requires an accepted UAC contract",
        any(
            "accepted_uac_present=true" in p
            for p in acceptance_promotion_mod.validate_acceptance_promotions(
                unaccepted_confirmed, **confirmed_kwargs
            )
        ),
    )


def test_generated_output_contract() -> None:
    good = _generated_output_fixture()
    check(
        "complete generated-output contract passes",
        generated_output_mod.validate_generated_output_contract(good) == [],
    )
    legacy = json.loads(json.dumps(good))
    legacy["schema_version"] = "aem-guides-generated-output-contract-v1"
    legacy.pop("delivery_in_scope")
    legacy["oracles"] = [
        oracle for oracle in legacy["oracles"]
        if oracle["oracle_type"] != "DELIVERY_AVAILABLE"
    ]
    check(
        "legacy v1 generated-output contracts remain readable",
        generated_output_mod.validate_generated_output_contract(legacy) == [],
    )
    delivery_out = json.loads(json.dumps(good))
    delivery_out["delivery_in_scope"] = False
    delivery_out.pop("download_surface")
    delivery_out_oracle = next(
        oracle for oracle in delivery_out["oracles"]
        if oracle["oracle_type"] == "DELIVERY_AVAILABLE"
    )
    delivery_out_oracle.update({
        "applicability": "NOT_APPLICABLE",
        "status": "INVESTIGATED_AND_REJECTED",
        "expected": "Delivery is outside the source-backed scope.",
    })
    check(
        "delivery availability is not required when delivery is out of scope",
        generated_output_mod.validate_generated_output_contract(delivery_out) == [],
    )
    mismatched_delivery = json.loads(json.dumps(good))
    mismatched_delivery["delivery_in_scope"] = False
    check(
        "an out-of-scope delivery cannot retain a covered availability oracle",
        any(
            "DELIVERY_AVAILABLE must follow" in p
            for p in generated_output_mod.validate_generated_output_contract(
                mismatched_delivery
            )
        ),
    )
    missing_delivery_surface = json.loads(json.dumps(good))
    missing_delivery_surface.pop("download_surface")
    check(
        "in-scope delivery requires its real delivery surface",
        any(
            "requires a download_surface" in p
            for p in generated_output_mod.validate_generated_output_contract(
                missing_delivery_surface
            )
        ),
    )
    unresolved_delivery = json.loads(json.dumps(good))
    unresolved_delivery["delivery_in_scope"] = "UNRESOLVED"
    unresolved_delivery["delivery_scope_open_question_ref"] = "OQ-GHOST"
    unresolved_delivery_oracle = next(
        oracle for oracle in unresolved_delivery["oracles"]
        if oracle["oracle_type"] == "DELIVERY_AVAILABLE"
    )
    unresolved_delivery_oracle.update({
        "applicability": "UNRESOLVED",
        "status": "UNRESOLVED_AND_EXPOSED",
        "open_question_ref": "OQ-GHOST",
    })
    check(
        "unresolved delivery cannot invent an Open Question",
        any(
            "declared" in p
            for p in generated_output_mod.validate_generated_output_contract(
                unresolved_delivery, open_question_ids=set()
            )
        ),
    )
    split_delivery_question = json.loads(json.dumps(unresolved_delivery))
    split_delivery_question["delivery_scope_open_question_ref"] = "OQ-01"
    split_delivery_question_oracle = next(
        oracle for oracle in split_delivery_question["oracles"]
        if oracle["oracle_type"] == "DELIVERY_AVAILABLE"
    )
    split_delivery_question_oracle["open_question_ref"] = "OQ-02"
    check(
        "delivery scope and availability cannot point to different questions",
        any(
            "same Open Question" in p
            for p in generated_output_mod.validate_generated_output_contract(
                split_delivery_question, open_question_ids={"OQ-01", "OQ-02"}
            )
        ),
    )
    logs_only = json.loads(json.dumps(good))
    logs_only["payload_inventory"] = [
        {"item_id": "GOI-01", "item": "generation log", "role": "DIAGNOSTIC", "disposition": "INCLUDED"}
    ]
    check(
        "logs-only archive is not accepted as generated output",
        any("PRIMARY_CONTENT" in p for p in generated_output_mod.validate_generated_output_contract(logs_only)),
    )
    existence_only = json.loads(json.dumps(good))
    existence_only["oracles"] = [existence_only["oracles"][0]]
    check(
        "artifact-existence-only coverage fails",
        any("CONTENT_CORRECT" in p for p in generated_output_mod.validate_generated_output_contract(existence_only)),
    )
    check("archive-exists text is not a sufficient product oracle", oracle_mod.is_diagnostic_only("the archive exists"))


def test_generated_artifact_delivery_regression() -> None:
    manifest = _publishing_semantic_manifest()
    manifest["generated_output_contract"]["payload_inventory"] = [
        {"item_id": "GOI-01", "item": "generation logs", "role": "DIAGNOSTIC", "disposition": "INCLUDED"}
    ]
    run_gates = _load("run_gates_generated_artifact", "run_gates.py")
    problems = run_gates.validate_canonical_semantic_pipeline(manifest)
    check(
        "generated-artifact contract rejects a logs-only downloadable archive",
        any("PRIMARY_CONTENT" in p for p in problems),
    )


def test_content_identity_lifecycle_regression() -> None:
    good = _asset_identity_semantic_manifest()
    check(
        "current-identity lifecycle contract passes",
        content_identity_mod.validate_content_identity_contract(good["content_identity_contract"]) == [],
    )
    stale_fallback = json.loads(json.dumps(good))
    stale_fallback["content_identity_contract"]["fallback_policy"] = "APPROVED_FALLBACK"
    stale_fallback["content_identity_contract"].pop("fallback_authority", None)
    run_gates = _load("run_gates_content_identity", "run_gates.py")
    problems = run_gates.validate_canonical_semantic_pipeline(stale_fallback)
    check(
        "content-identity contract rejects an unauthorized previous-version fallback",
        any("fallback_authority" in p for p in problems),
    )
    invented_migration = json.loads(json.dumps(good["content_identity_contract"]))
    invented_migration["migration_behavior"] = "MIGRATE"
    check(
        "legacy migration cannot be invented without authority",
        any("migration_authority" in p for p in content_identity_mod.validate_content_identity_contract(invented_migration)),
    )


def test_postability_semantic_reviews() -> None:
    run_gates = _load("run_gates_postability", "run_gates.py")
    check(
        "every semantic REVIEW blocks posting",
        run_gates._postability_review_present(
            ["REVIEW feature-classification: generated artifact class is undeclared"]
        ) is True,
    )


def test_fluffyjaws_evidence() -> None:
    fj = fluffyjaws_evidence_mod

    # Backward-compatible: absent block is a clean pass.
    check("absent fluffyjaws block passes", fj.validate_block({}) == [])

    # Flag-gated probe defaults to disabled + unavailable.
    default_probe = fj.probe(env={})
    check(
        "probe defaults to DISABLED/unavailable",
        default_probe == {"mode": "FLUFFYJAWS_DISABLED", "available": False},
    )
    shadow_probe = fj.probe(env={"SKILL_FLUFFYJAWS_MODE": "FLUFFYJAWS_SHADOW"})
    check(
        "probe never reports available without an injected transport",
        shadow_probe["mode"] == "FLUFFYJAWS_SHADOW" and shadow_probe["available"] is False,
    )

    # Disabled/unavailable with discoveries is rejected.
    disabled_with_ev = {
        "fluffyjaws": {
            "mode": "FLUFFYJAWS_DISABLED",
            "available": False,
            "discoveries": [
                {"query": "q", "authority": "SUPPORTING_DISCOVERY", "regrounded_evidence_id": "E1"}
            ],
        },
        "evidence_authority": {"items": [
            {"evidence_id": "E1", "statement": "s", "status": "CONFIRMED", "authority": "SPECIFICATION_AUTHORITY"}
        ]},
    }
    check(
        "discoveries while disabled are rejected",
        any("DISABLED/unavailable" in p for p in fj.validate_block(disabled_with_ev)),
    )

    # A grounded shadow discovery that re-grounds into a first-class source passes.
    good = {
        "fluffyjaws": {
            "mode": "FLUFFYJAWS_SHADOW",
            "available": True,
            "discoveries": [
                {"query": "native pdf file properties", "authority": "SUPPORTING_DISCOVERY", "regrounded_evidence_id": "E1"}
            ],
        },
        "evidence_authority": {"items": [
            {"evidence_id": "E1", "statement": "s", "status": "CONFIRMED", "authority": "PRODUCT_REQUIREMENT_AUTHORITY"}
        ]},
    }
    check("grounded shadow discovery passes", fj.validate_block(good) == [])

    # Non-supporting authority is rejected.
    bad_auth = {
        "fluffyjaws": {"mode": "FLUFFYJAWS_SHADOW", "available": True, "discoveries": [
            {"query": "q", "authority": "SPECIFICATION_AUTHORITY", "regrounded_evidence_id": "E1"}
        ]},
        "evidence_authority": {"items": [
            {"evidence_id": "E1", "statement": "s", "status": "CONFIRMED", "authority": "SPECIFICATION_AUTHORITY"}
        ]},
    }
    check(
        "FluffyJaws cannot claim a first-class authority",
        any("SUPPORTING_DISCOVERY" in p for p in fj.validate_block(bad_auth)),
    )

    # Missing / non-authoritative re-grounding is rejected.
    ungrounded = {
        "fluffyjaws": {"mode": "FLUFFYJAWS_SHADOW", "available": True, "discoveries": [
            {"query": "q", "authority": "SUPPORTING_DISCOVERY"}
        ]},
        "evidence_authority": {"items": []},
    }
    check(
        "discovery without re-grounding is rejected",
        any("regrounded_evidence_id" in p for p in fj.validate_block(ungrounded)),
    )

    # Direct AC promotion is rejected.
    promotes = {
        "fluffyjaws": {"mode": "FLUFFYJAWS_SHADOW", "available": True, "discoveries": [
            {"query": "q", "authority": "SUPPORTING_DISCOVERY", "regrounded_evidence_id": "E1", "promotes_ac": True}
        ]},
        "evidence_authority": {"items": [
            {"evidence_id": "E1", "statement": "s", "status": "CONFIRMED", "authority": "IMPLEMENTATION_AUTHORITY"}
        ]},
    }
    check(
        "no FluffyJaws -> AC promotion path",
        any("promotes_ac" in p for p in fj.validate_block(promotes)),
    )

    print("test_fluffyjaws_evidence: OK")


def test_temporal_evidence() -> None:
    te = temporal_evidence_mod

    # Backward-compatible: no temporal metadata -> clean pass.
    check("absent temporal metadata passes", te.validate({}) == [])
    check("empty manifest not flagged present", te.is_present({}) is False)

    # Invalid state rejected.
    bad_state = {"evidence_authority": {"items": [
        {"evidence_id": "E1", "temporal_applicability": "MAYBE"}
    ]}}
    check("invalid temporal state rejected",
          any("must be one of" in p for p in te.validate(bad_state)))

    # UNKNOWN_VERSION supporting an AC without safe disposition is rejected.
    unknown_ac = {"evidence_authority": {"items": [
        {"evidence_id": "E1", "temporal_applicability": "UNKNOWN_VERSION",
         "supports_ac": True}
    ]}}
    check("UNKNOWN_VERSION cannot silently support an AC",
          any("cannot silently support" in p for p in te.validate(unknown_ac)))

    # Same, but dispositioned as NEEDS_CURRENT_VERIFICATION -> passes.
    unknown_ok = {"evidence_authority": {"items": [
        {"evidence_id": "E1", "temporal_applicability": "UNKNOWN_VERSION",
         "supports_ac": True, "disposition": "NEEDS_CURRENT_VERIFICATION"}
    ]}}
    check("unknown-version claim is safe when dispositioned", te.validate(unknown_ok) == [])

    # CURRENTLY_APPLICABLE supporting an AC -> passes.
    current_ok = {"evidence_authority": {"items": [
        {"evidence_id": "E1", "temporal_applicability": "CURRENTLY_APPLICABLE",
         "supports_ac": True}
    ]}}
    check("currently-applicable evidence may support an AC", te.validate(current_ok) == [])

    # SUPERSEDED must name what supersedes it.
    superseded_bare = {"evidence_authority": {"items": [
        {"evidence_id": "E1", "temporal_applicability": "SUPERSEDED"}
    ]}}
    check("SUPERSEDED must record superseded_by/conflict_with",
          any("superseded_by/conflict_with" in p for p in te.validate(superseded_bare)))

    # Normative authority must not be marked SUPERSEDED by recency alone.
    normative_superseded = {"evidence_authority": {"items": [
        {"evidence_id": "E1", "temporal_applicability": "SUPERSEDED",
         "superseded_by": "E2", "authority_is_normative": True}
    ]}}
    check("normative record not superseded by recency alone",
          any("recency alone" in p for p in te.validate(normative_superseded)))

    # Version conflict must be preserved with two records + applicability.
    conflict_bad = {"temporal_evidence": {"version_conflicts": [{"between": ["E1"]}]}}
    check("version conflict must preserve both records",
          any("at least two evidence_ids" in p for p in te.validate(conflict_bad)))

    conflict_ok = {"temporal_evidence": {"version_conflicts": [
        {"between": ["E1", "E2"], "applicability": "VERSION_MISMATCH"}
    ]}}
    check("marked version conflict passes", te.validate(conflict_ok) == [])

    print("test_temporal_evidence: OK")


def test_evidence_conflict_resolver() -> None:
    cr = evidence_conflict_resolver_mod

    # Backward-compatible: absent block passes.
    check("absent conflict_resolution passes", cr.validate({}) == [])

    def wrap(conflict):
        return {"conflict_resolution": {"conflicts": [conflict]}}

    base = {
        "claim_id": "C1", "normalized_claim": "x",
        "supporting_evidence_ids": ["E1"], "conflicting_evidence_ids": ["E2"],
    }

    # Invalid conflict type / resolution rejected.
    bad_type = dict(base, conflict_type="NOPE", resolution="UNRESOLVED", question_type="GENERAL")
    check("invalid conflict_type rejected", any("conflict_type" in p for p in cr.validate(wrap(bad_type))))

    # INVARIANT 1: code-vs-doc resolving in favor of implementation is rejected.
    code_wins = dict(base, conflict_type="PRODUCT_DOC_VS_CODE",
                     resolution="RESOLVED_BY_HIGHER_AUTHORITY",
                     winning_authority="VERIFIED_CURRENT_IMPLEMENTATION",
                     question_type="PRODUCT_PROMISE", resolution_reason="code says so")
    check("implementation cannot win over the contract (defect, not rewrite)",
          any("DEFECT" in p or "IMPLEMENTATION_DEVIATES_FROM_CONTRACT" in p for p in cr.validate(wrap(code_wins))))

    # Correct: code differs -> IMPLEMENTATION_DEVIATES_FROM_CONTRACT with reason passes.
    defect = dict(base, conflict_type="PRODUCT_DOC_VS_CODE",
                  resolution="IMPLEMENTATION_DEVIATES_FROM_CONTRACT",
                  question_type="PRODUCT_PROMISE",
                  resolution_reason="doc promises A; code produces B -> defect")
    check("documented defect resolution passes", cr.validate(wrap(defect)) == [])

    # INVARIANT 2: FluffyJaws / SUPPORTING_DISCOVERY can never win.
    fj_wins = dict(base, conflict_type="HUMAN_DECISION_VS_DOC",
                   resolution="RESOLVED_BY_HIGHER_AUTHORITY",
                   winning_authority="SUPPORTING_DISCOVERY",
                   question_type="GENERAL", resolution_reason="fluffyjaws said so")
    check("SUPPORTING_DISCOVERY cannot be the winning authority",
          any("SUPPORTING_DISCOVERY" in p for p in cr.validate(wrap(fj_wins))))

    # Question-specific authority: code cannot settle a normative question.
    normative = dict(base, conflict_type="NORMATIVE_VS_IMPLEMENTATION",
                     resolution="RESOLVED_BY_HIGHER_AUTHORITY",
                     winning_authority="VERIFIED_CURRENT_IMPLEMENTATION",
                     question_type="NORMATIVE_SEMANTIC", resolution_reason="r")
    check("implementation cannot settle a normative question",
          any("not appropriate for question_type" in p or "DEFECT" in p for p in cr.validate(wrap(normative))))

    normative_ok = dict(base, conflict_type="NORMATIVE_VS_IMPLEMENTATION",
                        resolution="RESOLVED_BY_HIGHER_AUTHORITY",
                        winning_authority="NORMATIVE_SEMANTIC",
                        question_type="NORMATIVE_SEMANTIC",
                        resolution_reason="DITA 1.3 defines the meaning")
    check("normative authority settles a normative question", cr.validate(wrap(normative_ok)) == [])

    # Non-settling state supporting an AC without safe disposition is rejected.
    unresolved_ac = dict(base, conflict_type="SCOPE_CONFLICT", resolution="PRODUCT_DECISION_REQUIRED",
                         question_type="GENERAL", supports_ac=True)
    check("non-settling state cannot silently support an AC",
          any("must be dispositioned" in p for p in cr.validate(wrap(unresolved_ac))))

    unresolved_ok = dict(unresolved_ac, disposition="OPEN_QUESTION")
    check("dispositioned open conflict passes", cr.validate(wrap(unresolved_ok)) == [])

    # Missing competing evidence rejected.
    no_ev = {"claim_id": "C1", "normalized_claim": "x", "conflict_type": "VERSION_CONFLICT",
             "resolution": "REFERENCE_ONLY", "question_type": "GENERAL",
             "supporting_evidence_ids": [], "conflicting_evidence_ids": []}
    check("competing evidence must be preserved",
          any("non-empty list" in p for p in cr.validate(wrap(no_ev))))

    print("test_evidence_conflict_resolver: OK")


def test_question_research() -> None:
    qr = question_research_mod

    # Backward-compatible: absent block passes.
    check("absent question_research passes", qr.validate({}) == [])

    def wrap(item, questions=None):
        block = {"question_research": {"items": [item]}}
        if questions is not None:
            block["missing_questions"] = {"questions": questions}
        return block

    base = {
        "question_ref": "MQ-1",
        "material": True,
        "research_requirement": "DOCUMENTATION",
        "research_status": "ANSWER_FOUND",
        "research_requests": ["RQ-1"],
        "research_evidence_ids": ["E-1"],
        "coverage_disposition": "OPEN_QUESTION",
    }

    # A fully routed, answered question passes.
    check("answered documentation research passes", qr.validate(wrap(base)) == [])

    # Invalid enum values rejected.
    check("invalid research_requirement rejected",
          any("research_requirement" in p for p in qr.validate(
              wrap(dict(base, research_requirement="GUESS")))))
    check("invalid research_status rejected",
          any("research_status" in p for p in qr.validate(
              wrap(dict(base, research_status="FOUND")))))

    # NONE <-> NOT_REQUIRED consistency; no requests allowed.
    none_ok = {
        "question_ref": "MQ-2",
        "material": True,
        "research_requirement": "NONE",
        "research_status": "NOT_REQUIRED",
    }
    check("explicit current-ticket authority proceeds without research",
          qr.validate(wrap(none_ok)) == [])
    check("NONE cannot terminate as ANSWER_FOUND",
          any("NOT_REQUIRED" in p for p in qr.validate(
              wrap(dict(none_ok, research_status="ANSWER_FOUND",
                        research_requests=["RQ-9"])))))
    check("NONE cannot issue research requests",
          any("cannot issue research requests" in p for p in qr.validate(
              wrap(dict(none_ok, research_requests=["RQ-9"])))))

    # Hard gate: material routed question still PENDING fails the review, with or
    # without a finalizing coverage disposition.
    pending = dict(base, research_status="PENDING", research_requests=[],
                   research_evidence_ids=[], coverage_disposition="OPEN_QUESTION")
    check("PENDING mandatory research fails review",
          any("still PENDING" in p for p in qr.validate(wrap(pending))))
    pending_finalized = dict(pending, coverage_disposition="COVERED")
    check("PENDING mandatory research cannot finalize coverage",
          any("cannot finalize" in p for p in qr.validate(wrap(pending_finalized))))

    # Incomplete research (PARTIAL / SOURCE_UNAVAILABLE / CONFLICTED) keeps the
    # question open; a finalizing disposition is rejected.
    for state in ("PARTIAL", "SOURCE_UNAVAILABLE", "CONFLICTED"):
        item = dict(base, research_status=state, coverage_disposition="COVERED")
        check(f"{state} research cannot finalize coverage",
              any("cannot finalize" in p for p in qr.validate(wrap(item))))
        item_open = dict(item, coverage_disposition="OPEN_QUESTION")
        check(f"{state} research stays an open question",
              qr.validate(wrap(item_open)) == [])

    # NOT_FOUND never means the opposite behavior is true.
    not_found = dict(base, research_status="NOT_FOUND",
                     coverage_disposition="INVESTIGATED_AND_REJECTED")
    check("NOT_FOUND cannot ground a rejection",
          any("never means the opposite behavior" in p
              for p in qr.validate(wrap(not_found))))
    not_found_open = dict(not_found, coverage_disposition="OPEN_QUESTION")
    check("NOT_FOUND as an open question passes",
          qr.validate(wrap(not_found_open)) == [])

    # NOT_APPLICABLE applies only to non-material questions.
    not_applicable = {
        "question_ref": "MQ-3",
        "material": False,
        "research_requirement": "DOCUMENTATION",
        "research_status": "NOT_APPLICABLE",
    }
    check("non-material question routing is not applicable",
          qr.validate(wrap(not_applicable)) == [])
    check("material question cannot be NOT_APPLICABLE",
          any("non-material" in p for p in qr.validate(
              wrap(dict(not_applicable, material=True)))))

    # ANSWER_FOUND requires the research request that found the answer.
    check("ANSWER_FOUND requires a research request",
          any("requires the research request" in p for p in qr.validate(
              wrap(dict(base, research_requests=[])))))

    # Duplicate routing entries are rejected.
    dup_manifest = {"question_research": {"items": [base, dict(base)]}}
    check("duplicate question_ref rejected",
          any("duplicate question_ref" in p for p in qr.validate(dup_manifest)))

    # Cross-check: a material missing question must carry a routing entry.
    unrouted = qr.validate(wrap(none_ok, questions=[
        {"question_id": "MQ-UNROUTED", "blocking": True},
    ]))
    check("material missing question without routing entry is flagged",
          any("no question_research routing entry" in p for p in unrouted))
    routed = qr.validate(wrap(none_ok, questions=[
        {"question_id": "MQ-2", "blocking": True},
    ]))
    check("routed material missing question passes", routed == [])

    print("test_question_research: OK")


def test_behavior_classification() -> None:
    bc = behavior_classification_mod

    # Backward-compatible: absent block passes.
    check("absent behavior_classification passes", bc.validate({}) == [])

    def wrap(item):
        return {"behavior_classification": {"items": [item]}}

    documented = {
        "target_ref": "DISP-1",
        "behavior_class": "EXISTING_CONFIRMED",
        "existing_evidence_ids": ["DOC-1"],
        "source_line": "Official product documentation",
    }
    check("documented baseline behavior passes", bc.validate(wrap(documented)) == [])

    requested = {
        "target_ref": "DISP-2",
        "behavior_class": "NEW_REQUIREMENT",
        "requested_evidence_ids": ["JIRA-1"],
        "source_line": "Current ticket acceptance criteria",
    }
    check("ticket-requested new behavior passes", bc.validate(wrap(requested)) == [])

    # Rule 1: EXISTING_CONFIRMED needs existing-behavior evidence.
    check("EXISTING_CONFIRMED requires existing evidence",
          any("requires existing-behavior evidence" in p for p in bc.validate(
              wrap({"target_ref": "D", "behavior_class": "EXISTING_CONFIRMED"}))))

    # Rule 3: existing documentation cannot claim a new feature, and the source
    # line cannot credit a documentation source the record does not carry.
    check("NEW_REQUIREMENT cannot cite existing documentation",
          any("must not claim a new feature" in p for p in bc.validate(
              wrap(dict(requested, existing_evidence_ids=["DOC-9"])))))
    check("NEW_REQUIREMENT source line cannot credit documentation",
          any("must not credit a documentation source" in p for p in bc.validate(
              wrap(dict(requested, source_line="Experience League")))))

    # Rule 4: a change-set-only behavior is NEW_REQUIREMENT, never existing.
    change_only = {
        "target_ref": "DISP-3",
        "behavior_class": "NEW_REQUIREMENT",
        "change_evidence_ids": ["PR-1"],
    }
    check("change-set-only behavior is a new requirement",
          bc.validate(wrap(change_only)) == [])
    check("change-set-only behavior cannot be EXISTING_CONFIRMED",
          any("requires existing-behavior evidence" in p for p in bc.validate(
              wrap({"target_ref": "DISP-3b", "behavior_class": "EXISTING_CONFIRMED",
                    "change_evidence_ids": ["PR-1"]}))))

    # Rule 5: preserved behavior names its existing evidence.
    preserved = {
        "target_ref": "DISP-4",
        "behavior_class": "PRESERVED_EXISTING_BEHAVIOR",
        "existing_evidence_ids": ["DOC-2"],
        "requested_evidence_ids": ["JIRA-2"],
    }
    check("preserved existing behavior passes", bc.validate(wrap(preserved)) == [])
    check("PRESERVED requires existing evidence",
          any("requires existing-behavior evidence" in p for p in bc.validate(
              wrap({"target_ref": "D", "behavior_class": "PRESERVED_EXISTING_BEHAVIOR",
                    "requested_evidence_ids": ["JIRA-2"]}))))

    # MODIFIED needs both the documented baseline and the ticket's change.
    modified = {
        "target_ref": "DISP-5",
        "behavior_class": "MODIFIED_EXISTING_BEHAVIOR",
        "existing_evidence_ids": ["DOC-3"],
        "requested_evidence_ids": ["JIRA-3"],
    }
    check("modified existing behavior passes", bc.validate(wrap(modified)) == [])
    check("MODIFIED requires the ticket's change evidence",
          any("current-ticket" in p for p in bc.validate(
              wrap({"target_ref": "D", "behavior_class": "MODIFIED_EXISTING_BEHAVIOR",
                    "existing_evidence_ids": ["DOC-3"]}))))

    # Rule 6: combining sources requires each side to genuinely support.
    check("combined source line needs existing-behavior evidence",
          any("genuinely supports part" in p for p in bc.validate(
              wrap(dict(modified, existing_evidence_ids=[] ,
                        requested_evidence_ids=["JIRA-3"],
                        source_line="Current ticket + Experience League")))))

    # Rule 7 / unresolved: UNKNOWN stays open until resolved.
    unknown_open = {
        "target_ref": "DISP-6",
        "behavior_class": "UNKNOWN",
        "coverage_disposition": "OPEN_QUESTION",
    }
    check("UNKNOWN stays an open question", bc.validate(wrap(unknown_open)) == [])
    check("UNKNOWN cannot finalize coverage",
          any("cannot finalize" in p for p in bc.validate(
              wrap(dict(unknown_open, coverage_disposition="COVERED")))))
    check("UNKNOWN must stay visible",
          any("must stay visible" in p for p in bc.validate(
              wrap({"target_ref": "D", "behavior_class": "CONFLICTED"}))))

    # Invalid class and duplicate targets rejected.
    check("invalid behavior_class rejected",
          any("behavior_class" in p for p in bc.validate(
              wrap({"target_ref": "D", "behavior_class": "LEGACY"}))))
    dup = {"behavior_classification": {"items": [documented, dict(documented)]}}
    check("duplicate target_ref rejected",
          any("duplicate target_ref" in p for p in bc.validate(dup)))

    print("test_behavior_classification: OK")


def test_question_planner() -> None:
    qp = question_planner_mod

    # Backward-compatible: absent block passes.
    check("absent question_plan passes", qp.validate({}) == [])

    def wrap(items, **extra):
        block = {"question_plan": {"items": items}}
        block["question_plan"].update(extra)
        return block

    def item(qid, category="EXPECTED_OUTCOME", **over):
        base = {
            "question_id": qid,
            "category": category,
            "question": f"What behavior does {qid} establish?",
            "why_material": "The answer changes the sign-off oracle.",
            "triggering_evidence_ids": ["JIRA-1"],
            "acceptance_impact": "Determines whether the fix has an AC.",
            "applicability": "APPLICABLE",
            "research_requirement": "DOCUMENTATION",
            "status": "PLANNED",
        }
        base.update(over)
        return base

    check("a well-formed material question passes", qp.validate(wrap([item("MQ-01")])) == [])

    # Every required field is enforced.
    for field in ("question_id", "question", "why_material", "acceptance_impact"):
        broken = item("MQ-01")
        broken[field] = ""
        check(f"missing {field} rejected",
              any(field in p for p in qp.validate(wrap([broken]))))
    broken = item("MQ-01", triggering_evidence_ids=[])
    check("empty triggering_evidence_ids rejected",
          any("triggering_evidence_ids" in p for p in qp.validate(wrap([broken]))))

    # Closed vocabularies.
    check("unknown category rejected",
          any("category" in p for p in qp.validate(wrap([item("MQ-01", category="LUCK")]))))
    check("unknown research requirement rejected",
          any("research_requirement" in p for p in qp.validate(
              wrap([item("MQ-01", research_requirement="VIBES")]))))
    check("unknown status rejected",
          any("status" in p for p in qp.validate(wrap([item("MQ-01", status="DONE")]))))
    check("unknown applicability rejected",
          any("applicability" in p for p in qp.validate(
              wrap([item("MQ-01", applicability="MAYBE")]))))

    # A question is not an AC.
    check("assertion instead of question rejected",
          any("evidence-seeking" in p for p in qp.validate(
              wrap([item("MQ-01", question="The purge keeps the logs.")]))))
    check("question record cannot declare an AC",
          any("not an AC" in p for p in qp.validate(
              wrap([item("MQ-01", ac_id="AC-01")]))))

    # Bounded budget: overflow must be explicit, never a silent discard.
    many = [item(f"MQ-{i:02d}") for i in range(1, 14)]
    check("budget overflow without escalation fails",
          any("budget" in p and "overflow" in p for p in qp.validate(wrap(many))))
    over_budget = wrap(many[:12], overflow={
        "state": "OVERFLOW",
        "escalation": "Reviewer triage decides which escalated question enters the plan.",
        "items": [dict(many[12], status="ESCALATED")],
    })
    check("explicit overflow/escalation passes", qp.validate(over_budget) == [])
    canonical_overflow = wrap(many[:12], overflow={
        "state": "QUESTION_BUDGET_EXCEEDED",
        "escalation": "Reviewer triage decides which escalated question enters the plan.",
        "items": [dict(many[12], status="ESCALATED")],
    })
    check("QUESTION_BUDGET_EXCEEDED is the canonical overflow state",
          qp.validate(canonical_overflow) == [])
    check("overflow without state fails",
          any("QUESTION_BUDGET_EXCEEDED" in p for p in qp.validate(
              wrap(many[:12], overflow={"items": [many[12]]}))))
    check("overflow items keep full question fields",
          any("why_material" in p for p in qp.validate(
              wrap(many[:12], overflow={
                  "state": "OVERFLOW",
                  "escalation": "Reviewer triage.",
                  "items": [{"question_id": "MQ-13"}],
              }))))
    check("main plan must respect the budget once overflow exists",
          any("move the excess" in p for p in qp.validate(
              wrap(many, overflow={"state": "OVERFLOW", "escalation": "x",
                                   "items": [dict(many[12], status="ESCALATED")]}))))
    check("duplicate question_id rejected",
          any("duplicate question_id" in p for p in qp.validate(
              wrap([item("MQ-01"), item("MQ-01", category="SCOPE")]))))

    # Do not emit every category for every ticket.
    carpet = [
        item(f"MQ-{i:02d}", category=category)
        for i, category in enumerate(qp.QUESTION_CATEGORIES[:10], 1)
    ]
    check("category carpet rejected",
          any("do not emit every category" in p for p in qp.validate(wrap(carpet))))
    selective = [
        item("MQ-01", category="EXPECTED_OUTCOME"),
        item("MQ-02", category="PRESERVATION"),
    ]
    check("selective categories pass", qp.validate(wrap(selective)) == [])

    print("test_question_planner: OK")


def test_question_resolver() -> None:
    qres = question_resolver_mod

    # Backward-compatible: absent block passes.
    check("absent question_resolutions passes", qres.validate({}) == [])

    def wrap(items, **blocks):
        manifest = {"question_resolutions": {"items": items}}
        manifest.update(blocks)
        return manifest

    def answer(authority="OFFICIAL_DOCUMENTATION", **over):
        base = {
            "claim": "The documented purge removes entries older than the period.",
            "source_ids": ["DOC-1"],
            "source_authority": authority,
            "applicability": "5.0 on-prem",
            "limitations": [],
            "contradictions": [],
        }
        base.update(over)
        return base

    def item(ref, status="ANSWERED", **over):
        base = {"question_ref": ref, "status": status,
                "decision_reason": "Recorded from the cited evidence."}
        if status in {"ANSWERED", "PARTIALLY_ANSWERED", "CONFLICTED"}:
            base["answer"] = answer()
        base.update(over)
        return base

    check("answered resolution passes", qres.validate(wrap([item("MQ-01")])) == [])

    # Answer retention contract.
    no_claim = item("MQ-01", answer=answer(claim=""))
    check("answer requires a claim", any("claim" in p for p in qres.validate(wrap([no_claim]))))
    no_sources = item("MQ-01", answer=answer(source_ids=[]))
    check("answer requires source_ids",
          any("source_ids" in p for p in qres.validate(wrap([no_sources]))))
    no_applicability = item("MQ-01", answer=answer(applicability=""))
    check("answer requires applicability",
          any("applicability" in p for p in qres.validate(wrap([no_applicability]))))
    check("ANSWERED without a retained answer fails",
          any("requires a retained answer" in p for p in qres.validate(
              wrap([{"question_ref": "MQ-01", "status": "ANSWERED"}]))))

    # An answer is not automatically an AC.
    check("resolution cannot declare an AC",
          any("not automatically an AC" in p for p in qres.validate(
              wrap([item("MQ-01", ac_id="AC-01")]))))

    # Non-establishing authorities cannot ground an ANSWERED expectation.
    for authority in ("ACTUAL_RESULT", "SUSPECTED_ROOT_CAUSE",
                      "ATTACHMENT_OBSERVATION", "HISTORICAL_JIRA", "AI_INFERENCE"):
        check(f"{authority} cannot ground ANSWERED",
              any("cannot establish an ANSWERED expectation" in p
                  for p in qres.validate(wrap([item("MQ-01", answer=answer(authority))]))))
    check("current-ticket requirement can ground ANSWERED",
          qres.validate(wrap([item("MQ-01", answer=answer("CURRENT_TICKET_REQUIREMENT"))])) == [])

    # PARTIALLY_ANSWERED must record limitations.
    check("PARTIALLY_ANSWERED requires limitations",
          any("limitations" in p for p in qres.validate(
              wrap([item("MQ-01", status="PARTIALLY_ANSWERED")]))))
    partial = item("MQ-01", status="PARTIALLY_ANSWERED",
                   answer=answer(limitations=["Only the default mode was documented."]))
    check("PARTIALLY_ANSWERED with limitations passes",
          qres.validate(wrap([partial])) == [])

    # ACCEPTANCE_TBD only when plausible answers materially change acceptance.
    tbd = item("MQ-01", status="ACCEPTANCE_TBD", answer=None,
               material_impact=["BEHAVIOR", "SCOPE"],
               plausible_answers=["retain logs", "purge logs"])
    check("material ACCEPTANCE_TBD passes", qres.validate(wrap([tbd])) == [])
    check("ACCEPTANCE_TBD requires material impact",
          any("material_impact" in p for p in qres.validate(
              wrap([item("MQ-01", status="ACCEPTANCE_TBD", answer=None,
                         plausible_answers=["a", "b"])]))))
    check("ACCEPTANCE_TBD requires two plausible answers",
          any("two plausible answers" in p for p in qres.validate(
              wrap([item("MQ-01", status="ACCEPTANCE_TBD", answer=None,
                         material_impact=["BEHAVIOR"], plausible_answers=["a"])]))))
    check("ACCEPTANCE_TBD rejects unknown impact areas",
          any("material_impact" in p for p in qres.validate(
              wrap([item("MQ-01", status="ACCEPTANCE_TBD", answer=None,
                         material_impact=["VIBES"], plausible_answers=["a", "b"])]))))

    # Root cause / diagnostics / mechanics are normally INVESTIGATION_ONLY.
    investigation = item("MQ-01", status="INVESTIGATION_ONLY", answer=None,
                         investigation_topic="ROOT_CAUSE")
    check("root cause as INVESTIGATION_ONLY passes",
          qres.validate(wrap([investigation])) == [])
    check("root cause as ANSWERED needs acceptance relevance",
          any("acceptance_relevance" in p for p in qres.validate(
              wrap([item("MQ-01", investigation_topic="ROOT_CAUSE")]))))
    justified = item("MQ-01", investigation_topic="IMPLEMENTATION_MECHANICS",
                     acceptance_relevance="The mechanic is itself the requested behavior.")
    check("justified mechanics exception passes",
          qres.validate(wrap([justified])) == [])

    # DUPLICATE / NOT_APPLICABLE / CONFLICTED discipline.
    check("DUPLICATE requires the surviving question",
          any("duplicate_of" in p for p in qres.validate(
              wrap([{"question_ref": "MQ-02", "status": "DUPLICATE"}]))))
    check("NOT_APPLICABLE requires a reason",
          any("reason" in p for p in qres.validate(
              wrap([{"question_ref": "MQ-03", "status": "NOT_APPLICABLE"}]))))
    check("CONFLICTED retains contradictions",
          any("contradictions" in p for p in qres.validate(
              wrap([item("MQ-01", status="CONFLICTED")]))))
    conflicted = item("MQ-01", status="CONFLICTED",
                      answer=answer(contradictions=["DOC-2 says the opposite."]))
    check("CONFLICTED with contradictions passes",
          qres.validate(wrap([conflicted])) == [])

    # NOT_FOUND is not negative proof.
    check("ANSWERED on NOT_FOUND research fails",
          any("not negative proof" in p for p in qres.validate(
              wrap([item("MQ-01", research_outcome="NOT_FOUND")]))))

    # Q1 schema: question_id + disposition with a flat answer claim and
    # top-level retention fields.
    flat = {
        "question_id": "MQ-01",
        "disposition": "ANSWERED",
        "answer": "The documented baseline removes aged entries.",
        "source_ids": ["DOC-1"],
        "source_authority": "OFFICIAL_DOCUMENTATION",
        "applicability": "current release",
        "limitations": [],
        "contradictions": [],
        "decision_reason": "The documentation establishes the baseline.",
    }
    check("Q1 flat resolution shape passes", qres.validate(wrap([flat])) == [])
    flat_missing = dict(flat, source_ids=[])
    check("flat shape keeps the retention contract",
          any("source_ids" in p for p in qres.validate(wrap([flat_missing]))))
    no_reason = {k: v for k, v in flat.items() if k != "decision_reason"}
    check("every material decision records its decision_reason",
          any("decision_reason" in p for p in qres.validate(wrap([no_reason]))))

    # Equal-authority conflict remains unresolved: ANSWERED with retained
    # contradictions requires the higher-authority basis, else CONFLICTED.
    answered_with_conflict = item(
        "MQ-01", answer=answer(contradictions=["DOC-2 says the opposite."]))
    check("ANSWERED with an unresolved equal-authority conflict fails",
          any("equal-authority conflict" in p
              for p in qres.validate(wrap([answered_with_conflict]))))
    resolved_by_authority = item(
        "MQ-01",
        answer=answer(contradictions=["DOC-2 says the opposite."]),
        conflict_resolution="The current Human Accepted AC outranks the older "
        "documentation page.")
    check("ANSWERED with a higher-authority basis passes",
          qres.validate(wrap([resolved_by_authority])) == [])

    # R1 reuse: R1-required research cannot be skipped.
    doc_dependent = {
        "question_plan": {"items": [{
            "question_id": "MQ-01", "category": "EXPECTED_OUTCOME",
            "question": "What does the documented baseline do?",
            "why_material": "m", "triggering_evidence_ids": ["JIRA-1"],
            "acceptance_impact": "a", "applicability": "APPLICABLE",
            "research_requirement": "DOCUMENTATION", "status": "RESOLVED"}]},
        "doc_research": {"routing": {"state": "DOC_RESEARCH_REQUIRED",
                                     "triggers": ["EVIDENCE_AGENT_REQUEST"]}},
    }
    check("ANSWERED over R1-required research fails",
          any("R1-required" in p for p in qres.validate(
              wrap([item("MQ-01")], **doc_dependent))))
    check("doc-requiring questions contradict RESEARCH_NOT_REQUIRED",
          any("cannot be skipped" in p for p in qres.validate(
              wrap([item("MQ-01")], **{
                  "question_plan": doc_dependent["question_plan"],
                  "doc_research": {"routing": {
                      "state": "RESEARCH_NOT_REQUIRED",
                      "not_required_reason": "x"}}}))))
    doc_unavailable = dict(doc_dependent)
    doc_unavailable["doc_research"] = {"routing": {
        "state": "DOC_RESEARCH_UNAVAILABLE",
        "triggers": ["EVIDENCE_AGENT_REQUEST"]}}
    check("documentation answer over UNAVAILABLE research fails",
          any("UNAVAILABLE" in p for p in qres.validate(
              wrap([item("MQ-01")], **doc_unavailable))))
    doc_conflicted = dict(doc_dependent)
    doc_conflicted["doc_research"] = {"routing": {
        "state": "DOC_RESEARCH_CONFLICTED",
        "triggers": ["EVIDENCE_AGENT_REQUEST"]}}
    check("ANSWERED over CONFLICTED doc research fails",
          any("CONFLICTED" in p for p in qres.validate(
              wrap([item("MQ-01")], **doc_conflicted))))
    doc_completed = dict(doc_dependent)
    doc_completed["doc_research"] = {
        "routing": {
            "state": "DOC_RESEARCH_COMPLETED",
            "triggers": ["EVIDENCE_AGENT_REQUEST"], "research_id": "DR-1"},
        "results": [{
            "research_id": "DR-1", "status": "DOC_RESEARCH_COMPLETED",
            "produced_by": "uac-doc-researcher",
            "topics": ["documented baseline"],
            "findings": [{
                "claim": "c", "source_id": "DOC-1",
                "source_type": "OFFICIAL_DOCUMENTATION",
                "authority": "OFFICIAL_PRODUCT_CONTRACT",
                "applicability": "current", "currentness": "CURRENT",
                "evidence_role": "EXISTING_BEHAVIOR"}],
            "source_ids": ["DOC-1"], "applicability": "current",
            "limitations": [], "conflicts": [],
            "question_refs": ["MQ-01"]}],
        "admitted_research_ids": ["DR-1"],
    }
    check("ANSWERED over completed doc research passes",
          qres.validate(wrap([item("MQ-01", research_ids=["DR-1"])],
                           **doc_completed)) == [])
    check("documentation answer must cite admitted research_ids",
          any("research_ids" in p for p in qres.validate(
              wrap([item("MQ-01")], **doc_completed))))
    check("stale research cannot answer a question",
          any("not a Doc Researcher result" in p for p in qres.validate(
              wrap([item("MQ-01", research_ids=["DR-9"])], **doc_completed))))
    check("unadmitted research cannot answer a question",
          any("never admitted" in p for p in qres.validate(
              wrap([item("MQ-01", research_ids=["DR-1"])],
                   **dict(doc_completed, doc_research=dict(
                       doc_completed["doc_research"],
                       admitted_research_ids=[]))))))
    check("wrong-bound research cannot answer another question",
          any("wrong-bound" in p for p in qres.validate(
              wrap([item("MQ-02", research_ids=["DR-1"])], **dict(
                  doc_completed,
                  question_plan={"items": [
                      doc_dependent["question_plan"]["items"][0],
                      {"question_id": "MQ-02", "category": "SCOPE",
                       "question": "What is the documented scope?",
                       "why_material": "m",
                       "triggering_evidence_ids": ["JIRA-1"],
                       "acceptance_impact": "a", "applicability": "APPLICABLE",
                       "research_requirement": "DOCUMENTATION",
                       "status": "RESOLVED"}],
                  })))))

    # Rule 11: PARTIAL research cannot produce a fully confirmed answer.
    partial_research = {
        "question_research": {"items": [{
            "question_ref": "MQ-01", "material": True,
            "research_requirement": "DOCUMENTATION",
            "research_status": "PARTIAL", "research_requests": ["RQ-1"]}]},
    }
    check("PARTIAL research blocks ANSWERED",
          any("PARTIAL research cannot produce" in p for p in qres.validate(
              wrap([item("MQ-01")], **partial_research))))
    check("PARTIAL research allows PARTIALLY_ANSWERED",
          qres.validate(wrap([item(
              "MQ-01", status="PARTIALLY_ANSWERED",
              answer=answer(limitations=["Only the default mode is "
                                         "established."]))],
              **partial_research)) == [])

    # CONFLICTED research keeps the question CONFLICTED.
    conflicted_research = {
        "question_research": {"items": [{
            "question_ref": "MQ-01", "material": True,
            "research_requirement": "DOCUMENTATION",
            "research_status": "CONFLICTED", "research_requests": ["RQ-1"]}]},
    }
    check("CONFLICTED research forces CONFLICTED resolution",
          any("stays CONFLICTED" in p or "CONFLICTED research" in p
              for p in qres.validate(wrap([item("MQ-01")],
                                          **conflicted_research))))

    # Rule 15: root-cause/diagnostic uncertainty never becomes ACCEPTANCE_TBD.
    check("root-cause uncertainty cannot become ACCEPTANCE_TBD",
          any("INVESTIGATION_ONLY" in p for p in qres.validate(
              wrap([item("MQ-01", status="ACCEPTANCE_TBD", answer=None,
                         investigation_topic="ROOT_CAUSE",
                         material_impact=["BEHAVIOR"],
                         plausible_answers=["a", "b"])]))))

    # DUPLICATE preserves all triggering evidence on the surviving question.
    dup_plan = {"question_plan": {"items": [
        {"question_id": "MQ-01", "category": "EXPECTED_OUTCOME",
         "question": "What does the documented baseline do?",
         "why_material": "m", "triggering_evidence_ids": ["JIRA-1"],
         "acceptance_impact": "a", "applicability": "APPLICABLE",
         "research_requirement": "NONE", "status": "RESOLVED"},
        {"question_id": "MQ-02", "category": "EXPECTED_OUTCOME",
         "question": "What does the documented baseline do?",
         "why_material": "m", "triggering_evidence_ids": ["JIRA-1", "ATT-2"],
         "acceptance_impact": "a", "applicability": "APPLICABLE",
         "research_requirement": "NONE", "status": "RESOLVED"},
    ]}}
    dup_lost = [item("MQ-01"), {"question_ref": "MQ-02", "status": "DUPLICATE",
                                "duplicate_of": "MQ-01",
                                "decision_reason": "Same question."}]
    check("DUPLICATE must preserve triggering evidence lineage",
          any("preserve all triggering evidence" in p
              for p in qres.validate(wrap(dup_lost, **dup_plan))))
    dup_kept = {"question_plan": {"items": [
        dict(dup_plan["question_plan"]["items"][0],
             triggering_evidence_ids=["JIRA-1", "ATT-2"]),
        dup_plan["question_plan"]["items"][1],
    ]}}
    check("DUPLICATE with preserved lineage passes",
          qres.validate(wrap(dup_lost, **dup_kept)) == [])

    print("test_question_resolver: OK")


def test_coverage_reasoner() -> None:
    cr = coverage_reasoner_mod

    # Backward-compatible: absent block passes.
    check("absent coverage_decisions passes", cr.validate({}) == [])

    def wrap(items, **extra):
        manifest = {"coverage_decisions": {"items": items}}
        manifest["coverage_decisions"]["writer_handoff"] = [
            entry["coverage_id"] for entry in items
            if isinstance(entry, dict) and entry.get("priority") != "EXCLUDED"
        ]
        for key, value in extra.items():
            if key == "writer_handoff":
                manifest["coverage_decisions"]["writer_handoff"] = value
            else:
                manifest[key] = value
        return manifest

    def item(cid, priority="P0", klass="ACCEPTANCE", **over):
        base = {
            "coverage_id": cid,
            "behavior": "The fixed surface shows the true state.",
            "question_ids": ["Q-1"],
            "evidence_ids": ["EV-1"],
            "priority": priority,
            "coverage_class": klass,
            "contract_type": "POSITIVE",
            "surface": "Map Dashboard",
            "state_or_transition": "",
            "configuration": "",
            "applicability": "current release",
            "reason": "Proves the primary ticket contract.",
            "acceptance_impact": "Without it the fix is unverifiable.",
            "dimensions_considered": ["STATE_TRANSITIONS", "PRESERVATION"],
        }
        base.update(over)
        return base

    check("a well-formed P0 decision passes", cr.validate(wrap([item("COV-01")])) == [])

    # Required fields.
    for field in ("coverage_id", "behavior", "applicability", "reason",
                  "acceptance_impact"):
        broken = item("COV-01")
        broken[field] = ""
        check(f"missing {field} rejected",
              any(field in p for p in cr.validate(wrap([broken]))))
    for field in ("surface", "state_or_transition", "configuration",
                  "dimensions_considered"):
        broken = item("COV-01")
        del broken[field]
        check(f"absent {field} rejected",
              any(field in p for p in cr.validate(wrap([broken]))))

    # Closed vocabularies.
    check("unknown priority rejected",
          any("priority" in p for p in cr.validate(wrap([item("COV-01", priority="P2")]))))
    check("unknown class rejected",
          any("coverage_class" in p for p in cr.validate(wrap([item("COV-01", klass="IDEA")]))))
    check("unknown contract_type rejected",
          any("contract_type" in p for p in cr.validate(
              wrap([item("COV-01", contract_type="BOTH")]))))
    check("positive_or_negative alias still validated",
          any("contract_type" in p for p in cr.validate(
              wrap([item("COV-01", contract_type=None,
                         positive_or_negative="BOTH")]))))
    check("PRESERVATION contract type passes",
          cr.validate(wrap([item("COV-01", contract_type="PRESERVATION")])) == [])
    check("unknown axis rejected",
          any("dimensions_considered" in p for p in cr.validate(
              wrap([item("COV-01", dimensions_considered=["MOOD"])]))))

    # Priority/class pairing.
    check("P0 must be ACCEPTANCE",
          any("primary ticket contract" in p for p in cr.validate(
              wrap([item("COV-01", priority="P0", klass="QE_REGRESSION")]))))
    check("P1 must be QE_REGRESSION",
          any("materially related regression" in p for p in cr.validate(
              wrap([item("COV-01", priority="P1", klass="ACCEPTANCE")]))))
    check("SUPPORTING regression passes",
          cr.validate(wrap([item("COV-02", priority="SUPPORTING",
                                 klass="QE_REGRESSION")])) == [])
    check("EXCLUDED passes with a reason",
          cr.validate(wrap([item("COV-03", priority="EXCLUDED", klass="INVESTIGATION",
                                 reason="Out of scope per the ticket.")])) == [])

    # Do not promote generic test ideas.
    check("untraced coverage decision rejected",
          any("generic test ideas" in p for p in cr.validate(
              wrap([item("COV-01", question_ids=[], evidence_ids=[])]))))
    check("evidence-only trace passes",
          cr.validate(wrap([item("COV-01", question_ids=[])])) == [])

    # Writer receives only accepted decisions; Reviewer sees all P0 represented.
    excluded = item("COV-03", priority="EXCLUDED", klass="INVESTIGATION",
                    reason="Out of scope per the ticket.")
    check("EXCLUDED in writer handoff rejected",
          any("never reaches the Writer" in p for p in cr.validate(
              wrap([item("COV-01"), excluded], writer_handoff=["COV-01", "COV-03"]))))
    check("P0 missing from writer handoff rejected",
          any("not represented" in p for p in cr.validate(
              wrap([item("COV-01"), item("COV-02", priority="P1", klass="QE_REGRESSION")],
                   writer_handoff=["COV-02"]))))
    check("complete writer handoff passes",
          cr.validate(wrap([item("COV-01"), excluded],
                           writer_handoff=["COV-01"])) == [])

    # Chain integrity with resolved questions.
    chain = {
        "question_plan": {"items": [{
            "question_id": "Q-1", "category": "EXPECTED_OUTCOME",
            "question": "What must the panel show?",
            "why_material": "m", "triggering_evidence_ids": ["JIRA-1"],
            "acceptance_impact": "a", "applicability": "APPLICABLE",
            "research_requirement": "NONE", "status": "RESOLVED",
        }]},
        "question_resolutions": {"items": [{
            "question_ref": "Q-1", "status": "PARTIALLY_ANSWERED",
            "answer": {"claim": "c", "source_ids": ["E1"],
                       "source_authority": "OFFICIAL_DOCUMENTATION",
                       "applicability": "current", "limitations": ["one mode"],
                       "contradictions": []},
        }]},
    }
    manifest = wrap([item("COV-01")], **chain)
    check("PARTIALLY_ANSWERED cannot ground ACCEPTANCE",
          any("cannot ground ACCEPTANCE" in p for p in cr.validate(manifest)))
    ok = wrap([item("COV-01", klass="QE_REGRESSION", priority="P1")], **chain)
    check("PARTIALLY_ANSWERED can ground QE_REGRESSION", cr.validate(ok) == [])

    chain_tbd = {"question_resolutions": {"items": [
        {"question_ref": "Q-1", "status": "ACCEPTANCE_TBD",
         "material_impact": ["BEHAVIOR"], "plausible_answers": ["a", "b"]}]}}
    check("ACCEPTANCE_TBD grounds only INVESTIGATION",
          any("cannot ground" in p for p in cr.validate(
              wrap([item("COV-01", klass="QE_REGRESSION", priority="P1")],
                   **chain_tbd))))

    chain_unresolved = {"question_plan": {"items": [{
        "question_id": "Q-1", "category": "EXPECTED_OUTCOME",
        "question": "What must the panel show?",
        "why_material": "m", "triggering_evidence_ids": ["JIRA-1"],
        "acceptance_impact": "a", "applicability": "APPLICABLE",
        "research_requirement": "NONE", "status": "PLANNED"}]}}
    check("unresolved planned question cannot ground coverage",
          any("unresolved" in p for p in cr.validate(
              wrap([item("COV-01")], **chain_unresolved))))
    check("never-planned question cannot ground coverage",
          any("never planned" in p for p in cr.validate(
              wrap([item("COV-01", question_ids=["Q-9"])], **chain_unresolved))))

    # Required research cannot be skipped into an ACCEPTANCE decision.
    chain_research = dict(chain)
    chain_research["question_research"] = {"items": [{
        "question_ref": "Q-1", "material": True,
        "research_requirement": "DOCUMENTATION", "research_status": "NOT_FOUND",
        "research_requests": ["RQ-1"]}]}
    check("NOT_FOUND research cannot ground ACCEPTANCE",
          any("cannot be skipped" in p or "not negative proof" in p
              for p in cr.validate(wrap([item("COV-01")], **chain_research))))

    # Existing documented behavior must not be repackaged as new acceptance.
    chain_behavior = dict(chain)
    chain_behavior["question_resolutions"] = {"items": [{
        "question_ref": "Q-1", "status": "ANSWERED",
        "answer": {"claim": "c", "source_ids": ["E1"],
                   "source_authority": "OFFICIAL_DOCUMENTATION",
                   "applicability": "current", "limitations": [],
                   "contradictions": []}}]}
    chain_behavior["behavior_classification"] = {"items": [{
        "target_ref": "B-1", "behavior_class": "EXISTING_CONFIRMED",
        "existing_evidence_ids": ["DOC-1"]}]}
    check("EXISTING_CONFIRMED cannot ground new ACCEPTANCE",
          any("documented-today" in p for p in cr.validate(
              wrap([item("COV-01", behavior_ref="B-1")], **chain_behavior))))
    check("EXISTING_CONFIRMED can ground QE_REGRESSION",
          cr.validate(wrap([item("COV-01", priority="P1", klass="QE_REGRESSION",
                                 behavior_ref="B-1")], **chain_behavior)) == [])

    # The Writer must receive an explicit admitted package.
    no_handoff = {"coverage_decisions": {"items": [item("COV-01")]}}
    check("missing writer_handoff fails",
          any("explicit admitted" in p for p in cr.validate(no_handoff)))

    # Research binding: coverage cites the admitted research of its questions.
    chain_research_ids = dict(chain_behavior)
    chain_research_ids["question_resolutions"] = {"items": [{
        "question_ref": "Q-1", "status": "ANSWERED",
        "decision_reason": "documented",
        "answer": {"claim": "c", "source_ids": ["E1"],
                   "source_authority": "OFFICIAL_DOCUMENTATION",
                   "applicability": "current", "limitations": [],
                   "contradictions": []},
        "research_ids": ["DR-1"]}]}
    chain_research_ids["doc_research"] = {
        "routing": {"state": "DOC_RESEARCH_COMPLETED",
                    "triggers": ["EVIDENCE_AGENT_REQUEST"],
                    "research_id": "DR-1"},
        "results": [{"research_id": "DR-1", "status": "DOC_RESEARCH_COMPLETED",
                     "produced_by": "uac-doc-researcher",
                     "topics": ["t"], "findings": [{
                         "claim": "c", "source_id": "E1",
                         "source_type": "OFFICIAL_DOCUMENTATION",
                         "authority": "OFFICIAL_PRODUCT_CONTRACT",
                         "applicability": "current", "currentness": "CURRENT",
                         "evidence_role": "EXISTING_BEHAVIOR"}],
                     "source_ids": ["E1"], "applicability": "current",
                     "limitations": [], "conflicts": [],
                     "question_refs": ["Q-1"]}],
        "admitted_research_ids": ["DR-1"],
    }
    check("research binding intact passes",
          cr.validate(wrap([item("COV-01", research_ids=["DR-1"])],
                           **chain_research_ids)) == [])
    check("coverage dropping the underlying research binding fails",
          any("research binding" in p for p in cr.validate(
              wrap([item("COV-01")], **chain_research_ids))))
    check("coverage citing unknown research fails",
          any("not a Doc Researcher result" in p for p in cr.validate(
              wrap([item("COV-01", research_ids=["DR-9"])],
                   **chain_research_ids))))

    # DUPLICATE linkage: coverage links the surviving question, never the
    # duplicate alone.
    dup_chain = dict(chain_behavior)
    dup_chain["question_plan"] = {"items": [
        {"question_id": "Q-1", "category": "EXPECTED_OUTCOME",
         "question": "What must the panel show?",
         "why_material": "m", "triggering_evidence_ids": ["JIRA-1"],
         "acceptance_impact": "a", "applicability": "APPLICABLE",
         "research_requirement": "NONE", "status": "RESOLVED"},
        {"question_id": "Q-2", "category": "EXPECTED_OUTCOME",
         "question": "What must the panel show?",
         "why_material": "m", "triggering_evidence_ids": ["JIRA-2"],
         "acceptance_impact": "a", "applicability": "APPLICABLE",
         "research_requirement": "NONE", "status": "RESOLVED"},
    ]}
    dup_chain["question_resolutions"] = {"items": [
        {"question_ref": "Q-1", "status": "ANSWERED",
         "decision_reason": "documented",
         "answer": {"claim": "c", "source_ids": ["E1"],
                    "source_authority": "OFFICIAL_DOCUMENTATION",
                    "applicability": "current", "limitations": [],
                    "contradictions": []}},
        {"question_ref": "Q-2", "status": "DUPLICATE", "duplicate_of": "Q-1",
         "decision_reason": "same question"},
    ]}
    check("DUPLICATE-linked coverage without the survivor fails",
          any("DUPLICATE" in p for p in cr.validate(
              wrap([item("COV-01", priority="P1", klass="QE_REGRESSION",
                         question_ids=["Q-2"])], **dup_chain))))
    check("DUPLICATE linkage through the survivor passes",
          cr.validate(wrap([item("COV-01", priority="P1", klass="QE_REGRESSION",
                                 question_ids=["Q-1", "Q-2"])],
                           **dup_chain)) == [])

    # Observation/root-cause safety net on the coverage side.
    observed = dict(chain_behavior)
    observed["question_resolutions"] = {"items": [{
        "question_ref": "Q-1", "status": "ANSWERED",
        "decision_reason": "observed failure",
        "answer": {"claim": "c", "source_ids": ["E1"],
                   "source_authority": "ACTUAL_RESULT",
                   "applicability": "current", "limitations": [],
                   "contradictions": []}}]}
    check("ACTUAL_RESULT cannot ground ACCEPTANCE coverage",
          any("cannot establish acceptance behavior" in p
              for p in cr.validate(wrap([item("COV-01")], **observed))))

    # PRESERVATION contract cannot rest on a NEW_REQUIREMENT behavior.
    preservation_conflict = dict(chain_behavior)
    preservation_conflict["behavior_classification"] = {"items": [{
        "target_ref": "B-1", "behavior_class": "NEW_REQUIREMENT",
        "requested_evidence_ids": ["JIRA-1"]}]}
    check("a new requirement is not a preservation contract",
          any("not a preservation contract" in p for p in cr.validate(
              wrap([item("COV-01", contract_type="PRESERVATION",
                         behavior_ref="B-1")], **preservation_conflict))))

    # Writer package / Reviewer binding.
    def package(*acs):
        return {"writer_package": {"acs": list(acs)}}

    def ac(ac_id, coverage_ids, **over):
        base = {"ac_id": ac_id, "text": "The approved outcome holds.",
                "coverage_ids": coverage_ids}
        base.update(over)
        return base

    regression_item = item("COV-02", priority="P1", klass="QE_REGRESSION")
    investigation_item = item("COV-03", priority="SUPPORTING",
                              klass="INVESTIGATION")
    excluded_item = item("COV-04", priority="EXCLUDED", klass="INVESTIGATION",
                         reason="Out of scope.")
    items = [item("COV-01"), regression_item, investigation_item,
             excluded_item]

    check("writer package binding passes",
          cr.validate(wrap(items, **package(ac("AC-1", ["COV-01"])))) == [])
    check("Writer cannot add behavior absent from admitted coverage",
          any("absent from admitted coverage" in p for p in cr.validate(
              wrap(items, **package({"ac_id": "AC-1", "text": "x",
                                     "coverage_ids": []})))))
    check("AC cannot bind unknown coverage",
          any("unknown coverage_id" in p for p in cr.validate(
              wrap(items, **package(ac("AC-1", ["COV-99"]))))))
    check("QE_REGRESSION never leaks into an AC",
          any("never leak" in p for p in cr.validate(
              wrap(items, **package(ac("AC-1", ["COV-01", "COV-02"]))))))
    check("INVESTIGATION never becomes an AC",
          any("never leak" in p for p in cr.validate(
              wrap(items, **package(ac("AC-1", ["COV-01", "COV-03"]))))))
    check("EXCLUDED never reaches an AC",
          any("not in the admitted" in p for p in cr.validate(
              wrap(items, **package(ac("AC-1", ["COV-01", "COV-04"]))))))
    check("P0 cannot disappear from the final draft",
          any("cannot disappear" in p for p in cr.validate(
              wrap(items, **package()))))

    # Variants stay bound to the same expected outcome.
    variant_item = item("COV-01", variants=[
        {"label": "single-item action", "evidence_ids": ["EV-1"]},
        {"label": "bulk action", "evidence_ids": ["EV-1b"]},
    ])
    check("bound variants pass",
          cr.validate(wrap([variant_item],
                           **package(ac("AC-1", ["COV-01"],
                                        variants=["single-item action",
                                                  "bulk action"])))) == [])
    check("variant without evidence binding fails",
          any("evidence_ids" in p for p in cr.validate(
              wrap([item("COV-01", variants=[{"label": "bulk action"}])]))))
    check("Writer cannot add unapproved variants",
          any("not an approved variant" in p for p in cr.validate(
              wrap([variant_item],
                   **package(ac("AC-1", ["COV-01"],
                                variants=["scheduled run"]))))))

    print("test_coverage_reasoner: OK")


def test_coverage_equivalence() -> None:
    ce = coverage_equivalence_mod

    # Backward-compatible: absent block passes.
    check("absent coverage_equivalence passes", ce.validate({}) == [])

    def coverage(cid, behavior, qids, priority="P1", klass="QE_REGRESSION",
                 polarity="POSITIVE"):
        return {
            "coverage_id": cid,
            "behavior": behavior,
            "question_ids": qids,
            "evidence_ids": [f"EV-{qid}" for qid in qids],
            "priority": priority,
            "coverage_class": klass,
            "positive_or_negative": polarity,
            "surface": "the affected surface",
            "state": "",
            "configuration": "",
            "applicability": "current release",
            "reason": "Traces to resolved question evidence.",
            "acceptance_impact": "Defines what the Writer may assert.",
            "dimensions_considered": ["STATE_TRANSITIONS"],
        }

    def decision(did, left, right, classification, shared, differing, **over):
        base = {
            "decision_id": did,
            "left_coverage_id": left,
            "right_coverage_id": right,
            "classification": classification,
            "shared_dimensions": shared,
            "differing_dimensions": differing,
            "reason": "Structural comparison of the coverage decisions.",
            "merge_allowed": classification == "SAME_OUTCOME_VARIANT",
        }
        base.update(over)
        return base

    # Human UAC example 1: "Approved remains Approved after refresh" and
    # "Refresh does not return Approved to Ready for Review" describe the same
    # outcome through positive and negative phrasing -> SAME_OUTCOME_VARIANT,
    # and the Writer normally creates one AC (a merge preserving everything).
    refresh_pair = [
        coverage("COV-R1", "Approved remains Approved after refresh.",
                 ["Q-R1"], priority="P0", klass="ACCEPTANCE"),
        coverage("COV-R2", "Refresh does not return Approved to Ready for "
                 "Review.", ["Q-R2"], polarity="NEGATIVE"),
    ]
    same_outcome = decision(
        "EQ-R1", "COV-R1", "COV-R2", "SAME_OUTCOME_VARIANT",
        ["EXPECTED_OUTCOME", "STATE_TRANSITION", "APPLICABILITY"],
        ["QUESTION_IDS"],
    )
    merge = {
        "merge_id": "MERGE-R1",
        "merged_coverage_ids": ["COV-R1", "COV-R2"],
        "classification": "SAME_OUTCOME_VARIANT",
        "canonical_outcome": "The approved state persists across a refresh.",
        "priority": "P0",
        "question_ids": ["Q-R1", "Q-R2"],
        "evidence_ids": ["EV-Q-R1", "EV-Q-R2"],
        "variants": ["positive assertion", "negative assertion"],
        "source_lineage": ["COV-R1", "COV-R2", "Q-R1", "Q-R2"],
    }
    manifest = {
        "coverage_decisions": {"items": refresh_pair},
        "coverage_equivalence": {"decisions": [same_outcome], "merges": [merge]},
    }
    check("human UAC refresh pair is SAME_OUTCOME_VARIANT and merges",
          ce.validate(manifest) == [])

    # Human UAC example 2: "Translation file remains Approved" vs "Translation
    # project becomes Completed" -> DISTINCT_OUTCOME; merging them is rejected.
    translation_pair = [
        coverage("COV-T1", "Translation file remains Approved.", ["Q-T1"]),
        coverage("COV-T2", "Translation project becomes Completed.", ["Q-T2"]),
    ]
    distinct = decision(
        "EQ-T1", "COV-T1", "COV-T2", "DISTINCT_OUTCOME",
        ["APPLICABILITY"], ["EXPECTED_OUTCOME", "STATE_TRANSITION"],
    )
    manifest = {
        "coverage_decisions": {"items": translation_pair},
        "coverage_equivalence": {"decisions": [distinct]},
    }
    check("translation file vs project outcomes are DISTINCT",
          ce.validate(manifest) == [])
    bad_merge = {
        "merge_id": "MERGE-T1",
        "merged_coverage_ids": ["COV-T1", "COV-T2"],
        "classification": "DISTINCT_OUTCOME",
        "priority": "P1",
        "question_ids": ["Q-T1", "Q-T2"],
        "evidence_ids": ["EV-Q-T1", "EV-Q-T2"],
        "variants": ["file state", "project state"],
        "source_lineage": ["COV-T1", "COV-T2"],
    }
    manifest["coverage_equivalence"]["merges"] = [bad_merge]
    check("distinct behavior is never merged to reduce AC count",
          any("never merged" in p for p in ce.validate(manifest)))

    # Classification/dimension discipline.
    check("SAME_OUTCOME_VARIANT requires a shared expected outcome",
          any("EXPECTED_OUTCOME" in p for p in ce.validate({
              "coverage_equivalence": {"decisions": [decision(
                  "EQ-1", "COV-A", "COV-B", "SAME_OUTCOME_VARIANT",
                  ["STATE_TRANSITION"], ["EXPECTED_OUTCOME"])]}})))
    check("DISTINCT_OUTCOME requires a differing expected outcome",
          any("EXPECTED_OUTCOME" in p for p in ce.validate({
              "coverage_equivalence": {"decisions": [decision(
                  "EQ-1", "COV-A", "COV-B", "DISTINCT_OUTCOME",
                  ["EXPECTED_OUTCOME"], ["SCOPE"])]}})))
    check("DEPENDENT_OUTCOME requires a differing outcome and dependency",
          any("dependency" in p for p in ce.validate({
              "coverage_equivalence": {"decisions": [decision(
                  "EQ-1", "COV-A", "COV-B", "DEPENDENT_OUTCOME",
                  ["SCOPE"], ["EXPECTED_OUTCOME"])]}})))
    dependent = decision("EQ-1", "COV-A", "COV-B", "DEPENDENT_OUTCOME",
                         ["SCOPE"], ["EXPECTED_OUTCOME"],
                         dependency="COV-B applies only after COV-A's state.")
    check("dependent outcome with dependency passes",
          ce.validate({"coverage_equivalence": {"decisions": [dependent]}}) == [])
    check("CONFLICT requires the contradiction to stay visible",
          any("conflict_summary" in p for p in ce.validate({
              "coverage_equivalence": {"decisions": [decision(
                  "EQ-1", "COV-A", "COV-B", "CONFLICT",
                  ["EXPECTED_OUTCOME"], ["POLARITY" ])]}})))
    conflict = decision("EQ-1", "COV-A", "COV-B", "CONFLICT",
                        ["EXPECTED_OUTCOME"], ["QUESTION_IDS"],
                        conflict_summary="One decision keeps entries; the other purges them.")
    check("visible conflict passes",
          ce.validate({"coverage_equivalence": {"decisions": [conflict]}}) == [])
    check("unknown comparison dimension rejected",
          any("unknown" in p for p in ce.validate({
              "coverage_equivalence": {"decisions": [decision(
                  "EQ-1", "COV-A", "COV-B", "CONFLICT",
                  ["EXPECTED_OUTCOME"], ["POLARITY"],
                  conflict_summary="x")]}})))
    check("dimension cannot be shared and differing",
          any("both shared and differing" in p for p in ce.validate({
              "coverage_equivalence": {"decisions": [decision(
                  "EQ-1", "COV-A", "COV-B", "DISTINCT_OUTCOME",
                  ["EXPECTED_OUTCOME"], ["EXPECTED_OUTCOME"])]}})))
    check("unknown classification rejected",
          any("classification" in p for p in ce.validate({
              "coverage_equivalence": {"decisions": [decision(
                  "EQ-1", "COV-A", "COV-B", "SIMILAR",
                  ["SCOPE"], ["EXPECTED_OUTCOME"])]}})))

    # The comparison happens on coverage decisions, not Writer prose.
    check("unknown coverage endpoints rejected",
          any("not a known coverage decision" in p for p in ce.validate({
              "coverage_decisions": {"items": refresh_pair},
              "coverage_equivalence": {"decisions": [
                  decision("EQ-1", "COV-R1", "COV-X9", "DISTINCT_OUTCOME",
                           ["SCOPE"], ["EXPECTED_OUTCOME"])]}})))
    check("self-comparison rejected",
          any("compare to itself" in p for p in ce.validate({
              "coverage_equivalence": {"decisions": [
                  decision("EQ-1", "COV-A", "COV-A", "DISTINCT_OUTCOME",
                           ["SCOPE"], ["EXPECTED_OUTCOME"])]}})))

    # Merge preservation: all question IDs, evidence IDs, variants, lineage.
    no_basis = {
        "coverage_decisions": {"items": refresh_pair},
        "coverage_equivalence": {"merges": [merge]},
    }
    check("merge without a SAME_OUTCOME_VARIANT basis decision fails",
          any("requires a SAME_OUTCOME_VARIANT decision" in p
              for p in ce.validate(no_basis)))
    thinned = dict(merge, question_ids=["Q-R1"])
    check("merge dropping question IDs fails",
          any("preserve all member question IDs" in p for p in ce.validate({
              "coverage_decisions": {"items": refresh_pair},
              "coverage_equivalence": {"decisions": [same_outcome],
                                       "merges": [thinned]}})))
    thinned = dict(merge, evidence_ids=["EV-Q-R1"])
    check("merge dropping evidence IDs fails",
          any("preserve all member evidence IDs" in p for p in ce.validate({
              "coverage_decisions": {"items": refresh_pair},
              "coverage_equivalence": {"decisions": [same_outcome],
                                       "merges": [thinned]}})))
    for field in ("variants", "source_lineage"):
        thinned = dict(merge)
        thinned[field] = []
        check(f"merge without {field} fails",
              any(field in p for p in ce.validate({
                  "coverage_equivalence": {"decisions": [same_outcome],
                                           "merges": [thinned]}})))
    demoted = dict(merge, priority="P1")
    check("merge must keep the highest member priority",
          any("highest member priority" in p for p in ce.validate({
              "coverage_decisions": {"items": refresh_pair},
              "coverage_equivalence": {"decisions": [same_outcome],
                                       "merges": [demoted]}})))
    excluded_member = [
        coverage("COV-R1", "Approved remains Approved after refresh.", ["Q-R1"],
                 priority="P0", klass="ACCEPTANCE"),
        coverage("COV-R3", "An excluded idea.", ["Q-R3"], priority="EXCLUDED",
                 klass="INVESTIGATION"),
    ]
    excluded_merge = dict(merge, merged_coverage_ids=["COV-R1", "COV-R3"],
                          question_ids=["Q-R1", "Q-R3"],
                          evidence_ids=["EV-Q-R1", "EV-Q-R3"])
    excluded_decision = decision("EQ-R3", "COV-R1", "COV-R3",
                                 "SAME_OUTCOME_VARIANT",
                                 ["EXPECTED_OUTCOME"], ["QUESTION_IDS"])
    check("EXCLUDED coverage cannot be merged",
          any("EXCLUDED" in p for p in ce.validate({
              "coverage_decisions": {"items": excluded_member},
              "coverage_equivalence": {"decisions": [excluded_decision],
                                       "merges": [excluded_merge]}})))
    double_merge = {
        "coverage_decisions": {"items": refresh_pair},
        "coverage_equivalence": {
            "decisions": [same_outcome],
            "merges": [merge, dict(merge, merge_id="MERGE-R2")],
        },
    }
    check("one decision survives into exactly one AC",
          any("already merged" in p for p in ce.validate(double_merge)))

    print("test_coverage_equivalence: OK")


def test_coverage_equivalence_e1() -> None:
    """E1 hard negatives and the unfamiliar fixture for semantic coverage
    equivalence."""

    ce = coverage_equivalence_mod

    check("absent coverage_equivalence passes (E1)", ce.validate({}) == [])

    def coverage(cid, behavior, qids, **over):
        base = {
            "coverage_id": cid,
            "behavior": behavior,
            "question_ids": qids,
            "evidence_ids": [f"EV-{qid}" for qid in qids],
            "priority": "P1",
            "coverage_class": "QE_REGRESSION",
            "contract_type": "POSITIVE",
            "surface": "the review surface",
            "state_or_transition": "",
            "configuration": "",
            "applicability": "current release",
            "reason": "r",
            "acceptance_impact": "a",
            "dimensions_considered": [],
        }
        base.update(over)
        return base

    def decision(did, left, right, classification, shared, differing, **over):
        base = {
            "decision_id": did,
            "left_coverage_id": left,
            "right_coverage_id": right,
            "classification": classification,
            "shared_dimensions": shared,
            "differing_dimensions": differing,
            "reason": "Structural comparison.",
            "merge_allowed": classification == "SAME_OUTCOME_VARIANT",
        }
        base.update(over)
        return base

    def merge(mid, members, **over):
        base = {
            "merge_id": mid,
            "merged_coverage_ids": members,
            "classification": "SAME_OUTCOME_VARIANT",
            "canonical_outcome": "The shared observable outcome.",
            "priority": "P1",
            "question_ids": sorted({q for q in members}),
            "evidence_ids": sorted({f"EV-{q}" for q in members}),
            "variants": ["individual path", "bulk path"],
            "source_lineage": list(members),
        }
        base.update(over)
        return base

    # merge_allowed discipline.
    check("merge_allowed is required",
          any("merge_allowed" in p for p in ce.validate({
              "coverage_equivalence": {"decisions": [
                  dict(decision("EQ-1", "COV-A", "COV-B", "DISTINCT_OUTCOME",
                                ["SCOPE"], ["EXPECTED_OUTCOME"]),
                       merge_allowed=None)]}})))
    check("merge_allowed only for SAME_OUTCOME_VARIANT",
          any("never merge" in p for p in ce.validate({
              "coverage_equivalence": {"decisions": [
                  decision("EQ-1", "COV-A", "COV-B", "DISTINCT_OUTCOME",
                           ["SCOPE"], ["EXPECTED_OUTCOME"],
                           merge_allowed=True)]}})))

    pair = [
        coverage("COV-A", "The saved state persists.", ["Q-A"]),
        coverage("COV-B", "The saved state does not revert.", ["Q-B"],
                 contract_type="NEGATIVE"),
    ]
    same = decision("EQ-1", "COV-A", "COV-B", "SAME_OUTCOME_VARIANT",
                    ["EXPECTED_OUTCOME", "STATE_TRANSITION", "APPLICABILITY"],
                    ["QUESTION_IDS"])

    # Hard negative: same wording, different outcome.
    distinct_same_words = decision(
        "EQ-2", "COV-A", "COV-C", "DISTINCT_OUTCOME", ["APPLICABILITY"],
        ["EXPECTED_OUTCOME"])
    check("same terminology with different outcome stays DISTINCT",
          ce.validate({
              "coverage_decisions": {"items": [*pair, coverage(
                  "COV-C", "The project becomes Completed.", ["Q-C"])]},
              "coverage_equivalence": {"decisions": [distinct_same_words]},
          }) == [])

    # Hard negative: different applicability (engine/version/surface) never
    # merges - parity is never inferred.
    other_engine = coverage("COV-X", "The saved state persists.", ["Q-X"],
                            applicability="legacy engine")
    cross_engine_merge = merge("MERGE-X", ["COV-A", "COV-X"],
                               question_ids=["Q-A", "Q-X"],
                               evidence_ids=["EV-Q-A", "EV-Q-X"])
    check("different applicability cannot merge (no parity inference)",
          any("applicability" in p for p in ce.validate({
              "coverage_decisions": {"items": [pair[0], other_engine]},
              "coverage_equivalence": {
                  "decisions": [decision(
                      "EQ-X", "COV-A", "COV-X", "SAME_OUTCOME_VARIANT",
                      ["EXPECTED_OUTCOME"], ["APPLICABILITY"])],
                  "merges": [cross_engine_merge]}})))

    # Hard negative: different material configuration never merges.
    other_config = coverage("COV-CFG", "The saved state persists.", ["Q-CFG"],
                            configuration="mode B")
    check("different material configuration cannot merge",
          any("configuration" in p for p in ce.validate({
              "coverage_decisions": {"items": [pair[0], other_config]},
              "coverage_equivalence": {
                  "decisions": [decision(
                      "EQ-C", "COV-A", "COV-CFG", "SAME_OUTCOME_VARIANT",
                      ["EXPECTED_OUTCOME"], ["CONFIGURATION"])],
                  "merges": [merge("MERGE-C", ["COV-A", "COV-CFG"],
                                   question_ids=["Q-A", "Q-CFG"],
                                   evidence_ids=["EV-Q-A", "EV-Q-CFG"])]}})))

    # Sufficiency boundary: INSUFFICIENT / CONFLICTED members never merge;
    # PARTIAL members must be explicitly bounded.
    boundary_base = {
        "coverage_decisions": {"items": pair},
        "coverage_equivalence": {
            "decisions": [same],
            "merges": [merge("MERGE-1", ["COV-A", "COV-B"],
                             question_ids=["Q-A", "Q-B"],
                             evidence_ids=["EV-Q-A", "EV-Q-B"])],
        },
    }
    for state, expectation in (("INSUFFICIENT", "cannot merge"),
                               ("CONFLICTED", "never merge")):
        blocked = {
            **boundary_base,
            "evidence_sufficiency": {"coverage_assessments": [
                {"coverage_ref": "COV-B", "sufficiency": state,
                 "question_refs": ["Q-B"], "sufficiency_reason": "r"}]},
        }
        check(f"{state} coverage {expectation}",
              any(expectation.split()[0] in p or state in p
                  for p in ce.validate(blocked)))
    partial = {
        **boundary_base,
        "evidence_sufficiency": {"coverage_assessments": [
            {"coverage_ref": "COV-B", "sufficiency": "PARTIAL",
             "question_refs": ["Q-B"], "sufficiency_reason": "r",
             "established_portion": "the default path"}]},
    }
    check("PARTIAL member must be explicitly bounded",
          any("partial_members" in p for p in ce.validate(partial)))
    bounded = {
        **boundary_base,
        "evidence_sufficiency": partial["evidence_sufficiency"],
    }
    bounded["coverage_equivalence"]["merges"][0]["partial_members"] = ["COV-B"]
    check("bounded PARTIAL member passes", ce.validate(bounded) == [])

    # ACCEPTANCE_TBD is never absorbed by a confirmed merge.
    tbd = {
        **boundary_base,
        "question_resolutions": {"items": [
            {"question_ref": "Q-B", "status": "ACCEPTANCE_TBD",
             "decision_reason": "r", "material_impact": ["SCOPE"],
             "plausible_answers": ["a", "b"]}]},
    }
    check("ACCEPTANCE_TBD never disappears into a merge",
          any("ACCEPTANCE_TBD" in p for p in ce.validate(tbd)))

    # Research preservation: member research ids must survive the merge.
    researched = [
        coverage("COV-RA", "The documented behavior holds.", ["Q-RA"],
                 research_ids=["DR-1"]),
        coverage("COV-RB", "The documented behavior does not regress.",
                 ["Q-RB"], research_ids=["DR-2"], contract_type="NEGATIVE"),
    ]
    research_merge = merge("MERGE-R", ["COV-RA", "COV-RB"],
                           question_ids=["Q-RA", "Q-RB"],
                           evidence_ids=["EV-Q-RA", "EV-Q-RB"])
    check("merge must preserve member research ids",
          any("research" in p for p in ce.validate({
              "coverage_decisions": {"items": researched},
              "coverage_equivalence": {
                  "decisions": [decision(
                      "EQ-R", "COV-RA", "COV-RB", "SAME_OUTCOME_VARIANT",
                      ["EXPECTED_OUTCOME"], ["QUESTION_IDS"])],
                  "merges": [research_merge]}})))
    research_merge["research_refs"] = ["DR-1", "DR-2"]
    check("merge preserving research ids passes",
          ce.validate({
              "coverage_decisions": {"items": researched},
              "coverage_equivalence": {
                  "decisions": [decision(
                      "EQ-R", "COV-RA", "COV-RB", "SAME_OUTCOME_VARIANT",
                      ["EXPECTED_OUTCOME"], ["QUESTION_IDS"])],
                  "merges": [research_merge]}}) == [])

    # canonical_outcome is required and internal-only.
    check("canonical_outcome required on merges",
          any("canonical_outcome" in p for p in ce.validate({
              "coverage_equivalence": {
                  "decisions": [same],
                  "merges": [dict(merge("MERGE-1", ["COV-A", "COV-B"],
                                        question_ids=["Q-A", "Q-B"],
                                        evidence_ids=["EV-Q-A", "EV-Q-B"]),
                                 canonical_outcome="")]}})))

    # Unfamiliar fixture: two differently-worded same-outcome decisions merge;
    # one closely-related distinct outcome stays separate.
    unfamiliar_items = [
        coverage("COV-U1", "The saved filter is still applied when the panel "
                 "reopens.", ["Q-U1"]),
        coverage("COV-U2", "Reopening the panel never clears the saved "
                 "filter.", ["Q-U2"], contract_type="NEGATIVE"),
        coverage("COV-U3", "The export finishes with a completion marker.",
                 ["Q-U3"]),
    ]
    unfamiliar = {
        "coverage_decisions": {"items": unfamiliar_items},
        "coverage_equivalence": {
            "decisions": [
                decision("EQ-U1", "COV-U1", "COV-U2", "SAME_OUTCOME_VARIANT",
                         ["EXPECTED_OUTCOME", "STATE_TRANSITION",
                          "APPLICABILITY"], ["QUESTION_IDS"]),
                decision("EQ-U2", "COV-U1", "COV-U3", "DISTINCT_OUTCOME",
                         ["APPLICABILITY"], ["EXPECTED_OUTCOME"]),
            ],
            "merges": [merge("MERGE-U1", ["COV-U1", "COV-U2"],
                             question_ids=["Q-U1", "Q-U2"],
                             evidence_ids=["EV-Q-U1", "EV-Q-U2"])],
        },
    }
    check("unfamiliar fixture: differently-worded same outcomes merge, "
          "distinct stays separate", ce.validate(unfamiliar) == [])
    print("  equivalence trace [unfamiliar fixture]:")
    print("    COV-U1 + COV-U2 -> SAME_OUTCOME_VARIANT -> MERGE-U1")
    print("    COV-U1 vs COV-U3 -> DISTINCT_OUTCOME (not merged)")

    print("test_coverage_equivalence_e1: OK")


def _hist_item(**over):
    item = {
        "history_id": "HIST-1",
        "question_id": "Q-1",
        "jira_key_or_source_id": "EV-H1",
        "relationship": "DISCOVERY_ONLY",
        "feature_match": "SIMILAR",
        "surface_match": "SAME",
        "version_match": "SAME",
        "configuration_match": "SAME",
        "failure_mode_match": "SIMILAR",
        "expected_behavior_match": "UNKNOWN",
        "currentness": "STALE",
        "superseded_status": "NOT_SUPERSEDED",
        "human_accepted_ac_available": False,
        "applicability": "same surface, older release",
        "authority_role": "HISTORICAL_JIRA",
        "allowed_use": "DISCOVERY",
        "reason": "Terminology and configuration discovery only.",
        "limitations": ["Does not establish current behavior."],
    }
    item.update(over)
    return item


def _hist_manifest(items, with_resolution=True, question_id="Q-1"):
    manifest = {
        "question_plan": {"items": [{
            "question_id": question_id, "category": "EXPECTED_OUTCOME",
            "question": "What is the current expected behavior?",
            "why_material": "m", "triggering_evidence_ids": ["EV-C1"],
            "acceptance_impact": "a", "applicability": "APPLICABLE",
            "research_requirement": "NONE", "status": "RESOLVED"}]},
        "historical_jira_assessment": {"items": items},
    }
    if with_resolution:
        manifest["question_resolutions"] = {"items": [{
            "question_ref": question_id, "status": "ANSWERED",
            "decision_reason": "Established by the current ticket.",
            "answer": {"claim": "The current behavior holds.",
                       "source_ids": ["EV-C1"],
                       "source_authority": "CURRENT_TICKET_REQUIREMENT",
                       "applicability": "current",
                       "limitations": [], "contradictions": []}}]}
    return manifest


def test_historical_jira_safety() -> None:
    hj = historical_jira_safety_mod

    check("absent historical_jira_assessment passes", hj.validate({}) == [])

    good = _hist_manifest([_hist_item()])
    check("a clean discovery-only assessment passes", hj.validate(good) == [])

    supporting = _hist_manifest([_hist_item(
        relationship="SUPPORTING_PRECEDENT", allowed_use="SUPPORT_ANSWER",
        feature_match="SAME", failure_mode_match="SAME",
        expected_behavior_match="SAME", currentness="CURRENT")])
    check("a materially same supporting precedent passes",
          hj.validate(supporting) == [])

    authoritative = _hist_manifest([_hist_item(
        relationship="AUTHORITATIVE_HISTORY", allowed_use="ESTABLISH_ANSWER",
        feature_match="SAME", failure_mode_match="SAME",
        expected_behavior_match="SAME", currentness="CURRENT",
        human_accepted_ac_available=True,
        authority_basis="existing policy rule allows this historical contract "
        "for the unchanged surface",
        applicability="identical surface, version, and configuration")])
    check("authoritative history with an existing authority basis passes",
          hj.validate(authoritative) == [])

    no_basis = _hist_manifest([_hist_item(
        relationship="AUTHORITATIVE_HISTORY", allowed_use="ESTABLISH_ANSWER",
        feature_match="SAME", failure_mode_match="SAME",
        expected_behavior_match="SAME", currentness="CURRENT")])
    check("AUTHORITATIVE_HISTORY without an existing authority basis fails",
          any("authority_basis" in p for p in hj.validate(no_basis)))

    loose_applicability = _hist_manifest([_hist_item(
        relationship="AUTHORITATIVE_HISTORY", allowed_use="ESTABLISH_ANSWER",
        feature_match="SAME", failure_mode_match="SAME",
        expected_behavior_match="SAME", currentness="CURRENT",
        version_match="SIMILAR",
        authority_basis="existing policy rule")])
    check("AUTHORITATIVE_HISTORY requires exact applicability",
          any("exact" in p and "applicability" in p
              for p in hj.validate(loose_applicability)))

    duplicate = _hist_manifest([_hist_item(), _hist_item()])
    check("duplicate history_id fails",
          any("duplicate history_id" in p for p in hj.validate(duplicate)))

    unbound = _hist_manifest([_hist_item(question_id="Q-404")])
    check("unbound historical use fails (never admitted globally)",
          any("never admitted globally" in p for p in hj.validate(unbound)))

    bad_use = _hist_manifest([_hist_item(allowed_use="ESTABLISH_ANSWER")])
    check("allowed_use incompatible with relationship fails",
          any("incompatible" in p for p in hj.validate(bad_use)))

    observation = _hist_manifest([_hist_item(
        evidence_kind="ACTUAL_RESULT", relationship="SUPPORTING_PRECEDENT",
        allowed_use="SUPPORT_ANSWER", feature_match="SAME",
        failure_mode_match="SAME", expected_behavior_match="SAME",
        currentness="CURRENT")])
    problems = hj.validate(observation)
    check("historical Actual Result stays an observation",
          any("remains" in p and "observation" in p for p in problems))

    # DISCOVERY_ONLY cited as establishing evidence in the resolution.
    cited = _hist_manifest([_hist_item()])
    cited["question_resolutions"]["items"][0]["answer"]["source_ids"] = [
        "EV-C1", "EV-H1"
    ]
    check("DISCOVERY_ONLY cannot directly establish an answer",
          any("cannot directly" in p for p in hj.validate(cited)))

    # CONFLICTING_HISTORY silently resolved.
    conflict = _hist_manifest([_hist_item(
        relationship="CONFLICTING_HISTORY", allowed_use="CONFLICT_SIGNAL",
        expected_behavior_match="DIFFERENT")])
    check("CONFLICTING_HISTORY cannot silently resolve a question",
          any("silently" in p for p in hj.validate(conflict)))
    conflict_kept = _hist_manifest([_hist_item(
        relationship="CONFLICTING_HISTORY", allowed_use="CONFLICT_SIGNAL",
        expected_behavior_match="DIFFERENT")], with_resolution=False)
    conflict_kept["question_resolutions"] = {"items": [{
        "question_ref": "Q-1", "status": "CONFLICTED",
        "decision_reason": "The disagreement is preserved."}]}
    check("CONFLICTING_HISTORY preserved as CONFLICTED passes",
          hj.validate(conflict_kept) == [])

    # S1: discovery evidence cannot make a question SUFFICIENT.
    s1 = _hist_manifest([_hist_item()])
    s1["evidence_sufficiency"] = {"question_assessments": [{
        "question_ref": "Q-1", "sufficiency_status": "SUFFICIENT",
        "decision_reason": "d", "authority_status": "AUTHORITATIVE",
        "research_completion": "NOT_REQUIRED",
        "applicability_status": "APPLICABLE",
        "currentness_status": "CURRENT",
        "contradiction_status": "NONE",
        "supported_claims": ["c"], "unsupported_claims": [],
        "limitations": [], "evidence_ids": ["EV-H1"], "research_ids": []}]}
    check("DISCOVERY_ONLY evidence cannot make a question SUFFICIENT",
          any("cannot make" in p for p in hj.validate(s1)))

    # C1: historical evidence cannot directly create a coverage decision.
    c1 = _hist_manifest([_hist_item(
        relationship="SUPPORTING_PRECEDENT", allowed_use="SUPPORT_ANSWER",
        feature_match="SAME", failure_mode_match="SAME",
        expected_behavior_match="SAME", currentness="CURRENT")])
    c1["coverage_decisions"] = {"items": [{
        "coverage_id": "COV-1", "behavior": "b",
        "question_ids": ["Q-9"], "evidence_ids": ["EV-H1"],
        "priority": "P1", "coverage_class": "QE_REGRESSION"}]}
    check("historical evidence reaches coverage only through its question",
          any("bound Question" in p for p in hj.validate(c1)))

    # L1: discovery history never reaches AC lineage / Source lines.
    l1 = _hist_manifest([_hist_item()])
    l1["requirement_lineage"] = {
        "sources": [], "tbd_lineage": [], "reviews": [],
        "ac_lineage": [{"ac_id": "AC-1", "coverage_refs": [],
                        "equivalence_refs": [], "question_refs": ["Q-1"],
                        "evidence_refs": ["EV-C1", "EV-H1"],
                        "research_refs": [], "source_refs": [],
                        "writer_revision": "w1", "source_versions": {},
                        "human_source_line": "Source: the ticket"}]}
    check("DISCOVERY_ONLY evidence never reaches final Source lines",
          any("never reaches AC lineage" in p for p in hj.validate(l1)))

    print("test_historical_jira_safety: OK")


def test_historical_jira_safety_regressions() -> None:
    """Ten hard negatives, the named AEM Guides fixtures, and an unfamiliar
    structurally different scenario."""

    hj = historical_jira_safety_mod

    def manifest_with(item):
        return _hist_manifest([item])

    # 1. Highly similar historical ticket, different Expected Result.
    case = manifest_with(_hist_item(
        relationship="SUPPORTING_PRECEDENT", allowed_use="SUPPORT_ANSWER",
        feature_match="SAME", failure_mode_match="SAME",
        expected_behavior_match="DIFFERENT"))
    check("HN1 similar ticket with different Expected Result cannot support",
          any("expected behavior differs" in p for p in hj.validate(case)))

    # 2. Same feature, wrong product version.
    case = manifest_with(_hist_item(version_match="DIFFERENT"))
    check("HN2 wrong version forces NOT_APPLICABLE despite similarity",
          any("NOT_APPLICABLE" in p for p in hj.validate(case)))

    # 3. Same terminology, different product surface.
    case = manifest_with(_hist_item(surface_match="DIFFERENT"))
    check("HN3 wrong surface forces NOT_APPLICABLE",
          any("NOT_APPLICABLE" in p for p in hj.validate(case)))

    # 4. Same failure, different configuration.
    case = manifest_with(_hist_item(configuration_match="DIFFERENT"))
    check("HN4 different configuration forces NOT_APPLICABLE",
          any("NOT_APPLICABLE" in p for p in hj.validate(case)))

    # 5. Historical Actual Result resembling current desired behavior.
    case = manifest_with(_hist_item(
        evidence_kind="ACTUAL_RESULT", relationship="AUTHORITATIVE_HISTORY",
        allowed_use="ESTABLISH_ANSWER", feature_match="SAME",
        failure_mode_match="SAME", expected_behavior_match="SAME",
        currentness="CURRENT", authority_basis="existing policy rule"))
    problems = hj.validate(case)
    check("HN5 historical Actual Result never becomes authoritative",
          any("remains an" in p and "observation" in p for p in problems))

    # 6. Historical Human AC with no current applicability proof.
    case = manifest_with(_hist_item(
        relationship="AUTHORITATIVE_HISTORY", allowed_use="ESTABLISH_ANSWER",
        evidence_kind="ACCEPTED_AC", feature_match="SAME",
        failure_mode_match="SAME", expected_behavior_match="SAME",
        currentness="CURRENT", human_accepted_ac_available=True,
        applicability="same surface, version unknown"))
    problems = hj.validate(case)
    check("HN6 historical Human AC without an authority rule is not "
          "automatically authoritative",
          any("authority_basis" in p for p in problems))

    # 7. Historical ticket superseded by newer behavior.
    case = manifest_with(_hist_item(
        relationship="SUPPORTING_PRECEDENT", allowed_use="SUPPORT_ANSWER",
        feature_match="SAME", failure_mode_match="SAME",
        expected_behavior_match="SAME", superseded_status="SUPERSEDED"))
    check("HN7 superseded history never supports current behavior",
          any("superseded" in p for p in hj.validate(case)))

    # 8. Historical ticket conflicts with the current Human Accepted AC.
    case = manifest_with(_hist_item(
        relationship="CONFLICTING_HISTORY", allowed_use="CONFLICT_SIGNAL",
        expected_behavior_match="DIFFERENT"))
    case["question_resolutions"]["items"][0]["answer"]["source_authority"] = (
        "ACCEPTED_UAC"
    )
    check("HN8 conflict with current Human AC stays unresolved",
          any("silently" in p for p in hj.validate(case)))

    # 9. Historical ticket useful only for finding documentation.
    case = manifest_with(_hist_item(allowed_use="DISCOVERY"))
    case["question_resolutions"]["items"][0]["answer"]["source_ids"] = [
        "EV-H1"
    ]
    problems = hj.validate(case)
    check("HN9 documentation-finding history cannot establish the answer",
          any("cannot directly" in p for p in problems))

    # 10. Multiple similar historical tickets with inconsistent outcomes.
    case = _hist_manifest([
        _hist_item(history_id="HIST-A", relationship="SUPPORTING_PRECEDENT",
                   allowed_use="SUPPORT_ANSWER", feature_match="SAME",
                   failure_mode_match="SAME",
                   expected_behavior_match="SAME", currentness="CURRENT"),
        _hist_item(history_id="HIST-B", relationship="CONFLICTING_HISTORY",
                   allowed_use="CONFLICT_SIGNAL",
                   expected_behavior_match="DIFFERENT"),
    ])
    problems = hj.validate(case)
    check("HN10 inconsistent historical outcomes preserve the conflict",
          any("silently" in p for p in problems))

    # Named regression fixtures (feature names appear only in tests).
    # Translation: historical ticket reveals persistence patterns but cannot
    # override the current approval requirement.
    translation = _hist_manifest([_hist_item(
        relationship="SUPPORTING_PRECEDENT", allowed_use="SUPPORT_ANSWER",
        feature_match="SAME", failure_mode_match="SAME",
        expected_behavior_match="SAME", currentness="CURRENT",
        reason="Historical review-state persistence pattern.")])
    check("Translation: supporting precedent may contribute",
          hj.validate(translation) == [])

    # Native PDF: historical DITA-OT behavior must not establish it.
    native_pdf = _hist_manifest([_hist_item(surface_match="DIFFERENT")])
    check("Native PDF fixture: cross-engine history is NOT_APPLICABLE",
          any("NOT_APPLICABLE" in p for p in hj.validate(native_pdf)))

    # Editor: Old Editor history must not establish New Editor acceptance.
    editor = _hist_manifest([_hist_item(surface_match="DIFFERENT",
                                        relationship="SUPPORTING_PRECEDENT",
                                        allowed_use="SUPPORT_ANSWER")])
    check("Editor fixture: old-surface history is NOT_APPLICABLE",
          any("NOT_APPLICABLE" in p for p in hj.validate(editor)))

    # Assets: 6.5 history must not establish Cloud behavior.
    assets = _hist_manifest([_hist_item(version_match="DIFFERENT")])
    check("Assets fixture: wrong-deployment history is NOT_APPLICABLE",
          any("NOT_APPLICABLE" in p for p in hj.validate(assets)))

    # Unfamiliar fixture: lexically near-identical historical ticket, one
    # material applicability difference; the current question stays
    # unresolved on current evidence.
    unfamiliar = _hist_manifest(
        [_hist_item(configuration_match="DIFFERENT")],
        with_resolution=False)
    unfamiliar["question_resolutions"] = {"items": [{
        "question_ref": "Q-1", "status": "ACCEPTANCE_TBD",
        "decision_reason": "Current evidence does not establish the answer.",
        "material_impact": ["CONFIGURATION"],
        "plausible_answers": ["enabled", "disabled"]}]}
    problems = hj.validate(unfamiliar)
    check("unfamiliar fixture: near-identical history with one material "
          "difference is NOT_APPLICABLE and the question stays TBD",
          any("NOT_APPLICABLE" in p for p in problems)
          and not any("silently" in p for p in problems))
    unfamiliar_fixed = _hist_manifest(
        [_hist_item(configuration_match="DIFFERENT",
                    relationship="NOT_APPLICABLE", allowed_use="NONE")],
        with_resolution=False)
    unfamiliar_fixed["question_resolutions"] = {"items": [{
        "question_ref": "Q-1", "status": "ACCEPTANCE_TBD",
        "decision_reason": "Current evidence does not establish the answer.",
        "material_impact": ["CONFIGURATION"],
        "plausible_answers": ["enabled", "disabled"]}]}
    check("unfamiliar fixture: NOT_APPLICABLE + TBD passes cleanly",
          hj.validate(unfamiliar_fixed) == [])

    print("test_historical_jira_safety_regressions: OK")


def _retrieval_manifest(results, request_over=None, question_id="Q-1"):
    request = {
        "request_id": "REQ-1",
        "question_id": question_id,
        "research_id": "RSH-1",
        "query": "actual query text used",
        "required_source_type": "OFFICIAL_PRODUCT_DOC",
        "product_context": "current release",
        "applicability": "current release",
        "requested_claim": "the claim the question seeks",
        "top_k": 5,
        "retrieval_mode": "PRODUCTION",
        "budget": {"queries_per_question": 1, "chunks_retrieved": 5,
                   "chunks_fetched": 1, "research_rounds": 1},
    }
    request.update(request_over or {})
    rows = []
    for i, over in enumerate(results):
        row = {
            "retrieval_result_id": f"RR-{i}",
            "request_id": "REQ-1",
            "question_id": question_id,
            "source_id": f"SRC-{i}",
            "chunk_id": f"SRC-{i}#c1",
            "rank": i + 1,
            "retrieval_score": 0.9 - 0.1 * i,
            "source_type": "OFFICIAL_PRODUCT_DOC",
            "applicability": "CONFIRMED",
            "relationship": "TOPIC_MATCH",
            "fetched": False,
            "limitations": [],
        }
        row.update(over)
        rows.append(row)
    return {
        "question_plan": {"items": [{
            "question_id": question_id, "category": "CONFIGURATION",
            "question": "Which property controls the behavior?",
            "why_material": "m", "triggering_evidence_ids": [],
            "acceptance_impact": "a", "applicability": "APPLICABLE",
            "research_requirement": "NONE", "status": "RESOLVED"}]},
        "retrieval_requests": {"items": [request]},
        "retrieval_results": {"items": rows},
    }


def test_retrieval_admission() -> None:
    ra = retrieval_admission_mod

    check("absent retrieval blocks pass", ra.validate({}) == [])

    clean = _retrieval_manifest([{
        "relationship": "DECISIVE", "fetched": True,
        "supported_claim": "the property controls the retention period",
        "decisiveness": "directly establishes the requested claim"}])
    check("a fetched confirmed decisive candidate passes",
          ra.validate(clean) == [])

    discovery = _retrieval_manifest([{"relationship": "TOPIC_MATCH"}])
    check("an honest topic-match candidate passes",
          ra.validate(discovery) == [])

    unbound_q = _retrieval_manifest([], request_over={"question_id": "Q-404"})
    check("retrieval bound to a nonexistent question fails",
          any("does not exist" in p for p in ra.validate(unbound_q)))

    no_query = _retrieval_manifest([], request_over={"query": ""})
    check("the actual query used must be recorded",
          any("actual query" in p for p in ra.validate(no_query)))

    over_budget = _retrieval_manifest([], request_over={"top_k": 50})
    check("top_k is bounded - no answer is a valid result",
          any("retrieval budget" in p for p in ra.validate(over_budget)))

    snippet = _retrieval_manifest([{
        "relationship": "SUPPORTS_CLAIM", "fetched": False}])
    problems = ra.validate(snippet)
    check("a search snippet cannot materially support a claim (fetch first)",
          any("fetch" in p.lower() or "ceiling" in p for p in problems))

    wrong_app = _retrieval_manifest([{
        "relationship": "DECISIVE", "fetched": True,
        "applicability": "WRONG",
        "supported_claim": "c", "decisiveness": "d"}])
    check("wrong applicability can never be decisive",
          any("ceiling" in p for p in ra.validate(wrong_app)))

    unclear_app = _retrieval_manifest([{
        "relationship": "DECISIVE", "fetched": True,
        "applicability": "UNCLEAR",
        "supported_claim": "c", "decisiveness": "d"}])
    check("unclear applicability is not confirmed applicability",
          any("ceiling" in p or "CONFIRMED" in p
              for p in ra.validate(unclear_app)))

    unassessed = _retrieval_manifest([{
        "relationship": "SUPPORTS_CLAIM", "fetched": True,
        "applicability": "NOT_ASSESSED"}])
    check("unassessed applicability stays topic match",
          any("ceiling" in p for p in ra.validate(unassessed)))

    stale = _retrieval_manifest([{
        "relationship": "DECISIVE", "fetched": True, "stale": True,
        "supported_claim": "c", "decisiveness": "d"}])
    check("stale retrieval is rejected",
          any("ceiling" in p for p in ra.validate(stale)))

    no_claim = _retrieval_manifest([{
        "relationship": "DECISIVE", "fetched": True}])
    check("decisive requires the exact supported claim",
          any("supported_claim" in p for p in ra.validate(no_claim)))

    mismatched_q = _retrieval_manifest([{
        "relationship": "TOPIC_MATCH", "question_id": "Q-9"}])
    check("candidate question must match the bound request",
          any("does not match" in p for p in ra.validate(mismatched_q)))

    # Historical Jira via RAG routes through H1 before establishing use.
    historical = _retrieval_manifest([{
        "relationship": "SUPPORTS_CLAIM", "fetched": True,
        "is_historical": True, "source_type": "HISTORICAL_JIRA"}])
    check("retrieved historical Jira without an H1 assessment fails",
          any("never bypasses H1" in p for p in ra.validate(historical)))
    historical["historical_jira_assessment"] = {"items": [{
        "history_id": "HIST-1", "question_id": "Q-1",
        "jira_key_or_source_id": "SRC-0", "relationship": "SUPPORTING_PRECEDENT",
        "feature_match": "SAME", "surface_match": "SAME", "version_match": "SAME",
        "configuration_match": "SAME", "failure_mode_match": "SAME",
        "expected_behavior_match": "SAME", "currentness": "CURRENT",
        "superseded_status": "NOT_SUPERSEDED", "human_accepted_ac_available": False,
        "applicability": "current release", "authority_role": "HISTORICAL_JIRA",
        "allowed_use": "SUPPORT_ANSWER", "reason": "r", "limitations": []}]}
    check("retrieved historical Jira with an H1 assessment passes",
          ra.validate(historical) == [])

    # S1: topic-match evidence never makes a question SUFFICIENT.
    s1 = _retrieval_manifest([{"relationship": "TOPIC_MATCH"}])
    s1["evidence_sufficiency"] = {"question_assessments": [{
        "question_ref": "Q-1", "sufficiency_status": "SUFFICIENT",
        "evidence_ids": ["SRC-0#c1"]}]}
    check("TOPIC_MATCH cannot make a question SUFFICIENT",
          any("not an answer" in p for p in ra.validate(s1)))

    # L1: unused/unfetched retrieval never enters AC lineage.
    l1 = _retrieval_manifest([{"relationship": "RELEVANT"}])
    l1["requirement_lineage"] = {
        "sources": [], "tbd_lineage": [], "reviews": [],
        "ac_lineage": [{"ac_id": "AC-1", "evidence_refs": ["SRC-0#c1"]}]}
    check("unused retrieval never contaminates final Source lines",
          any("never enters AC lineage" in p for p in ra.validate(l1)))

    print("test_retrieval_admission: OK")


def test_retrieval_admission_regressions() -> None:
    """Nearby-property, engine/surface/deployment hard negatives."""

    ra = retrieval_admission_mod

    # Nearby configuration hard negative: same numeric value, different
    # property identity -> never admitted as property-specific evidence.
    nearby = _retrieval_manifest([{
        "relationship": "SUPPORTS_CLAIM", "fetched": True,
        "subject_key": "display-limit-property",
        "supported_claim": "the display limit defaults to 25"}],
        request_over={"subject_key": "retention-count-property"})
    problems = ra.validate(nearby)
    check("nearby property with a same-looking value is not evidence",
          any("subject" in p and "ceiling" in p for p in problems))
    exact = _retrieval_manifest([{
        "relationship": "SUPPORTS_CLAIM", "fetched": True,
        "subject_key": "retention-count-property",
        "supported_claim": "the retention count bounds retained entries"}],
        request_over={"subject_key": "retention-count-property"})
    check("exact configuration identity admits supporting evidence",
          ra.validate(exact) == [])

    # Engine/path hard negatives: same terminology, wrong surface.
    for surface in ("native-vs-legacy engine", "new-vs-old editor",
                    "cloud-vs-classic deployment"):
        case = _retrieval_manifest([{
            "relationship": "DECISIVE", "fetched": True,
            "applicability": "WRONG", "supported_claim": "c",
            "decisiveness": "d"}])
        check(f"wrong-surface evidence is never decisive ({surface})",
              any("ceiling" in p for p in ra.validate(case)))

    # Unanswerable-style: unclear overview evidence supports at most, never
    # decides.
    unclear = _retrieval_manifest([{
        "relationship": "SUPPORTS_CLAIM", "fetched": True,
        "applicability": "UNCLEAR"}])
    check("unclear evidence may support but never decides",
          ra.validate(unclear) == [])

    print("test_retrieval_admission_regressions: OK")


def test_retrieval_benchmark() -> None:
    """Offline question-level retrieval benchmark and metrics."""

    rb = retrieval_benchmark_mod
    metrics, problems = rb.evaluate()
    check("benchmark fixture manifest satisfies the admission gate",
          problems == [])

    retrieval = metrics["retrieval"]
    admission = metrics["admission"]
    counts = metrics["counts"]

    check("benchmark covers ten domains plus unanswerable questions",
          counts["questions"] == 12 and counts["answerable"] == 10
          and counts["unanswerable"] == 2)
    check("fixture retrieval recall is complete", retrieval["recall_at_k"] == 1.0)
    check("fixture MRR is computed", retrieval["mrr"] == 0.9)
    check("decisive evidence recall is complete",
          retrieval["decisive_evidence_recall_at_k"] == 1.0)
    check("hard negatives ARE retrieved (retrieval is not admission)",
          retrieval["hard_negative_retrieval_rate"] == 1.0)
    check("no hard negative is ever ADMITTED as establishing",
          admission["wrong_version_admission_rate"] == 0.0
          and admission["wrong_surface_admission_rate"] == 0.0
          and admission["topic_match_as_proof_rate"] == 0.0)
    check("fetch-before-use compliance is total",
          admission["fetch_before_use_compliance"] == 1.0)
    check("the headline metric is zero: no decisive misadmission",
          admission["decisive_evidence_misadmission_rate"] == 0.0)
    check("unanswerable questions produce no hallucinated answers",
          admission["unanswerable_false_answer_rate"] == 0.0)
    check("retrieval and admission are reported separately",
          set(retrieval) & set(admission) == set())

    smoke = rb.live_smoke()
    check("live smoke reports gateway status honestly without writing",
          isinstance(smoke, dict) and "status" in smoke)

    print("test_retrieval_benchmark: OK")
    print(f"  retrieval metrics: {json.dumps(retrieval, sort_keys=True)}")
    print(f"  admission metrics: {json.dumps(admission, sort_keys=True)}")


def _lineage_fixture():
    """Compact complete chain for the lineage tests: one accepted behavior
    traced from the ticket source to the reviewed AC, plus one TBD question."""

    return {
        "question_plan": {"items": [
            {"question_id": "Q-1", "category": "EXPECTED_OUTCOME",
             "question": "What must the panel show after the fix?",
             "why_material": "m", "triggering_evidence_ids": ["EV-1"],
             "acceptance_impact": "a", "applicability": "APPLICABLE",
             "research_requirement": "NONE", "status": "RESOLVED"},
            {"question_id": "Q-2", "category": "SCOPE",
             "question": "Which entries does the control apply to?",
             "why_material": "m", "triggering_evidence_ids": ["EV-1"],
             "acceptance_impact": "a", "applicability": "APPLICABLE",
             "research_requirement": "DOCUMENTATION", "status": "RESOLVED"},
        ]},
        "question_research": {"items": [
            {"question_ref": "Q-1", "material": True,
             "research_requirement": "NONE", "research_status": "NOT_REQUIRED"},
            {"question_ref": "Q-2", "material": True,
             "research_requirement": "DOCUMENTATION",
             "research_status": "PARTIAL", "research_requests": ["RQ-2"],
             "research_evidence_ids": ["EV-1"]},
        ]},
        "question_resolutions": {"items": [
            {"question_ref": "Q-1", "status": "ANSWERED",
             "decision_reason": "The ticket establishes it.",
             "answer": {"claim": "The panel shows the saved state.",
                        "source_ids": ["EV-1"],
                        "source_authority": "CURRENT_TICKET_REQUIREMENT",
                        "applicability": "current", "limitations": [],
                        "contradictions": []}},
            {"question_ref": "Q-2", "status": "ACCEPTANCE_TBD",
             "decision_reason": "The scope is not documented.",
             "material_impact": ["SCOPE"],
             "plausible_answers": ["all entries", "only outputs"]},
        ]},
        "doc_research": {
            "routing": {"state": "DOC_RESEARCH_PARTIAL",
                        "triggers": ["CHANGES_DOCUMENTED_FUNCTIONALITY"],
                        "research_id": "DR-1"},
            "results": [{
                "research_id": "DR-1", "status": "DOC_RESEARCH_PARTIAL",
                "produced_by": "uac-doc-researcher", "topics": ["scope"],
                "findings": [{"claim": "The documented baseline covers the "
                              "default mode only.",
                              "source_id": "EV-1",
                              "source_type": "OFFICIAL_DOCUMENTATION",
                              "authority": "OFFICIAL_PRODUCT_CONTRACT",
                              "applicability": "current",
                              "currentness": "CURRENT",
                              "evidence_role": "EXISTING_BEHAVIOR"}],
                "source_ids": ["EV-1"], "applicability": "current",
                "limitations": ["Scope undocumented."], "conflicts": [],
                "question_refs": ["Q-2"]}],
            "admitted_research_ids": ["DR-1"],
        },
        "coverage_decisions": {
            "items": [{
                "coverage_id": "COV-1", "behavior": "The panel shows the "
                "saved state.", "question_ids": ["Q-1"],
                "evidence_ids": ["EV-1"], "research_ids": [],
                "priority": "P0", "coverage_class": "ACCEPTANCE",
                "contract_type": "POSITIVE", "surface": "the panel",
                "state_or_transition": "", "configuration": "",
                "applicability": "current release", "reason": "r",
                "acceptance_impact": "a", "dimensions_considered": [],
            }],
            "writer_handoff": ["COV-1"],
        },
        "writer_package": {"acs": [{
            "ac_id": "AC-1", "text": "The panel shows the saved state.",
            "coverage_ids": ["COV-1"]}]},
        "requirement_lineage": {
            "sources": [{
                "source_id": "SRC-1", "source_type": "JIRA_EXPECTED_RESULT",
                "source_locator": "jira:current", "source_version": "r1",
                "authority_role": "CURRENT_TICKET_REQUIREMENT",
                "applicability": "current release", "status": "ADMITTED",
                "evidence_ids": ["EV-1"],
            }],
            "ac_lineage": [{
                "ac_id": "AC-1", "coverage_refs": ["COV-1"],
                "equivalence_refs": [], "question_refs": ["Q-1"],
                "evidence_refs": ["EV-1"], "research_refs": [],
                "source_refs": ["SRC-1"], "writer_revision": "w1",
                "source_versions": {"SRC-1": "r1"},
                "human_source_line": "Source: the ticket's accepted "
                "requirement",
            }],
            "tbd_lineage": [{
                "question_ref": "Q-2", "research_refs": ["DR-1"],
                "research_status": "PARTIAL", "sufficiency": "INSUFFICIENT",
                "disposition": "ACCEPTANCE_TBD",
                "reason_unresolved": "The retention scope is not documented.",
                "evidence_refs": ["EV-1"], "source_refs": ["SRC-1"],
            }],
            "reviews": [{
                "review_id": "REV-1", "reviewed_writer_revision": "w1",
                "ac_ids": ["AC-1"], "decision": "APPROVED",
                "failures": [], "upstream_refs": [],
            }],
        },
    }


def _synthetic_runtime_result():
    """Minimal canonical runtime result dict (envelope shape) for projection
    tests - no backend import needed."""

    return {
        "run_id": "run:synthetic-1",
        "status": "needs_human_review",
        "runtime_id": "aem-guides-test-plan-runtime",
        "runtime_version": "2.0.0",
        "output_payload": {
            "missing_questions": [
                {"question_id": "question:aaa", "question_text": "Q one?",
                 "blocking": False, "question_revision": "rev1"},
                {"question_id": "question:bbb", "question_text": "Q two?",
                 "blocking": True, "question_revision": "rev2"},
            ],
            "question_research": [
                {"question_id": "question:aaa",
                 "research_requirement": "DOCUMENTATION",
                 "research_status": "ANSWER_FOUND",
                 "research_request_ids": ["retrieval:1"],
                 "evidence_ids": ["ev:1"], "reason": "r"},
                {"question_id": "question:bbb",
                 "research_requirement": "NONE",
                 "research_status": "NOT_REQUIRED",
                 "research_request_ids": [], "evidence_ids": [],
                 "reason": "r"},
            ],
            "behavior_classifications": [
                {"disposition_id": "disposition:1",
                 "behavior_class": "NEW_REQUIREMENT",
                 "existing_evidence_ids": [],
                 "requested_evidence_ids": ["ev:1"],
                 "change_evidence_ids": [], "rationale": "ticket only"},
            ],
            "coverage_dispositions": [
                {"disposition_id": "disposition:1",
                 "candidate": "The retained entry persists.",
                 "disposition": "PROPOSED_ACCEPTANCE_CONTRACT",
                 "source_question_ids": ["question:aaa"],
                 "evidence_ids": ["ev:1"], "rationale": "r"},
            ],
            "promotion_decisions": [
                {"candidate_id": "candidate:1", "status": "PROMOTED",
                 "reasons": []},
            ],
            "acceptance_candidates": [
                {"candidate_id": "candidate:1",
                 "statement": "The retained entry persists.",
                 "source_disposition_ids": ["disposition:1"]},
            ],
            "gate_decisions": [
                {"gate": "AcceptancePromotionGate", "status": "PASSED"},
            ],
        },
        "trace": {"stage_trace": [{"stage": "ContractFactExtractor"}],
                  "human_clarifications": []},
    }


def test_canonical_runtime_projection() -> None:
    adapter = runtime_adapter_mod

    # Envelope-shaped input.
    manifest, meta = adapter.project_runtime_result(_synthetic_runtime_result())
    check("research records project losslessly",
          manifest["question_research"]["items"][0]["question_ref"]
          == "question:aaa"
          and manifest["question_research"]["items"][0]["research_requests"]
          == ["retrieval:1"])
    check("classification target refs are rebound to disposition ids",
          manifest["behavior_classification"]["items"][0]["target_ref"]
          == "disposition:1")
    check("coverage class maps only exact equivalents",
          manifest["coverage_decisions"]["items"][0]["coverage_class"]
          == "ACCEPTANCE")
    check("coverage priority is never reconstructed",
          manifest["coverage_decisions"]["items"][0]["priority"]
          == adapter.UNAVAILABLE_FROM_RUNTIME
          and "coverage_decisions.priority" in meta["lossy_fields"])
    check("runtime metadata preserved",
          meta["runtime_revision"] == "run:synthetic-1"
          and meta["adapter_version"].startswith("aem-guides-runtime-projection"))
    check("unavailable blocks are recorded, never fabricated",
          "evidence_sufficiency" in meta["unavailable_fields"]
          and "evidence_sufficiency" not in manifest
          and "coverage_equivalence" not in manifest)

    # Pipeline-result-shaped input (qe_review_package path).
    wrapped = {"qe_review_package": {"canonical_result": {
        "run_id": "run:synthetic-1", "status": "needs_human_review",
        "output_payload": _synthetic_runtime_result()["output_payload"],
        "trace": {"stage_trace": []},
    }}}
    manifest2, meta2 = adapter.project_runtime_result(wrapped)
    check("pipeline-result shape projects identically",
          manifest2["question_research"] == manifest["question_research"])

    print("test_canonical_runtime_projection: OK")


def test_runtime_replay_modes() -> None:
    adapter = runtime_adapter_mod
    manifest, _meta = adapter.project_runtime_result(_synthetic_runtime_result())
    report = run_gates_mod.replay_runtime_projection(manifest)
    statuses = {row["gate"]: row["status"] for row in report["gate_results"]}

    check("evaluable gates run for real",
          statuses["question-research"] in {"PASS", "FAIL"})
    check("absent contracts are NOT_EVALUABLE, never fabricated PASS",
          statuses["evidence-sufficiency"] == "NOT_EVALUABLE"
          and statuses["coverage-equivalence"] == "NOT_EVALUABLE"
          and statuses["historical-jira-safety"] == "NOT_EVALUABLE")
    check("projection quality is honestly PARTIAL",
          report["projection_quality"] == "PARTIAL")
    check("promotion replay agrees on the clean fixture",
          report["runtime_promotion_status"] == "AGREES")

    # Deliberate disagreement: research-pending question bound to the promoted
    # candidate -> DISAGREEMENT, artifact untouched.
    tampered = json.loads(json.dumps(manifest))
    tampered["question_research"]["items"][0]["research_status"] = "PENDING"
    report2 = run_gates_mod.replay_runtime_projection(tampered)
    check("research-pending promoted question yields DISAGREEMENT",
          report2["runtime_promotion_status"] == "DISAGREES"
          and report2["disagreements"][0]["severity"]
          == "BLOCKING_POLICY_DIVERGENCE")
    check("replay never repairs the artifact",
          manifest["question_research"]["items"][0]["research_status"]
          == "ANSWER_FOUND")

    # Unavailable information: stripped research block -> NOT_EVALUABLE.
    stripped = json.loads(json.dumps(manifest))
    del stripped["question_research"]
    stripped["_projection"]["unavailable_fields"] = sorted(
        set(stripped["_projection"]["unavailable_fields"]) | {"question_research"}
    )
    report3 = run_gates_mod.replay_runtime_projection(stripped)
    statuses3 = {row["gate"]: row["status"] for row in report3["gate_results"]}
    check("stripped information is NOT_EVALUABLE, not PASS",
          statuses3["question-research"] == "NOT_EVALUABLE"
          and report3["runtime_promotion_status"] == "NOT_EVALUABLE")

    print("test_runtime_replay_modes: OK")


def test_requirement_lineage() -> None:
    rl = requirement_lineage_mod

    check("absent requirement_lineage passes", rl.validate({}) == [])
    fixture = _lineage_fixture()
    check("complete lineage fixture passes", rl.validate(fixture) == [])
    for line in rl.trace_ac(fixture, "AC-1"):
        print(f"  lineage trace: {line}")

    # 1. Every final AC has complete lineage.
    missing = _lineage_fixture()
    missing["requirement_lineage"]["ac_lineage"] = []
    check("a Writer AC without lineage fails",
          any("no lineage" in p for p in rl.validate(missing)))

    # 2. The Writer cannot fabricate lineage.
    fabricated = _lineage_fixture()
    fabricated["requirement_lineage"]["ac_lineage"][0]["coverage_refs"] = [
        "COV-99"
    ]
    check("fabricated coverage lineage fails",
          any("does not exist" in p for p in rl.validate(fabricated)))
    fabricated = _lineage_fixture()
    fabricated["requirement_lineage"]["ac_lineage"][0]["research_refs"] = [
        "DR-99"
    ]
    check("invented research IDs fail",
          any("not a Doc Researcher result" in p for p in rl.validate(fabricated)))
    fabricated = _lineage_fixture()
    fabricated["requirement_lineage"]["ac_lineage"][0]["question_refs"] = [
        "Q-1", "Q-99"
    ]
    check("fabricated question lineage fails",
          any("does not exist" in p or "fabricated or dropped" in p
              for p in rl.validate(fabricated)))

    # 3. An unused retrieved source never appears in a Source line.
    contaminated = _lineage_fixture()
    contaminated["requirement_lineage"]["sources"].append({
        "source_id": "SRC-UNUSED", "source_type": "OTHER_APPROVED_SOURCE",
        "source_locator": "doc:nearby", "status": "RETRIEVED",
        "evidence_ids": ["EV-UNUSED"],
    })
    contaminated["requirement_lineage"]["ac_lineage"][0]["source_refs"] = [
        "SRC-1", "SRC-UNUSED"
    ]
    check("unused retrieved source contaminating lineage fails",
          any("unused" in p or "exactly the admitted" in p
              for p in rl.validate(contaminated)))

    # 9. Unrelated evidence never contaminates AC lineage.
    contaminated = _lineage_fixture()
    contaminated["requirement_lineage"]["ac_lineage"][0]["evidence_refs"] = [
        "EV-1", "EV-UNRELATED"
    ]
    check("unrelated evidence in AC lineage fails",
          any("never contaminates" in p or "traces to no original source" in p
              for p in rl.validate(contaminated)))

    # 7. A Writer change makes the review stale.
    stale_review = _lineage_fixture()
    stale_review["requirement_lineage"]["ac_lineage"][0]["writer_revision"] = "w2"
    check("Writer change after review is stale",
          any("never reused across changed drafts" in p
              for p in rl.validate(stale_review)))

    # 8. A source revision invalidates dependent lineage.
    stale_source = _lineage_fixture()
    stale_source["requirement_lineage"]["sources"][0]["source_version"] = "r2"
    check("source revision invalidates dependent lineage",
          any("invalidates the dependent lineage" in p
              for p in rl.validate(stale_source)))

    # 10. Human UAC output never exposes internal lineage jargon.
    jargon = _lineage_fixture()
    jargon["requirement_lineage"]["ac_lineage"][0]["human_source_line"] = (
        "Source: COV-1 via canonical_outcome"
    )
    check("internal jargon in the human Source line fails",
          any("internal" in p for p in rl.validate(jargon)))

    # 5. Unsuccessful research stays visible for TBD.
    missing_tbd = _lineage_fixture()
    missing_tbd["requirement_lineage"]["tbd_lineage"] = []
    check("TBD without lineage disappears -> fails",
          any("never disappear" in p for p in rl.validate(missing_tbd)))
    bad_tbd = _lineage_fixture()
    bad_tbd["requirement_lineage"]["tbd_lineage"][0]["ac_refs"] = ["AC-1"]
    check("a TBD path never references a confirmed AC",
          any("never references a confirmed AC" in p
              for p in rl.validate(bad_tbd)))

    # A question never cites nonexistent evidence.
    broken = _lineage_fixture()
    broken["question_plan"]["items"][0]["triggering_evidence_ids"] = ["EV-404"]
    check("question citing nonexistent evidence fails",
          any("nonexistent evidence" in p for p in rl.validate(broken)))

    print("test_requirement_lineage: OK")


def _deepcopy(value):
    import copy
    return copy.deepcopy(value)


def test_requirement_lineage_regressions() -> None:
    """Lineage traces: the named Output History and Translation fixtures plus
    an unfamiliar structurally different fixture."""

    rl = requirement_lineage_mod

    def question(qid, category, requirement, evidence):
        return {"question_id": qid, "category": category,
                "question": f"What does {qid} establish?",
                "why_material": "m", "triggering_evidence_ids": evidence,
                "acceptance_impact": "a", "applicability": "APPLICABLE",
                "research_requirement": requirement, "status": "RESOLVED"}

    def resolution(ref, status, authority="CURRENT_TICKET_REQUIREMENT",
                   **over):
        item = {"question_ref": ref, "status": status,
                "decision_reason": "Recorded from the cited evidence."}
        if status == "ANSWERED":
            item["answer"] = {
                "claim": f"Answer for {ref}.",
                "source_ids": [f"EV-{ref[1:].lstrip('-')}"],
                "source_authority": authority, "applicability": "current",
                "limitations": [], "contradictions": []}
        item.update(over)
        return item

    def research(ref, requirement, status):
        item = {"question_ref": ref, "material": True,
                "research_requirement": requirement,
                "research_status": status}
        if status not in {"NOT_REQUIRED", "PENDING"}:
            item["research_requests"] = [f"RQ-{ref}"]
        return item

    def coverage(cid, qid, priority, klass, research_ids=None,
                 contract="POSITIVE"):
        return {
            "coverage_id": cid, "behavior": f"Coverage from {qid}.",
            "question_ids": [qid], "evidence_ids": [f"EV-{qid[1:].lstrip('-')}"],
            "research_ids": research_ids or [], "priority": priority,
            "coverage_class": klass, "contract_type": contract,
            "surface": "the affected surface", "state_or_transition": "",
            "configuration": "", "applicability": "current release",
            "reason": "r", "acceptance_impact": "a",
            "dimensions_considered": [],
        }

    # --- Output History lineage fixture -----------------------------------
    output_history = {
        "question_plan": {"items": [
            question("Q-O1", "EXPECTED_OUTCOME", "DOCUMENTATION", ["EV-O1"]),
            question("Q-O2", "VARIANT", "NONE", ["EV-O2"]),
            question("Q-O3", "VARIANT", "NONE", ["EV-O3"]),
            question("Q-O5", "SCOPE", "DOCUMENTATION", ["EV-O5"]),
        ]},
        "question_research": {"items": [
            research("Q-O1", "DOCUMENTATION", "ANSWER_FOUND"),
            research("Q-O2", "NONE", "NOT_REQUIRED"),
            research("Q-O3", "NONE", "NOT_REQUIRED"),
            research("Q-O5", "DOCUMENTATION", "PARTIAL"),
        ]},
        "question_resolutions": {"items": [
            resolution("Q-O1", "ANSWERED", "OFFICIAL_DOCUMENTATION",
                       research_ids=["DR-O"]),
            resolution("Q-O2", "ANSWERED"),
            resolution("Q-O3", "ANSWERED"),
            resolution("Q-O5", "ACCEPTANCE_TBD", material_impact=["SCOPE"],
                       plausible_answers=["all entries", "outputs only"]),
        ]},
        "doc_research": {
            "routing": {"state": "DOC_RESEARCH_PARTIAL",
                        "triggers": ["CHANGES_DOCUMENTED_FUNCTIONALITY"],
                        "research_id": "DR-O"},
            "results": [{
                "research_id": "DR-O", "status": "DOC_RESEARCH_PARTIAL",
                "produced_by": "uac-doc-researcher",
                "topics": ["baseline purge"],
                "findings": [{"claim": "The documented baseline purges aged "
                              "entries.",
                              "source_id": "EV-O1",
                              "source_type": "OFFICIAL_DOCUMENTATION",
                              "authority": "OFFICIAL_PRODUCT_CONTRACT",
                              "applicability": "current",
                              "currentness": "CURRENT",
                              "evidence_role": "EXISTING_BEHAVIOR"}],
                "source_ids": ["EV-O1"], "applicability": "current",
                "limitations": ["The count scope is not documented."],
                "conflicts": [], "question_refs": ["Q-O1", "Q-O5"]}],
            "admitted_research_ids": ["DR-O"],
        },
        "coverage_decisions": {
            "items": [
                coverage("COV-O2", "Q-O2", "P0", "ACCEPTANCE"),
                coverage("COV-O3", "Q-O3", "P0", "ACCEPTANCE"),
                coverage("COV-O1", "Q-O1", "P1", "QE_REGRESSION",
                         ["DR-O"], contract="PRESERVATION"),
            ],
            "writer_handoff": ["COV-O2", "COV-O3", "COV-O1"],
        },
        "writer_package": {"acs": [
            {"ac_id": "AC-O1", "text": "The new count retention holds.",
             "coverage_ids": ["COV-O2"]},
            {"ac_id": "AC-O2", "text": "The log-only action retains logs.",
             "coverage_ids": ["COV-O3"]},
        ]},
        "requirement_lineage": {
            "sources": [
                {"source_id": "SRC-TICKET",
                 "source_type": "JIRA_EXPECTED_RESULT",
                 "source_locator": "jira:current", "source_version": "r1",
                 "authority_role": "CURRENT_TICKET_REQUIREMENT",
                 "applicability": "current release", "status": "ADMITTED",
                 "evidence_ids": ["EV-O2", "EV-O3", "EV-O5"]},
                {"source_id": "SRC-DOC", "source_type": "OFFICIAL_PRODUCT_DOC",
                 "source_locator": "doc:baseline", "source_version": "r1",
                 "authority_role": "OFFICIAL_DOCUMENTATION",
                 "applicability": "current release", "status": "ADMITTED",
                 "evidence_ids": ["EV-O1"]},
            ],
            "ac_lineage": [
                {"ac_id": "AC-O1", "coverage_refs": ["COV-O2"],
                 "equivalence_refs": [], "question_refs": ["Q-O2"],
                 "evidence_refs": ["EV-O2"], "research_refs": [],
                 "source_refs": ["SRC-TICKET"], "writer_revision": "w1",
                 "source_versions": {"SRC-TICKET": "r1"},
                 "human_source_line": "Source: the ticket's accepted "
                 "requirement"},
                {"ac_id": "AC-O2", "coverage_refs": ["COV-O3"],
                 "equivalence_refs": [], "question_refs": ["Q-O3"],
                 "evidence_refs": ["EV-O3"], "research_refs": [],
                 "source_refs": ["SRC-TICKET"], "writer_revision": "w1",
                 "source_versions": {"SRC-TICKET": "r1"},
                 "human_source_line": "Source: the ticket's accepted "
                 "requirement"},
            ],
            "tbd_lineage": [{
                "question_ref": "Q-O5", "research_refs": ["DR-O"],
                "research_status": "PARTIAL", "sufficiency": "INSUFFICIENT",
                "disposition": "ACCEPTANCE_TBD",
                "reason_unresolved": "The count retention scope is not "
                "documented.",
                "evidence_refs": [], "source_refs": [],
            }],
            "reviews": [{
                "review_id": "REV-O1", "reviewed_writer_revision": "w1",
                "ac_ids": ["AC-O1", "AC-O2"], "decision": "APPROVED",
                "failures": [], "upstream_refs": [],
            }],
        },
    }
    problems = rl.validate(output_history)
    check("Output History lineage fixture is clean", problems == [])
    print("  lineage trace [Output History]:")
    for line in rl.trace_ac(output_history, "AC-O1"):
        print(f"    {line}")
    print("    TBD: Q-O5 -> DR-O PARTIAL -> INSUFFICIENT -> ACCEPTANCE_TBD "
          "(visible, never an AC)")

    # The baseline documentation never appears in the new-behavior lineage.
    contaminated = _deepcopy(output_history)
    contaminated["requirement_lineage"]["ac_lineage"][0]["source_refs"] = [
        "SRC-TICKET", "SRC-DOC"
    ]
    check("baseline documentation never appears in the new-behavior lineage",
          any("exactly the admitted sources" in p
              for p in rl.validate(contaminated)))

    # --- Translation lineage fixture: the merge keeps member classes; the
    # QE_REGRESSION member is supporting lineage, never acceptance authority.
    translation = {
        "question_plan": {"items": [
            question("Q-T1", "PRESERVATION", "NONE", ["EV-T1"]),
            question("Q-T2", "NEGATIVE_CONTRACT", "NONE", ["EV-T2"]),
            question("Q-T4", "PERSISTENCE", "NONE", ["EV-T4"]),
        ]},
        "question_research": {"items": [
            research("Q-T1", "NONE", "NOT_REQUIRED"),
            research("Q-T2", "NONE", "NOT_REQUIRED"),
            research("Q-T4", "NONE", "NOT_REQUIRED"),
        ]},
        "question_resolutions": {"items": [
            resolution("Q-T1", "ANSWERED"),
            resolution("Q-T2", "ANSWERED"),
            resolution("Q-T4", "INVESTIGATION_ONLY",
                       investigation_topic="ROOT_CAUSE",
                       decision_reason="Root cause is investigation, not "
                       "acceptance."),
        ]},
        "coverage_decisions": {
            "items": [
                coverage("COV-T1", "Q-T1", "P0", "ACCEPTANCE"),
                coverage("COV-T2", "Q-T2", "P1", "QE_REGRESSION",
                         contract="NEGATIVE"),
            ],
            "writer_handoff": ["COV-T1", "COV-T2"],
        },
        "coverage_equivalence": {
            "decisions": [{
                "decision_id": "EQ-T1", "left_coverage_id": "COV-T1",
                "right_coverage_id": "COV-T2",
                "classification": "SAME_OUTCOME_VARIANT",
                "shared_dimensions": ["EXPECTED_OUTCOME", "APPLICABILITY"],
                "differing_dimensions": ["QUESTION_IDS"],
                "reason": "Same persistence outcome, positive and negative "
                "form.",
                "merge_allowed": True,
            }],
            "merges": [{
                "equivalence_id": "EQG-T1",
                "coverage_refs": ["COV-T1", "COV-T2"],
                "classification": "SAME_OUTCOME_VARIANT",
                "canonical_outcome": "The approved state persists across a "
                "refresh.",
                "priority": "P0",
                "question_refs": ["Q-T1", "Q-T2"],
                "evidence_refs": ["EV-T1", "EV-T2"],
                "variant_refs": ["positive assertion", "negative assertion"],
                "source_lineage": ["COV-T1", "COV-T2"],
            }],
        },
        "writer_package": {"acs": [{
            "ac_id": "AC-T1", "text": "The approved state persists.",
            "coverage_ids": ["COV-T1"], "equivalence_refs": ["EQG-T1"],
            "variants": ["positive assertion", "negative assertion"]}]},
        "requirement_lineage": {
            "sources": [{
                "source_id": "SRC-T", "source_type": "JIRA_EXPECTED_RESULT",
                "source_locator": "jira:current", "source_version": "r1",
                "authority_role": "CURRENT_TICKET_REQUIREMENT",
                "applicability": "current release", "status": "ADMITTED",
                "evidence_ids": ["EV-T1", "EV-T2", "EV-T4"],
            }],
            "ac_lineage": [{
                "ac_id": "AC-T1", "coverage_refs": ["COV-T1"],
                "equivalence_refs": ["EQG-T1"],
                "question_refs": ["Q-T1", "Q-T2"],
                "evidence_refs": ["EV-T1", "EV-T2"], "research_refs": [],
                "source_refs": ["SRC-T"], "writer_revision": "w1",
                "source_versions": {"SRC-T": "r1"},
                "human_source_line": "Source: the ticket's accepted "
                "requirement",
            }],
            "tbd_lineage": [],
            "reviews": [{
                "review_id": "REV-T1", "reviewed_writer_revision": "w1",
                "ac_ids": ["AC-T1"], "decision": "APPROVED",
                "failures": [], "upstream_refs": [],
            }],
        },
    }
    problems = rl.validate(translation)
    check("Translation lineage fixture is clean (merge member classes kept)",
          problems == [])
    print("  lineage trace [Translation]:")
    for line in rl.trace_ac(translation, "AC-T1"):
        print(f"    {line}")
    print("    EQG-T1 members: COV-T1 P0/ACCEPTANCE (acceptance authority), "
          "COV-T2 P1/QE_REGRESSION (supporting/regression lineage only)")

    # 6. A QE_REGRESSION member never becomes acceptance authority through E1.
    no_authority = _deepcopy(translation)
    no_authority["requirement_lineage"]["ac_lineage"][0]["coverage_refs"] = [
        "COV-T2"
    ]
    no_authority["requirement_lineage"]["ac_lineage"][0]["question_refs"] = [
        "Q-T1", "Q-T2"
    ]
    no_authority["requirement_lineage"]["ac_lineage"][0]["evidence_refs"] = [
        "EV-T1", "EV-T2"
    ]
    check("QE_REGRESSION member cannot be the acceptance authority",
          any("never becomes acceptance authority" in p
              for p in rl.validate(no_authority)))

    # The root-cause question never appears in the final AC's lineage.
    contaminated = _deepcopy(translation)
    contaminated["requirement_lineage"]["ac_lineage"][0]["question_refs"] = [
        "Q-T1", "Q-T2", "Q-T4"
    ]
    check("investigation-only question never enters AC lineage",
          any("fabricated or dropped" in p or "does not exist" in p
              for p in rl.validate(contaminated)))

    # --- Unfamiliar fixture: doc-research-backed lineage --------------------
    unfamiliar = {
        "question_plan": {"items": [
            question("Q-U1", "PERSISTENCE", "DOCUMENTATION", ["EV-U1"]),
        ]},
        "question_research": {"items": [
            research("Q-U1", "DOCUMENTATION", "ANSWER_FOUND"),
        ]},
        "question_resolutions": {"items": [
            resolution("Q-U1", "ANSWERED", "OFFICIAL_DOCUMENTATION",
                       research_ids=["DR-U"]),
        ]},
        "doc_research": {
            "routing": {"state": "DOC_RESEARCH_COMPLETED",
                        "triggers": ["CHANGES_DOCUMENTED_FUNCTIONALITY"],
                        "research_id": "DR-U"},
            "results": [{
                "research_id": "DR-U", "status": "DOC_RESEARCH_COMPLETED",
                "produced_by": "uac-doc-researcher", "topics": ["persistence"],
                "findings": [{"claim": "The dialog persists the last used "
                              "folder per user.",
                              "source_id": "EV-U1",
                              "source_type": "OFFICIAL_DOCUMENTATION",
                              "authority": "OFFICIAL_PRODUCT_CONTRACT",
                              "applicability": "current",
                              "currentness": "CURRENT",
                              "evidence_role": "EXISTING_BEHAVIOR"}],
                "source_ids": ["EV-U1"], "applicability": "current",
                "limitations": [], "conflicts": [], "question_refs": ["Q-U1"]}],
            "admitted_research_ids": ["DR-U"],
        },
        "coverage_decisions": {
            "items": [coverage("COV-U1", "Q-U1", "P0", "ACCEPTANCE",
                               ["DR-U"])],
            "writer_handoff": ["COV-U1"],
        },
        "writer_package": {"acs": [{
            "ac_id": "AC-U1", "text": "The dialog restores the last folder.",
            "coverage_ids": ["COV-U1"]}]},
        "requirement_lineage": {
            "sources": [{
                "source_id": "SRC-U", "source_type": "OFFICIAL_PRODUCT_DOC",
                "source_locator": "doc:dialog", "source_version": "r1",
                "authority_role": "OFFICIAL_DOCUMENTATION",
                "applicability": "current release", "status": "ADMITTED",
                "evidence_ids": ["EV-U1"],
            }],
            "ac_lineage": [{
                "ac_id": "AC-U1", "coverage_refs": ["COV-U1"],
                "equivalence_refs": [], "question_refs": ["Q-U1"],
                "evidence_refs": ["EV-U1"], "research_refs": ["DR-U"],
                "source_refs": ["SRC-U"], "writer_revision": "w1",
                "source_versions": {"SRC-U": "r1"},
                "human_source_line": "Source: the documented product "
                "behavior",
            }],
            "tbd_lineage": [],
            "reviews": [{
                "review_id": "REV-U1", "reviewed_writer_revision": "w1",
                "ac_ids": ["AC-U1"], "decision": "APPROVED",
                "failures": [], "upstream_refs": [],
            }],
        },
    }
    check("unfamiliar doc-research lineage is clean",
          rl.validate(unfamiliar) == [])
    print("  lineage trace [unfamiliar fixture]:")
    for line in rl.trace_ac(unfamiliar, "AC-U1"):
        print(f"    {line}")

    # 4. Doc Research contribution stays visible when actually used.
    dropped = _deepcopy(unfamiliar)
    dropped["requirement_lineage"]["ac_lineage"][0]["research_refs"] = []
    check("dropping the contributing research from lineage fails",
          any("stays visible" in p or "must cover" in p
              for p in rl.validate(dropped)))

    print("test_requirement_lineage_regressions: OK")


def test_evidence_sufficiency() -> None:
    es = evidence_sufficiency_mod

    # Backward-compatible: absent block passes.
    check("absent evidence_sufficiency passes", es.validate({}) == [])

    def dims():
        return {name: "evaluated" for name in es.EVALUATION_DIMENSIONS}

    def q_assessment(ref, state, **over):
        base = {
            "question_ref": ref,
            "sufficiency": state,
            "dimensions": dims(),
            "authority_status": "ESTABLISHING",
            "research_completion": "COMPLETED",
            "applicability_status": "APPLICABLE",
            "currentness_status": "CURRENT",
            "contradiction_status": "NONE",
            "supported_claims": [f"The established answer to {ref}."],
            "unsupported_claims": [],
            "limitations": [],
            "evidence_ids": [],
            "research_ids": [],
            "decision_reason": "Evidence evaluated across every dimension.",
            "reason": "Evidence evaluated across every dimension.",
        }
        base.update(over)
        return base

    def c_assessment(ref, state, question_refs, **over):
        base = {
            "coverage_ref": ref,
            "sufficiency": state,
            "question_refs": question_refs,
            "reason": "Computed from the underlying questions.",
            "sufficiency_reason": "Computed from the underlying questions.",
            "evidence_ids": [f"EV-{qid}" for qid in question_refs],
            "research_ids": [],
        }
        base.update(over)
        return base

    def coverage(cid, qids, priority="P0", klass="ACCEPTANCE", evidence=None):
        return {
            "coverage_id": cid,
            "behavior": f"Coverage derived from {qids}.",
            "question_ids": qids,
            "evidence_ids": evidence if evidence is not None
            else [f"EV-{qid}" for qid in qids],
            "priority": priority,
            "coverage_class": klass,
            "positive_or_negative": "POSITIVE",
            "surface": "the affected surface",
            "state": "",
            "configuration": "",
            "applicability": "current release",
            "reason": "Traces to resolved question evidence.",
            "acceptance_impact": "Defines what the Writer may assert.",
            "dimensions_considered": ["STATE_TRANSITIONS"],
        }

    # One authoritative current-ticket AC may be SUFFICIENT on its own.
    solo = {
        "evidence_sufficiency": {
            "question_assessments": [
                q_assessment("Q-1", "SUFFICIENT",
                             establishing_authority="CURRENT_TICKET_REQUIREMENT")],
        }
    }
    check("one authoritative Jira AC may be SUFFICIENT", es.validate(solo) == [])

    # Volume alone is not sufficient without an establishing authority.
    check("supporting volume alone is not SUFFICIENT",
          any("establishing_authority" in p for p in es.validate({
              "evidence_sufficiency": {"question_assessments": [
                  q_assessment("Q-1", "SUFFICIENT")]}})))

    # Every evaluation dimension must be evaluated.
    incomplete = q_assessment("Q-1", "INSUFFICIENT")
    del incomplete["dimensions"]["CONTRADICTIONS"]
    check("unevaluated dimension rejected",
          any("CONTRADICTIONS" in p for p in es.validate({
              "evidence_sufficiency": {"question_assessments": [incomplete]}})))

    # PARTIAL names the established portion; CONFLICTED retains contradictions.
    check("PARTIAL requires the established portion",
          any("established_portion" in p for p in es.validate({
              "evidence_sufficiency": {"question_assessments": [
                  q_assessment("Q-1", "PARTIAL")]}})))
    check("PARTIAL with the established portion passes",
          es.validate({"evidence_sufficiency": {"question_assessments": [
              q_assessment("Q-1", "PARTIAL",
                           established_portion="Only the default mode is "
                           "established.",
                           unsupported_claims=["The multi-mode matrix."])]}}) == [])
    check("CONFLICTED requires contradictions",
          any("contradictions" in p for p in es.validate({
              "evidence_sufficiency": {"question_assessments": [
                  q_assessment("Q-1", "CONFLICTED")]}})))
    check("CONFLICTED with contradictions passes",
          es.validate({"evidence_sufficiency": {"question_assessments": [
              q_assessment("Q-1", "CONFLICTED",
                           contradiction_status="CONFLICTING",
                           contradictions=["DOC-2 disagrees."])]}}) == [])

    # A question requiring documentation cannot be SUFFICIENT while its
    # mandatory research is pending (or otherwise unresolved).
    research_pending = {
        "question_research": {"items": [{
            "question_ref": "Q-1", "material": True,
            "research_requirement": "DOCUMENTATION",
            "research_status": "PENDING"}]},
        "evidence_sufficiency": {"question_assessments": [
            q_assessment("Q-1", "SUFFICIENT")]},
    }
    check("SUFFICIENT over PENDING mandatory research fails",
          any("mandatory research is PENDING" in p
              for p in es.validate(research_pending)))
    research_pending["question_research"]["items"][0]["research_status"] = (
        "NOT_FOUND"
    )
    check("SUFFICIENT over NOT_FOUND research fails",
          any("NOT_FOUND" in p for p in es.validate(research_pending)))
    research_pending["question_research"]["items"][0]["research_status"] = (
        "PARTIAL"
    )
    research_pending["question_research"]["items"][0]["research_requests"] = ["R1"]
    check("SUFFICIENT over PARTIAL research fails",
          any("caps the assessment at PARTIAL" in p
              for p in es.validate(research_pending)))
    research_pending["evidence_sufficiency"]["question_assessments"] = [
        q_assessment("Q-1", "PARTIAL", established_portion="Default mode only.",
                     unsupported_claims=["The multi-mode matrix."],
                     research_completion="PARTIAL")]
    check("PARTIAL under PARTIAL research passes",
          es.validate(research_pending) == [])

    # Coverage sufficiency is computed from the underlying questions.
    base_chain = {
        "question_resolutions": {"items": [{
            "question_ref": "Q-1", "status": "ANSWERED",
            "answer": {"claim": "c", "source_ids": ["JIRA-1"],
                       "source_authority": "CURRENT_TICKET_REQUIREMENT",
                       "applicability": "current", "limitations": [],
                       "contradictions": []}}]},
        "coverage_decisions": {"items": [coverage("COV-1", ["Q-1"])]},
    }
    good = dict(base_chain)
    good["evidence_sufficiency"] = {
        "question_assessments": [q_assessment("Q-1", "SUFFICIENT")],
        "coverage_assessments": [c_assessment("COV-1", "SUFFICIENT", ["Q-1"])],
    }
    check("SUFFICIENT question grounds SUFFICIENT P0 ACCEPTANCE",
          es.validate(good) == [])

    insufficient = dict(base_chain)
    insufficient["evidence_sufficiency"] = {
        "question_assessments": [q_assessment("Q-1", "INSUFFICIENT")],
        "coverage_assessments": [c_assessment("COV-1", "SUFFICIENT", ["Q-1"])],
    }
    check("INSUFFICIENT underneath cannot surface as SUFFICIENT",
          any("only as strong as its underlying" in p
              for p in es.validate(insufficient)))
    insufficient["evidence_sufficiency"]["coverage_assessments"] = [
        c_assessment("COV-1", "INSUFFICIENT", ["Q-1"])]
    check("INSUFFICIENT cannot generate ACCEPTANCE coverage",
          any("cannot generate Acceptance" in p
              for p in es.validate(insufficient)))
    insufficient["coverage_decisions"] = {
        "items": [coverage("COV-1", ["Q-1"], priority="P1", klass="QE_REGRESSION")]
    }
    check("INSUFFICIENT regression coverage passes",
          es.validate(insufficient) == [])

    # CONFLICTED questions cannot silently generate an AC.
    conflicted = dict(base_chain)
    conflicted["question_resolutions"] = {"items": [{
        "question_ref": "Q-1", "status": "CONFLICTED",
        "answer": {"claim": "c", "source_ids": ["JIRA-1"],
                   "source_authority": "CURRENT_TICKET_REQUIREMENT",
                   "applicability": "current", "limitations": [],
                   "contradictions": ["DOC-2 disagrees."]}}]}
    conflicted["evidence_sufficiency"] = {
        "question_assessments": [q_assessment("Q-1", "SUFFICIENT")],
        "coverage_assessments": [c_assessment("COV-1", "SUFFICIENT", ["Q-1"])],
    }
    check("CONFLICTED resolution forces CONFLICTED assessment",
          any("CONFLICTED" in p for p in es.validate(conflicted)))
    conflicted["evidence_sufficiency"]["question_assessments"] = [
        q_assessment("Q-1", "CONFLICTED", contradiction_status="CONFLICTING",
                     contradictions=["DOC-2 disagrees."])]
    check("CONFLICTED question cannot surface SUFFICIENT coverage",
          any("CONFLICTED" in p for p in es.validate(conflicted)))
    conflicted["evidence_sufficiency"]["coverage_assessments"] = [
        c_assessment("COV-1", "CONFLICTED", ["Q-1"])]
    check("CONFLICTED coverage cannot be ACCEPTANCE class",
          any("silently generate an AC" in p for p in es.validate(conflicted)))

    # P0 ACCEPTANCE requires SUFFICIENT unless explicitly ACCEPTANCE_TBD.
    tbd = dict(base_chain)
    tbd["evidence_sufficiency"] = {
        "question_assessments": [q_assessment("Q-1", "PARTIAL",
                                              established_portion="Default mode.",
                                              unsupported_claims=["The multi-"
                                              "mode matrix."])],
        "coverage_assessments": [c_assessment("COV-1", "PARTIAL", ["Q-1"],
                                              established_portion="Default mode.")],
    }
    check("P0 ACCEPTANCE below SUFFICIENT fails without TBD representation",
          any("represented_as_acceptance_tbd" in p for p in es.validate(tbd)))
    tbd["evidence_sufficiency"]["coverage_assessments"] = [
        c_assessment("COV-1", "PARTIAL", ["Q-1"],
                     established_portion="Default mode.",
                     represented_as_acceptance_tbd=True)]
    check("explicit ACCEPTANCE_TBD representation passes",
          es.validate(tbd) == [])

    # The Writer must not receive unsupported coverage as confirmed behavior.
    handoff = dict(base_chain)
    handoff["coverage_decisions"] = {
        "items": [coverage("COV-1", ["Q-1"], priority="P1",
                           klass="QE_REGRESSION")],
        "writer_handoff": ["COV-1"],
    }
    handoff["evidence_sufficiency"] = {
        "question_assessments": [q_assessment("Q-1", "INSUFFICIENT")],
        "coverage_assessments": [c_assessment("COV-1", "INSUFFICIENT", ["Q-1"])],
    }
    check("INSUFFICIENT coverage never reaches the Writer",
          any("must not receive unsupported" in p for p in es.validate(handoff)))
    handoff["evidence_sufficiency"]["coverage_assessments"] = [
        c_assessment("COV-1", "PARTIAL", ["Q-1"])]
    check("PARTIAL in the handoff requires the established portion",
          any("established portion" in p for p in es.validate(handoff)))

    # Lineage: question_refs must match the coverage decision exactly.
    bad_lineage = dict(base_chain)
    bad_lineage["evidence_sufficiency"] = {
        "question_assessments": [q_assessment("Q-1", "SUFFICIENT")],
        "coverage_assessments": [c_assessment("COV-1", "SUFFICIENT", ["Q-2"])],
    }
    check("sufficiency lineage must match the coverage decision",
          any("sufficiency lineage" in p for p in es.validate(bad_lineage)))

    # Reviewer lineage: every non-EXCLUDED decision is assessed.
    missing_assessment = dict(base_chain)
    missing_assessment["evidence_sufficiency"] = {
        "question_assessments": [q_assessment("Q-1", "SUFFICIENT")],
    }
    check("unassessed coverage decision fails",
          any("no sufficiency assessment" in p
              for p in es.validate(missing_assessment)))

    print("test_evidence_sufficiency: OK")


def test_evidence_sufficiency_output_history_regression() -> None:
    """Output History purge regression for evidence sufficiency.

    - Existing AGE behavior: documentation makes the evidence SUFFICIENT.
    - COUNT: the Jira requirement establishes the new behavior -> SUFFICIENT.
    - COUNT scope: unresolved -> INSUFFICIENT / ACCEPTANCE_TBD.
    - LOGS_ONLY: Jira may establish the deletion/preservation contract.
    - Mode/action cross-product: not SUFFICIENT merely because both controls
      exist - it needs evidence that covers the combination.
    """

    es = evidence_sufficiency_mod

    def dims():
        return {name: "evaluated" for name in es.EVALUATION_DIMENSIONS}

    def question(qid, category, text, requirement, evidence):
        return {
            "question_id": qid, "category": category, "question": text,
            "why_material": "The answer changes the acceptance oracle.",
            "triggering_evidence_ids": evidence,
            "acceptance_impact": "Decides what the AC may assert.",
            "applicability": "APPLICABLE",
            "research_requirement": requirement,
            "status": "RESOLVED",
        }

    def research(ref, requirement, status, evidence=None):
        item = {
            "question_ref": ref, "material": True,
            "research_requirement": requirement, "research_status": status,
        }
        if status not in {"NOT_REQUIRED", "PENDING"}:
            item["research_requests"] = [f"RQ-{ref}"]
        if evidence:
            item["research_evidence_ids"] = evidence
        return item

    def resolution(ref, status, authority, sources, **over):
        item = {"question_ref": ref, "status": status,
                "decision_reason": over.pop(
                    "decision_reason",
                    "Recorded from the cited evidence and routing state.")}
        if status in {"ANSWERED", "PARTIALLY_ANSWERED"}:
            item["answer"] = {
                "claim": over.pop("claim", f"Resolved answer for {ref}."),
                "source_ids": sources,
                "source_authority": authority,
                "applicability": "5.0 on-prem",
                "limitations": over.pop("limitations", []),
                "contradictions": over.pop("contradictions", []),
            }
        item.update(over)
        return item

    def q_assessment(ref, state, **over):
        base = {"question_ref": ref, "sufficiency": state,
                "dimensions": dims(),
                "authority_status": "ESTABLISHING",
                "research_completion": "COMPLETED",
                "applicability_status": "APPLICABLE",
                "currentness_status": "CURRENT",
                "contradiction_status": "NONE",
                "supported_claims": [f"The established answer to {ref}."],
                "unsupported_claims": [],
                "limitations": [],
                "evidence_ids": [],
                "research_ids": [],
                "decision_reason": "Evaluated per dimension.",
                "reason": "Evaluated per dimension."}
        base.update(over)
        return base

    def c_assessment(ref, state, refs, **over):
        base = {"coverage_ref": ref, "sufficiency": state,
                "question_refs": refs, "reason": "Computed from questions.",
                "evidence_ids": None, "research_ids": []}
        base.update(over)
        return base

    def coverage(cid, qids, priority, klass, evidence):
        return {
            "coverage_id": cid, "behavior": f"Coverage for {qids}.",
            "question_ids": qids, "evidence_ids": evidence,
            "priority": priority, "coverage_class": klass,
            "positive_or_negative": "POSITIVE",
            "surface": "Map Dashboard Outputs tab", "state": "",
            "configuration": "", "applicability": "5.0 on-prem",
            "reason": "Traces to resolved question evidence.",
            "acceptance_impact": "Defines what the Writer may assert.",
            "dimensions_considered": ["CONFIGURATION_BRANCHES"],
        }

    questions = [
        question("Q-AGE", "EXPECTED_OUTCOME", "What is the documented baseline "
                 "of the existing time-based purge?", "DOCUMENTATION", ["JIRA-1"]),
        question("Q-COUNT", "VARIANT", "Which retention count does the ticket "
                 "add?", "NONE", ["JIRA-1"]),
        question("Q-COUNT-SCOPE", "SCOPE", "Which entries does the count "
                 "retention apply to?", "DOCUMENTATION", ["JIRA-1"]),
        question("Q-LOGS-ONLY", "VARIANT", "What does the log-only action retain "
                 "and delete?", "NONE", ["JIRA-1"]),
        question("Q-MODE", "CONFIGURATION", "Which purge modes exist?", 
                 "DOCUMENTATION", ["JIRA-1"]),
        question("Q-ACTION", "ENTRY_PATH", "Which purge actions exist?",
                 "DOCUMENTATION", ["JIRA-1"]),
    ]
    research_items = [
        research("Q-AGE", "DOCUMENTATION", "ANSWER_FOUND", ["DOC-AGE"]),
        research("Q-COUNT", "NONE", "NOT_REQUIRED"),
        research("Q-COUNT-SCOPE", "DOCUMENTATION", "PARTIAL", ["DOC-AGE"]),
        research("Q-LOGS-ONLY", "NONE", "NOT_REQUIRED"),
        research("Q-MODE", "DOCUMENTATION", "ANSWER_FOUND", ["DOC-MODE"]),
        research("Q-ACTION", "DOCUMENTATION", "ANSWER_FOUND", ["DOC-ACTION"]),
    ]
    resolutions = [
        resolution("Q-AGE", "ANSWERED", "OFFICIAL_DOCUMENTATION", ["DOC-AGE"]),
        resolution("Q-COUNT", "ANSWERED", "CURRENT_TICKET_REQUIREMENT",
                   ["JIRA-1"]),
        resolution("Q-COUNT-SCOPE", "ACCEPTANCE_TBD", None, [],
                   material_impact=["SCOPE"],
                   plausible_answers=["all entries", "only generated outputs"]),
        resolution("Q-LOGS-ONLY", "ANSWERED", "CURRENT_TICKET_REQUIREMENT",
                   ["JIRA-1"]),
        resolution("Q-MODE", "ANSWERED", "OFFICIAL_DOCUMENTATION", ["DOC-MODE"]),
        resolution("Q-ACTION", "ANSWERED", "OFFICIAL_DOCUMENTATION",
                   ["DOC-ACTION"]),
    ]
    coverage_items = [
        coverage("COV-AGE", ["Q-AGE"], "P1", "QE_REGRESSION", ["DOC-AGE"]),
        coverage("COV-COUNT", ["Q-COUNT"], "P0", "ACCEPTANCE", ["JIRA-1"]),
        coverage("COV-COUNT-SCOPE", ["Q-COUNT-SCOPE"], "P1", "QE_REGRESSION",
                 ["DOC-AGE"]),
        coverage("COV-LOGS-ONLY", ["Q-LOGS-ONLY"], "P0", "ACCEPTANCE",
                 ["JIRA-1"]),
        coverage("COV-MODE-ACTION", ["Q-MODE", "Q-ACTION"], "P1",
                 "QE_REGRESSION", ["DOC-MODE", "DOC-ACTION"]),
    ]
    question_assessments = [
        q_assessment("Q-AGE", "SUFFICIENT", evidence_ids=["DOC-AGE"]),
        q_assessment("Q-COUNT", "SUFFICIENT", research_completion="NOT_REQUIRED",
                     evidence_ids=["JIRA-1"]),
        q_assessment("Q-COUNT-SCOPE", "INSUFFICIENT",
                     research_completion="PARTIAL",
                     evidence_ids=["DOC-AGE"],
                     limitations=["The retention scope of the count control is "
                                  "not documented."]),
        q_assessment("Q-LOGS-ONLY", "SUFFICIENT",
                     research_completion="NOT_REQUIRED", evidence_ids=["JIRA-1"]),
        q_assessment("Q-MODE", "SUFFICIENT", evidence_ids=["DOC-MODE"]),
        q_assessment("Q-ACTION", "SUFFICIENT", evidence_ids=["DOC-ACTION"]),
    ]
    coverage_assessments = [
        c_assessment("COV-AGE", "SUFFICIENT", ["Q-AGE"]),
        c_assessment("COV-COUNT", "SUFFICIENT", ["Q-COUNT"]),
        c_assessment("COV-COUNT-SCOPE", "INSUFFICIENT", ["Q-COUNT-SCOPE"]),
        c_assessment("COV-LOGS-ONLY", "SUFFICIENT", ["Q-LOGS-ONLY"]),
        c_assessment("COV-MODE-ACTION", "PARTIAL", ["Q-MODE", "Q-ACTION"],
                     established_portion="Each control alone is established; "
                     "their combination is not."),
    ]
    manifest = {
        "question_plan": {"items": questions},
        "question_research": {"items": research_items},
        "question_resolutions": {"items": resolutions},
        "coverage_decisions": {
            "items": coverage_items,
            "writer_handoff": ["COV-AGE", "COV-COUNT", "COV-LOGS-ONLY"],
        },
        "evidence_sufficiency": {
            "question_assessments": question_assessments,
            "coverage_assessments": coverage_assessments,
        },
    }
    problems = es.validate(manifest)
    check("Output History sufficiency chain is clean", problems == [])

    print("  question trace [Output History sufficiency]:")
    for assessment in question_assessments:
        print(f"    {assessment['question_ref']}: {assessment['sufficiency']}")
    for assessment in coverage_assessments:
        print(f"    {assessment['coverage_ref']}: {assessment['sufficiency']}")

    # Cross-product must not become SUFFICIENT merely because both controls
    # exist: member evidence alone never suffices for the combination.
    manifest["evidence_sufficiency"]["coverage_assessments"] = [
        c_assessment("COV-MODE-ACTION", "SUFFICIENT", ["Q-MODE", "Q-ACTION"]),
    ]
    manifest["coverage_decisions"].pop("writer_handoff")
    manifest["coverage_decisions"]["items"] = [
        row for row in coverage_items
        if row["coverage_id"] == "COV-MODE-ACTION"
    ]
    manifest["question_plan"]["items"] = [
        row for row in questions
        if row["question_id"] in {"Q-MODE", "Q-ACTION"}
    ]
    manifest["evidence_sufficiency"]["question_assessments"] = [
        q_assessment("Q-MODE", "SUFFICIENT"),
        q_assessment("Q-ACTION", "SUFFICIENT"),
    ]
    check("cross-product is not sufficient merely because both controls exist",
          any("combination" in p for p in es.validate(manifest)))
    manifest["evidence_sufficiency"]["coverage_assessments"] = [
        c_assessment("COV-MODE-ACTION", "SUFFICIENT", ["Q-MODE", "Q-ACTION"],
                     combination_evidence_ids=["DOC-CROSS"]),
    ]
    check("combination evidence makes the cross-product sufficient",
          es.validate(manifest) == [])

    print("test_evidence_sufficiency_output_history_regression: OK")


def test_evidence_sufficiency_unfamiliar_ticket() -> None:
    """The same sufficiency contract on a structurally different, unfamiliar
    ticket: different domain, different categories, an ACCEPTED_UAC authority,
    a CONFLICTED path, and a PENDING-research path - no named fixture ticket.
    """

    es = evidence_sufficiency_mod

    def dims():
        return {name: "evaluated" for name in es.EVALUATION_DIMENSIONS}

    def question(qid, category, text, requirement, evidence):
        return {
            "question_id": qid, "category": category, "question": text,
            "why_material": "The answer changes the acceptance oracle.",
            "triggering_evidence_ids": evidence,
            "acceptance_impact": "Decides what the AC may assert.",
            "applicability": "APPLICABLE",
            "research_requirement": requirement,
            "status": "RESOLVED",
        }

    def research(ref, requirement, status, evidence=None):
        item = {
            "question_ref": ref, "material": True,
            "research_requirement": requirement, "research_status": status,
        }
        if status not in {"NOT_REQUIRED", "PENDING"}:
            item["research_requests"] = [f"RQ-{ref}"]
        if evidence:
            item["research_evidence_ids"] = evidence
        return item

    def q_assessment(ref, state, **over):
        base = {"question_ref": ref, "sufficiency": state,
                "dimensions": dims(),
                "authority_status": "ESTABLISHING",
                "research_completion": "COMPLETED",
                "applicability_status": "APPLICABLE",
                "currentness_status": "CURRENT",
                "contradiction_status": "NONE",
                "supported_claims": [f"The established answer to {ref}."],
                "unsupported_claims": [],
                "limitations": [],
                "evidence_ids": [],
                "research_ids": [],
                "decision_reason": "Evaluated per dimension.",
                "reason": "Evaluated per dimension."}
        base.update(over)
        return base

    def c_assessment(ref, state, refs, **over):
        base = {"coverage_ref": ref, "sufficiency": state,
                "question_refs": refs, "reason": "Computed from questions.",
                "evidence_ids": None, "research_ids": []}
        base.update(over)
        return base

    def coverage(cid, qids, priority, klass, evidence):
        return {
            "coverage_id": cid, "behavior": f"Coverage for {qids}.",
            "question_ids": qids, "evidence_ids": evidence,
            "priority": priority, "coverage_class": klass,
            "positive_or_negative": "POSITIVE",
            "surface": "the settings dialog", "state": "",
            "configuration": "", "applicability": "cloud",
            "reason": "Traces to resolved question evidence.",
            "acceptance_impact": "Defines what the Writer may assert.",
            "dimensions_considered": ["CLOUD_65"],
        }

    manifest = {
        "question_plan": {"items": [
            question("Q-U1", "APPLICABILITY", "Which deployments does the "
                     "toggle apply to?", "DOCUMENTATION", ["JIRA-U1"]),
            question("Q-U2", "ERROR_RECOVERY", "What must happen when saving "
                     "the toggle fails?", "NONE", ["JIRA-U1"]),
            question("Q-U3", "NEGATIVE_CONTRACT", "Must the toggle reject "
                     "unknown channels?", "DOCUMENTATION", ["JIRA-U1"]),
            question("Q-U4", "SCALE", "What volume limit applies to the "
                     "queue?", "DOCUMENTATION", ["JIRA-U1"]),
        ]},
        "question_research": {"items": [
            research("Q-U1", "DOCUMENTATION", "ANSWER_FOUND", ["DOC-U1"]),
            research("Q-U2", "NONE", "NOT_REQUIRED"),
            research("Q-U3", "DOCUMENTATION", "CONFLICTED",
                     ["DOC-U3A", "DOC-U3B"]),
            research("Q-U4", "DOCUMENTATION", "PENDING"),
        ]},
        "question_resolutions": {"items": [
            {"question_ref": "Q-U1", "status": "ANSWERED",
             "decision_reason": "The documentation establishes applicability.",
             "answer": {"claim": "The toggle applies on cloud only.",
                        "source_ids": ["DOC-U1"],
                        "source_authority": "OFFICIAL_DOCUMENTATION",
                        "applicability": "cloud", "limitations": [],
                        "contradictions": []}},
            {"question_ref": "Q-U2", "status": "ANSWERED",
             "decision_reason": "The accepted UAC states the failure contract.",
             "answer": {"claim": "A failed save keeps the previous value and "
                        "shows an error.",
                        "source_ids": ["JIRA-U1"],
                        "source_authority": "ACCEPTED_UAC",
                        "applicability": "cloud", "limitations": [],
                        "contradictions": []}},
            {"question_ref": "Q-U3", "status": "CONFLICTED",
             "decision_reason": "Two equally authoritative pages disagree.",
             "answer": {"claim": "Sources disagree on rejecting unknown "
                        "channels.",
                        "source_ids": ["DOC-U3A", "DOC-U3B"],
                        "source_authority": "OFFICIAL_DOCUMENTATION",
                        "applicability": "cloud", "limitations": [],
                        "contradictions": ["DOC-U3A rejects; DOC-U3B accepts."]}},
        ]},
        "coverage_decisions": {
            "items": [
                coverage("COV-U1", ["Q-U1"], "P1", "QE_REGRESSION", ["DOC-U1"]),
                coverage("COV-U2", ["Q-U2"], "P0", "ACCEPTANCE", ["JIRA-U1"]),
                coverage("COV-U3", ["Q-U3"], "P1", "QE_REGRESSION",
                         ["DOC-U3A", "DOC-U3B"]),
                coverage("COV-U4", ["Q-U4"], "SUPPORTING", "QE_REGRESSION",
                         ["JIRA-U1"]),
            ],
            "writer_handoff": ["COV-U2", "COV-U1"],
        },
    }
    # Q-U4 is planned and applicable but unresolved (research still PENDING),
    # so the resolver gate requires its absence to stay visible in the chain:
    # it has no resolution, and the resolver gate's planned-vs-resolved check
    # would fail - the chain stops at the resolver for it. The sufficiency
    # gate therefore assesses it directly as INSUFFICIENT.
    manifest["evidence_sufficiency"] = {
        "question_assessments": [
            q_assessment("Q-U1", "SUFFICIENT", evidence_ids=["DOC-U1"]),
            q_assessment("Q-U2", "SUFFICIENT",
                         research_completion="NOT_REQUIRED",
                         evidence_ids=["JIRA-U1"]),
            q_assessment("Q-U3", "CONFLICTED",
                         research_completion="CONFLICTED",
                         contradiction_status="CONFLICTING",
                         contradictions=["DOC-U3A rejects; DOC-U3B accepts."]),
            q_assessment("Q-U4", "INSUFFICIENT", research_completion="PENDING"),
        ],
        "coverage_assessments": [
            c_assessment("COV-U1", "SUFFICIENT", ["Q-U1"]),
            c_assessment("COV-U2", "SUFFICIENT", ["Q-U2"]),
            c_assessment("COV-U3", "CONFLICTED", ["Q-U3"]),
            c_assessment("COV-U4", "INSUFFICIENT", ["Q-U4"]),
        ],
    }
    problems = es.validate(manifest)
    check("unfamiliar ticket sufficiency chain is clean", problems == [])

    print("  question trace [unfamiliar ticket sufficiency]:")
    for assessment in manifest["evidence_sufficiency"]["question_assessments"]:
        print(f"    {assessment['question_ref']}: {assessment['sufficiency']}")
    for assessment in manifest["evidence_sufficiency"]["coverage_assessments"]:
        print(f"    {assessment['coverage_ref']}: {assessment['sufficiency']}")

    # The conflicted question can never silently become sufficient.
    manifest["evidence_sufficiency"]["question_assessments"][2] = (
        q_assessment("Q-U3", "SUFFICIENT")
    )
    check("CONFLICTED research cannot be assessed SUFFICIENT",
          any("CONFLICTED" in p for p in es.validate(manifest)))

    # The pending-research question can never be assessed SUFFICIENT.
    manifest["evidence_sufficiency"]["question_assessments"][2] = (
        q_assessment("Q-U3", "CONFLICTED",
                     research_completion="CONFLICTED",
                     contradiction_status="CONFLICTING",
                     contradictions=["DOC-U3A rejects; DOC-U3B accepts."])
    )
    manifest["evidence_sufficiency"]["question_assessments"][3] = (
        q_assessment("Q-U4", "SUFFICIENT")
    )
    check("PENDING mandatory research cannot be SUFFICIENT",
          any("mandatory research is PENDING" in p for p in es.validate(manifest)))

    print("test_evidence_sufficiency_unfamiliar_ticket: OK")


def test_evidence_sufficiency_hard_negatives() -> None:
    """Hard negatives: sufficiency never comes from volume, wrong
    applicability, observation-only evidence, unresolved research, or
    neighboring-claim evidence bleed."""

    es = evidence_sufficiency_mod

    def dims():
        return {name: "evaluated" for name in es.EVALUATION_DIMENSIONS}

    def q_assessment(ref, state, **over):
        base = {
            "question_ref": ref,
            "sufficiency": state,
            "dimensions": dims(),
            "authority_status": "ESTABLISHING",
            "research_completion": "COMPLETED",
            "applicability_status": "APPLICABLE",
            "currentness_status": "CURRENT",
            "contradiction_status": "NONE",
            "supported_claims": [f"The established answer to {ref}."],
            "unsupported_claims": [],
            "limitations": [],
            "evidence_ids": [],
            "research_ids": [],
            "decision_reason": "Evaluated per dimension.",
            "reason": "Evaluated per dimension.",
        }
        base.update(over)
        return base

    def wrap(*assessments, **blocks):
        manifest = {"evidence_sufficiency": {"question_assessments": list(assessments)}}
        manifest.update(blocks)
        return manifest

    # Many non-decisive passages are not sufficient; one authoritative source is.
    check("many irrelevant results without establishing authority fail",
          any("establishing_authority" in p for p in es.validate(
              wrap(q_assessment("Q-1", "SUFFICIENT",
                                evidence_ids=["RAG-1", "RAG-2", "RAG-3"])))))
    check("NON_ESTABLISHING authority is never SUFFICIENT",
          any("ESTABLISHING authority_status" in p for p in es.validate(
              wrap(q_assessment("Q-1", "SUFFICIENT",
                                authority_status="NON_ESTABLISHING",
                                establishing_authority="ACCEPTED_UAC")))))
    check("one authoritative source may be SUFFICIENT",
          es.validate(wrap(q_assessment(
              "Q-1", "SUFFICIENT",
              establishing_authority="ACCEPTED_UAC",
              evidence_ids=["UAC-1"]))) == [])

    # Wrong applicability (version/engine/surface) is insufficient without an
    # explicit compatibility bridge; UNCLEAR is never confirmed.
    check("wrong-version evidence is not SUFFICIENT",
          any("wrong-applicability" in p for p in es.validate(
              wrap(q_assessment("Q-1", "SUFFICIENT",
                                applicability_status="WRONG_APPLICABILITY",
                                establishing_authority="OFFICIAL_DOCUMENTATION")))))
    check("explicit compatibility evidence bridges applicability",
          es.validate(wrap(q_assessment(
              "Q-1", "SUFFICIENT",
              applicability_status="WRONG_APPLICABILITY",
              establishing_authority="OFFICIAL_DOCUMENTATION",
              compatibility_evidence_ids=["COMPAT-1"]))) == [])
    check("UNCLEAR applicability is never confirmed",
          any("UNCLEAR" in p for p in es.validate(
              wrap(q_assessment("Q-1", "SUFFICIENT",
                                applicability_status="UNCLEAR",
                                establishing_authority="OFFICIAL_DOCUMENTATION")))))
    check("stale-currentness evidence needs a compatibility bridge",
          any("stale" in p for p in es.validate(
              wrap(q_assessment("Q-1", "SUFFICIENT", currentness_status="STALE",
                                establishing_authority="OFFICIAL_DOCUMENTATION")))))

    # Research completion: NOT_FOUND is not negative proof; PARTIAL caps;
    # PENDING blocks.
    check("NOT_FOUND research cannot be SUFFICIENT",
          any("NOT_FOUND" in p for p in es.validate(
              wrap(q_assessment("Q-1", "SUFFICIENT",
                                research_completion="NOT_FOUND",
                                establishing_authority="ACCEPTED_UAC")))))
    check("NOT_FOUND never establishes the opposite behavior",
          any("opposite" in p for p in es.validate(
              wrap(q_assessment("Q-1", "INSUFFICIENT",
                                research_completion="NOT_FOUND",
                                supported_claims=[],
                                unsupported_claims=["The actual question."],
                                proves_opposite=True)))))
    check("INSUFFICIENT without opposite-claim fields passes",
          es.validate(wrap(q_assessment(
              "Q-1", "INSUFFICIENT", research_completion="NOT_FOUND",
              supported_claims=[],
              unsupported_claims=["The actual question."]))) == [])
    check("PARTIAL research caps a full answer",
          any("immaterial" in p for p in es.validate(
              wrap(q_assessment("Q-1", "SUFFICIENT",
                                research_completion="PARTIAL",
                                establishing_authority="ACCEPTED_UAC")))))
    check("PARTIAL research with a demonstrably immaterial limitation passes",
          es.validate(wrap(q_assessment(
              "Q-1", "SUFFICIENT", research_completion="PARTIAL",
              establishing_authority="ACCEPTED_UAC",
              immaterial_limitation="The undocumented mode is out of scope for "
              "this answer."))) == [])
    check("PENDING research cannot be SUFFICIENT",
          any("PENDING" in p for p in es.validate(
              wrap(q_assessment("Q-1", "SUFFICIENT",
                                research_completion="PENDING",
                                establishing_authority="ACCEPTED_UAC")))))

    # Equal-authority conflict stays CONFLICTED - never settled by convenience.
    check("CONFLICTING evidence forces CONFLICTED",
          any("CONFLICTED" in p for p in es.validate(
              wrap(q_assessment("Q-1", "SUFFICIENT",
                                contradiction_status="CONFLICTING",
                                establishing_authority="ACCEPTED_UAC")))))
    check("CONFLICTED with retained contradictions passes",
          es.validate(wrap(q_assessment(
              "Q-1", "CONFLICTED", contradiction_status="CONFLICTING",
              supported_claims=[],
              limitations=["Unsettled equal-authority conflict."],
              contradictions=["Two equal authorities disagree."]))) == [])

    # Claim bleed: evidence bound to a neighboring question cannot support
    # this claim, even when the numeric values match.
    bleed = wrap(
        q_assessment("Q-B", "SUFFICIENT",
                     establishing_authority="OFFICIAL_DOCUMENTATION",
                     evidence_ids=["DOC-A"]),
        question_plan={"items": [
            {"question_id": "Q-A", "category": "CONFIGURATION",
             "question": "What does setting A control?", "why_material": "m",
             "triggering_evidence_ids": ["DOC-A"], "acceptance_impact": "a",
             "applicability": "APPLICABLE", "research_requirement": "NONE",
             "status": "RESOLVED"},
            {"question_id": "Q-B", "category": "CONFIGURATION",
             "question": "What does setting B control?", "why_material": "m",
             "triggering_evidence_ids": ["DOC-B"], "acceptance_impact": "a",
             "applicability": "APPLICABLE", "research_requirement": "NONE",
             "status": "RESOLVED"},
        ]},
    )
    check("evidence cannot bleed into a neighboring claim",
          any("cannot bleed" in p for p in es.validate(bleed)))
    bleed["evidence_sufficiency"]["question_assessments"] = [
        q_assessment("Q-A", "SUFFICIENT",
                     establishing_authority="OFFICIAL_DOCUMENTATION",
                     evidence_ids=["DOC-A"]),
        q_assessment("Q-B", "SUFFICIENT",
                     establishing_authority="OFFICIAL_DOCUMENTATION",
                     evidence_ids=["DOC-B"]),
    ]
    check("claim-bound evidence passes",
          es.validate(bleed) == [])

    # Stale sufficiency records cannot be reused after a question revision.
    stale = wrap(
        q_assessment("Q-A", "SUFFICIENT",
                     establishing_authority="ACCEPTED_UAC",
                     evidence_ids=["JIRA-A"], question_revision="r1"),
        question_plan={"items": [
            {"question_id": "Q-A", "category": "EXPECTED_OUTCOME",
             "question": "What is the outcome?", "why_material": "m",
             "triggering_evidence_ids": ["JIRA-A"], "acceptance_impact": "a",
             "applicability": "APPLICABLE", "research_requirement": "NONE",
             "status": "RESOLVED", "revision": "r2"},
        ]},
    )
    check("stale sufficiency record rejected after question revision",
          any("stale" in p for p in es.validate(stale)))

    # The research_completion sub-state must match the mandatory research state.
    mismatch = wrap(
        q_assessment("Q-1", "SUFFICIENT", research_completion="COMPLETED",
                     establishing_authority="ACCEPTED_UAC"),
        question_research={"items": [{
            "question_ref": "Q-1", "material": True,
            "research_requirement": "NONE", "research_status": "NOT_REQUIRED"}]},
    )
    check("research_completion must match the research state",
          any("does not match" in p for p in es.validate(mismatch)))

    print("test_evidence_sufficiency_hard_negatives: OK")


def test_evidence_sufficiency_claim_level_unfamiliar() -> None:
    """Unfamiliar structurally different fixture: one authoritative source is
    sufficient for one claim while a related claim remains insufficient despite
    multiple supporting but non-decisive sources."""

    es = evidence_sufficiency_mod

    def dims():
        return {name: "evaluated" for name in es.EVALUATION_DIMENSIONS}

    manifest = {
        "question_plan": {"items": [
            {"question_id": "Q-C1", "category": "EXPECTED_OUTCOME",
             "question": "What must the dialog show after saving?",
             "why_material": "Primary acceptance oracle.",
             "triggering_evidence_ids": ["UAC-C1"],
             "acceptance_impact": "Defines the AC.", "applicability": "APPLICABLE",
             "research_requirement": "NONE", "status": "RESOLVED"},
            {"question_id": "Q-C2", "category": "SCALE",
             "question": "What happens at the documented volume limit?",
             "why_material": "A related claim the ticket hints at.",
             "triggering_evidence_ids": ["UAC-C1"],
             "acceptance_impact": "Bounds the regression scope.",
             "applicability": "APPLICABLE",
             "research_requirement": "NONE", "status": "RESOLVED"},
        ]},
        "question_research": {"items": [
            {"question_ref": "Q-C1", "material": True,
             "research_requirement": "NONE", "research_status": "NOT_REQUIRED"},
            {"question_ref": "Q-C2", "material": True,
             "research_requirement": "NONE", "research_status": "NOT_REQUIRED"},
        ]},
        "evidence_sufficiency": {"question_assessments": [
            {
                "question_ref": "Q-C1", "sufficiency": "SUFFICIENT",
                "dimensions": dims(),
                "authority_status": "ESTABLISHING",
                "research_completion": "NOT_REQUIRED",
                "applicability_status": "APPLICABLE",
                "currentness_status": "CURRENT",
                "contradiction_status": "NONE",
                "supported_claims": ["The dialog shows the saved state."],
                "unsupported_claims": [],
                "limitations": [], "evidence_ids": ["UAC-C1"],
                "research_ids": [],
                "establishing_authority": "ACCEPTED_UAC",
                "decision_reason": "The accepted UAC directly establishes the "
                "expected behavior.",
                "reason": "The accepted UAC directly establishes it.",
            },
            {
                "question_ref": "Q-C2", "sufficiency": "INSUFFICIENT",
                "dimensions": dims(),
                "authority_status": "ESTABLISHING",
                "research_completion": "NOT_REQUIRED",
                "applicability_status": "APPLICABLE",
                "currentness_status": "CURRENT",
                "contradiction_status": "NONE",
                "supported_claims": [],
                "unsupported_claims": ["The behavior at the volume limit."],
                "limitations": ["Three related passages discuss the limit but "
                                "none answers it decisively."],
                "evidence_ids": ["UAC-C1"],
                "research_ids": [],
                "decision_reason": "Supporting volume without a decisive answer "
                "is not sufficient.",
                "reason": "Non-decisive support is not sufficient.",
            },
        ]},
    }
    check("claim-level unfamiliar fixture is clean",
          es.validate(manifest) == [])
    print("  sufficiency trace [unfamiliar claim-level fixture]:")
    for row in manifest["evidence_sufficiency"]["question_assessments"]:
        print(f"    {row['question_ref']}: {row['sufficiency']} "
              f"(supported={len(row['supported_claims'])}, "
              f"unsupported={len(row['unsupported_claims'])})")

    print("test_evidence_sufficiency_claim_level_unfamiliar: OK")


def test_doc_research_routing() -> None:
    dr = doc_research_mod

    # Backward-compatible: absent block passes.
    check("absent doc_research passes", dr.validate({}) == [])

    def result(rid, status="DOC_RESEARCH_COMPLETED", **over):
        base = {
            "research_id": rid,
            "status": status,
            "produced_by": "uac-doc-researcher",
            "topics": ["documented baseline behavior"],
            "findings": [{
                "claim": "The documented baseline removes aged entries.",
                "source_id": "DOC-1",
                "source_type": "OFFICIAL_DOCUMENTATION",
                "authority": "OFFICIAL_PRODUCT_CONTRACT",
                "applicability": "current release",
                "currentness": "CURRENT",
                "evidence_role": "EXISTING_BEHAVIOR",
            }],
            "source_ids": ["DOC-1"],
            "applicability": "current release",
            "limitations": [],
            "conflicts": [],
        }
        base.update(over)
        return base

    def routing(state, **over):
        base = {"state": state}
        base.update(over)
        return base

    # HARD GATE: required research with no terminal result blocks the plan.
    check("DOC_RESEARCH_REQUIRED without a terminal result fails the hard gate",
          any("MUST NOT proceed" in p for p in dr.validate({
              "doc_research": {"routing": routing(
                  "DOC_RESEARCH_REQUIRED",
                  triggers=["CHANGES_DOCUMENTED_FUNCTIONALITY"])}})))

    # Routing only on material triggers - never merely because docs exist.
    check("terminal routing without a trigger fails",
          any("merely" in p for p in dr.validate({
              "doc_research": {
                  "routing": routing("DOC_RESEARCH_COMPLETED",
                                     research_id="DR-1"),
                  "results": [result("DR-1")]}})))
    check("unknown trigger rejected",
          any("unknown triggers" in p for p in dr.validate({
              "doc_research": {
                  "routing": routing("DOC_RESEARCH_COMPLETED",
                                     triggers=["NICE_TO_HAVE"],
                                     research_id="DR-1"),
                  "results": [result("DR-1")]}})))

    # Terminal routing requires the matching Doc Researcher result.
    check("terminal state without results fails",
          any("requires the Doc Researcher result" in p for p in dr.validate({
              "doc_research": {"routing": routing(
                  "DOC_RESEARCH_COMPLETED",
                  triggers=["EVIDENCE_AGENT_REQUEST"])}})))
    check("routing state must match a result status",
          any("no matching result status" in p for p in dr.validate({
              "doc_research": {
                  "routing": routing("DOC_RESEARCH_COMPLETED",
                                     triggers=["EVIDENCE_AGENT_REQUEST"],
                                     research_id="DR-1"),
                  "results": [result("DR-1", status="DOC_RESEARCH_PARTIAL",
                                     limitations=["one topic unanswered"])]}})))
    check("PARTIAL represented as COMPLETE fails",
          any("PARTIAL research must not be represented as complete" in p
              for p in dr.validate({
                  "doc_research": {
                      "routing": routing(
                          "DOC_RESEARCH_COMPLETED",
                          triggers=["EVIDENCE_AGENT_REQUEST"],
                          research_id="DR-1"),
                      "results": [result("DR-1", status="DOC_RESEARCH_PARTIAL",
                                         limitations=["one topic unanswered"])]}})))

    # RESEARCH_NOT_REQUIRED discipline.
    not_required = {"doc_research": {"routing": routing(
        "RESEARCH_NOT_REQUIRED",
        not_required_reason="The Human Accepted AC is authoritative and "
        "documentation would not materially change acceptance reasoning.")}}
    check("justified RESEARCH_NOT_REQUIRED passes",
          dr.validate(not_required) == [])
    check("RESEARCH_NOT_REQUIRED requires the reason",
          any("not_required_reason" in p for p in dr.validate(
              {"doc_research": {"routing": routing("RESEARCH_NOT_REQUIRED")}})))
    check("RESEARCH_NOT_REQUIRED cannot carry results",
          any("cannot carry research results" in p for p in dr.validate({
              "doc_research": {
                  "routing": routing("RESEARCH_NOT_REQUIRED",
                                     not_required_reason="x"),
                  "results": [result("DR-1")]}})))

    # Result contract.
    completed = {"doc_research": {
        "routing": routing("DOC_RESEARCH_COMPLETED",
                           triggers=["CHANGES_DOCUMENTED_FUNCTIONALITY"],
                           research_id="DR-1"),
        "results": [result("DR-1")],
    }}
    check("well-formed completed research passes", dr.validate(completed) == [])
    impersonated = {"doc_research": {
        "routing": routing("DOC_RESEARCH_COMPLETED",
                           triggers=["CHANGES_DOCUMENTED_FUNCTIONALITY"],
                           research_id="DR-1"),
        "results": [result("DR-1", produced_by="coordinator")],
    }}
    check("coordinator must not impersonate the Researcher",
          any("impersonate" in p for p in dr.validate(impersonated)))
    bad_role = {"doc_research": {
        "routing": routing("DOC_RESEARCH_COMPLETED",
                           triggers=["CHANGES_DOCUMENTED_FUNCTIONALITY"],
                           research_id="DR-1"),
        "results": [result("DR-1", findings=[{
            "claim": "c", "source_id": "DOC-1",
            "source_type": "OFFICIAL_DOCUMENTATION",
            "authority": "OFFICIAL_PRODUCT_CONTRACT",
            "applicability": "current", "evidence_role": "NEW_FEATURE"}])],
    }}
    check("unknown evidence_role rejected",
          any("evidence_role" in p for p in dr.validate(bad_role)))
    uncited = {"doc_research": {
        "routing": routing("DOC_RESEARCH_COMPLETED",
                           triggers=["CHANGES_DOCUMENTED_FUNCTIONALITY"],
                           research_id="DR-1"),
        "results": [result("DR-1", source_ids=[])],
    }}
    check("finding citing an unretrieved source fails",
          any("missing from source_ids" in p for p in dr.validate(uncited)))
    empty_completed = {"doc_research": {
        "routing": routing("DOC_RESEARCH_COMPLETED",
                           triggers=["CHANGES_DOCUMENTED_FUNCTIONALITY"],
                           research_id="DR-1"),
        "results": [result("DR-1", findings=[], source_ids=[])],
    }}
    check("COMPLETED requires findings",
          any("requires at least one finding" in p
              for p in dr.validate(empty_completed)))
    partial = {"doc_research": {
        "routing": routing("DOC_RESEARCH_PARTIAL",
                           triggers=["JIRA_EVIDENCE_INSUFFICIENT_DOC_MAY_ANSWER"],
                           research_id="DR-1"),
        "results": [result("DR-1", status="DOC_RESEARCH_PARTIAL",
                           limitations=["mode matrix undocumented"])],
    }}
    check("PARTIAL with limitations passes", dr.validate(partial) == [])
    check("PARTIAL without limitations fails",
          any("limitations" in p for p in dr.validate({"doc_research": {
              "routing": routing("DOC_RESEARCH_PARTIAL",
                                 triggers=["JIRA_EVIDENCE_INSUFFICIENT_DOC_MAY_ANSWER"],
                                 research_id="DR-1"),
              "results": [result("DR-1", status="DOC_RESEARCH_PARTIAL")]}})))
    unavailable = {"doc_research": {
        "routing": routing("DOC_RESEARCH_UNAVAILABLE",
                           triggers=["APPLICABILITY_NEEDS_CONFIRMATION"],
                           research_id="DR-1"),
        "results": [result("DR-1", status="DOC_RESEARCH_UNAVAILABLE",
                           findings=[], source_ids=[],
                           limitations=["docs unavailable for the version"])],
    }}
    check("UNAVAILABLE with limitations passes", dr.validate(unavailable) == [])
    not_found_as_proof = {"doc_research": {
        "routing": routing("DOC_RESEARCH_COMPLETED",
                           triggers=["CHANGES_DOCUMENTED_FUNCTIONALITY"],
                           research_id="DR-1"),
        "results": [result("DR-1", findings=[{
            "claim": "The mode must not retain entries.",
            "source_id": "DOC-1", "source_type": "OFFICIAL_DOCUMENTATION",
            "authority": "OFFICIAL_PRODUCT_CONTRACT", "applicability": "current",
            "evidence_role": "EXISTING_BEHAVIOR",
            "absence_proves": True}])],
    }}
    check("NOT_FOUND is never evidence of the opposite behavior",
          any("absence" in p for p in dr.validate(not_found_as_proof)))

    # The Researcher never writes ACs or decides acceptance scope.
    authoring = {"doc_research": {
        "routing": routing("DOC_RESEARCH_COMPLETED",
                           triggers=["CHANGES_DOCUMENTED_FUNCTIONALITY"],
                           research_id="DR-1"),
        "results": [result("DR-1", ac_id="AC-01")],
    }}
    check("Researcher writing ACs fails",
          any("does not write ACs" in p for p in dr.validate(authoring)))

    # The Writer receives only admitted research.
    check("unadmitted research id rejected",
          any("never receives arbitrary" in p for p in dr.validate({
              "doc_research": {
                  "routing": routing("DOC_RESEARCH_COMPLETED",
                                     triggers=["EVIDENCE_AGENT_REQUEST"],
                                     research_id="DR-1"),
                  "results": [result("DR-1")],
                  "admitted_research_ids": ["DR-9"]}})))
    admitted = {"doc_research": {
        "routing": routing("DOC_RESEARCH_COMPLETED",
                           triggers=["EVIDENCE_AGENT_REQUEST"],
                           research_id="DR-1"),
        "results": [result("DR-1")],
        "admitted_research_ids": ["DR-1"],
    }}
    check("admitted research passes", dr.validate(admitted) == [])

    print("test_doc_research_routing: OK")


def test_doc_research_routing_regressions() -> None:
    """Routing regressions: the named purge fixture must route through the Doc
    Researcher; the Human Accepted AC ticket must not; an unfamiliar generic
    scenario exercises the same hard gate."""

    dr = doc_research_mod

    def result(rid, topics, findings, **over):
        base = {
            "research_id": rid,
            "status": "DOC_RESEARCH_COMPLETED",
            "produced_by": "uac-doc-researcher",
            "topics": topics,
            "findings": findings,
            "source_ids": sorted({f["source_id"] for f in findings}),
            "applicability": "current release",
            "limitations": [],
            "conflicts": [],
        }
        base.update(over)
        return base

    # Regression fixture 1 (named ticket as fixture): an enhancement changing
    # an existing documented feature MUST route through the Doc Researcher.
    # Research distinguishes the documented baseline from the new behavior;
    # existing docs are never cited as proof of the new behavior.
    purge = {
        "doc_research": {
            "routing": {
                "state": "DOC_RESEARCH_COMPLETED",
                "triggers": [
                    "CHANGES_DOCUMENTED_FUNCTIONALITY",
                    "EXISTING_BEHAVIOR_MUST_BE_UNDERSTOOD_OR_PRESERVED",
                    "BACKWARD_COMPATIBILITY_MATERIAL",
                ],
                "research_id": "DR-PURGE",
            },
            "results": [result(
                "DR-PURGE",
                ["existing time-based purge baseline",
                 "retention semantics of the new ticket controls"],
                [
                    {"claim": "The documented time-based purge removes aged "
                     "entries and their logs.",
                     "source_id": "DOC-BASE",
                     "source_type": "OFFICIAL_DOCUMENTATION",
                     "authority": "OFFICIAL_PRODUCT_CONTRACT",
                     "applicability": "current release",
                     "currentness": "CURRENT",
                     "evidence_role": "EXISTING_BEHAVIOR"},
                    {"claim": "The ticket adds a count-based retention option "
                     "and a log-only action on top of that baseline.",
                     "source_id": "JIRA-CURRENT",
                     "source_type": "CURRENT_TICKET",
                     "authority": "CURRENT_TICKET_REQUIREMENT",
                     "applicability": "current release",
                     "currentness": "CURRENT",
                     "evidence_role": "REQUIREMENT_CLARIFICATION"},
                ],
            )],
            "admitted_research_ids": ["DR-PURGE"],
        },
        "behavior_classification": {"items": [
            {"target_ref": "B-BASELINE", "behavior_class": "EXISTING_CONFIRMED",
             "existing_evidence_ids": ["DOC-BASE"]},
            {"target_ref": "B-COUNT", "behavior_class": "NEW_REQUIREMENT",
             "requested_evidence_ids": ["JIRA-CURRENT"]},
        ]},
    }
    problems = dr.validate(purge)
    check("purge fixture routes through the Doc Researcher cleanly",
          problems == [])
    print("  routing trace [documented-feature enhancement]:")
    print("    triggers: " + ", ".join(purge["doc_research"]["routing"]["triggers"]))
    print("    -> DOC_RESEARCH_REQUIRED -> invoke uac-doc-researcher")
    for finding in purge["doc_research"]["results"][0]["findings"]:
        print(f"    DR-PURGE finding [{finding['evidence_role']}] "
              f"{finding['source_id']}: {finding['claim'][:60]}...")
    print("    -> DOC_RESEARCH_COMPLETED -> admitted to Writer")

    # Existing docs must not be falsely cited as proof of the new behavior.
    falsely_cited = {
        "doc_research": {
            "routing": {
                "state": "DOC_RESEARCH_COMPLETED",
                "triggers": ["CHANGES_DOCUMENTED_FUNCTIONALITY"],
                "research_id": "DR-PURGE",
            },
            "results": [result(
                "DR-PURGE",
                ["retention semantics"],
                [{"claim": "The baseline purge removes aged entries.",
                  "source_id": "DOC-BASE",
                  "source_type": "OFFICIAL_DOCUMENTATION",
                  "authority": "OFFICIAL_PRODUCT_CONTRACT",
                  "applicability": "current release",
                  "currentness": "CURRENT",
                  "evidence_role": "EXISTING_BEHAVIOR",
                  "supports_behavior_ref": "B-COUNT"}],
            )],
        },
        "behavior_classification": purge["behavior_classification"],
    }
    check("existing docs never prove the new behavior",
          any("proof of new behavior" in p and "NEW_REQUIREMENT" in p
              for p in dr.validate(falsely_cited)))

    # Regression fixture 2 (structurally different): an explicit authoritative
    # Human Accepted AC needs no external product clarification.
    human_accepted = {
        "doc_research": {"routing": {
            "state": "RESEARCH_NOT_REQUIRED",
            "not_required_reason": "The Human Accepted AC states the exact "
            "expected behavior; documentation would not materially change "
            "acceptance reasoning.",
        }},
    }
    check("Human Accepted AC ticket routes RESEARCH_NOT_REQUIRED",
          dr.validate(human_accepted) == [])
    print("  routing trace [Human Accepted AC ticket]:")
    print("    no material trigger -> RESEARCH_NOT_REQUIRED "
          "(Jira authority sufficient) -> Writer proceeds")

    # Unfamiliar generic scenario: a configuration-driven dialog ticket where
    # the ticket never documents the config semantics -> research is required,
    # and without a terminal result the hard gate blocks Coverage/Writer.
    unfamiliar = {
        "doc_research": {"routing": {
            "state": "DOC_RESEARCH_REQUIRED",
            "triggers": ["CONFIGURATION_SEMANTICS_UNESTABLISHED"],
        }},
    }
    check("unfamiliar ticket: unestablished config semantics require research",
          any("MUST NOT proceed" in p for p in dr.validate(unfamiliar)))
    unfamiliar_done = {
        "doc_research": {
            "routing": {
                "state": "DOC_RESEARCH_COMPLETED",
                "triggers": ["CONFIGURATION_SEMANTICS_UNESTABLISHED"],
                "research_id": "DR-U1",
            },
            "results": [result(
                "DR-U1",
                ["dialog configuration semantics"],
                [{"claim": "The dialog reads its entries from the folder "
                  "profile configuration.",
                  "source_id": "DOC-U1",
                  "source_type": "OFFICIAL_DOCUMENTATION",
                  "authority": "OFFICIAL_PRODUCT_CONTRACT",
                  "applicability": "current release",
                  "currentness": "CURRENT",
                  "evidence_role": "EXISTING_BEHAVIOR"}],
            )],
            "admitted_research_ids": ["DR-U1"],
        },
    }
    check("unfamiliar ticket completes through the same contract",
          dr.validate(unfamiliar_done) == [])
    print("  routing trace [unfamiliar config-semantics ticket]:")
    print("    trigger: CONFIGURATION_SEMANTICS_UNESTABLISHED")
    print("    -> DOC_RESEARCH_REQUIRED -> uac-doc-researcher -> "
          "DOC_RESEARCH_COMPLETED -> admitted")

    print("test_doc_research_routing_regressions: OK")


def test_question_reasoning_chain_regressions() -> None:
    """End-to-end Question Planner -> Research Router -> Question Resolver ->
    Coverage Reasoner regressions per domain, each delivering its question
    trace."""

    qp = question_planner_mod
    qr = question_research_mod
    qres = question_resolver_mod
    cr = coverage_reasoner_mod
    ce = coverage_equivalence_mod
    es = evidence_sufficiency_mod

    def question(qid, category, text, requirement, evidence):
        return {
            "question_id": qid,
            "category": category,
            "question": text,
            "why_material": "The answer changes the acceptance oracle or scope.",
            "triggering_evidence_ids": evidence,
            "acceptance_impact": "Decides what the AC may assert.",
            "applicability": "APPLICABLE",
            "research_requirement": requirement,
            "status": "RESOLVED",
        }

    def research(ref, requirement, status):
        item = {
            "question_ref": ref,
            "material": True,
            "research_requirement": requirement,
            "research_status": status,
        }
        if status not in {"NOT_REQUIRED", "PENDING"}:
            item["research_requests"] = [f"RQ-{ref}"]
        if status == "ANSWER_FOUND":
            item["research_evidence_ids"] = [f"EV-{ref}"]
        return item

    def resolution(ref, status, authority="CURRENT_TICKET_REQUIREMENT", **over):
        item = {
            "question_ref": ref,
            "status": status,
            "decision_reason": over.pop(
                "decision_reason",
                "Recorded from the cited evidence and routing state."),
        }
        if status in {"ANSWERED", "PARTIALLY_ANSWERED", "CONFLICTED"}:
            item["answer"] = {
                "claim": over.pop("claim", f"The evidence answers {ref}."),
                "source_ids": over.pop("source_ids", [f"EV-{ref}"]),
                "source_authority": authority,
                "applicability": over.pop("applicability", "current release"),
                "limitations": over.pop("limitations", []),
                "contradictions": over.pop("contradictions", []),
            }
        item.update(over)
        return item

    domains = {
        "Translation": [
            ("Q-T1", "PRESERVATION", "Does an Approved translation file remain "
             "Approved after a refresh?", "NONE", ["JIRA-T1"]),
            ("Q-T2", "NEGATIVE_CONTRACT", "Must a refresh never return an "
             "Approved file to Ready for Review?", "NONE", ["JIRA-T1"]),
            ("Q-T3", "STATE_TRANSITION", "Which review states can a translation "
             "job transition between?", "DOCUMENTATION", ["JIRA-T1"]),
            ("Q-T4", "PERSISTENCE", "Are duplicate or stale project references "
             "the root cause of the wrong state?", "NONE", ["JIRA-T1"]),
        ],
        "Output History": [
            ("Q-O1", "EXPECTED_OUTCOME", "What is the documented baseline of the "
             "existing time-based purge?", "DOCUMENTATION", ["DOC-O1"]),
            ("Q-O2", "VARIANT", "Which retention modes does the ticket add beyond "
             "the documented baseline?", "NONE", ["JIRA-O1"]),
            ("Q-O3", "PRESERVATION", "Which generated output entries must remain "
             "intact after a log-only purge?", "DOCUMENTATION", ["JIRA-O1"]),
            ("Q-O4", "COMPATIBILITY", "Are the purge defaults backward-compatible "
             "for existing presets?", "DOCUMENTATION", ["JIRA-O1"]),
            ("Q-O5", "SCOPE", "Which entries does the COUNT retention apply "
             "to?", "DOCUMENTATION", ["JIRA-O1"]),
        ],
        "Broken Links": [
            ("Q-B1", "NEGATIVE_CONTRACT", "How must a broken keyword-key link "
             "surface when validation runs?", "NONE", ["JIRA-B1"]),
            ("Q-B2", "ENTRY_PATH", "Which entry paths can start link validation?",
             "IMPLEMENTATION", ["JIRA-B1"]),
            ("Q-B3", "ERROR_RECOVERY", "What happens when link validation fails "
             "mid-run?", "DOCUMENTATION", ["JIRA-B1"]),
        ],
        "Native PDF": [
            ("Q-P1", "VARIANT", "Which output engines does the rendering fix "
             "apply to, Native PDF and DITA-OT?", "NONE", ["JIRA-P1"]),
            ("Q-P2", "PRESERVATION", "Which existing rendering behavior must remain "
             "unchanged for unaffected constructs?", "DOCUMENTATION", ["JIRA-P1"]),
            ("Q-P3", "ERROR_RECOVERY", "What must the product show when rendering "
             "fails for a large map?", "DOCUMENTATION", ["JIRA-P1"]),
            ("Q-P4", "SCALE", "Which documented size limits apply to the affected "
             "rendering path?", "DOCUMENTATION", ["JIRA-P1"]),
        ],
        "Editor": [
            ("Q-E1", "STATE_TRANSITION", "Which save states must both editors "
             "show for the changed content?", "DOCUMENTATION", ["JIRA-E1"]),
            ("Q-E2", "NEGATIVE_CONTRACT", "What must the editor do when the "
             "content is invalid?", "NONE", ["JIRA-E1"]),
            ("Q-E3", "ENTRY_PATH", "Does the fix apply to both the Web Editor and "
             "the new Editor?", "DOCUMENTATION", ["JIRA-E1"]),
        ],
    }

    # The dedicated Coverage Reasoner maps each domain's resolved questions to
    # coverage decisions: (coverage_id, question_id, priority, class, polarity,
    # axes). P0 proves the primary ticket contract; P1 is materially related
    # regression behavior.
    domain_coverage = {
        "Translation": [
            ("COV-T1", "Q-T1", "P0", "ACCEPTANCE", "POSITIVE",
             ["PRESERVATION", "REFRESH_REVISIT"]),
            ("COV-T2", "Q-T2", "P1", "QE_REGRESSION", "NEGATIVE",
             ["NEGATIVE_CONTRACTS", "REFRESH_REVISIT"]),
            ("COV-T3", "Q-T3", "P1", "QE_REGRESSION", "POSITIVE",
             ["STATE_TRANSITIONS", "ALTERNATE_UI_PATHS"]),
        ],
        "Output History": [
            ("COV-O1", "Q-O2", "P0", "ACCEPTANCE", "POSITIVE",
             ["CONFIGURATION_BRANCHES"]),
            ("COV-O2", "Q-O1", "P1", "QE_REGRESSION", "POSITIVE",
             ["PRESERVATION"]),
            ("COV-O3", "Q-O3", "P1", "QE_REGRESSION", "POSITIVE",
             ["PRESERVATION", "NEGATIVE_CONTRACTS"]),
            ("COV-O4", "Q-O4", "P1", "QE_REGRESSION", "POSITIVE",
             ["CONFIGURATION_BRANCHES", "CLOUD_65"]),
        ],
        "Broken Links": [
            ("COV-B1", "Q-B1", "P0", "ACCEPTANCE", "NEGATIVE",
             ["NEGATIVE_CONTRACTS"]),
            ("COV-B2", "Q-B2", "P1", "QE_REGRESSION", "POSITIVE",
             ["ALTERNATE_UI_PATHS", "SINGLE_BULK"]),
            ("COV-B3", "Q-B3", "P1", "QE_REGRESSION", "NEGATIVE",
             ["STATE_TRANSITIONS"]),
        ],
        "Native PDF": [
            ("COV-P1", "Q-P1", "P0", "ACCEPTANCE", "POSITIVE",
             ["NATIVE_PDF_DITA_OT", "CONFIGURATION_BRANCHES"]),
            ("COV-P2", "Q-P2", "P1", "QE_REGRESSION", "POSITIVE",
             ["PRESERVATION", "NATIVE_PDF_DITA_OT"]),
            ("COV-P3", "Q-P3", "P1", "QE_REGRESSION", "NEGATIVE",
             ["SCALE"]),
            ("COV-P4", "Q-P4", "SUPPORTING", "QE_REGRESSION", "POSITIVE",
             ["SCALE"]),
        ],
        "Editor": [
            ("COV-E1", "Q-E2", "P0", "ACCEPTANCE", "NEGATIVE",
             ["NEGATIVE_CONTRACTS", "NEW_OLD_EDITOR"]),
            ("COV-E2", "Q-E1", "P1", "QE_REGRESSION", "POSITIVE",
             ["STATE_TRANSITIONS", "NEW_OLD_EDITOR", "AUTHOR_SOURCE"]),
            ("COV-E3", "Q-E3", "P1", "QE_REGRESSION", "POSITIVE",
             ["ALTERNATE_UI_PATHS", "NEW_OLD_EDITOR"]),
        ],
    }

    def coverage(cid, qid, priority, klass, polarity, axes):
        return {
            "coverage_id": cid,
            "behavior": f"Coverage derived from {qid}.",
            "question_ids": [qid],
            "evidence_ids": [f"EV-{qid}"],
            "priority": priority,
            "coverage_class": klass,
            "contract_type": polarity,
            "surface": "the affected surface",
            "state_or_transition": "",
            "configuration": "",
            "applicability": "current release",
            "reason": "Traces to the resolved question evidence.",
            "acceptance_impact": "Defines what the Writer may assert.",
            "dimensions_considered": axes,
        }

    # One semantic equivalence comparison per domain, recorded on the coverage
    # decisions. The Translation fixture is the human UAC state-preservation
    # example: the positive and negative phrasings of the same refresh outcome
    # merge into one AC; every other domain compares DISTINCT_OUTCOMEs and
    # nothing merges merely to reduce AC count.
    domain_equivalence = {
        "Translation": {
            "decision": ("EQ-T1", "COV-T1", "COV-T2", "SAME_OUTCOME_VARIANT",
                         ["EXPECTED_OUTCOME", "STATE_TRANSITION",
                          "APPLICABILITY"], ["QUESTION_IDS"]),
            "merge_id": "MERGE-T1",
        },
        "Output History": {
            "decision": ("EQ-O1", "COV-O3", "COV-O4", "DISTINCT_OUTCOME",
                         ["APPLICABILITY"], ["EXPECTED_OUTCOME"]),
            "merge_id": None,
        },
        "Broken Links": {
            "decision": ("EQ-B1", "COV-B2", "COV-B3", "DISTINCT_OUTCOME",
                         ["APPLICABILITY"], ["EXPECTED_OUTCOME"]),
            "merge_id": None,
        },
        "Native PDF": {
            "decision": ("EQ-P1", "COV-P3", "COV-P4", "DISTINCT_OUTCOME",
                         ["APPLICABILITY"], ["EXPECTED_OUTCOME"]),
            "merge_id": None,
        },
        "Editor": {
            "decision": ("EQ-E1", "COV-E2", "COV-E3", "DISTINCT_OUTCOME",
                         ["APPLICABILITY"], ["EXPECTED_OUTCOME"]),
            "merge_id": None,
        },
    }

    # Per-question resolution overrides: the Translation root-cause question
    # stays INVESTIGATION_ONLY (never an AC); the Output History retention-
    # scope question stays ACCEPTANCE_TBD while its research is partial.
    resolution_overrides = {
        "Q-T4": {
            "status": "INVESTIGATION_ONLY",
            "investigation_topic": "ROOT_CAUSE",
            "decision_reason": "Root-cause uncertainty guides the fix "
            "investigation; it is not acceptance behavior.",
        },
        "Q-O5": {
            "status": "ACCEPTANCE_TBD",
            "material_impact": ["SCOPE"],
            "plausible_answers": [
                "COUNT applies to all retained history entries",
                "COUNT applies only to generated output entries",
            ],
            "decision_reason": "Different plausible answers change the "
            "acceptance scope of the retention control.",
        },
    }
    research_overrides = {
        "Q-O5": "PARTIAL",
    }
    sufficiency_overrides = {
        "Q-O5": "INSUFFICIENT",
    }

    # R1 reuse: every domain has documentation-requiring questions, so the
    # existing Doc Researcher routing contract produces a terminal result the
    # resolver can rely on.  The Output History fixture's research is PARTIAL:
    # the retention scope of the new count control is not documented.
    doc_result_overrides = {
        "Output History": {
            "status": "DOC_RESEARCH_PARTIAL",
            "limitations": [
                "The retention scope of the new count control is not "
                "documented."
            ],
        },
    }

    def doc_block(domain, doc_question_ids):
        rid = f"DR-{domain}"
        override = doc_result_overrides.get(domain, {})
        status = override.get("status", "DOC_RESEARCH_COMPLETED")
        findings = [
            {
                "claim": f"Documentation establishes the baseline for {qid}.",
                "source_id": f"EV-{qid}",
                "source_type": "OFFICIAL_DOCUMENTATION",
                "authority": "OFFICIAL_PRODUCT_CONTRACT",
                "applicability": "current release",
                "currentness": "CURRENT",
                "evidence_role": "EXISTING_BEHAVIOR",
            }
            for qid in doc_question_ids
        ]
        return {
            "routing": {
                "state": status,
                "triggers": ["CHANGES_DOCUMENTED_FUNCTIONALITY"],
                "research_id": rid,
            },
            "results": [{
                "research_id": rid,
                "status": status,
                "produced_by": "uac-doc-researcher",
                "topics": ["documented baseline behavior"],
                "findings": findings,
                "source_ids": sorted({f["source_id"] for f in findings}),
                "applicability": "current release",
                "limitations": override.get("limitations", []),
                "conflicts": [],
                "question_refs": list(doc_question_ids),
            }],
            "admitted_research_ids": [rid],
        }

    for domain, rows in domains.items():
        plan_items = [
            question(row[0], row[1], row[2], row[3], row[4]) for row in rows
        ]
        research_items = []
        for qid, _category, _text, requirement, _evidence in rows:
            status = research_overrides.get(
                qid,
                "NOT_REQUIRED" if requirement == "NONE" else "ANSWER_FOUND",
            )
            research_items.append(research(qid, requirement, status))
        resolution_items = []
        for qid, _category, _text, requirement, _evidence in rows:
            override = resolution_overrides.get(qid)
            if override is not None:
                override = dict(override)
                resolution_items.append(
                    resolution(qid, override.pop("status"), **override)
                )
                continue
            resolution_items.append(
                resolution(
                    qid,
                    "ANSWERED",
                    authority=("CURRENT_TICKET_REQUIREMENT"
                               if requirement == "NONE"
                               else "OFFICIAL_DOCUMENTATION"),
                    research_ids=(
                        [f"DR-{domain}"] if requirement == "DOCUMENTATION"
                        else []
                    ),
                )
            )
        coverage_items = []
        requirements_by_qid = {row[0]: row[3] for row in rows}
        for row in domain_coverage[domain]:
            entry = coverage(*row)
            if requirements_by_qid[row[1]] == "DOCUMENTATION":
                # Research binding: cover the underlying resolution's research.
                entry["research_ids"] = [f"DR-{domain}"]
            coverage_items.append(entry)
        if domain == "Translation":
            # The approved outcome is proven by both the individual and the
            # bulk action - variants of one coverage decision, one AC.
            coverage_items[0]["variants"] = [
                {"label": "individual approval", "evidence_ids": ["EV-Q-T1"]},
                {"label": "bulk approval", "evidence_ids": ["EV-Q-T1b"]},
            ]
        writer_handoff = [row[0] for row in domain_coverage[domain]]
        p0_ids = [row[0] for row in domain_coverage[domain]
                  if row[2] == "P0"]
        writer_package = {
            "acs": [
                {
                    "ac_id": f"AC-{domain}-{n}",
                    "text": f"Accepted behavior for {p0}.",
                    "coverage_ids": [p0],
                    **(
                        {"variants": ["individual approval", "bulk approval"]}
                        if domain == "Translation"
                        else {}
                    ),
                }
                for n, p0 in enumerate(p0_ids, 1)
            ],
        }
        eq = domain_equivalence[domain]
        eq_id, eq_left, eq_right, eq_class, eq_shared, eq_diff = eq["decision"]
        equivalence = {
            "decision_id": eq_id,
            "left_coverage_id": eq_left,
            "right_coverage_id": eq_right,
            "classification": eq_class,
            "shared_dimensions": eq_shared,
            "differing_dimensions": eq_diff,
            "reason": "Structural comparison of the coverage decisions.",
            "merge_allowed": eq_class == "SAME_OUTCOME_VARIANT",
        }
        merges = []
        if eq["merge_id"]:
            merged_ids = [eq_left, eq_right]
            members = [c for c in coverage_items
                       if c["coverage_id"] in merged_ids]
            merges.append({
                "merge_id": eq["merge_id"],
                "merged_coverage_ids": merged_ids,
                "classification": "SAME_OUTCOME_VARIANT",
                "canonical_outcome": (
                    "The approved review state persists across a refresh."
                ),
                "priority": "P0",
                "question_ids": sorted({
                    q for c in members for q in c["question_ids"]}),
                "evidence_ids": sorted({
                    e for c in members for e in c["evidence_ids"]}),
                "variants": sorted({
                    v["label"] for c in members for v in c.get("variants", [])}),
                "source_lineage": sorted({
                    ref for c in members
                    for ref in [c["coverage_id"], *c["question_ids"]]}),
            })
        doc_questions = [
            row[0] for row in rows if row[3] == "DOCUMENTATION"
        ]
        question_assessments = []
        resolutions_by_qid = {
            row["question_ref"]: row for row in resolution_items
        }
        research_by_qid = {row["question_ref"]: row for row in research_items}
        completion_by_status = {
            "NOT_REQUIRED": "NOT_REQUIRED",
            "ANSWER_FOUND": "COMPLETED",
            "PARTIAL": "PARTIAL",
        }
        for row in rows:
            qid = row[0]
            if resolutions_by_qid[qid]["status"] in {
                "INVESTIGATION_ONLY",
                "NOT_APPLICABLE",
                "DUPLICATE",
            }:
                continue
            state = sufficiency_overrides.get(qid, "SUFFICIENT")
            question_assessments.append({
                "question_ref": qid,
                "sufficiency": state,
                "dimensions": {
                    name: "evaluated"
                    for name in es.EVALUATION_DIMENSIONS
                },
                "authority_status": "ESTABLISHING",
                "research_completion": completion_by_status[
                    research_by_qid[qid]["research_status"]
                ],
                "applicability_status": "APPLICABLE",
                "currentness_status": "CURRENT",
                "contradiction_status": "NONE",
                "supported_claims": (
                    [f"The established answer to {qid}."]
                    if state in {"SUFFICIENT", "PARTIAL"}
                    else []
                ),
                "unsupported_claims": (
                    [] if state == "SUFFICIENT" else ["The unresolved portion."]
                ),
                "limitations": [],
                "evidence_ids": [] if state == "INSUFFICIENT" else [f"EV-{qid}"],
                "research_ids": (
                    [f"DR-{domain}"] if row[3] == "DOCUMENTATION" else []
                ),
                "decision_reason": "Evidence evaluated across every dimension.",
                "reason": "Evidence evaluated across every dimension.",
            })
        coverage_assessments = [
            {
                "coverage_ref": row[0],
                "sufficiency": "SUFFICIENT",
                "question_refs": [row[1]],
                "reason": "Computed from the underlying question.",
                "sufficiency_reason": "Computed from the underlying question.",
                "evidence_ids": [f"EV-{row[1]}"],
                "research_ids": (
                    [f"DR-{domain}"]
                    if requirements_by_qid[row[1]] == "DOCUMENTATION"
                    else []
                ),
            }
            for row in domain_coverage[domain]
        ]
        manifest = {
            "question_plan": {"items": plan_items},
            "question_research": {"items": research_items},
            "question_resolutions": {"items": resolution_items},
            "doc_research": doc_block(domain, doc_questions),
            "coverage_decisions": {
                "items": coverage_items,
                "writer_handoff": writer_handoff,
            },
            "coverage_equivalence": {
                "decisions": [equivalence],
                "merges": merges,
            },
            "evidence_sufficiency": {
                "question_assessments": question_assessments,
                "coverage_assessments": coverage_assessments,
            },
            "writer_package": writer_package,
        }
        planner_problems = qp.validate(manifest)
        research_problems = qr.validate(manifest)
        resolver_problems = qres.validate(manifest)
        doc_problems = doc_research_mod.validate(manifest)
        coverage_problems = cr.validate(manifest)
        equivalence_problems = ce.validate(manifest)
        sufficiency_problems = es.validate(manifest)
        check(f"{domain}: planner gate clean", planner_problems == [])
        check(f"{domain}: research router gate clean", research_problems == [])
        check(f"{domain}: resolver gate clean", resolver_problems == [])
        check(f"{domain}: doc research routing gate clean", doc_problems == [])
        check(f"{domain}: coverage reasoner gate clean", coverage_problems == [])
        check(f"{domain}: equivalence gate clean", equivalence_problems == [])
        check(f"{domain}: sufficiency gate clean", sufficiency_problems == [])

        # Deliver the question, research, and resolution traces.
        print(f"  question trace [{domain}]:")
        for item_row in plan_items:
            print(
                f"    {item_row['question_id']} [{item_row['category']}]: "
                f"{item_row['question']}"
            )
        print(f"  research trace [{domain}]:")
        doc_status = doc_result_overrides.get(domain, {}).get(
            "status", "DOC_RESEARCH_COMPLETED"
        )
        print(
            f"    doc routing: DOC_RESEARCH_REQUIRED -> uac-doc-researcher "
            f"-> {doc_status} (DR-{domain})"
        )
        for route in research_items:
            print(
                f"    {route['question_ref']}: "
                f"{route['research_requirement']}/{route['research_status']}"
            )
        print(f"  resolution trace [{domain}]:")
        for outcome in resolution_items:
            decisions = [
                c for c in coverage_items
                if outcome["question_ref"] in c["question_ids"]
            ]
            tail = " ".join(
                f"-> {c['coverage_id']} {c['priority']}/{c['coverage_class']}"
                for c in decisions
            )
            print(f"    {outcome['question_ref']} -> {outcome['status']} {tail}")
        merge_note = (
            f"-> {eq['merge_id']} (one AC)" if eq["merge_id"] else "(not merged)"
        )
        print(f"    {eq_id}: {eq_left} vs {eq_right} -> {eq_class} {merge_note}")

    # Cross-gate: required research cannot be skipped anywhere in the chain.
    manifest = {
        "question_plan": {"items": [question(
            "Q-X1", "EXPECTED_OUTCOME", "What retention does the mode keep?",
            "DOCUMENTATION", ["JIRA-X1"])]},
        "question_research": {"items": [research("Q-X1", "DOCUMENTATION", "PENDING")]},
        "question_resolutions": {"items": [resolution("Q-X1", "ANSWERED")]},
    }
    check("PENDING required research fails the router review",
          any("still PENDING" in p for p in qr.validate(manifest)))
    check("ANSWERED over skipped research fails the resolver",
          any("cannot be skipped" in p or "not negative proof" in p
              for p in qres.validate(manifest)))
    manifest["coverage_decisions"] = {"items": [
        coverage("COV-X1", "Q-X1", "P0", "ACCEPTANCE", "POSITIVE",
                 ["CONFIGURATION_BRANCHES"])]}
    check("PENDING research cannot ground ACCEPTANCE coverage",
          any("cannot be skipped" in p for p in cr.validate(manifest)))

    # NOT_FOUND never grounds an answer through the chain.
    manifest["question_research"] = {"items": [research("Q-X1", "DOCUMENTATION", "NOT_FOUND")]}
    check("ANSWERED over NOT_FOUND fails the resolver",
          any("not negative proof" in p for p in qres.validate(manifest)))
    check("NOT_FOUND research cannot ground ACCEPTANCE coverage",
          any("not negative proof" in p for p in cr.validate(manifest)))

    # A planned question is never silently dropped before resolution.
    del manifest["coverage_decisions"]
    manifest["question_resolutions"] = {"items": []}
    check("planned question without resolution fails",
          any("never silently dropped" in p for p in qres.validate(manifest)))

    # A resolution for a question that was never planned fails.
    manifest["question_resolutions"] = {"items": [resolution("Q-X9", "ANSWERED")]}
    check("resolution without planning fails",
          any("never planned" in p for p in qres.validate(manifest)))

    print("test_question_reasoning_chain_regressions: OK")


def test_question_reasoning_unseen_fixture() -> None:
    """Structurally different unseen-style fixture: an unfamiliar ticket whose
    chain includes a DUPLICATE question, an equal-authority CONFLICTED
    question, a NOT_APPLICABLE question, and PARTIAL doc research - exercising
    the same planner -> router -> resolver contract without any named fixture."""

    qp = question_planner_mod
    qr = question_research_mod
    qres = question_resolver_mod
    dr = doc_research_mod

    plan_items = [
        {"question_id": "Q-N1", "category": "PERSISTENCE",
         "question": "Where does the dialog persist the last used folder?",
         "why_material": "The answer decides the persistence oracle.",
         "triggering_evidence_ids": ["JIRA-N1", "JIRA-N2"],
         "acceptance_impact": "Decides whether re-open state is asserted.",
         "applicability": "APPLICABLE",
         "research_requirement": "DOCUMENTATION", "status": "RESOLVED"},
        {"question_id": "Q-N2", "category": "APPLICABILITY",
         "question": "Does the dialog apply to collections as well as single "
         "assets?",
         "why_material": "The answer bounds the applicable surfaces.",
         "triggering_evidence_ids": ["JIRA-N1"],
         "acceptance_impact": "Decides which surfaces the AC covers.",
         "applicability": "APPLICABLE",
         "research_requirement": "DOCUMENTATION", "status": "RESOLVED"},
        {"question_id": "Q-N3", "category": "VARIANT",
         "question": "Does the export include referenced content metadata?",
         "why_material": "The answer changes the export contract.",
         "triggering_evidence_ids": ["JIRA-N1"],
         "acceptance_impact": "Decides the export payload oracle.",
         "applicability": "APPLICABLE",
         "research_requirement": "DOCUMENTATION", "status": "RESOLVED"},
        {"question_id": "Q-N4", "category": "PERSISTENCE",
         "question": "Where does the dialog persist the last used folder?",
         "why_material": "Duplicate trigger from a second evidence row.",
         "triggering_evidence_ids": ["JIRA-N2"],
         "acceptance_impact": "Same oracle as Q-N1.",
         "applicability": "APPLICABLE",
         "research_requirement": "NONE", "status": "RESOLVED"},
        {"question_id": "Q-N5", "category": "SCOPE",
         "question": "Does the export include binary content?",
         "why_material": "The ticket marks binary content out of scope.",
         "triggering_evidence_ids": ["JIRA-N1"],
         "acceptance_impact": "Confirms the scope boundary.",
         "applicability": "APPLICABLE",
         "research_requirement": "NONE", "status": "RESOLVED"},
    ]
    research_items = [
        {"question_ref": "Q-N1", "material": True,
         "research_requirement": "DOCUMENTATION",
         "research_status": "ANSWER_FOUND", "research_requests": ["RQ-N1"],
         "research_evidence_ids": ["DOC-N1"]},
        {"question_ref": "Q-N2", "material": True,
         "research_requirement": "DOCUMENTATION",
         "research_status": "PARTIAL", "research_requests": ["RQ-N2"],
         "research_evidence_ids": ["DOC-N2"]},
        {"question_ref": "Q-N3", "material": True,
         "research_requirement": "DOCUMENTATION",
         "research_status": "CONFLICTED", "research_requests": ["RQ-N3"],
         "research_evidence_ids": ["DOC-N3A", "DOC-N3B"]},
        {"question_ref": "Q-N4", "material": True,
         "research_requirement": "NONE", "research_status": "NOT_REQUIRED"},
        {"question_ref": "Q-N5", "material": True,
         "research_requirement": "NONE", "research_status": "NOT_REQUIRED"},
    ]
    resolution_items = [
        {"question_id": "Q-N1", "disposition": "ANSWERED",
         "decision_reason": "The documentation establishes persistence.",
         "answer": "The documented dialog persists the last used folder per "
         "user.",
         "source_ids": ["DOC-N1"], "source_authority": "OFFICIAL_DOCUMENTATION",
         "applicability": "current release", "limitations": [],
         "contradictions": [],
         "research_ids": ["DR-UNSEEN"]},
        {"question_id": "Q-N2", "disposition": "PARTIALLY_ANSWERED",
         "decision_reason": "Only the single-asset portion is documented.",
         "answer": "Single assets are covered; collections are undocumented.",
         "source_ids": ["DOC-N2"], "source_authority": "OFFICIAL_DOCUMENTATION",
         "applicability": "current release",
         "limitations": ["Collection applicability is not documented."],
         "contradictions": [],
         "research_ids": ["DR-UNSEEN"]},
        {"question_id": "Q-N3", "disposition": "CONFLICTED",
         "decision_reason": "Two equally authoritative pages disagree; no "
         "higher authority settles it.",
         "answer": "Two equally authoritative pages disagree on referenced "
         "metadata.",
         "source_ids": ["DOC-N3A", "DOC-N3B"],
         "source_authority": "OFFICIAL_DOCUMENTATION",
         "applicability": "current release", "limitations": [],
         "contradictions": ["DOC-N3A includes referenced metadata; "
                            "DOC-N3B excludes it."]},
        {"question_id": "Q-N4", "disposition": "DUPLICATE",
         "duplicate_of": "Q-N1",
         "decision_reason": "Materially the same question as Q-N1 from a "
         "second trigger."},
        {"question_id": "Q-N5", "disposition": "NOT_APPLICABLE",
         "reason": "Binary content is explicitly out of scope for the ticket.",
         "decision_reason": "The ticket bounds the scope."},
    ]
    doc_block = {
        "routing": {
            "state": "DOC_RESEARCH_PARTIAL",
            "triggers": ["CHANGES_DOCUMENTED_FUNCTIONALITY"],
            "research_id": "DR-UNSEEN",
        },
        "results": [{
            "research_id": "DR-UNSEEN",
            "status": "DOC_RESEARCH_PARTIAL",
            "produced_by": "uac-doc-researcher",
            "topics": ["dialog persistence", "collection applicability"],
            "findings": [
                {"claim": "The documented dialog persists the last used folder "
                 "per user.",
                 "source_id": "DOC-N1",
                 "source_type": "OFFICIAL_DOCUMENTATION",
                 "authority": "OFFICIAL_PRODUCT_CONTRACT",
                 "applicability": "current release", "currentness": "CURRENT",
                 "evidence_role": "EXISTING_BEHAVIOR"},
                {"claim": "Single-asset applicability is documented; "
                 "collections are not addressed.",
                 "source_id": "DOC-N2",
                 "source_type": "OFFICIAL_DOCUMENTATION",
                 "authority": "OFFICIAL_PRODUCT_CONTRACT",
                 "applicability": "current release", "currentness": "CURRENT",
                 "evidence_role": "REQUIREMENT_CLARIFICATION"},
            ],
            "source_ids": ["DOC-N1", "DOC-N2"],
            "applicability": "current release",
            "limitations": ["Collection applicability is not documented."],
            "conflicts": [],
            "question_refs": ["Q-N1", "Q-N2"],
        }],
        "admitted_research_ids": ["DR-UNSEEN"],
    }
    manifest = {
        "question_plan": {"items": plan_items},
        "question_research": {"items": research_items},
        "question_resolutions": {"items": resolution_items},
        "doc_research": doc_block,
    }
    check("unseen fixture: planner gate clean", qp.validate(manifest) == [])
    check("unseen fixture: research router gate clean",
          qr.validate(manifest) == [])
    check("unseen fixture: resolver gate clean", qres.validate(manifest) == [])
    check("unseen fixture: doc research routing gate clean",
          dr.validate(manifest) == [])

    # C1 generalization: the same coverage contract holds on the unfamiliar
    # fixture - the answered question grounds acceptance coverage, the
    # partially answered question grounds regression coverage of the
    # established portion, and CONFLICTED / DUPLICATE / NOT_APPLICABLE
    # questions cannot produce coverage.
    cr = coverage_reasoner_mod

    def unseen_coverage(cid, qids, priority, klass, research_ids):
        return {
            "coverage_id": cid,
            "behavior": f"Coverage derived from {qids}.",
            "question_ids": qids,
            "evidence_ids": [f"EV-{qid}" for qid in qids],
            "research_ids": research_ids,
            "priority": priority,
            "coverage_class": klass,
            "contract_type": "POSITIVE",
            "surface": "the export dialog",
            "state_or_transition": "",
            "configuration": "",
            "applicability": "current release",
            "reason": "Traces to the resolved question evidence.",
            "acceptance_impact": "Defines what the Writer may assert.",
            "dimensions_considered": ["PRESERVATION"],
        }

    manifest["coverage_decisions"] = {
        "items": [
            unseen_coverage("COV-N1", ["Q-N1"], "P0", "ACCEPTANCE",
                            ["DR-UNSEEN"]),
            unseen_coverage("COV-N2", ["Q-N2"], "P1", "QE_REGRESSION",
                            ["DR-UNSEEN"]),
        ],
        "writer_handoff": ["COV-N1", "COV-N2"],
    }
    manifest["writer_package"] = {
        "acs": [{"ac_id": "AC-N1", "text": "The persisted folder is restored.",
                 "coverage_ids": ["COV-N1"]}],
    }
    check("unseen fixture: coverage gate clean",
          cr.validate(manifest) == [])
    check("unfamiliar fixture follows the generic coverage contract",
          cr.validate(manifest) == [])

    conflicted_coverage = dict(manifest["coverage_decisions"])
    conflicted_coverage["items"] = [
        *manifest["coverage_decisions"]["items"],
        unseen_coverage("COV-N3", ["Q-N3"], "P1", "QE_REGRESSION", []),
    ]
    check("CONFLICTED question cannot produce coverage",
          any("cannot ground" in p for p in cr.validate(
              dict(manifest, coverage_decisions=conflicted_coverage))))
    applicable_coverage = dict(manifest["coverage_decisions"])
    applicable_coverage["items"] = [
        *manifest["coverage_decisions"]["items"],
        unseen_coverage("COV-N5", ["Q-N5"], "P1", "QE_REGRESSION", []),
    ]
    check("NOT_APPLICABLE question cannot produce coverage",
          any("cannot ground" in p for p in cr.validate(
              dict(manifest, coverage_decisions=applicable_coverage))))
    duplicate_only = dict(manifest["coverage_decisions"])
    duplicate_only["items"] = [
        *manifest["coverage_decisions"]["items"],
        unseen_coverage("COV-N4", ["Q-N4"], "P1", "QE_REGRESSION", []),
    ]
    check("DUPLICATE must link the surviving question",
          any("DUPLICATE" in p for p in cr.validate(
              dict(manifest, coverage_decisions=duplicate_only))))

    print("  question trace [unseen fixture]:")
    for row in plan_items:
        print(f"    {row['question_id']} [{row['category']}]: {row['question']}")
    print("  research trace [unseen fixture]:")
    print("    doc routing: DOC_RESEARCH_REQUIRED -> uac-doc-researcher "
          "-> DOC_RESEARCH_PARTIAL (DR-UNSEEN)")
    for route in research_items:
        print(f"    {route['question_ref']}: "
              f"{route['research_requirement']}/{route['research_status']}")
    print("  resolution trace [unseen fixture]:")
    for outcome in resolution_items:
        print(f"    {outcome['question_id']} -> {outcome['disposition']}")

    # The equal-authority conflict must stay unresolved - it cannot be
    # rewritten as ANSWERED without a higher-authority basis.
    manifest["question_resolutions"]["items"][2] = {
        "question_id": "Q-N3", "disposition": "ANSWERED",
        "answer": "Referenced metadata is included.",
        "source_ids": ["DOC-N3A"],
        "source_authority": "OFFICIAL_DOCUMENTATION",
        "applicability": "current release", "limitations": [],
        "contradictions": ["DOC-N3B excludes it."],
    }
    check("equal-authority conflict cannot be resolved by picking one side",
          any("equal-authority conflict" in p
              for p in qres.validate(manifest)))

    print("test_question_reasoning_unseen_fixture: OK")


def test_scope_applicability() -> None:
    sa = scope_applicability_mod

    check("absent scope_applicability passes", sa.validate({}) == [])

    def wrap(*cands, outcome="Fix the purge cleanup job"):
        return {"scope_applicability": {"primary_customer_outcome": outcome, "candidates": list(cands)}}

    direct = {"candidate_ref": "CF-01", "scope_status": "DIRECT_SCOPE",
              "scope_basis": "CURRENT_JIRA_AFFECTED_SURFACE",
              "customer_contract_relation": "PRIMARY", "scope_evidence_ids": ["CF-01"]}

    check("grounded direct-scope candidate passes", sa.validate(wrap(direct)) == [])

    # Name-only expansion into scope is rejected.
    name_only = {"candidate_ref": "X1", "scope_status": "SHARED_PATH_REGRESSION",
                 "scope_basis": "SAME_FEATURE_NAME", "customer_contract_relation": "SECONDARY_SHARED",
                 "scope_evidence_ids": ["E1"], "shared_path_evidence": ["E1"]}
    check("name-only scope expansion is rejected",
          any("name-only basis" in p for p in sa.validate(wrap(direct, name_only))))

    # In-scope candidate without evidence is rejected.
    no_ev = {"candidate_ref": "X2", "scope_status": "DIRECT_SCOPE",
             "scope_basis": "IMPLEMENTATION_APPLICABILITY", "customer_contract_relation": "PRIMARY",
             "scope_evidence_ids": []}
    check("in-scope candidate needs evidence",
          any("scope_evidence_ids" in p for p in sa.validate(wrap(no_ev))))

    # SHARED_PATH_REGRESSION must be evidenced and not PRIMARY.
    shared_primary = {"candidate_ref": "X3", "scope_status": "SHARED_PATH_REGRESSION",
                      "scope_basis": "SHARED_IMPLEMENTATION_PATH", "customer_contract_relation": "PRIMARY",
                      "scope_evidence_ids": ["E1"], "shared_path_evidence": ["E1"]}
    check("shared-path regression must stay distinct from primary",
          any("must not be PRIMARY" in p for p in sa.validate(wrap(direct, shared_primary))))

    shared_ok = {"candidate_ref": "X3", "scope_status": "SHARED_PATH_REGRESSION",
                 "scope_basis": "SHARED_IMPLEMENTATION_PATH", "customer_contract_relation": "SECONDARY_SHARED",
                 "scope_evidence_ids": ["E1"], "shared_path_evidence": ["shared job executor path E1"]}
    check("evidenced shared-path regression passes", sa.validate(wrap(direct, shared_ok)) == [])

    # REFERENCE_ONLY cannot promote an AC.
    ref_promote = {"candidate_ref": "X4", "scope_status": "REFERENCE_ONLY",
                   "scope_basis": "SEMANTIC_APPLICABILITY", "customer_contract_relation": "NOT_CONTRACT",
                   "promotes_ac": True}
    check("reference-only cannot promote an AC",
          any("must not promote an AC" in p for p in sa.validate(wrap(direct, ref_promote))))

    # UNRESOLVED_SCOPE must map to an Open Question.
    unresolved = {"candidate_ref": "X5", "scope_status": "UNRESOLVED_SCOPE",
                  "scope_basis": "SHARED_SEMANTIC_PATH", "customer_contract_relation": "SECONDARY_SHARED"}
    check("unresolved scope must become an Open Question",
          any("open_question_ref" in p for p in sa.validate(wrap(direct, unresolved))))

    unresolved_ok = dict(unresolved, open_question_ref="OQ-09")
    check("unresolved scope with Open Question passes", sa.validate(wrap(direct, unresolved_ok)) == [])

    # Target-surface-first: candidates without a primary DIRECT_SCOPE anchor are rejected.
    check("scope must anchor on the primary outcome",
          any("must begin from a DIRECT_SCOPE" in p for p in sa.validate(wrap(shared_ok))))

    print("test_scope_applicability: OK")


def test_ac_language_policy() -> None:
    lp = ac_language_policy_mod

    check("absent ac_synthesis passes", lp.validate({}) == [])

    def wrap(final_acs, source=None):
        b = {"ac_synthesis": {"final_acs": final_acs}}
        if source is not None:
            b["ac_synthesis"]["source_candidate_ids"] = source
        return b

    good = {"ac_ref": "AC-01", "title": "Deleted-preset data is removed on cleanup",
            "body": "When cleanup completes, deleted-preset execution data must be absent and valid data must remain.",
            "candidate_ids": ["CF-09"]}
    check("clear final AC passes", lp.validate(wrap([good])) == [])

    vague = dict(good, ac_ref="AC-02", body="The job should work correctly after the fix.")
    check("vague expectation flagged",
          any("VAGUE_EXPECTATION" in p for p in lp.validate(wrap([vague]))))

    bad_title = dict(good, ac_ref="AC-03", title="Regression behavior")
    check("unclear title flagged",
          any("UNCLEAR_AC_TITLE" in p for p in lp.validate(wrap([bad_title]))))

    leak = dict(good, ac_ref="AC-04",
                body="PurgePresetExecutionDataJob.process() must break the loop on error.")
    check("implementation leak flagged",
          any("IMPLEMENTATION_DETAIL_LEAK" in p for p in lp.validate(wrap([leak]))))

    leak_ok = dict(leak, technical_artifact_is_requirement=True)
    check("declared technical-artifact AC is allowed", lp.validate(wrap([leak_ok])) == [])

    multi = dict(good, ac_ref="AC-05", distinct_contract_count=2)
    check("multiple contracts flagged",
          any("MULTIPLE_UNRELATED_CONTRACTS" in p for p in lp.validate(wrap([multi]))))

    # MATERIAL_CANDIDATE_LOSS: a dropped source candidate is caught.
    lossy = {"ac_ref": "AC-01", "title": "Merged cleanup contract",
             "body": "Deleted-preset data must be removed while valid data remains.",
             "candidate_ids": ["CF-09"], "merged_candidate_ids": ["CF-09"]}
    check("material candidate loss flagged",
          any("MATERIAL_CANDIDATE_LOSS" in p for p in lp.validate(wrap([lossy], source=["CF-09", "CF-03"]))))
    check("full retention passes",
          lp.validate(wrap([dict(lossy, merged_candidate_ids=["CF-09", "CF-03"])], source=["CF-09", "CF-03"])) == [])

    # HIDDEN_MATERIAL_SCENARIO: merge hiding a distinct material dimension.
    hidden = {"ac_ref": "AC-01", "title": "Combined failure and success behavior",
              "body": "Cleanup reports failures and returns succeeded when done.",
              "candidate_ids": ["CF-02", "CF-04"], "merged_candidate_ids": ["CF-02", "CF-04"],
              "distinct_material_dimensions": ["failure"]}
    check("hidden material dimension flagged",
          any("HIDDEN_MATERIAL_SCENARIO" in p for p in lp.validate(wrap([hidden]))))

    # REDUNDANT_AC: duplicate bodies.
    dup = [good, dict(good, ac_ref="AC-09")]
    check("redundant AC flagged",
          any("REDUNDANT_AC" in p for p in lp.validate(wrap(dup))))

    print("test_ac_language_policy: OK")


def test_publishing_scope_coverage() -> None:
    ps = publishing_scope_coverage_mod

    # Non-publishing ticket: not applicable, always clean.
    non_pub = {"issue": {"components": ["Authoring"]}}
    check("non-publishing ticket is not applicable", ps.validate(non_pub, "some plan text") == [])

    pub = {"issue": {"components": ["Publishing"]}}
    bare_plan = "**Acceptance Criteria**\n- AC-01 [Proposed]: (Basic) Given a preset | When output is generated | Then metadata is written | Evidence: Jira.\n"
    probs = ps.validate(pub, bare_plan)
    check("publishing plan without DITA-OT coverage is flagged",
          any("DITA-OT processing" in p for p in probs))
    check("publishing plan without preset scope is flagged",
          any("preset IN-scope" in p for p in probs))

    good_plan = (
        "**Acceptance Criteria**\n"
        "- AC-14 [Proposed]: (Integration) Given a PDF preset that uses the DITA-OT processing engine rather than the native engine | When output is generated | Then existing DITA-OT behaviour is unchanged | Evidence: Jira.\n"
        "- AC-15 [Proposed]: (Integration) Given the change | When output is generated for a non-Native-PDF preset | Then it is out of scope unless shared-code analysis proves the path is shared | Evidence: Jira.\n"
    )
    check("publishing plan covering DITA-OT mode and preset scope passes",
          ps.validate(pub, good_plan) == [])

    # Text-signal activation (no component) also triggers.
    text_pub = {"issue": {"components": []}}
    check("output-preset text signal activates the check",
          ps.validate(text_pub, "**Acceptance Criteria**\n- AC-01: native pdf output preset metadata\n") != [])

    # UACGAP-02: a publishing token that appears ONLY inside the historical-neighbours
    # section must NOT classify a non-publishing ticket as publishing.
    neighbour_only = {"issue": {"components": ["Editor"]}}
    neighbour_plan = (
        "**Acceptance Criteria**\n"
        "- AC-01 [Proposed]: (Basic) Given a map | When a topicref is inserted | Then an attribute is added | Evidence: Jira.\n\n"
        "**Known Jira Bugs / Past Similar Tickets**\n"
        '- GUIDES-10509 "Native pdf - navtitle for topichead is not honoured" - Similarity: adjacent.\n'
    )
    check("neighbour-only native-pdf mention does not classify as publishing",
          not ps.is_publishing_ticket(neighbour_only, neighbour_plan))
    check("neighbour-only native-pdf plan is not flagged",
          ps.validate(neighbour_only, neighbour_plan) == [])
    # But the same token in the ticket's OWN Acceptance Criteria still activates.
    own_plan = (
        "**Acceptance Criteria**\n- AC-01: native pdf output preset in scope | Evidence: Jira.\n\n"
        "**Known Jira Bugs / Past Similar Tickets**\n- GUIDES-1 nothing.\n"
    )
    check("own-section native-pdf mention still classifies as publishing",
          ps.is_publishing_ticket(neighbour_only, own_plan))

    print("test_publishing_scope_coverage: OK")


def test_miss_probe_library() -> None:
    mpl = miss_probe_library_mod

    # Shipped library has the seeded value-provenance probe, and it is ACTIVE.
    library = mpl.load_library()
    check("library loads seeded probes", len(library) >= 1)
    seed = next((p for p in library if p.get("probe_id") == "MP-001"), None)
    check("seeded MP-001 present", seed is not None)
    status, _ = mpl.effective_status(seed)
    check("seeded probe is ACTIVE", status == "ACTIVE")
    check(
        "seeded probe axis is VALUE_SET_CHANNEL",
        seed["implied_dimension"]["axis"] == "VALUE_SET_CHANNEL",
    )

    def probe(**over):
        base = json.loads(json.dumps(seed))
        for k, v in over.items():
            if "." in k:
                a, b = k.split(".", 1)
                base.setdefault(a, {})[b] = v
            else:
                base[k] = v
        return base

    # A MODEL-sourced delta can never be ACTIVE.
    model_probe = probe()
    model_probe["provenance"]["source"] = "MODEL"
    check("model-sourced probe is not ACTIVE", mpl.effective_status(model_probe)[0] != "ACTIVE")

    # A language/testability pattern is not a discovery probe.
    lang_probe = probe(pattern_class="RENDERING_LANGUAGE_PATTERN")
    check("language pattern is retired", mpl.effective_status(lang_probe)[0] == "RETIRED")

    # A non-generalized (single concrete literal) probe is rejected.
    literal_probe = probe()
    literal_probe["signal_pattern"]["match"] = ["getMetadataList"]
    check("single-literal probe is not ACTIVE", mpl.effective_status(literal_probe)[0] != "ACTIVE")

    # A VALIDATING probe runs in SHADOW.
    validating = probe()
    validating["provenance"]["promotion_state"] = "VALIDATING"
    check("validating probe is SHADOW", mpl.effective_status(validating)[0] == "SHADOW")

    # candidates_for matches evidence and tags LEARNED_PROBE + probe_id + delta.
    pairs = [("E1", "The handler reads the value from jcr:content/metadata on the repository node.")]
    learned = mpl.candidates_for(pairs)
    match = next((c for c in learned if c["generator"] == "LEARNED_PROBE"), None)
    check("learned candidate emitted for matching evidence", match is not None)
    check("learned candidate axis is VALUE_SET_CHANNEL", match["dimension"] == "VALUE_SET_CHANNEL")
    check("learned candidate carries probe id", match["probe_id"] == "MP-001")
    check("learned candidate cites the evidence label", "E1" in match["current_evidence"])
    check(
        "learned candidate technical_basis names the probe and delta",
        any("LEARNED_PROBE:MP-001" in t for t in match["technical_basis"])
        and any("delta:" in t for t in match["technical_basis"]),
    )

    # No match -> no learned candidate.
    check("no learned candidate without a match", mpl.candidates_for([("E9", "unrelated text")]) == [])

    # manifest miss_probe_activity consistency.
    check("absent miss_probe_activity passes", mpl.validate({}) == [])
    bad = {"miss_probe_activity": {"dispositions": [{"probe_id": "MP-999", "disposition": "COVERED_BY_AC"}]}}
    check("unknown probe id flagged", any("unknown probe_id" in p for p in mpl.validate(bad)))

    print("test_miss_probe_library: OK")


def test_feature_map() -> None:
    fm = feature_map_mod

    feature_map = fm.load_map()
    check("checked-in feature map passes strict governance", fm.validate_repository_map() == [])
    check("feature map schema is v1", feature_map["schema_version"] == fm.SCHEMA_VERSION)
    check("feature map is installed and approved", fm.is_present() is True)
    check("feature map has seven curated surfaces", len(feature_map["surfaces"]) == 7)
    asset_surface = next(
        (surface for surface in feature_map["surfaces"] if surface["surface"] == "ASSET_UPLOAD_DAM"),
        None,
    )
    check("asset-upload surface is present", asset_surface is not None)
    asset_features = {item["feature"] for item in asset_surface["native_features"]}
    check(
        "asset-upload surface contains the six required native features",
        {
            "duplicate detection",
            "versioning and timeline",
            "DAM update-asset workflows",
            "processing profiles / metadata",
            "smart tags",
            "expiry",
        }.issubset(asset_features),
    )
    check(
        "every curated feature is Human-approved and cites Experience League",
        all(
            item["approval_status"] == fm.APPROVED_STATUS
            and item["reference"].startswith("Experience League ")
            and item["reference_urls"]
            and all(url.startswith(fm.EXPERIENCE_LEAGUE_PREFIX) for url in item["reference_urls"])
            for surface in feature_map["surfaces"]
            for item in surface["native_features"]
        ),
    )
    check(
        "surface match phrases are generic lower-case text rather than code paths or identifiers",
        all(
            token == token.casefold()
            and not any(mark in token for mark in ("/", "\\", "::", "(", ")", "."))
            and not re.search(r"[a-z][a-z0-9]*[A-Z]", token)
            for surface in feature_map["surfaces"]
            for token in surface["match"]
        ),
    )

    pairs = [
        (
            "E-UPLOAD",
            "The asset upload uses the shared overwrite path after an upload conflict.",
        )
    ]
    candidates = fm.candidates_for(pairs)
    by_feature = {candidate["feature"]: candidate for candidate in candidates}
    check("asset upload emits duplicate-detection candidate", "duplicate detection" in by_feature)
    check("asset upload emits versioning candidate", "versioning and timeline" in by_feature)
    duplicate = by_feature["duplicate detection"]
    check("feature candidate generator is FEATURE_MAP", duplicate["generator"] == "FEATURE_MAP")
    check("feature candidate status is investigation-only", duplicate["status"] == "INVESTIGATION_CANDIDATE")
    check("feature candidate carries feature tag", duplicate["feature"] == "duplicate detection")
    check("feature candidate carries implied dimension axis", duplicate["implied_dimension_axis"] == "CODE_PATH_CONSUMER")
    check("feature candidate uses canonical coverage dimension", duplicate["dimension"] == "CONSUMER")
    check("feature candidate carries reference tag", duplicate["reference"].startswith("Experience League "))
    check("feature candidate cites matching evidence", "E-UPLOAD" in duplicate["current_evidence"])
    check("feature candidate is explicitly advisory", duplicate["advisory_only"] is True)
    check(
        "feature and reference survive in technical basis",
        any("duplicate detection" in basis for basis in duplicate["technical_basis"])
        and any("reference:Experience League" in basis for basis in duplicate["technical_basis"]),
    )

    check(
        "non-matching evidence contributes no feature-map candidate",
        fm.candidates_for([("E-EDITOR", "The caret remains in the editor after typing.")]) == [],
    )
    baseline_candidates = fm.candidates_for(
        [("E-BASELINE", "Create a translation project and select Use Baseline.")]
    )
    baseline_translation = next(
        (
            candidate
            for candidate in baseline_candidates
            if candidate.get("feature") == "baseline translation project"
        ),
        None,
    )
    check(
        "baseline evidence emits the approved translation-project candidate",
        baseline_translation is not None,
    )
    check(
        "baseline translation candidate preserves its direct Experience League source",
        baseline_translation is not None
        and "translate-documents-web-editor"
        in " ".join(baseline_translation.get("reference_urls", [])),
    )
    check(
        "baseline translation is a configuration-branch investigation",
        baseline_translation is not None
        and baseline_translation.get("implied_dimension_axis") == "CONFIG_BRANCH",
    )
    adjacent_translation_candidates = fm.candidates_for(
        [("E-TRANSLATION", "Create a translation project for selected topics.")]
    )
    check(
        "translation evidence without a baseline signal does not activate baseline translation",
        not any(
            candidate.get("feature") == "baseline translation project"
            for candidate in adjacent_translation_candidates
        ),
    )
    check(
        "Oxygen remains outside the governed map pending sufficient source approval",
        not any(surface.get("surface") == "EDITOR_OXYGEN" for surface in feature_map["surfaces"]),
    )
    review_surface = next(
        (surface for surface in feature_map["surfaces"] if surface["surface"] == "REVIEW"),
        None,
    )
    baseline_surface = next(
        (surface for surface in feature_map["surfaces"] if surface["surface"] == "BASELINE"),
        None,
    )
    check(
        "baseline surface contains only the approved translation-project feature",
        baseline_surface is not None
        and [
            feature.get("feature") for feature in baseline_surface.get("native_features", [])
        ]
        == ["baseline translation project"],
    )
    review_urls = [
        url
        for feature in (review_surface or {}).get("native_features", [])
        for url in feature.get("reference_urls", [])
    ]
    check(
        "review membership and panel candidates use the direct review-comments source",
        review_surface is not None
        and len(review_surface.get("native_features", [])) == 2
        and all("review-address-review-comments" in url for url in review_urls)
        and not any("review-manage-tasks-review-dashboard" in url for url in review_urls),
    )
    with tempfile.TemporaryDirectory() as tmp:
        malformed = Path(tmp) / "feature-map.json"
        malformed.write_text("{not-json", encoding="utf-8")
        check("malformed map loads as empty", fm.load_map(malformed)["surfaces"] == [])
        check("malformed map contributes no candidate", fm.candidates_for(pairs, malformed) == [])
        check("missing map contributes no candidate", fm.candidates_for(pairs, Path(tmp) / "missing.json") == [])

        wrong_surfaces = Path(tmp) / "wrong-surfaces.json"
        wrong_surfaces.write_text(
            json.dumps(
                {
                    "schema_version": fm.SCHEMA_VERSION,
                    "curation_status": fm.APPROVED_STATUS,
                    "authority": "Adobe Experience League",
                    "surfaces": 42,
                }
            ),
            encoding="utf-8",
        )
        check("wrong-typed surfaces fail open", fm.load_map(wrong_surfaces)["surfaces"] == [])
        check("wrong-typed surfaces contribute no candidate", fm.candidates_for(pairs, wrong_surfaces) == [])

        wrong_features = Path(tmp) / "wrong-features.json"
        wrong_features.write_text(
            json.dumps(
                {
                    "schema_version": fm.SCHEMA_VERSION,
                    "curation_status": fm.APPROVED_STATUS,
                    "authority": "Adobe Experience League",
                    "surfaces": [
                        {
                            "surface": "ASSET_UPLOAD_DAM",
                            "match": ["asset upload"],
                            "native_features": 42,
                        }
                    ],
                }
            ),
            encoding="utf-8",
        )
        check("wrong-typed native features fail open", fm.load_map(wrong_features)["surfaces"] == [])
        check("wrong-typed native features contribute no candidate", fm.candidates_for(pairs, wrong_features) == [])

        unapproved = Path(tmp) / "unapproved.json"
        unapproved_data = json.loads(
            (Path(__file__).resolve().parent.parent / "data" / "aem_feature_map.json").read_text(
                encoding="utf-8"
            )
        )
        unapproved_data["curation_status"] = "MODEL_PROPOSED"
        unapproved.write_text(json.dumps(unapproved_data), encoding="utf-8")
        check("non-Human-approved map is ignored", fm.load_map(unapproved)["surfaces"] == [])
        check(
            "strict governance rejects non-Human-approved checked-in data",
            any("curation_status" in problem for problem in fm.validate_repository_map(unapproved)),
        )

        hidden_unapproved = Path(tmp) / "hidden-unapproved.json"
        hidden_unapproved_data = json.loads(json.dumps(unapproved_data))
        hidden_unapproved_data["curation_status"] = fm.APPROVED_STATUS
        hidden_unapproved_data["surfaces"][0]["native_features"][0]["approval_status"] = "MODEL_PROPOSED"
        hidden_unapproved.write_text(json.dumps(hidden_unapproved_data), encoding="utf-8")
        check(
            "strict governance rejects an unapproved entry instead of silently sanitizing it",
            any("Human-approved" in problem for problem in fm.validate_repository_map(hidden_unapproved)),
        )

    surface_candidate_sets = [
        candidates,
        fm.candidates_for([("E-PUBLISH", "Generate output with an output preset.")]),
        fm.candidates_for([("E-TRANSLATE", "Start a translation project for a target language.")]),
        baseline_candidates,
    ]
    check(
        "every emitted feature candidate validates in canonical coverage-hypothesis shape",
        all(
            coverage_mod.validate_coverage_block(candidate_set) == []
            for candidate_set in surface_candidate_sets
        ),
    )

    check("feature map summary reports approved entries", "approved feature(s)" in fm.summarize())
    print("test_feature_map: OK")


def test_offline_retrieval() -> None:
    offline = offline_retrieval_mod
    original_loader = offline._load_backend

    class FakeVector:
        def tolist(self):
            return [0.1, 0.2, 0.3]

    calls = []

    def fake_query(collection, vector, k=5):
        calls.append((collection, vector, k))
        check("offline retrieval converts embedding to a plain list", isinstance(vector, list))
        if collection == "docs":
            return [
                {
                    "id": "doc-1",
                    "document": "Experience Manager detects duplicate assets during upload.",
                    "metadata": {
                        "title": "Detect duplicate assets",
                        "url": "https://experienceleague.adobe.com/example/detect-duplicate-assets",
                        "source_type": "EXPERIENCE_LEAGUE",
                        "authority": "OFFICIAL_CURRENT_PRODUCT_DOCUMENTATION",
                    },
                    "distance": 0.225,
                }
            ]
        return [
            {
                "id": "EXAMPLE-9::acceptance_criteria_chunk::0",
                "document": "Acceptance criteria: this Human answer must not be returned.",
                "metadata": {
                    "jira_key": "EXAMPLE-9",
                    "title": "Hidden accepted UAC",
                    "components": '["Asset Management"]',
                    "chunk_type": "acceptance_criteria_chunk",
                },
                "distance": 0.1,
            },
            {
                "id": "EXAMPLE-10::problem_chunk::0",
                "document": (
                    "Overwrite can leave the previous binary. "
                    "Acceptance criteria: this later answer section is excluded."
                ),
                "metadata": {
                    "jira_key": "EXAMPLE-10",
                    "title": "Overwrite keeps the previous binary",
                    "components": '["Asset Management"]',
                    "chunk_type": "problem_chunk",
                },
                "distance": 0.31,
            },
            {
                "id": "EXAMPLE-11::problem_chunk::0",
                "document": "Unrelated publishing failure.",
                "metadata": {
                    "jira_key": "EXAMPLE-11",
                    "title": "Unrelated publishing failure",
                    "components": '["Publishing"]',
                    "chunk_type": "problem_chunk",
                },
                "distance": 0.32,
            },
        ]

    fake_backend = {
        "embed_query": lambda query: FakeVector(),
        "query_collection": fake_query,
        "get_collection_count": lambda collection: 7,
        "is_chroma_available": lambda: True,
        "docs_collection": "docs",
        "history_collection": "history",
    }
    offline._load_backend = lambda: fake_backend
    docs = offline.retrieve_docs("duplicate detection on upload", 3)
    check("offline docs normalize one retrieved row", len(docs) == 1)
    doc = docs[0]
    check("offline docs preserve title", doc["title"] == "Detect duplicate assets")
    check("offline docs preserve URL", "detect-duplicate-assets" in doc["url"])
    check("offline docs preserve distance", doc["distance"] == 0.225)
    check("offline docs use OFFLINE_CHROMA", doc["source_label"] == "OFFLINE_CHROMA")
    check("offline docs are supporting discovery", doc["authority_class"] == "SUPPORTING_DISCOVERY")
    check("offline docs are non-authoritative", doc["non_authoritative"] is True)
    check("offline docs record success", offline.retrieval_status("docs")["status"] == "SUCCESS")

    history = offline.retrieve_history("asset upload overwrite", "Asset Management", 3)
    check("offline history returns only same-component safe chunks", len(history) == 1)
    check("offline history preserves Jira key", history[0]["jira_key"] == "EXAMPLE-10")
    check("offline history never claims live indexed history", history[0]["indexed_history_run"] is False)
    check("offline history strips embedded Human AC text", "acceptance criteria" not in history[0]["snippet"].casefold())
    check("offline history is non-authoritative", history[0]["non_authoritative"] is True)

    absent_backend = dict(fake_backend)
    absent_backend["get_collection_count"] = lambda collection: 0
    offline._load_backend = lambda: absent_backend
    check("absent docs collection returns no result", offline.retrieve_docs("upload", 3) == [])
    check(
        "absent docs collection records a reason",
        offline.retrieval_status("docs")["reason"] == "collection_absent_or_empty",
    )
    check("absent history collection returns no result", offline.retrieve_history("upload", "Asset Management", 3) == [])
    check(
        "absent history collection records a reason",
        offline.retrieval_status("history")["reason"] == "collection_absent_or_empty",
    )

    offline._load_backend = lambda: None
    check("unimportable backend returns no fabricated docs", offline.retrieve_docs("upload", 3) == [])
    check(
        "unimportable backend reason is recorded without raw exception text",
        offline.retrieval_status("docs")["reason"] == "backend_package_not_importable",
    )
    offline._load_backend = original_loader
    check("offline retrieval exercised both real collection contracts", {call[0] for call in calls} == {"docs", "history"})
    print("test_offline_retrieval: OK")


def test_dimension_synthesizer() -> None:
    ds = dimension_synthesizer_mod

    class OfflineStub:
        def __init__(self, available=True):
            self.available = available
            self.docs_calls = []
            self.history_calls = []
            self.statuses = {
                "docs": {"status": "UNAVAILABLE", "reason": "collection_absent_or_empty"},
                "history": {"status": "UNAVAILABLE", "reason": "collection_absent_or_empty"},
            }

        def retrieve_docs(self, query, k):
            self.docs_calls.append((query, k))
            if self.available and "duplicate detection" in str(query).casefold():
                self.statuses["docs"] = {"status": "SUCCESS", "reason": "normalized_results"}
                return [
                    {
                        "source_label": "OFFLINE_CHROMA",
                        "authority_class": "SUPPORTING_DISCOVERY",
                        "non_authoritative": True,
                        "title": "Detect duplicate assets",
                        "snippet": "Experience Manager detects duplicates during asset upload.",
                        "url": "https://experienceleague.adobe.com/en/docs/experience-manager-cloud-service/content/assets/admin/detect-duplicate-assets",
                        "source_ref": "https://experienceleague.adobe.com/en/docs/experience-manager-cloud-service/content/assets/admin/detect-duplicate-assets",
                        "distance": 0.225,
                    }
                ]
            self.statuses["docs"] = {
                "status": "EMPTY" if self.available else "UNAVAILABLE",
                "reason": "query_returned_no_rows" if self.available else "collection_absent_or_empty",
            }
            return []

        def retrieve_history(self, query, component, k):
            self.history_calls.append((query, component, k))
            if not self.available:
                self.statuses["history"] = {
                    "status": "UNAVAILABLE",
                    "reason": "collection_absent_or_empty",
                }
                return []
            self.statuses["history"] = {"status": "SUCCESS", "reason": "normalized_results"}
            return [
                {
                    "source_label": "OFFLINE_CHROMA",
                    "authority_class": "SUPPORTING_DISCOVERY",
                    "non_authoritative": True,
                    "indexed_history_run": False,
                    "jira_key": "EXAMPLE-10",
                    "title": "Overwrite keeps the previous binary",
                    "distance": 0.31,
                }
            ]

        def retrieval_status(self, kind):
            return dict(self.statuses[kind])

    original_offline_loader = ds._load_offline_retrieval
    unavailable = OfflineStub(available=False)
    ds._load_offline_retrieval = lambda: unavailable

    # Non-activated: no behavior_model or evidence_catalog.
    check("synthesizer not activated on empty manifest", ds.synthesize({})["activated"] is False)
    check("no review notes when not activated", ds.review_notes({}) == [])

    manifest = {
        "behavior_model": {
            "facts": [
                {
                    "fact": "The handler reads the value from the repository node jcr:content/metadata.",
                    "evidence_ids": ["E1"],
                }
            ]
        },
        "rag_probes": [],
    }
    result = ds.synthesize(manifest)
    check("synthesizer activated with behavior_model", result["activated"] is True)
    value_cands = [
        c for c in result["candidates"]
        if c.get("implied_dimension_axis") == "VALUE_SET_CHANNEL" and c["generator"] == "CODE_NEIGHBORHOOD"
    ]
    check("emits a VALUE_SET_CHANNEL code-neighborhood candidate", len(value_cands) == 1)
    check("candidate cites the generating evidence id", "E1" in value_cands[0]["current_evidence"])
    check("candidate has non-empty technical_basis", bool(value_cands[0]["technical_basis"]))
    check(
        "records a history gap when no source",
        any("HISTORY_NEIGHBORHOOD" in g and "no live" in g for g in result["gaps"]),
    )
    check(
        "records a rag gap when no probes",
        any("RAG_NEIGHBORHOOD" in g for g in result["gaps"]),
    )
    check(
        "unrepresented candidate surfaces as a DISCOVERY note",
        any("DISCOVERY:" in n and "VALUE_SET_CHANNEL" in n for n in ds.review_notes(manifest)),
    )

    # A dimension tag is not evidence that a discovered relationship was checked.
    represented = dict(manifest)
    represented["coverage_hypotheses"] = [{"dimension": "VALUE_SET_CHANNEL"}]
    check(
        "axis-only representation cannot suppress discovery review",
        any("VALUE_SET_CHANNEL" in n for n in ds.review_notes(represented)),
    )

    feature_manifest = {
        "behavior_model": {
            "facts": [
                {
                    "fact": "The shared asset upload resolves an overwrite after an upload conflict.",
                    "evidence_ids": ["E-UPLOAD"],
                }
            ]
        },
        "rag_probes": [],
    }
    feature_result = ds.synthesize(feature_manifest)
    feature_candidates = [
        candidate
        for candidate in feature_result["candidates"]
        if candidate.get("generator") == "FEATURE_MAP"
    ]
    feature_names = {candidate.get("feature") for candidate in feature_candidates}
    check("synthesizer appends FEATURE_MAP duplicate detection", "duplicate detection" in feature_names)
    check("synthesizer appends FEATURE_MAP versioning", "versioning and timeline" in feature_names)
    check(
        "feature-map candidate receives a stable synthesizer id",
        all(candidate["hypothesis_id"].startswith("DS-") for candidate in feature_candidates),
    )
    feature_notes = ds.review_notes(feature_manifest)
    check(
        "unrepresented feature-map candidate surfaces as DISCOVERY review",
        any(
            "DISCOVERY:" in note
            and "generator=FEATURE_MAP" in note
            and "feature=duplicate detection" in note
            for note in feature_notes
        ),
    )

    represented_feature = json.loads(json.dumps(feature_manifest))
    represented_feature["coverage_hypotheses"] = [
        {
            "dimension": "CONSUMER",
            "equivalence_key": next(
                candidate["equivalence_key"]
                for candidate in feature_candidates
                if candidate["feature"] == "duplicate detection"
            ),
        }
    ]
    represented_feature_notes = ds.review_notes(represented_feature)
    check(
        "feature key without verification cannot suppress discovery review",
        any("feature=duplicate detection" in note for note in represented_feature_notes),
    )
    check(
        "other same-axis feature-map candidates remain visible",
        any("feature=DAM update-asset workflows" in note for note in represented_feature_notes),
    )

    # A current behavior hit uses Human-approved feature-map vocabulary only to
    # formulate the query; the candidate exists because a real local row was returned.
    available = OfflineStub(available=True)
    ds._load_offline_retrieval = lambda: available
    before = json.loads(json.dumps(feature_manifest))
    offline_result = ds.synthesize(feature_manifest)
    offline_rag = [
        candidate for candidate in offline_result["candidates"]
        if candidate.get("generator") == "RAG_NEIGHBORHOOD"
        and candidate.get("source_label") == "OFFLINE_CHROMA"
    ]
    check("offline RAG emits a retrieved duplicate-detection neighbor", len(offline_rag) == 1)
    check(
        "offline RAG current evidence includes the retrieved document title",
        "Detect duplicate assets" in offline_rag[0]["current_evidence"][0],
    )
    check("offline RAG is supporting discovery", offline_rag[0]["authority_class"] == "SUPPORTING_DISCOVERY")
    check("offline RAG is advisory and non-authoritative", offline_rag[0]["advisory_only"] is True and offline_rag[0]["non_authoritative"] is True)
    check("offline RAG candidate validates in canonical hypothesis shape", coverage_mod.validate_coverage_block(offline_rag) == [])
    check(
        "feature-map expansion, not a hardcoded branch, formed the duplicate query",
        any("duplicate detection" in query.casefold() for query, _ in available.docs_calls),
    )
    offline_history = [
        candidate for candidate in offline_result["candidates"]
        if candidate.get("generator") == "HISTORY_NEIGHBORHOOD"
        and candidate.get("source_label") == "OFFLINE_CHROMA"
    ]
    # This fixture has no component, so the same-component history path stays honest.
    check("offline history does not run without a component", offline_history == [] and available.history_calls == [])
    check("offline synthesis does not mutate the manifest", feature_manifest == before)
    check("offline synthesis never invents indexed_history_run", "indexed_history_run" not in feature_manifest)
    check(
        "offline RAG surfaces through the existing DISCOVERY note",
        any(
            "generator=RAG_NEIGHBORHOOD" in note
            and "source_label=OFFLINE_CHROMA" in note
            and "Detect duplicate assets" in note
            for note in ds.review_notes(feature_manifest)
        ),
    )

    history_manifest = json.loads(json.dumps(feature_manifest))
    history_manifest["issue"] = {"key": "EXAMPLE-1", "components": ["Asset Management"]}
    history_result = ds.synthesize(history_manifest)
    history_candidates = [
        candidate for candidate in history_result["candidates"]
        if candidate.get("generator") == "HISTORY_NEIGHBORHOOD"
        and candidate.get("source_label") == "OFFLINE_CHROMA"
    ]
    check("offline history emits a same-component investigation candidate", len(history_candidates) == 1)
    check("offline history candidate explicitly remains non-live", history_candidates[0]["indexed_history_run"] is False)
    check("offline history does not mutate the live-history flag", "indexed_history_run" not in history_manifest)

    live_history = json.loads(json.dumps(history_manifest))
    live_history["indexed_history_run"] = True
    live_history["jira_history_queries"] = [{"component": "Platform", "scope": "cross_customer"}]
    history_calls_before = len(available.history_calls)
    live_result = ds.synthesize(live_history)
    check("recorded live history suppresses offline history lookup", len(available.history_calls) == history_calls_before)
    check(
        "recorded live history remains distinguishable from OFFLINE_CHROMA",
        any(
            candidate.get("generator") == "HISTORY_NEIGHBORHOOD"
            and not candidate.get("source_label")
            for candidate in live_result["candidates"]
        ),
    )

    ds._load_offline_retrieval = lambda: OfflineStub(available=False)
    absent_result = ds.synthesize(history_manifest)
    absent_offline = [
        candidate for candidate in absent_result["candidates"]
        if candidate.get("source_label") == "OFFLINE_CHROMA"
    ]
    check("absent collections fabricate no offline candidate", absent_offline == [])
    check(
        "absent collections record both offline generator gaps",
        any("RAG_NEIGHBORHOOD" in gap and "collection_absent_or_empty" in gap for gap in absent_result["gaps"])
        and any("HISTORY_NEIGHBORHOOD" in gap and "collection_absent_or_empty" in gap for gap in absent_result["gaps"]),
    )

    ds._load_offline_retrieval = lambda: available

    with tempfile.TemporaryDirectory() as tmp:
        gate = _load("run_gates_feature_map_integration", "run_gates.py")
        gate.dimension_synthesizer_mod._load_offline_retrieval = lambda: available
        plan_path = Path(tmp) / "plan.md"
        combined_path = Path(tmp) / "combined.md"
        manifest_path = Path(tmp) / "manifest.json"
        plan_path.write_text("# Test Plan\n", encoding="utf-8")
        combined_path.write_text("# Test Plan\n", encoding="utf-8")
        manifest_path.write_text(json.dumps(feature_manifest), encoding="utf-8")
        _, gate_notes = gate.run(
            str(plan_path),
            str(combined_path),
            str(manifest_path),
            None,
            True,
        )
        check(
            "run_gates emits FEATURE_MAP REVIEW DISCOVERY note",
            any(
                note.startswith("REVIEW DISCOVERY:")
                and "generator=FEATURE_MAP" in note
                and "feature=duplicate detection" in note
                for note in gate_notes
            ),
        )
        check(
            "run_gates emits OFFLINE_CHROMA RAG REVIEW DISCOVERY note",
            any(
                note.startswith("REVIEW DISCOVERY:")
                and "generator=RAG_NEIGHBORHOOD" in note
                and "source_label=OFFLINE_CHROMA" in note
                and "Detect duplicate assets" in note
                for note in gate_notes
            ),
        )
        nonmatch_manifest = {
            "behavior_model": {
                "facts": [{"fact": "The caret remains visible after typing.", "evidence_ids": ["E1"]}]
            }
        }
        manifest_path.write_text(json.dumps(nonmatch_manifest), encoding="utf-8")
        _, nonmatch_notes = gate.run(
            str(plan_path),
            str(combined_path),
            str(manifest_path),
            None,
            True,
        )
        check(
            "run_gates emits no FEATURE_MAP review for non-matching evidence",
            all("generator=FEATURE_MAP" not in note for note in nonmatch_notes),
        )
    ds._load_offline_retrieval = original_offline_loader
    print("test_dimension_synthesizer: OK")


def test_evidence_provenance() -> None:
    import hashlib

    nl = chr(10)
    with tempfile.TemporaryDirectory() as tmp:
        code_path = Path(tmp) / "Handler.java"
        code_path.write_text("class Handler { void run() {} }" + nl, encoding="utf-8")
        good_hash = "sha256:" + hashlib.sha256(code_path.read_bytes()).hexdigest()
        ref = code_path.as_posix()

        plan = nl.join([
            "**Acceptance Criteria**",
            "- AC-01: The handler runs. Evidence: E1; RAG probe recorded.",
            "",
        ])

        def manifest(entries, **extra):
            data = {
                "evidence_catalog": entries,
                "rag_probes": ["how does the handler run in the product"],
                "behavior_model": {"facts": [{"fact": "runs", "evidence_ids": ["E1"]}]},
            }
            data.update(extra)
            return data

        def write(data):
            p = Path(tmp) / "m.json"
            p.write_text(json.dumps(data), encoding="utf-8")
            return str(p)

        good_entries = [
            {"id": "E1", "source_type": "code", "source_ref": ref, "source_hash": good_hash},
            {"id": "E2", "source_type": "rag", "probe": "how does the handler run in the product"},
        ]
        f, _ = verify_mod.verify_provenance(plan, write(manifest(good_entries)))
        check("provenance: well-formed catalog passes", f == [])

        # No catalog -> no-op (backward compatible).
        f, _ = verify_mod.verify_provenance(plan, write({"rag_probes": []}))
        check("provenance: absent catalog is a clean pass", f == [])

        # behaviour_matters False -> opt-out.
        f, _ = verify_mod.verify_provenance(plan, write(manifest(good_entries, behaviour_matters=False)))
        check("provenance: behaviour_matters false opts out", f == [])

        # Dangling id (plan cites E9 not in catalog).
        f, _ = verify_mod.verify_provenance(
            plan.replace("E1;", "E1 E9;"), write(manifest(good_entries))
        )
        check(
            "provenance: dangling id fails with prefix",
            any(p.startswith(verify_mod.PROVENANCE_PREFIX) and "E9" in p for p in f),
        )

        # Missing source_ref path.
        missing = [dict(good_entries[0], source_ref=(Path(tmp) / "nope.java").as_posix()), good_entries[1]]
        f, _ = verify_mod.verify_provenance(plan, write(manifest(missing)))
        check("provenance: missing path fails", any("does not exist on disk" in p for p in f))

        # Hash mismatch.
        bad_hash = [dict(good_entries[0], source_hash="sha256:" + "0" * 64), good_entries[1]]
        f, _ = verify_mod.verify_provenance(plan, write(manifest(bad_hash)))
        check("provenance: hash mismatch fails", any("source_hash mismatch" in p for p in f))

        # RAG entry not matching a recorded probe.
        bad_rag = [good_entries[0], {"id": "E2", "source_type": "rag", "probe": "unrelated probe"}]
        f, _ = verify_mod.verify_provenance(plan, write(manifest(bad_rag)))
        check("provenance: unrecorded rag probe fails", any("recorded rag_probes" in p for p in f))

    run_gates_source = Path(__file__).with_name("run_gates.py").read_text(encoding="utf-8")
    check(
        "run_gates invokes verify_provenance",
        "verify_mod.verify_provenance(combined, manifest_path)" in run_gates_source,
    )
    print("test_evidence_provenance: OK")


def test_reviewer_request_coverage() -> None:
    gate = reviewer_request_coverage_mod
    nl = chr(10)

    plan = nl.join([
        "**Acceptance Criteria**",
        "- AC-13: Map Preview shows the same corrected index labels as the generated PDF.",
        "",
        "**Open Questions**",
        "- OQ-02: Does single-topic download share the same collector. QA impact: sets scope.",
        "",
    ])

    def block(entries):
        return {"reviewer_requests": entries}

    covered = {
        "request_id": "RR-01",
        "source": "jira_comment",
        "reviewer": "reviewer",
        "raw_text": "also check Map Preview",
        "surface_or_behavior": "Map Preview index labels",
        "disposition": "COVERED_BY_AC",
        "ac_refs": ["AC-13"],
    }

    check("no signal passes untouched", gate.validate(plan, {}) == [])
    check("covered reviewer request passes", gate.validate(plan, block([covered])) == [])

    bad_disp = dict(covered, disposition="REGRESSION")
    problems = gate.validate(plan, block([bad_disp]))
    check(
        "regression disposition is rejected with the prefix",
        any(p.startswith(gate.PREFIX) and "disposition" in p for p in problems),
    )

    no_refs = dict(covered)
    no_refs.pop("ac_refs")
    check(
        "covered-by-ac without ac_refs fails",
        any("no ac_refs" in p for p in gate.validate(plan, block([no_refs]))),
    )

    missing_ref = dict(covered, ac_refs=["AC-99"])
    check(
        "ac_refs absent from the plan fail",
        any("not present in the plan" in p for p in gate.validate(plan, block([missing_ref]))),
    )

    dangling_oq = {
        "request_id": "RR-02",
        "source": "jira_comment",
        "reviewer": "reviewer",
        "raw_text": "also check temp files",
        "surface_or_behavior": "temp-file representation",
        "disposition": "OPEN_QUESTION_UNRESOLVED_PATH",
        "open_question_ref": "OQ-77",
    }
    check(
        "unresolved-path open question must be known",
        any("not a known Open Question" in p for p in gate.validate(plan, block([dangling_oq]))),
    )

    imperative_manifest = {
        "reviewer_comments": ["Please also check the sorting of index terms with child elements."],
    }
    check(
        "imperative comment with no block fails",
        any("no reviewer_requests block" in p for p in gate.validate(plan, imperative_manifest)),
    )

    uncaptured = dict(imperative_manifest, reviewer_requests=[covered])
    check(
        "imperative comment not captured by any entry fails",
        any("not captured" in p for p in gate.validate(plan, uncaptured)),
    )

    run_gates_source = Path(__file__).with_name("run_gates.py").read_text(encoding="utf-8")
    check(
        "run_gates loads the reviewer-request gate",
        'reviewer_request_coverage_mod = _load("reviewer_request_coverage"' in run_gates_source,
    )
    check(
        "run_gates invokes the reviewer-request validator without hiding its prefix",
        "failures += reviewer_request_coverage_mod.validate(body, manifest_data)" in run_gates_source,
    )

    # Part 1: the reviewer_comments input is mandatory so the gate cannot stay dormant.
    req = gate.require_reviewer_comments_declared
    check("absent reviewer_comments is a hard failure", any("reviewer_comments must be declared" in p for p in req({})))
    check("empty reviewer_comments without checked flag fails", any("reviewer_comments_checked" in p for p in req({"reviewer_comments": []})))
    check("empty reviewer_comments with checked flag passes", req({"reviewer_comments": [], "reviewer_comments_checked": True}) == [])
    check("populated reviewer_comments passes the declaration check", req({"reviewer_comments": ["Please also check Map Preview."]}) == [])
    check("non-list reviewer_comments fails", any("must be a list" in p for p in req({"reviewer_comments": "x"})))
    print("test_reviewer_request_coverage: OK")


def test_reproducibility_gate() -> None:
    gate = reproducibility_gate_mod
    nl = chr(10)

    fix_plan = nl.join([
        "**Acceptance Criteria**",
        "- AC-01 Given a batch upload When two files hit UUID conflicts Then the correct asset is written.",
    ])
    signal_manifest = {
        "issue": {
            "summary": "Batch upload can overwrite the wrong asset on UUID conflict",
            "description": "We have been UNABLE TO REPRODUCE it in our environment; only a working hypothesis.",
            "labels": ["crosshair-needs-clarification"],
        }
    }

    # No signal -> not activated, clean pass (backward-compatible).
    clean_manifest = {"issue": {"summary": "Add indexterm to native PDF", "description": "steps to reproduce: publish"}}
    check("no not-reproducible signal is not activated", not gate.is_present(fix_plan, clean_manifest))
    check("no-signal plan passes", gate.validate(fix_plan, clean_manifest) == [])

    # Signal present, no block -> hard fail.
    check("signal without block activates", gate.is_present(fix_plan, signal_manifest))
    probs = gate.validate(fix_plan, signal_manifest)
    check("signal without reproducibility block fails", any("no reproducibility block" in p for p in probs))

    # Unconfirmed + no strategy declared -> fail.
    unconfirmed = dict(signal_manifest, reproducibility={
        "status": "UNCONFIRMED",
        "evidence": "comment: unable to reproduce; label crosshair-needs-clarification",
        "reproduction_strategy_present": False,
    })
    probs = gate.validate(fix_plan, unconfirmed)
    check("unconfirmed without strategy fails", any("REPRODUCTION STRATEGY" in p for p in probs))

    # Strategy claimed but no strategy content + fix ACs not gated -> fails both.
    claimed = dict(signal_manifest, reproducibility={
        "status": "UNCONFIRMED",
        "evidence": "unable to reproduce",
        "reproduction_strategy_present": True,
        "fix_acs_gated_on_reproduction": False,
    })
    probs = gate.validate(fix_plan, claimed)
    check("claimed strategy without content fails", any("no reproduction-strategy content" in p for p in probs))
    check("fix ACs not gated fails", any("gated on 'once reproduced'" in p for p in probs))

    # Complete: strategy content in plan + ACs gated -> pass.
    good_plan = nl.join([
        "**Reproduction Strategy**",
        "- Reliably reproduce by forcing the race: concurrent batch upload of two files that",
        "  collide on the same target UUID against a shared JCR session; vary batch size and timing.",
        "",
        "**Acceptance Criteria (Proposed - gated on once reproduced)**",
        "- AC-01 Once reproduced, the correct asset is written under the conflict.",
    ])
    good = dict(signal_manifest, reproducibility={
        "status": "UNCONFIRMED",
        "evidence": "unable to reproduce; working hypothesis (batch UUID-conflict race)",
        "reproduction_strategy_present": True,
        "fix_acs_gated_on_reproduction": True,
    })
    check("complete reproduction plan passes", gate.validate(good_plan, good) == [])

    run_gates_source = Path(__file__).with_name("run_gates.py").read_text(encoding="utf-8")
    check(
        "run_gates loads the reproducibility gate",
        'reproducibility_gate_mod = _load("reproducibility_gate"' in run_gates_source,
    )
    check(
        "run_gates invokes the reproducibility validator without hiding its prefix",
        "failures += reproducibility_gate_mod.validate(body, manifest_data)" in run_gates_source,
    )

    print("test_reproducibility_gate: OK")


def test_probe_coverage_gate() -> None:
    gate = probe_coverage_gate_mod
    nl = chr(10)

    # A plan whose evidence trips MP-004 (output-generation entry points): the word
    # "native pdf" + "output preset" activates it.
    pub_plan = nl.join([
        "**Understanding From Jira**",
        "- Issue understood: native pdf output preset table rendering.",
        "**Acceptance Criteria**",
        "- AC-01 [Proposed]: (Basic) Given a native pdf output preset | When published | Then it renders | Evidence: Jira.",
    ])
    manifest_no_dim = {"issue": {"summary": "native pdf output preset issue", "components": ["Publishing"]}}
    check("output-generation evidence activates a probe", gate.is_present(pub_plan, manifest_no_dim))
    probs = gate.validate(pub_plan, manifest_no_dim)
    check("activated probe without a covering dimension fails", any("PROBE COVERAGE GATE:" in p for p in probs))

    # Covering the ENTRY_POINT axis via a clarification dimension satisfies it.
    manifest_covered = dict(manifest_no_dim, clarification={
        "dimension_space": [
            {"dimension_id": "D-01", "axis": "ENTRY_POINT", "material": True, "resolution": "COVERED_BY_AC", "ac_refs": ["AC-01"]}
        ]
    })
    check("covering the axis via a clarification dimension passes", gate.validate(pub_plan, manifest_covered) == [])

    # Explicit probe_dispositions rejection also satisfies it.
    active = [p for p in gate.activated_probes(pub_plan, manifest_no_dim) if not p["shadow"]]
    pid = active[0]["probe_id"] if active else "MP-004"
    manifest_disp = dict(manifest_no_dim, probe_dispositions=[
        {"probe_id": pid, "disposition": "NOT_APPLICABLE", "reason": "single-surface ticket; other entry points do not apply here."}
    ])
    check("explicit probe disposition satisfies the gate", gate.validate(pub_plan, manifest_disp) == [])

    # UACGAP-06: a populated entry_point_equivalence block satisfies an ENTRY_POINT probe.
    ep_plan = nl.join([
        "**Understanding From Jira**",
        "- Issue understood: a topicref is added via drag and drop and a toolbar button.",
        "**Acceptance Criteria**",
        "- AC-01 [Proposed]: (Integration) Given x | When added via any entry point | Then y | Evidence: Jira.",
    ])
    ep_manifest = {"issue": {"summary": "drag and drop insert not adding attribute", "components": ["Editor"]}}
    ep_active = [p for p in gate.activated_probes(ep_plan, ep_manifest) if not p["shadow"]]
    if any(p["axis"] == "ENTRY_POINT" for p in ep_active):
        check("ENTRY_POINT probe unsatisfied without a dimension or block",
              any("ENTRY_POINT" in p for p in gate.validate(ep_plan, ep_manifest)))
        ep_with_block = dict(ep_manifest, entry_point_equivalence={"candidates": [{"entry_point_id": "EP-01"}]})
        check("populated entry_point_equivalence block satisfies the ENTRY_POINT probe",
              not any("ENTRY_POINT" in p for p in gate.validate(ep_plan, ep_with_block)))

    # No probe token in the evidence -> not activated, clean pass (backward-compatible).
    quiet_plan = "**Acceptance Criteria**\n- AC-01 [Proposed]: (Basic) Given a thing | When acted | Then result | Evidence: Jira.\n"
    quiet_manifest = {"issue": {"summary": "an unrelated backend null guard", "components": ["Miscellaneous"]}}
    check("no matching probe is not activated", not gate.is_present(quiet_plan, quiet_manifest))
    check("no-probe plan passes", gate.validate(quiet_plan, quiet_manifest) == [])

    run_gates_source = Path(__file__).with_name("run_gates.py").read_text(encoding="utf-8")
    check(
        "run_gates loads the probe-coverage gate",
        'probe_coverage_gate_mod = _load("probe_coverage_gate"' in run_gates_source,
    )
    check(
        "run_gates invokes the probe-coverage validator without hiding its prefix",
        "failures += probe_coverage_gate_mod.validate(body, manifest_data)" in run_gates_source,
    )

    print("test_probe_coverage_gate: OK")


def test_dita_semantics_activation() -> None:
    gate = dita_semantics_activation_mod
    nl = chr(10)

    plan = nl.join([
        "**Understanding From Jira**",
        "- Issue understood: @navtitle is not added to a topicref when required; @locktitle governs it.",
        "**Acceptance Criteria**",
        "- AC-01 [Proposed]: (Basic) Given navtitle required | When inserted | Then navtitle is set | Evidence: Jira.",
    ])
    manifest = {"issue": {"summary": "navtitle attribute not added", "description": "topichead and locktitle"}, "behaviour_matters": True}

    check("named DITA construct activates the gate", gate.is_present(plan, manifest))
    probs = gate.validate(plan, manifest)
    check("construct without a dita_semantics block fails", any("DITA SEMANTICS GATE:" in p for p in probs))

    # active:true delegates to the strict explorer (coverage_gate); this gate is satisfied.
    m_active = dict(manifest, dita_semantics={"active": True})
    check("active:true satisfies the activation gate", gate.validate(plan, m_active) == [])

    # active:false requires primary_constructs + a substantive neighbourhood_assessment.
    m_thin = dict(manifest, dita_semantics={"active": False, "primary_constructs": ["navtitle"], "neighbourhood_assessment": "too short"})
    check("active:false with a thin assessment fails", gate.validate(plan, m_thin) != [])
    m_full = dict(manifest, dita_semantics={
        "active": False,
        "primary_constructs": ["navtitle", "locktitle"],
        "neighbourhood_assessment": "navtitle is derived from the referenced <title> and governed by locktitle; topichead is the href-less variant covered by AC-07.",
    })
    check("active:false with a full assessment passes", gate.validate(plan, m_full) == [])

    # No construct named -> not activated (backward-compatible).
    quiet = {"issue": {"summary": "backend null guard on a job id", "description": "unrelated"}, "behaviour_matters": True}
    quiet_plan = "**Acceptance Criteria**\n- AC-01: Given x When y Then z | Evidence: Jira.\n"
    check("no construct is not activated", not gate.is_present(quiet_plan, quiet))
    check("no-construct plan passes", gate.validate(quiet_plan, quiet) == [])

    # behaviour_matters false opts out entirely.
    check("behaviour_matters false opts out", gate.validate(plan, dict(manifest, behaviour_matters=False)) == [])

    run_gates_source = Path(__file__).with_name("run_gates.py").read_text(encoding="utf-8")
    check(
        "run_gates loads the dita-semantics activation gate",
        'dita_semantics_activation_mod = _load("dita_semantics_activation"' in run_gates_source,
    )
    check(
        "run_gates invokes the dita-semantics validator without hiding its prefix",
        "failures += dita_semantics_activation_mod.validate(body, manifest_data)" in run_gates_source,
    )

    print("test_dita_semantics_activation: OK")


def test_evidence_anchor_recognition() -> None:
    # UACGAP-05: a bare inspected code path (relative source file, optionally :line)
    # is a first-class Evidence anchor - no Jira/URL prefix required.
    rx = validate_mod.UNDERLYING_SOURCE_RE
    for s in [
        "xmleditor src/util/drag.ts:88 createKeyDefData",
        "Starling libs/fmdita/pdf/Basic/content.css .entry border rule",
        "insert_topicref_controller.ts:106-115 forceNavTitle",
        "app/services/foo.py:12",
    ]:
        check(f"inspected code path is a valid evidence anchor: {s!r}", bool(rx.search(s)))
    for s in ["OASIS DITA keydef model", "the referenced topic title"]:
        check(f"bare prose without an anchor still fails: {s!r}", not rx.search(s))
    # existing anchors still work
    check("jira key still anchors", bool(rx.search("Jira GUIDES-54348 expected result")))
    check("url still anchors", bool(rx.search("https://experienceleague.adobe.com/x")))
    print("test_evidence_anchor_recognition: OK")


def test_jira_safe_text() -> None:
    j = jira_safe_text_mod
    nl = chr(10)
    raw = nl.join([
        "* *AC-01 — Navtitle added*: With `ditaAttributes.required.navtitle` set, see [doc](https://x.y/z).",
        "OQ-03: the fallback question.",
    ])
    # strip_markup removes wiki/markdown markers
    stripped = j.strip_markup(raw)
    check("strip_markup removes asterisks", "*" not in stripped)
    check("strip_markup removes backticks", "`" not in stripped)
    check("strip_markup removes em dash", "—" not in stripped)
    check("strip_markup converts md link to text (url)", "doc (https://x.y/z)" in stripped)

    # a plain body with an issue-key-shaped label is still flagged (Jira would strike it)
    plain = "AC-01 (Navtitle added): the criterion. OQ-03: the question."
    probs = j.validate_jira_safe(plain)
    check("issue-key-shaped label is flagged outside noformat", any("auto-link" in p for p in probs))

    # jira_comment_body wraps in {noformat}, which neutralizes markup AND key auto-linking
    body = j.jira_comment_body(raw)
    check("jira_comment_body wraps in noformat", body.startswith("{noformat}") and body.rstrip().endswith("{noformat}"))
    check("wrapped body preserves the AC label literally", "AC-01" in body)
    check("wrapped body has no residual markup", "*" not in body and "`" not in body)
    check("validate passes for a noformat-wrapped body", j.validate_jira_safe(body) == [])

    print("test_jira_safe_text: OK")


def test_root_cause_fix_driven() -> None:
    gate = root_cause_fix_driven_mod
    nl = chr(10)

    positive_plan = nl.join([
        "**Understanding From Jira**",
        "- Lifecycle understood as: Post-Fix Validation with an inspected candidate fix.",
        "",
        "**Acceptance Criteria**",
        "- AC-01 [Proposed]: (Basic) Given an item with eligible child text | When its label is resolved | Then the eligible child text appears in the label | Evidence: inspected fix contract.",
        "- AC-02 [Proposed]: (Integration) Given an item with a nested primary child | When its label is resolved | Then the nested primary child remains separate from the parent label | Evidence: inspected fix invariant.",
        "- AC-03 [Proposed]: (Negative) Given a sibling child with its own display meaning | When the parent label is resolved | Then the sibling value is not appended to the parent label | Evidence: fix-introduced risk analysis.",
        "",
        "**Automation Coverage & Gaps**",
        "- Main feature coverage: Partially covered - an added unit test proves label collection and nested separation; end-to-end output remains uncovered.",
        "",
        "**Open Questions**",
        "- OQ-01: Which additional display-bearing siblings are eligible. QA impact: the answer changes the negative fixture matrix.",
        "",
    ])
    base_block = {
        "root_cause_fix": {
            "requirement_oracle": "The ticket and attachment ask that all eligible child text appear in the label, as other resolvers already do.",
            "scope_delta": [
                {
                    "requirement": "Additional display-bearing siblings beyond the fixed set may also be eligible.",
                    "coverage": "PARTIAL",
                    "open_question_ref": "OQ-01",
                }
            ],
            "root_cause": "The resolver flattened child text without preserving semantic boundaries.",
            "fix_contract": "Collect eligible child text while preserving excluded semantic children.",
            "fix_adds": ["Eligible non-primary child text contributes to the label."],
            "fix_preserves": [
                "AC-02: Nested primary children remain separate from the parent label."
            ],
            "fix_introduced_risks": [
                {
                    "risk": "A sibling with separate display meaning could be appended.",
                    "mapped_ac": "AC-03",
                    "open_question_ref": None,
                }
            ],
            "added_tests": [
                {
                    "path": "tests/unit/label-resolution.test",
                    "layer": "unit",
                    "proves": "Eligible child collection and nested separation.",
                }
            ],
            "verification_performed": "One local build and the added unit test.",
            "verification_gap": [
                "Other preset and processing-engine combinations",
                "Rendered end-to-end output",
                "Consumers that share the resolver",
            ],
            "lifecycle_stage": "Post-Fix Validation",
        }
    }

    check(
        "fully populated fix-driven block passes",
        gate.validate(positive_plan, base_block) == [],
    )
    check(
        "positive fixture activates the fix-driven gate",
        gate.is_present(positive_plan, base_block),
    )

    no_fix_plan = nl.join([
        "**Understanding From Jira**",
        "- Lifecycle understood as: Pre-Development UAC; no development link, branch, or PR is present.",
        "",
        "**Acceptance Criteria**",
        "- AC-01 [Proposed]: (Basic) Given a toolbar action | When the user selects it | Then the panel opens | Evidence: current issue contract.",
        "",
    ])
    no_fix_manifest = {
        "issue": {"description": "The toolbar action does not open."},
        "development_links": [],
        "evidence_preflight": {
            "claim_restrictions": [
                "Jira history unavailable: no same-mechanism historical status, resolution, or fix-version claim is made."
            ]
        },
    }
    check("ticket with no positive fix signal stays inactive", not gate.is_present(no_fix_plan, no_fix_manifest))
    check("ticket with no positive fix signal passes untouched", gate.validate(no_fix_plan, no_fix_manifest) == [])
    check(
        "an explicit fix branch activates without accepting a bare fix-version token",
        gate.is_present("Fix branch: fix/child-selection", {}),
    )

    for signal_label, signal_manifest in (
        ("root-cause statement", {"evidence": ["The root cause was an overly broad child-text traversal."]}),
        ("pull request", {"development_links": ["https://git.example.invalid/team/repo/pull/123"]}),
        ("commit", {"development_links": ["https://git.example.invalid/team/repo/commit/abcdef1234567890"]}),
        ("branch", {"implementation_branch": ["feature/fix-child-selection"]}),
        ("diff", {"evidence": ["diff --git a/Resolver.java b/Resolver.java"]}),
        ("merged claim", {"evidence": ["The candidate fix was merged to develop."]}),
        ("cherry-picked claim", {"evidence": ["The candidate was cherry-picked to the release branch."]}),
        ("hotfix claim", {"evidence": ["A hotfix is available for validation."]}),
        ("fixed-in-build claim", {"evidence": ["Fixed in build 42."]}),
        ("verified-in-build claim", {"evidence": ["Verified in build 42."]}),
    ):
        check(
            f"documented activation signal is detected: {signal_label}",
            gate.is_present("", signal_manifest),
        )

    for absent_claim in (
        "The change is not merged.",
        "The issue is not fixed in build 42.",
        "The behavior was not verified in build 42.",
        "No hotfix is available.",
    ):
        check(
            f"negative fix-status claim stays inactive: {absent_claim}",
            not gate.is_present(absent_claim, {}),
        )

    # False-positive guard: publishing/layout vocabulary "merged" must NOT activate the
    # gate (a Native PDF ticket says "merged page layout" / "merged with previous page").
    for benign in (
        "The metadata page layout is merged with the previous page in Page layout order.",
        "Merge with Previous page loses the topic metadata values.",
        "The merged page layout shows only the labels.",
        "CALS table merged cells render correctly.",
        "The fix must restore the topic metadata on the merged page.",
        "A change to the layout must show values on the merged page.",
    ):
        check(
            f"benign layout 'merged' does not activate the fix gate: {benign[:34]}",
            not gate.is_present(benign, {}),
        )
    # But a real fix-context "merged" claim must still activate.
    for fixy in (
        "The candidate fix was merged to develop.",
        "PR merged into main.",
        "The change was merged in build 42.",
    ):
        check(
            f"fix-context 'merged' still activates the fix gate: {fixy[:34]}",
            gate.is_present(fixy, {}),
        )

    missing_block = {"issue": {"description": "Root cause: the resolver drops eligible child text."}}
    problems = gate.validate(positive_plan, missing_block)
    check("fix signal without root_cause_fix block fails", any("requires a root_cause_fix" in p for p in problems))
    check("missing-block failures use stable prefix", all(p.startswith(gate.PREFIX) for p in problems))

    pre_development = json.loads(json.dumps(base_block))
    pre_development["root_cause_fix"]["lifecycle_stage"] = "Pre-Development"
    problems = gate.validate(positive_plan, pre_development)
    check("described fix with Pre-Development lifecycle fails", any("cannot be Pre-Development" in p for p in problems))
    check("lifecycle failures use stable prefix", all(p.startswith(gate.PREFIX) for p in problems))

    unguarded_preserve = json.loads(json.dumps(base_block))
    unguarded_preserve["root_cause_fix"]["fix_preserves"] = [
        "Nested primary children remain separate from the parent label."
    ]
    problems = gate.validate(positive_plan, unguarded_preserve)
    check("preserved invariant without a guarding AC fails", any("must name the real AC-##" in p for p in problems))
    check("preservation failures use stable prefix", all(p.startswith(gate.PREFIX) for p in problems))

    unmapped_risk = json.loads(json.dumps(base_block))
    unmapped_risk["root_cause_fix"]["fix_introduced_risks"] = [
        {"risk": "A sibling value could be appended.", "mapped_ac": None, "open_question_ref": None}
    ]
    problems = gate.validate(positive_plan, unmapped_risk)
    check("fix-introduced risk without AC or OQ fails", any("must map to a negative AC or an Open Question" in p for p in problems))
    check("risk failures use stable prefix", all(p.startswith(gate.PREFIX) for p in problems))

    not_covered_plan = positive_plan.replace(
        "Main feature coverage: Partially covered",
        "Main feature coverage: Not covered",
    )
    problems = gate.validate(not_covered_plan, base_block)
    check("added test with Not covered main-feature verdict fails", any("Covered or Partially covered" in p for p in problems))
    check("automation failures use stable prefix", all(p.startswith(gate.PREFIX) for p in problems))

    missing_verification_gap = json.loads(json.dumps(base_block))
    missing_verification_gap["root_cause_fix"]["verification_gap"] = []
    problems = gate.validate(positive_plan, missing_verification_gap)
    check("narrow verification without a named gap fails", any("requires verification_gap" in p for p in problems))

    no_risks = json.loads(json.dumps(base_block))
    no_risks["root_cause_fix"]["fix_introduced_risks"] = []
    no_risks["root_cause_fix"]["no_new_risk_reason"] = "The fix narrows one local predicate and does not broaden any reader or writer."
    check("empty risk list with concrete no-new-risk reason passes", gate.validate(positive_plan, no_risks) == [])

    # Requirement-oracle / scope-delta teeth: the fix diff is never the spec.
    missing_oracle = json.loads(json.dumps(base_block))
    del missing_oracle["root_cause_fix"]["requirement_oracle"]
    problems = gate.validate(positive_plan, missing_oracle)
    check("missing requirement_oracle fails", any("requirement_oracle" in p for p in problems))
    check("requirement_oracle failures use stable prefix", all(p.startswith(gate.PREFIX) for p in problems))

    unmapped_delta = json.loads(json.dumps(base_block))
    unmapped_delta["root_cause_fix"]["scope_delta"] = [
        {"requirement": "The broader selected-property list must be covered.", "coverage": "NONE"}
    ]
    problems = gate.validate(positive_plan, unmapped_delta)
    check("scope_delta item without an AC/OQ mapping fails", any("must map to an AC or an Open Question" in p for p in problems))

    dangling_delta = json.loads(json.dumps(base_block))
    dangling_delta["root_cause_fix"]["scope_delta"] = [
        {"requirement": "The broader selected-property list must be covered.", "open_question_ref": "OQ-99"}
    ]
    problems = gate.validate(positive_plan, dangling_delta)
    check("scope_delta mapping to an absent OQ fails", any("OQ-99" in p for p in problems))

    empty_delta_no_claim = json.loads(json.dumps(base_block))
    empty_delta_no_claim["root_cause_fix"]["scope_delta"] = []
    problems = gate.validate(positive_plan, empty_delta_no_claim)
    check("empty scope_delta without fix_fully_covers claim fails", any("empty scope_delta requires" in p for p in problems))

    full_cover = json.loads(json.dumps(base_block))
    full_cover["root_cause_fix"]["scope_delta"] = []
    full_cover["root_cause_fix"]["fix_fully_covers_requirement"] = True
    full_cover["root_cause_fix"]["fix_fully_covers_reason"] = "The diff implements the entire requirement oracle with nothing left out."
    check("empty scope_delta with a concrete full-coverage claim passes", gate.validate(positive_plan, full_cover) == [])

    run_gates_source = Path(__file__).with_name("run_gates.py").read_text(encoding="utf-8")
    check(
        "run_gates loads the root-cause/fix-driven gate",
        'root_cause_fix_driven_mod = _load("root_cause_fix_driven"' in run_gates_source,
    )
    check(
        "run_gates invokes the root-cause/fix-driven validator without hiding its prefix",
        "failures += root_cause_fix_driven_mod.validate(body, manifest_data)" in run_gates_source,
    )

    print("test_root_cause_fix_driven: OK")


def test_security_coverage() -> None:
    gate = security_coverage_mod
    nl = chr(10)

    def block(input_record, reference_record, authz_record):
        return {
            "security_coverage": {
                "schema_version": gate.SCHEMA_VERSION,
                "dimensions": [input_record, reference_record, authz_record],
            }
        }

    def not_applicable(dimension, reason):
        return {
            "dimension": dimension,
            "disposition": "NOT_APPLICABLE",
            "reason": reason,
            "ac_refs": [],
        }

    input_na = not_applicable("INPUT_SAFETY", "No XML or DITA input is parsed.")
    reference_na = not_applicable(
        "REFERENCE_TRAVERSAL", "No DITA reference is resolved by the changed path."
    )
    authz_na = not_applicable("AUTHZ", "No endpoint, shared destination, role, or permission changes.")

    plain_plan = nl.join([
        "**Acceptance Criteria**",
        "- AC-01 [Proposed]: (Basic) Given a toolbar button | When the user selects it | Then the panel opens | Evidence: current UI contract.",
        "",
    ])
    check("non-security plan passes without a security block", gate.validate(plain_plan, {}) == [])
    check("non-security plan does not activate the security gate", not gate.is_present(plain_plan, {}))
    check(
        "explicit all-N/A security ledger passes for a non-security plan",
        gate.validate(plain_plan, block(input_na, reference_na, authz_na)) == [],
    )

    input_plan = nl.join([
        "**Acceptance Criteria**",
        "- AC-01 [Proposed]: (Negative) Given uploaded DITA content | When the XML parser processes it | Then the import reports a validation result | Evidence: upload contract.",
        "",
    ])
    probs = gate.validate(input_plan, {})
    check("XML ingest without a security ledger fails", bool(probs))
    check("every XML ingest failure uses the stable prefix", all(p.startswith(gate.PREFIX) for p in probs))

    weak_input = block(
        {
            "dimension": "INPUT_SAFETY",
            "disposition": "COVERED_BY_AC",
            "reason": "The upload path parses DITA.",
            "ac_refs": ["AC-01"],
        },
        reference_na,
        authz_na,
    )
    probs = gate.validate(input_plan, weak_input)
    check("XML ingest without XXE coverage fails", any("external-entity" in p for p in probs))
    check("XML ingest without entity-expansion coverage fails", any("entity-expansion" in p for p in probs))
    check("XML ingest without malformed input coverage fails", any("malformed" in p for p in probs))
    check("XML ingest without oversized input coverage fails", any("oversized" in p for p in probs))

    mention_only_input_plan = nl.join([
        "**Acceptance Criteria**",
        "- AC-01 [Proposed]: (Negative) Given DITA with XXE, Billion Laughs entity expansion, malformed DITA input, or oversized DITA input | When the XML parser processes it | Then the case is recorded for later analysis | Evidence: security review.",
        "",
    ])
    probs = gate.validate(mention_only_input_plan, weak_input)
    check("mentioning XXE without disabling it does not satisfy coverage", any("external-entity" in p for p in probs))
    check("mentioning entity expansion without a limit does not satisfy coverage", any("entity-expansion" in p for p in probs))
    check("mentioning malformed input without a safe outcome does not satisfy coverage", any("malformed" in p for p in probs))
    check("mentioning oversized input without a safe outcome does not satisfy coverage", any("oversized" in p for p in probs))

    safe_input_plan = nl.join([
        "**Acceptance Criteria**",
        "- AC-01 [Proposed]: (Negative) Given uploaded DITA content with XXE or external entities | When the XML parser processes it | Then external entities are disabled and the input is rejected | Evidence: security contract.",
        "- AC-02 [Proposed]: (Negative) Given DITA content with Billion Laughs entity expansion | When the XML parser processes it | Then the configured entity expansion limit rejects the input | Evidence: security contract.",
        "- AC-03 [Proposed]: (Negative) Given malformed DITA input or oversized DITA input beyond the file size limit | When it is uploaded | Then the import rejects it without processing the content | Evidence: security contract.",
        "",
    ])
    safe_input = block(
        {
            "dimension": "INPUT_SAFETY",
            "disposition": "COVERED_BY_AC",
            "reason": "The upload path parses user-supplied DITA.",
            "ac_refs": ["AC-01", "AC-02", "AC-03"],
        },
        reference_na,
        authz_na,
    )
    check("complete XML input-safety AC mapping passes", gate.validate(safe_input_plan, safe_input) == [])

    oq_plan = nl.join([
        "**Acceptance Criteria**",
        "- AC-01 [Proposed]: (Basic) Given uploaded DITA content | When the XML parser processes it | Then the import reports a result | Evidence: upload contract.",
        "**Open Questions**",
        "- OQ-01: Should the parser disable XXE and external entities, reject Billion Laughs entity expansion at an entity limit, reject malformed DITA input, and reject oversized DITA input at the file size limit? QA impact: this defines the hostile-input fixtures and safe failure oracles.",
        "",
    ])
    deferred_input = block(
        {
            "dimension": "INPUT_SAFETY",
            "disposition": "OPEN_QUESTION",
            "reason": "The hostile-input contract requires a product decision.",
            "open_question_ref": "OQ-01",
        },
        reference_na,
        authz_na,
    )
    check("complete QA-impact Open Question disposition passes", gate.validate(oq_plan, deferred_input) == [])

    conref_plan = nl.join([
        "**Acceptance Criteria**",
        "- AC-01 [Proposed]: (Basic) Given a topic with a conref | When the reference resolves | Then the target content appears | Evidence: reference contract.",
        "",
    ])
    weak_reference = block(
        input_na,
        {
            "dimension": "REFERENCE_TRAVERSAL",
            "disposition": "COVERED_BY_AC",
            "reason": "The changed path resolves conref targets.",
            "ac_refs": ["AC-01"],
        },
        authz_na,
    )
    probs = gate.validate(conref_plan, weak_reference)
    check("conref plan without traversal coverage fails", any("path-traversal" in p for p in probs))

    safe_conref_plan = nl.join([
        "**Acceptance Criteria**",
        "- AC-01 [Proposed]: (Negative) Given a conref containing a path traversal outside the permitted content scope | When the reference resolves | Then the out-of-scope reference is blocked and cannot read outside the allowed content scope | Evidence: reference security contract.",
        "",
    ])
    check(
        "conref traversal protection passes",
        gate.validate(safe_conref_plan, weak_reference) == [],
    )

    endpoint_plan = nl.join([
        "**Acceptance Criteria**",
        "- AC-01 [Proposed]: (Basic) Given a REST endpoint that accepts user content | When a user submits a file | Then the file is processed | Evidence: endpoint contract.",
        "",
    ])
    weak_authz = block(
        input_na,
        reference_na,
        {
            "dimension": "AUTHZ",
            "disposition": "COVERED_BY_AC",
            "reason": "The endpoint accepts user-supplied content.",
            "ac_refs": ["AC-01"],
        },
    )
    probs = gate.validate(endpoint_plan, weak_authz)
    check("content endpoint without unauthorized-role denial fails", any("unauthorized role" in p for p in probs))
    check("content endpoint without escalation protection fails", any("privilege escalation" in p for p in probs))

    publish_endpoint_plan = nl.join([
        "**Acceptance Criteria**",
        "- AC-01 [Proposed]: (Basic) Given a REST publish endpoint that accepts user DITA content | When output is written to a shared location | Then publishing completes | Evidence: publishing contract.",
        "",
    ])
    probs = gate.validate(publish_endpoint_plan, weak_authz)
    check("publish endpoint without authorization coverage fails", any("unauthorized role" in p for p in probs))
    check("publish endpoint failure preserves the SECURITY GATE prefix", all(p.startswith(gate.PREFIX) for p in probs))

    safe_endpoint_plan = nl.join([
        "**Acceptance Criteria**",
        "- AC-01 [Proposed]: (Negative) Given an unauthorized role | When it submits user content to the REST endpoint | Then access is denied | Evidence: authorization contract.",
        "- AC-02 [Proposed]: (Negative) Given the changed REST endpoint | When a permitted user submits content | Then the path cannot cause privilege escalation or permission bypass | Evidence: authorization contract.",
        "",
    ])
    safe_authz = block(
        input_na,
        reference_na,
        {
            "dimension": "AUTHZ",
            "disposition": "COVERED_BY_AC",
            "reason": "The endpoint accepts user-supplied content.",
            "ac_refs": ["AC-01", "AC-02"],
        },
    )
    check("complete endpoint authorization mapping passes", gate.validate(safe_endpoint_plan, safe_authz) == [])

    explicit_authz_na = block(
        input_na,
        reference_na,
        not_applicable(
            "AUTHZ",
            "The signalled endpoint is behind an unchanged authorization boundary and the changed code cannot alter role enforcement.",
        ),
    )
    check(
        "genuinely inapplicable signalled dimension passes with a concrete reason",
        gate.validate(endpoint_plan, explicit_authz_na) == [],
    )

    placeholder_reason = block(
        input_na,
        reference_na,
        not_applicable("AUTHZ", "N/A"),
    )
    probs = gate.validate(plain_plan, placeholder_reason)
    check("placeholder N/A reason fails", any("non-placeholder reason" in p for p in probs))

    missing_dimension = {
        "security_coverage": {
            "dimensions": [input_na, reference_na],
        }
    }
    probs = gate.validate(plain_plan, missing_dimension)
    check("explicit security ledger cannot omit a dimension", any("silent for AUTHZ" in p for p in probs))
    check("security summary reports clean complete ledger", "SecurityCoverage: CLEAN" in gate.summarize(plain_plan, block(input_na, reference_na, authz_na)))

    run_gates_source = Path(__file__).with_name("run_gates.py").read_text(encoding="utf-8")
    check("run_gates loads the security coverage gate", 'security_coverage_mod = _load("security_coverage"' in run_gates_source)
    check("run_gates invokes security coverage validation", "security_coverage_mod.validate(body, manifest_data)" in run_gates_source)
    check("run_gates preserves the security gate failure prefix", "failures += security_coverage_mod.validate(body, manifest_data)" in run_gates_source)

    print("test_security_coverage: OK")


def test_localization_regression_coverage() -> None:
    gate = localization_regression_coverage_mod
    nl = chr(10)

    def block(state_record, xliff_record, project_record):
        return {
            "localization_coverage": {
                "schema_version": gate.SCHEMA_VERSION,
                "dimensions": [state_record, xliff_record, project_record],
            }
        }

    def not_applicable(dimension, reason):
        return {
            "dimension": dimension,
            "disposition": "NOT_APPLICABLE",
            "reason": reason,
            "ac_refs": [],
        }

    state_na = not_applicable(
        "TRANSLATION_STATE",
        "The changed UI control does not read or update translated source assets.",
    )
    xliff_na = not_applicable(
        "XLIFF_ROUNDTRIP",
        "The changed path does not modify source markup or XLIFF conversion.",
    )
    project_na = not_applicable(
        "PROJECT_TYPES",
        "The change does not create, add to, or scope a translation project.",
    )

    check(
        "translation states remain the documented product set",
        gate.TRANSLATION_STATUS_SET
        == {
            "Out of Date",
            "In Progress",
            "In Sync",
            "Out of Sync",
            "Missing copy",
        },
    )
    check(
        "translation project types remain the documented product set",
        gate.PROJECT_TYPE_SET
        == {
            "newTranslationProject",
            "xliffTranslationProject",
            "newMultiLingualTranslationProject",
            "addToExistingProject",
            "newScopingTranslationProject",
        },
    )

    plain_plan = nl.join([
        "**Acceptance Criteria**",
        "- AC-01 [Proposed]: (Basic) Given a toolbar button | When the user selects it | Then the panel opens | Evidence: current UI contract.",
        "",
    ])
    check("non-localization plan passes untouched", gate.validate(plain_plan, {}) == [])
    check("non-localization plan does not activate the gate", not gate.is_present(plain_plan, {}))
    cross_gate_manifest = {
        "security_coverage": {
            "dimensions": [
                {
                    "dimension": "AUTHZ",
                    "disposition": "NOT_APPLICABLE",
                    "reason": "No user content endpoint is changed.",
                }
            ]
        }
    }
    check(
        "another coverage ledger cannot self-activate localization",
        gate.validate(plain_plan, cross_gate_manifest) == [],
    )

    metadata_plan = nl.join([
        "**Acceptance Criteria**",
        "- AC-01 [Proposed]: (Basic) Given a topic metadata property | When the user updates it | Then the saved property is displayed | Evidence: metadata contract.",
        "",
    ])
    probs = gate.validate(metadata_plan, {})
    check("metadata change without localization coverage fails", bool(probs))
    check("metadata failure uses the stable prefix", all(p.startswith(gate.PREFIX) for p in probs))

    publishing_plan = nl.join([
        "**Acceptance Criteria**",
        "- AC-01 [Proposed]: (Basic) Given a Native PDF output preset | When publishing completes | Then the generated output is available | Evidence: publishing contract.",
        "",
    ])
    probs = gate.validate(publishing_plan, {})
    check("publishing change without translation-state disposition fails", bool(probs))
    check("publishing failure uses the stable prefix", all(p.startswith(gate.PREFIX) for p in probs))

    component_manifest = {"issue": {"components": ["Translation"]}}
    probs = gate.validate(plain_plan, component_manifest)
    check("Translation component activates the gate", bool(probs))

    explicit_na = block(
        not_applicable(
            "TRANSLATION_STATE",
            "The metadata is local UI state and is not read by assets in translation projects.",
        ),
        xliff_na,
        project_na,
    )
    check(
        "activated metadata change passes when every dimension is dispositioned",
        gate.validate(metadata_plan, explicit_na) == [],
    )

    weak_state_plan = nl.join([
        "**Acceptance Criteria**",
        "- AC-01 [Proposed]: (Integration) Given content already in a translation project | When its metadata changes | Then the translation status is refreshed | Evidence: translation contract.",
        "",
    ])
    state_block = block(
        {
            "dimension": "TRANSLATION_STATE",
            "disposition": "COVERED_BY_AC",
            "reason": "The metadata belongs to source content already in a translation project.",
            "ac_refs": ["AC-01"],
        },
        xliff_na,
        project_na,
    )
    probs = gate.validate(weak_state_plan, state_block)
    check("translation-state coverage requires Out of Sync", any("Out of Sync" in p for p in probs))
    check("translation-state coverage requires Missing copy", any("Missing copy" in p for p in probs))

    state_plan = nl.join([
        "**Acceptance Criteria**",
        "- AC-01 [Proposed]: (Integration) Given content already in a translation project | When its metadata changes | Then its status becomes Out of Sync and a missing target is detected as Missing copy | Evidence: translation status contract.",
        "",
    ])
    check(
        "complete translation-state AC mapping passes",
        gate.validate(state_plan, state_block) == [],
    )

    state_oq_plan = nl.join([
        "**Acceptance Criteria**",
        "- AC-01 [Proposed]: (Basic) Given topic metadata | When it changes | Then the value is saved | Evidence: metadata contract.",
        "**Open Questions**",
        "- OQ-01: For content already in a translation project, should the status become Out of Sync and should an absent target be detected as Missing copy? QA impact: the decision defines the translation-status regression oracles.",
        "",
    ])
    state_oq_block = block(
        {
            "dimension": "TRANSLATION_STATE",
            "disposition": "OPEN_QUESTION",
            "reason": "The accepted translation-state effect is not yet defined.",
            "open_question_ref": "OQ-01",
        },
        xliff_na,
        project_na,
    )
    check(
        "complete translation-state Open Question mapping passes",
        gate.validate(state_oq_plan, state_oq_block) == [],
    )

    weak_structure_plan = nl.join([
        "**Acceptance Criteria**",
        "- AC-01 [Proposed]: (Integration) Given changed DITA element markup | When XLIFF export runs | Then an export file is created | Evidence: structure contract.",
        "",
    ])
    structure_block = block(
        not_applicable(
            "TRANSLATION_STATE",
            "The structural fixture is not enrolled in a translation project for this contract.",
        ),
        {
            "dimension": "XLIFF_ROUNDTRIP",
            "disposition": "COVERED_BY_AC",
            "reason": "The change modifies DITA element markup used by XLIFF conversion.",
            "ac_refs": ["AC-01"],
        },
        project_na,
    )
    probs = gate.validate(weak_structure_plan, structure_block)
    check("XLIFF coverage requires import", any("XLIFF import" in p for p in probs))
    check("XLIFF coverage requires round-trip integrity", any("round-trip integrity" in p for p in probs))

    structure_plan = nl.join([
        "**Acceptance Criteria**",
        "- AC-01 [Proposed]: (Integration) Given changed table element markup | When XLIFF export and import complete | Then the XLIFF round-trip preserves the table structure and content | Evidence: XLIFF conversion contract.",
        "",
    ])
    check(
        "complete XLIFF round-trip mapping passes",
        gate.validate(structure_plan, structure_block) == [],
    )

    weak_project_plan = nl.join([
        "**Acceptance Criteria**",
        "- AC-01 [Proposed]: (Integration) Given translation project creation | When newTranslationProject is selected | Then the project is created | Evidence: translation project contract.",
        "",
    ])
    project_block = block(
        state_na,
        xliff_na,
        {
            "dimension": "PROJECT_TYPES",
            "disposition": "COVERED_BY_AC",
            "reason": "The change modifies translation-project creation and project-type scope.",
            "ac_refs": ["AC-01"],
        },
    )
    probs = gate.validate(weak_project_plan, project_block)
    check(
        "one project type cannot satisfy the supported set",
        any("xliffTranslationProject" in p and "newScopingTranslationProject" in p for p in probs),
    )

    project_plan = nl.join([
        "**Acceptance Criteria**",
        "- AC-01 [Proposed]: (Integration) Given translation project creation or scope | When the caller selects newTranslationProject, xliffTranslationProject, newMultiLingualTranslationProject, addToExistingProject, or newScopingTranslationProject | Then the selected supported project type is processed | Evidence: Translation Project API UAC reference.",
        "",
    ])
    check(
        "complete documented project-type set passes",
        gate.validate(project_plan, project_block) == [],
    )

    placeholder = block(
        not_applicable("TRANSLATION_STATE", "N/A"),
        xliff_na,
        project_na,
    )
    probs = gate.validate(plain_plan, placeholder)
    check("placeholder localization N/A reason fails", any("non-placeholder reason" in p for p in probs))

    missing_dimension = {
        "localization_coverage": {
            "dimensions": [state_na, xliff_na],
        }
    }
    probs = gate.validate(plain_plan, missing_dimension)
    check("localization ledger cannot omit a dimension", any("silent for PROJECT_TYPES" in p for p in probs))
    check(
        "localization summary reports clean complete ledger",
        "LocalizationRegressionCoverage: CLEAN"
        in gate.summarize(metadata_plan, explicit_na),
    )

    run_gates_source = Path(__file__).with_name("run_gates.py").read_text(encoding="utf-8")
    check(
        "run_gates loads localization regression coverage",
        'localization_regression_coverage_mod = _load(' in run_gates_source,
    )
    check(
        "run_gates invokes localization regression validation",
        "localization_regression_coverage_mod.validate(body, manifest_data)"
        in run_gates_source,
    )
    check(
        "run_gates preserves localization failure prefix",
        "failures += localization_regression_coverage_mod.validate(body, manifest_data)"
        in run_gates_source,
    )

    print("test_localization_regression_coverage: OK")


def test_upgrade_migration_coverage() -> None:
    gate = upgrade_migration_coverage_mod
    nl = chr(10)

    def block(*records):
        return {
            "upgrade_migration_coverage": {
                "schema_version": gate.SCHEMA_VERSION,
                "dimensions": list(records),
            }
        }

    def covered(dimension, reason, *ac_refs):
        return {
            "dimension": dimension,
            "disposition": "COVERED_BY_AC",
            "reason": reason,
            "ac_refs": list(ac_refs),
        }

    def open_question(dimension, reason, oq_ref):
        return {
            "dimension": dimension,
            "disposition": "OPEN_QUESTION",
            "reason": reason,
            "open_question_ref": oq_ref,
        }

    def not_applicable(dimension, reason):
        return {
            "dimension": dimension,
            "disposition": "NOT_APPLICABLE",
            "reason": reason,
            "ac_refs": [],
        }

    plain_plan = nl.join([
        "**Acceptance Criteria**",
        "- AC-01 [Proposed]: (Basic) Given a toolbar action | When the user selects it | Then the panel opens | Evidence: current UI contract.",
        "",
    ])
    check("non-migration plan passes untouched", gate.validate(plain_plan, {}) == [])
    check("non-migration plan does not activate the gate", not gate.is_present(plain_plan, {}))

    cross_gate_manifest = {
        "localization_coverage": {
            "dimensions": [
                {
                    "dimension": "TRANSLATION_STATE",
                    "disposition": "NOT_APPLICABLE",
                    "reason": "No data migration or release upgrade is changed.",
                }
            ]
        }
    }
    check(
        "another coverage ledger cannot self-activate migration",
        gate.validate(plain_plan, cross_gate_manifest) == [],
    )

    temporal_only = {
        "temporal_evidence": {
            "items": [
                {
                    "evidence_id": "E-01",
                    "applicability": "CURRENTLY_APPLICABLE",
                    "currentness": "current release",
                }
            ]
        }
    }
    check(
        "temporal applicability without a migration operation stays inactive",
        gate.validate(plain_plan, temporal_only) == [],
    )
    temporal_migration = {
        "temporal_evidence": {
            "items": [
                {
                    "evidence_id": "E-01",
                    "fact": "The source release uses a stored-data migration to the target schema.",
                }
            ]
        }
    }
    check(
        "migration evidence still activates operation coverage",
        bool(gate.validate(plain_plan, temporal_migration)),
    )

    signal_samples = (
        "Upgrade the product instance from the source release to the target release.",
        "The repository requires a stored data migration to the new schema.",
        "Convert non-UUID identifiers to UUID identifiers.",
        "Migrate the installation from on-premise to cloud.",
        "The change must preserve backward compatibility.",
    )
    for sample in signal_samples:
        check(
            f"migration activation signal is recognized: {sample}",
            bool(gate.detect_signals(sample, {})),
        )

    fix_boundary_manifest = {
        "issue": {
            "fix_versions": ["target release"],
            "description": "This boundary changes the stored configuration format.",
        }
    }
    check(
        "fix-version plus persisted-format change activates the gate",
        bool(gate.detect_signals("", fix_boundary_manifest)),
    )
    check(
        "fix-version field alone does not invent a migration operation",
        not gate.detect_signals("", {"issue": {"fix_versions": ["backlog"]}}),
    )

    migration_plan = nl.join([
        "**Understanding From Jira**",
        "- Requested outcome: Convert non-UUID identifiers to UUID identifiers.",
        "",
        "**Acceptance Criteria**",
        "- AC-01 [Proposed]: (Integration) Given legacy non-UUID records authored and stored in the old format before migration | When the source repository is prepared | Then the old records remain available as migration input | Evidence: migration contract.",
        "- AC-02 [Proposed]: (Integration) Given an upgrade package | When the migration operation is run | Then it completes successfully | Evidence: migration contract.",
        "- AC-03 [Proposed]: (Integration) Given a completed migration | When the operation is rerun | Then the rerunnable operation is idempotent | Evidence: migration contract.",
        "- AC-04 [Proposed]: (Negative) Given a migration failure | When the operation stops | Then it reports the failure with an error status and reason | Evidence: migration error contract.",
        "- AC-05 [Proposed]: (Integration) Given a partially migrated repository where non-UUID and UUID records coexist | When content is read | Then migrated UUID records and remaining legacy records are processed correctly together | Evidence: mixed-state contract.",
        "- AC-06 [Proposed]: (Integration) Given a completed migration | When rollback is run | Then the previous stored data is restored successfully | Evidence: rollback contract.",
        "",
    ])
    complete_block = block(
        covered(
            "PRE_STATE",
            "Legacy identifiers stored before the operation are the migration input.",
            "AC-01",
        ),
        covered(
            "MIGRATION_EXECUTION",
            "The operation, repeat policy, completion, and failure result are in scope.",
            "AC-02",
            "AC-03",
            "AC-04",
        ),
        covered(
            "POST_STATE_AND_MIXED",
            "Non-UUID and UUID records can coexist during partial conversion.",
            "AC-05",
        ),
        covered(
            "ROLLBACK_OR_IRREVERSIBILITY",
            "The approved contract supports restoring the previous stored state.",
            "AC-06",
        ),
    )
    check(
        "fully covered non-UUID to UUID migration passes",
        gate.validate(migration_plan, complete_block) == [],
    )

    problems = gate.validate(migration_plan, {})
    check("migration signal without a coverage ledger fails", bool(problems))
    check(
        "every missing-ledger failure uses the stable prefix",
        all(problem.startswith(gate.PREFIX) for problem in problems),
    )

    bad_pre = block(
        covered(
            "PRE_STATE",
            "The source-state fixture is required.",
            "AC-02",
        ),
        complete_block["upgrade_migration_coverage"]["dimensions"][1],
        complete_block["upgrade_migration_coverage"]["dimensions"][2],
        complete_block["upgrade_migration_coverage"]["dimensions"][3],
    )
    problems = gate.validate(migration_plan, bad_pre)
    check(
        "migration coverage cannot omit old authored or stored input",
        any("old format or source version" in problem for problem in problems),
    )

    weak_execution = block(
        complete_block["upgrade_migration_coverage"]["dimensions"][0],
        covered(
            "MIGRATION_EXECUTION",
            "The operation runs to completion.",
            "AC-02",
        ),
        complete_block["upgrade_migration_coverage"]["dimensions"][2],
        complete_block["upgrade_migration_coverage"]["dimensions"][3],
    )
    problems = gate.validate(migration_plan, weak_execution)
    check(
        "migration execution requires a rerun or one-shot policy",
        any("idempotent/rerunnable" in problem for problem in problems),
    )
    check(
        "migration execution requires failure reporting",
        any("failure reporting" in problem for problem in problems),
    )

    no_mixed_plan = migration_plan.replace(
        "- AC-05 [Proposed]: (Integration) Given a partially migrated repository where non-UUID and UUID records coexist | When content is read | Then migrated UUID records and remaining legacy records are processed correctly together | Evidence: mixed-state contract.",
        "- AC-05 [Proposed]: (Integration) Given migrated records | When the upgrade completes | Then UUID data in the target state remains readable | Evidence: post-state contract.",
    )
    problems = gate.validate(no_mixed_plan, complete_block)
    check(
        "non-UUID to UUID coverage requires the possible mixed state",
        any("partial or old-and-new mixed state" in problem for problem in problems),
    )
    check(
        "mixed-state failure preserves the stable prefix",
        all(problem.startswith(gate.PREFIX) for problem in problems),
    )

    atomic_plan = no_mixed_plan + nl + (
        "- Evidence note: the migration is atomic and has no partial or mixed state."
    )
    check(
        "verified atomic operation does not invent mixed-state coverage",
        gate.validate(atomic_plan, complete_block) == [],
    )

    bad_post_question = block(
        complete_block["upgrade_migration_coverage"]["dimensions"][0],
        complete_block["upgrade_migration_coverage"]["dimensions"][1],
        open_question(
            "POST_STATE_AND_MIXED",
            "The target result is still under discussion.",
            "OQ-01",
        ),
        complete_block["upgrade_migration_coverage"]["dimensions"][3],
    )
    post_question_plan = migration_plan + nl + (
        "- OQ-01: What target state should be produced? QA impact: the answer defines the migrated-result oracle."
    )
    problems = gate.validate(post_question_plan, bad_post_question)
    check(
        "applicable post-state coverage cannot be parked in an Open Question",
        any("must be covered by an AC" in problem for problem in problems),
    )

    oq_plan = migration_plan + nl + nl.join([
        "**Open Questions**",
        "- OQ-01: Which legacy content authored and stored in the old format before migration is required? QA impact: the answer defines the source-state fixtures.",
        "- OQ-02: Is rollback supported to restore old stored data, or is the migration irreversible? QA impact: the answer defines recovery and sign-off coverage.",
        "",
    ])
    oq_block = block(
        open_question(
            "PRE_STATE",
            "The authoritative legacy fixture is not decided.",
            "OQ-01",
        ),
        complete_block["upgrade_migration_coverage"]["dimensions"][1],
        complete_block["upgrade_migration_coverage"]["dimensions"][2],
        open_question(
            "ROLLBACK_OR_IRREVERSIBILITY",
            "The rollback contract is not decided by current evidence.",
            "OQ-02",
        ),
    )
    check(
        "pre-state and rollback may use QA-impact Open Questions",
        gate.validate(oq_plan, oq_block) == [],
    )

    explicit_na = block(
        not_applicable(
            "PRE_STATE",
            "The ticket changes only the upgrade banner and reads no old stored content.",
        ),
        not_applicable(
            "MIGRATION_EXECUTION",
            "No upgrade or migration operation is invoked by the changed display path.",
        ),
        not_applicable(
            "POST_STATE_AND_MIXED",
            "The display-only change creates no migrated or mixed persisted state.",
        ),
        not_applicable(
            "ROLLBACK_OR_IRREVERSIBILITY",
            "The display-only change writes no state that could be rolled back.",
        ),
    )
    display_upgrade_plan = nl.join([
        "**Acceptance Criteria**",
        "- AC-01 [Proposed]: (Basic) Given a version upgrade banner | When the page opens | Then the banner is displayed | Evidence: display contract.",
        "",
    ])
    check(
        "activated but genuinely inapplicable dimensions pass with reasons",
        gate.validate(display_upgrade_plan, explicit_na) == [],
    )

    placeholder = block(
        not_applicable("PRE_STATE", "N/A"),
        explicit_na["upgrade_migration_coverage"]["dimensions"][1],
        explicit_na["upgrade_migration_coverage"]["dimensions"][2],
        explicit_na["upgrade_migration_coverage"]["dimensions"][3],
    )
    problems = gate.validate(display_upgrade_plan, placeholder)
    check(
        "placeholder migration N/A reason fails",
        any("non-placeholder reason" in problem for problem in problems),
    )

    missing_dimension = {
        "upgrade_migration_coverage": {
            "dimensions": complete_block["upgrade_migration_coverage"]["dimensions"][:3]
        }
    }
    problems = gate.validate(migration_plan, missing_dimension)
    check(
        "migration ledger cannot omit rollback disposition",
        any("silent for ROLLBACK_OR_IRREVERSIBILITY" in problem for problem in problems),
    )
    check(
        "migration summary reports a clean complete ledger",
        "UpgradeMigrationCoverage: CLEAN"
        in gate.summarize(migration_plan, complete_block),
    )

    run_gates_source = Path(__file__).with_name("run_gates.py").read_text(
        encoding="utf-8"
    )
    check(
        "run_gates loads upgrade migration coverage",
        'upgrade_migration_coverage_mod = _load(' in run_gates_source,
    )
    check(
        "run_gates invokes upgrade migration validation",
        "upgrade_migration_coverage_mod.validate(body, manifest_data)"
        in run_gates_source,
    )
    check(
        "run_gates preserves migration failure prefix",
        "failures += upgrade_migration_coverage_mod.validate(body, manifest_data)"
        in run_gates_source,
    )

    print("test_upgrade_migration_coverage: OK")


def test_repro_dimension_matrix() -> None:
    rm = repro_dimension_matrix_mod

    check("absent repro_matrix passes", rm.validate({}) == [])

    def wrap(cells, oqs=None):
        m = {"repro_matrix": {"cells": cells}}
        if oqs is not None:
            m["open_questions"] = oqs
        return m

    ok = {"dimension": "CUSTOM_CONFIGURATION", "materiality": "MATERIAL",
          "repro_status": "CUSTOMER_ONLY", "coverage_status": "OPEN_QUESTION",
          "evidence": ["customer template differs"], "open_question_ref": "OQ-01"}
    check("customer-only material diff with an Open Question passes",
          rm.validate(wrap([ok], oqs=[{"id": "OQ-01"}])) == [])

    # Concluding a material customer-only diff invalid is rejected.
    rejected = dict(ok, coverage_status="REJECTED")
    check("material customer-only diff cannot be REJECTED",
          any("cannot be REJECTED" in p for p in rm.validate(wrap([rejected], oqs=[{"id": "OQ-01"}]))))

    # Material unresolved diff without an Open Question is rejected.
    no_oq = {"dimension": "PRODUCT_VERSION", "materiality": "MATERIAL",
             "repro_status": "NOT_REPRODUCED", "coverage_status": "OPEN_QUESTION",
             "evidence": ["repro only on 4.6"]}
    check("material unresolved diff must reference an Open Question",
          any("must reference an Open Question" in p for p in rm.validate(wrap([no_oq]))))

    # Immaterial dimension in the matrix is overexpansion.
    immat = {"dimension": "BROWSER", "materiality": "IMMATERIAL",
             "repro_status": "NOT_APPLICABLE", "coverage_status": "NOT_TESTED",
             "evidence": ["not relevant"]}
    check("immaterial dimension is flagged as overexpansion",
          any("must not be in the matrix" in p for p in rm.validate(wrap([immat]))))

    # Confirmed repro covered by an AC passes with no Open Question needed.
    confirmed = {"dimension": "PRESET", "materiality": "MATERIAL",
                 "repro_status": "REPRO_CONFIRMED", "coverage_status": "COVERED_BY_AC",
                 "evidence": ["reproduced on Native PDF preset"]}
    check("confirmed repro covered by an AC passes", rm.validate(wrap([confirmed])) == [])

    # Invalid enums rejected.
    bad = {"dimension": "NOPE", "materiality": "MATERIAL", "repro_status": "X",
           "coverage_status": "Y", "evidence": ["e"]}
    check("invalid dimension/state enums rejected", len(rm.validate(wrap([bad]))) >= 2)

    # Duplicate dimension rejected.
    check("duplicate dimension rejected",
          any("duplicate dimension" in p for p in rm.validate(wrap([confirmed, dict(confirmed)]))))

    print("test_repro_dimension_matrix: OK")


def test_acceptance_synthesizer() -> None:
    syn = acceptance_synthesizer_mod

    check("absent ac_synthesis passes", syn.validate({}) == [])
    # ac_synthesis present but no synthesis_group -> not activated -> pass
    check("ac_synthesis without synthesis_group is not activated",
          syn.validate({"ac_synthesis": {"final_acs": [{"ac_ref": "AC-01", "body": "x"}]}}) == [])

    def wrap(ac):
        return {"ac_synthesis": {"final_acs": [ac]}}

    good = {"ac_ref": "AC-01", "title": "Deleted-preset data removed on cleanup",
            "synthesis_group": "CORE_CUSTOMER_CONTRACT",
            "candidate_ids": ["CF-09", "CF-03"], "merged_candidate_ids": ["CF-09", "CF-03"],
            "evidence_ids": ["E1"], "scope_basis": "CURRENT_JIRA_AFFECTED_SURFACE",
            "oracle": "deleted-preset data absent; valid data remains"}
    check("fully-traced grouped AC passes", syn.validate(wrap(good)) == [])

    bad_group = dict(good, synthesis_group="RANDOM_BUCKET")
    check("unknown synthesis_group rejected",
          any("synthesis_group" in p for p in syn.validate(wrap(bad_group))))

    no_trace = {"ac_ref": "AC-02", "synthesis_group": "DIRECT_FIX_BEHAVIOR",
                "candidate_ids": ["CF-01"]}
    probs = syn.validate(wrap(no_trace))
    check("missing evidence_ids trace flagged", any("evidence_ids" in p for p in probs))
    check("missing scope_basis trace flagged", any("scope_basis" in p for p in probs))
    check("missing oracle trace flagged", any("oracle" in p for p in probs))

    merged_not_in_cand = dict(good, merged_candidate_ids=["CF-09", "CF-99"])
    check("merged candidate not in candidate_ids is flagged",
          any("not in candidate_ids" in p for p in syn.validate(wrap(merged_not_in_cand))))

    print("test_acceptance_synthesizer: OK")


def test_uac_linter() -> None:
    ul = uac_linter_mod

    # No plan, no block -> clean.
    check("empty inputs pass", ul.validate({}, "") == [])

    good_plan = (
        "**Acceptance Criteria**\n"
        "- AC-01 [Proposed]: (Basic) Given a preset | When output is generated | Then metadata.xml contains the map properties | Evidence: Jira.\n"
        "- AC-02 [Proposed]: (Basic) Given a topic | When output is generated | Then metadata.xml contains the topic properties | Evidence: Jira.\n"
        "**Expected Behaviour**\n- x\n"
    )
    check("distinct ACs pass", ul.validate({}, good_plan) == [])

    dup_plan = (
        "**Acceptance Criteria**\n"
        "- AC-01 [Proposed]: (Basic) Given a preset | When output is generated | Then metadata.xml contains the map properties | Evidence: Jira.\n"
        "- AC-02 [Proposed]: (Basic) Given a preset | When output is generated | Then metadata.xml contains the map properties | Evidence: Jira.\n"
    )
    check("duplicate AC outcome is flagged",
          any("DUPLICATE_AC" in p for p in ul.validate({}, dup_plan)))

    # Opt-in testability block: complete record passes.
    good_block = {"uac_linter": {"testability": [
        {"ac_ref": "AC-01", "condition_or_state": "preset set", "expected_behavior": "properties written",
         "observable_oracle": "metadata.xml", "scope": "Native PDF", "evidence": ["Jira"]}
    ]}}
    check("complete testability record passes", ul.validate(good_block, good_plan) == [])

    missing = {"uac_linter": {"testability": [{"ac_ref": "AC-01", "condition_or_state": "x"}]}}
    probs = ul.validate(missing, good_plan)
    check("missing oracle in testability flagged", any("observable_oracle" in p for p in probs))

    unknown_ac = {"uac_linter": {"testability": [
        {"ac_ref": "AC-99", "condition_or_state": "a", "expected_behavior": "b",
         "observable_oracle": "c", "scope": "d", "evidence": ["e"]}
    ]}}
    check("testability ac_ref not in plan flagged",
          any("not an AC in the plan" in p for p in ul.validate(unknown_ac, good_plan)))

    contra = {"uac_linter": {"testability": [], "oq_ac_contradictions": ["AC-01 vs OQ-02"]}}
    check("AC/OQ contradiction flagged",
          any("OQ_CONTRADICTS_AC" in p for p in ul.validate(contra, good_plan)))

    scope_mm = {"uac_linter": {"testability": [], "scope_mismatch_acs": ["AC-05"]}}
    check("scope mismatch flagged",
          any("SCOPE_MISMATCH" in p for p in ul.validate(scope_mm, good_plan)))

    print("test_uac_linter: OK")


def test_plain_ac_grammar() -> None:
    """v2 plain grammar, sub-points, legacy tolerance, and the AC-count cap."""
    ac = ac_contract_mod
    ul = uac_linter_mod

    plain = ac.parse_ac_line(
        "- AC-01 [Proposed]: (Basic) The DITAVAL editor lists every condition defined "
        "in the active Folder Profile. Evidence: Jira description GUIDES-14593."
    )
    check("plain v2 AC parses", plain is not None)
    check("plain v2 populates text", plain and plain["text"].startswith("The DITAVAL editor lists"))
    check("plain v2 has no Given/When leakage", plain and plain["given"] == "" and plain["when"] == "")
    check("plain v2 evidence captured", plain and plain["evidence"].startswith("Jira description"))
    check("plain v2 schema version", plain and plain["schema_version"] == ac.AC_SCHEMA_VERSION)

    # A plain criterion must not smuggle the reserved field keywords back in.
    smuggled = ac.parse_ac_line(
        "- AC-01 [Proposed]: (Basic) Given a profile the editor lists conditions. "
        "Evidence: Jira."
    )
    check("plain v2 rejects a Given-keyword body", smuggled is None)

    # Legacy Given/When/Then still parses for the historical corpus.
    legacy = ac.parse_ac_line(
        "- AC-01 [Proposed]: (Basic) Given a preset | When output is generated | "
        "Then metadata.xml contains the map properties | Evidence: Jira."
    )
    check("legacy v1 AC still parses", legacy is not None)
    check("legacy v1 keeps then field", legacy and legacy["then"].startswith("metadata.xml"))
    check("legacy v1 schema version", legacy and legacy["schema_version"] == ac.AC_SCHEMA_VERSION_LEGACY)

    # Sub-points: indented bullets attach to the AC head and are not AC lines.
    plan_with_sub = (
        "**Acceptance Criteria**\n"
        "- AC-01 [Proposed]: (Integration) Condition changes in a profile are reflected "
        "in the DITAVAL editor dropdowns. Evidence: Jira GUIDES-14593.\n"
        "  - Adding a condition to the Folder Profile makes it appear in the Attribute dropdown.\n"
        "  - Deleting a condition removes it from the dropdown.\n"
        "**Expected Behaviour**\n- Known.\n"
    )
    heads = ac.acceptance_lines(plan_with_sub)
    check("acceptance_lines excludes indented sub-points", len(heads) == 1)
    subs = ac.acceptance_sub_points(plan_with_sub)
    check("sub-points collected under the AC head", subs.get("AC-01") and len(subs["AC-01"]) == 2)

    # AC-count cap: at most AC_PRESENTATION_CAP presented AC points.
    under_cap = "**Acceptance Criteria**\n" + "".join(
        f"- AC-{i:02d} [Proposed]: (Basic) Distinct observable outcome number {i}. Evidence: Jira.\n"
        for i in range(1, ac.AC_PRESENTATION_CAP + 1)
    )
    check("at the cap passes", ac.validate_ac_count(under_cap) == [])
    over_cap = "**Acceptance Criteria**\n" + "".join(
        f"- AC-{i:02d} [Proposed]: (Basic) Distinct observable outcome number {i}. Evidence: Jira.\n"
        for i in range(1, ac.AC_PRESENTATION_CAP + 2)
    )
    check("over the cap is flagged by ac_contract", any("consolidated" in p for p in ac.validate_ac_count(over_cap)))
    check("over the cap is flagged by uac_linter",
          any("AC_COUNT_CAP" in p for p in ul.validate({}, over_cap)))

    print("test_plain_ac_grammar: OK")


def test_human_feedback_delta() -> None:
    hf = human_feedback_delta_mod

    check("absent human_feedback_delta passes", hf.validate({}) == [])

    def wrap(*deltas):
        return {"human_feedback_delta": {"deltas": list(deltas)}}

    approved = {"delta_type": "COVERAGE_ADDED", "pattern_class": "DISCOVERY_PATTERN",
                "source": "HUMAN", "promotion_state": "APPROVED", "first_failed_stage": "DISCOVERY",
                "human_cases": ["GUIDES-A", "GUIDES-B"], "counterexample_search_done": True}
    check("multi-case human approved delta passes", hf.validate(wrap(approved)) == [])

    # FluffyJaws cannot be promoted.
    fj = dict(approved, source="FLUFFYJAWS")
    check("FluffyJaws delta cannot be VALIDATING/APPROVED",
          any("only Human feedback" in p for p in hf.validate(wrap(fj))))

    # AI review cannot be promoted.
    ai = dict(approved, source="AI_REVIEW", promotion_state="VALIDATING")
    check("AI review delta cannot be promoted",
          any("only Human feedback" in p for p in hf.validate(wrap(ai))))

    # Language delta cannot be a discovery pattern.
    lang = {"delta_type": "LANGUAGE_SIMPLIFIED", "pattern_class": "DISCOVERY_PATTERN",
            "source": "HUMAN", "promotion_state": "CANDIDATE"}
    check("language delta cannot be DISCOVERY_PATTERN",
          any("must not be a DISCOVERY_PATTERN" in p for p in hf.validate(wrap(lang))))

    lang_ok = dict(lang, pattern_class="RENDERING_LANGUAGE_PATTERN")
    check("language delta as rendering pattern passes", hf.validate(wrap(lang_ok)) == [])

    # Coverage miss must record first_failed_stage.
    no_stage = {"delta_type": "COVERAGE_ADDED", "pattern_class": "DISCOVERY_PATTERN",
                "source": "HUMAN", "promotion_state": "CANDIDATE"}
    check("coverage add without first_failed_stage flagged",
          any("first_failed_stage" in p for p in hf.validate(wrap(no_stage))))

    # Single-case approval without normative/severe is rejected.
    single = {"delta_type": "SCOPE_NARROWED", "pattern_class": "SCOPE_PATTERN",
              "source": "HUMAN", "promotion_state": "APPROVED",
              "human_cases": ["GUIDES-A"], "counterexample_search_done": True}
    check("single-case approval without invariant/severe flagged",
          any(">=2 independent Human cases" in p for p in hf.validate(wrap(single))))

    # Approval without counterexample mining is rejected.
    no_ce = dict(approved, counterexample_search_done=False)
    check("approval without counterexample search flagged",
          any("counterexample_search_done" in p for p in hf.validate(wrap(no_ce))))

    print("test_human_feedback_delta: OK")


def test_execution_outcome() -> None:
    outcome = execution_outcome_mod

    check("absent execution_outcome passes", outcome.validate({}) == [])

    good_record = {
        "execution_outcome": {
            "plan_key": "plan-alpha",
            "acs": [
                {
                    "ac_id": "AC-01",
                    "execution": "FAIL",
                    "found_defect": True,
                    "defect_ref": "DEFECT-A",
                }
            ],
            "escapes": [
                {
                    "defect_ref": "DEFECT-ESCAPE-A",
                    "summary": "A material failure branch escaped the plan.",
                    "should_have_been_covered_by": "FAILURE_RECOVERY",
                    "first_missed_stage": "DISCOVERY",
                }
            ],
            "source": "HUMAN",
            "recorded_at": "2026-09-01T12:00:00+05:30",
        }
    }
    check("well-formed execution outcome passes", outcome.validate(good_record) == [])

    probes = outcome.to_candidate_miss_probes(good_record)
    check("Human escape yields one miss-probe input", len(probes) == 1)
    check(
        "Human escape remains governed CANDIDATE",
        probes[0]["source"] == "HUMAN"
        and probes[0]["promotion_state"] == "CANDIDATE"
        and probes[0]["auto_promote"] is False
        and probes[0]["auto_author_ac"] is False,
    )

    model_record = json.loads(json.dumps(good_record))
    model_record["execution_outcome"]["source"] = "MODEL"
    check(
        "MODEL-sourced execution outcome is rejected",
        any("MODEL/AI" in problem for problem in outcome.validate(model_record)),
    )

    missing_attribution = json.loads(json.dumps(good_record))
    escape = missing_attribution["execution_outcome"]["escapes"][0]
    escape.pop("should_have_been_covered_by")
    escape.pop("first_missed_stage")
    missing_problems = outcome.validate(missing_attribution)
    check(
        "escape without dimension is rejected",
        any("should_have_been_covered_by" in problem for problem in missing_problems),
    )
    check(
        "escape without first stage is rejected",
        any("first_missed_stage" in problem for problem in missing_problems),
    )

    second_record = json.loads(json.dumps(good_record))
    second_record["execution_outcome"]["plan_key"] = "plan-beta"
    second_record["execution_outcome"]["acs"][0]["defect_ref"] = "DEFECT-B"
    second_record["execution_outcome"]["escapes"] = []
    signals = outcome.dimension_priority_signals(
        [good_record, second_record],
        {"plan-alpha:AC-01": "FAILURE_RECOVERY", "plan-beta:AC-01": "FAILURE_RECOVERY"},
    )
    check(
        "repeated real defects raise only the mapped dimension priority",
        len(signals) == 1
        and signals[0]["coverage_dimension"] == "FAILURE_RECOVERY"
        and signals[0]["priority_action"] == "RAISE"
        and signals[0]["auto_author_ac"] is False,
    )

    gate = _load("run_gates_for_execution_outcome", "run_gates.py")
    with tempfile.TemporaryDirectory() as td:
        manifest_path = Path(td) / "manifest.json"
        malformed = json.loads(json.dumps(good_record))
        malformed["execution_outcome"]["escapes"][0].pop("first_missed_stage")
        manifest_path.write_text(json.dumps(malformed), encoding="utf-8")
        gate_failures, gate_notes = gate.check_execution_outcome(str(manifest_path))
        check("malformed outcome is not a hard gate failure", gate_failures == [])
        check(
            "malformed outcome creates a REVIEW note",
            any(note.startswith("REVIEW execution-outcome:") for note in gate_notes),
        )

        manifest_path.write_text(json.dumps(good_record), encoding="utf-8")
        gate_failures, gate_notes = gate.check_execution_outcome(str(manifest_path))
        check(
            "valid execution outcome adds no failure or review note",
            gate_failures == [] and gate_notes == [],
        )

    print("test_execution_outcome: OK")


def test_feedback_capture() -> None:
    feedback_capture_mod.run_self_tests()
    check(
        "queued feedback keeps a redacted correction only",
        feedback_capture_mod.queue_safe_capture({
            "jira_key": "PROJECT-123",
            "idempotency_key": "capture-self-test",
            "raw_feedback": "token=secret-value should not survive",
            "proposed_correction": "Use the corrected observable result.",
            "draft": {"draft_markdown": "the full plan must never enter the queue"},
            "ai_classification": {"guess": "not supervisory truth"},
        })
        == {
            "contract_version": "shared-uac-feedback-v1",
            "tenant_id": "kone",
            "jira_key": "PROJECT-123",
            "idempotency_key": "capture-self-test",
            "raw_feedback": "token=[REDACTED] should not survive",
            "source_kind": "UNCONFIRMED",
            "proposed_correction": "Use the corrected observable result.",
            "delta_type": "UNCLASSIFIED",
            "ai_classification": {},
            "draft_id": "",
            "plan_fingerprint": "",
            "evidence_bundle_id": "",
            "run_id": "",
            "ac_id": "",
            "client_context": {"client": "unknown", "session_id": "", "message_id": ""},
        },
    )
    print("test_feedback_capture: OK")


def test_entry_point_equivalence() -> None:
    ep = entry_point_equivalence_mod

    check("absent entry_point_equivalence passes", ep.validate({}) == [])

    def wrap(*cands, oqs=None):
        m = {"entry_point_equivalence": {"candidates": list(cands)}}
        if oqs is not None:
            m["open_questions"] = oqs
        return m

    # Shared handler with impl evidence -> shared regression passes.
    shared = {"entry_point_id": "EP-01", "product_action": "Generate PDF",
              "surface": "context menu", "equivalence_type": "SAME_HANDLER",
              "implementation_handler": "BaseExecutor.process", "shared_processing_path": "OT executor",
              "disposition": "SHARED_REGRESSION", "evidence": ["same handler in code"], "applicability": "APPLICABLE"}
    check("shared-handler regression with evidence passes", ep.validate(wrap(shared)) == [])

    # Same user intent promoted to regression -> rejected.
    intent = {"entry_point_id": "EP-02", "product_action": "Download PDF",
              "surface": "toolbar", "equivalence_type": "SAME_USER_INTENT",
              "disposition": "SHARED_REGRESSION", "evidence": ["looks similar"], "applicability": "UNRESOLVED"}
    check("same-user-intent cannot be promoted to regression",
          any("same user intent is not same implementation" in p for p in ep.validate(wrap(intent))))

    # Shared type without shared-path evidence -> rejected.
    no_ev = dict(shared, entry_point_id="EP-03", implementation_handler="", shared_processing_path="")
    check("shared-type promotion needs shared-path evidence",
          any("shared_processing_path or" in p for p in ep.validate(wrap(no_ev))))

    # Different implementation cannot be shared regression.
    diff = {"entry_point_id": "EP-04", "product_action": "Preview", "surface": "preview",
            "equivalence_type": "DIFFERENT_IMPLEMENTATION", "disposition": "SHARED_REGRESSION",
            "evidence": ["separate code"], "applicability": "NOT_APPLICABLE"}
    check("different-implementation cannot be shared regression",
          any("must not be promoted" in p for p in ep.validate(wrap(diff))))

    # Unknown relationship as OQ needs searched sources + declared OQ.
    unknown = {"entry_point_id": "EP-05", "product_action": "Download PDF", "surface": "toolbar",
               "equivalence_type": "UNKNOWN_RELATIONSHIP", "disposition": "OPEN_QUESTION",
               "evidence": ["unclear"], "applicability": "UNRESOLVED", "open_question_ref": "OQ-01"}
    check("OQ entry point without searched_sources flagged",
          any("searched_sources" in p for p in ep.validate(wrap(unknown, oqs=[{"id": "OQ-01"}]))))

    unknown_ok = dict(unknown, searched_sources=["GitHub code", "product docs", "IT tests"])
    check("investigated OQ entry point passes", ep.validate(wrap(unknown_ok, oqs=[{"id": "OQ-01"}])) == [])

    print("test_entry_point_equivalence: OK")


def test_value_provenance_coverage() -> None:
    vp = value_provenance_coverage_mod
    nl = chr(10)
    non_value = nl.join(["**Acceptance Criteria**", "- AC-01: the job stops the loop.", ""])
    check("non-value plan is not applicable", vp.validate({}, non_value) == [])
    bad = nl.join([
        "**Acceptance Criteria**",
        "- AC-01: selected File properties are written to metadata.xml for the topic.",
        "**Expected**", ""])
    check("value plan without provenance is flagged", any("provenance" in p for p in vp.validate({}, bad)))
    good = nl.join([
        "**Acceptance Criteria**",
        "- AC-01: selected File properties are written to metadata.xml.",
        "- AC-02: the value is read from the asset jcr:content metadata node set via CRX DE.",
        "**Expected**", ""])
    check("value plan with repository provenance passes", vp.validate({}, good) == [])
    na = {"value_provenance_not_applicable": {"reason": "Rendering-on-merge defect; the value is blank even for a normally authored value, so the write channel is not the variable under test."}}
    check("concrete value_provenance_not_applicable reason opts out", vp.validate(na, bad) == [])
    check("too-short not-applicable reason does not opt out", any("provenance" in p for p in vp.validate({"value_provenance_not_applicable": "n/a"}, bad)))
    print("test_value_provenance_coverage: OK")


def test_state_partition_coverage() -> None:
    sp = state_partition_coverage_mod
    nl = chr(10)
    non_state = nl.join(["**Acceptance Criteria**", "- AC-01: the panel shows the value.", ""])
    check("non-state plan is not applicable", sp.validate({}, non_state) == [])
    single = nl.join(["**Acceptance Criteria**", "- AC-01: the behaviour holds under a Global Profile.", "**Expected**", ""])
    check("single-state plan is flagged", any("state-partition" in p for p in sp.validate({}, single)))
    both = nl.join(["**Acceptance Criteria**", "- AC-01: the behaviour holds under both a Global Profile and a Folder Profile.", "**Expected**", ""])
    check("partition term passes", sp.validate({}, both) == [])
    na = {"state_partition_not_applicable": {"reason": "Only the Global profile can host this construct; a Folder profile cannot define it."}}
    check("concrete state opt-out passes", sp.validate(na, single) == [])
    check("stub state opt-out does not pass", any("state-partition" in p for p in sp.validate({"state_partition_not_applicable": "n/a"}, single)))
    print("test_state_partition_coverage: OK")


def test_native_pdf_coverage() -> None:
    npc = native_pdf_coverage_mod
    npc.run_self_tests()
    nl = chr(10)
    non = nl.join(["**Acceptance Criteria**", "- AC-01: the editor shows the label.", ""])
    check("non-Native-PDF plan is not applicable", npc.validate({}, non) == [])
    bare = nl.join(["**Acceptance Criteria**", "- AC-01: Native PDF output renders the table.", "**Expected**", ""])
    probs = npc.validate({}, bare)
    check("Native PDF plan missing the three dimensions is flagged", len(probs) == 3)
    check("Native PDF plan flags the Download-PDF entry point", any("entry points" in p for p in probs))
    covered = nl.join(["**Acceptance Criteria**",
        "- AC-01: Native PDF output renders the table.",
        "- AC-02: a single topic via Download PDF renders the same.",
        "- AC-03: Map Preview shows the same.",
        "- AC-04: the retained temporary files carry the correct merged HTML.", ""])
    check("Native PDF plan covering all three passes", npc.validate({}, covered) == [])
    print("test_native_pdf_coverage: OK")


def test_shared_path_regression_coverage() -> None:
    sp = shared_path_regression_coverage_mod
    nl = chr(10)
    non_shared = nl.join(["**Acceptance Criteria**", "- AC-01: the job stops the loop.", ""])
    check("no shared-path evidence is not applicable", sp.validate({}, non_shared) == [])

    miss = nl.join([
        "**Acceptance Criteria**",
        "- AC-01: metadata is built by shared code used by both engines; the AEM Site preset is out of scope.",
        "**Regression Areas**", "- nothing relevant.", ""])
    probs = sp.validate({}, miss)
    check("shared code without regression coverage is flagged", any("shared-path regression coverage" in p for p in probs))
    check("out-of-scope consumer on shared path is flagged", any("out of scope" in p for p in probs))

    good = nl.join([
        "**Acceptance Criteria**",
        "- AC-01: metadata is built by shared code used by both engines; other presets are covered as shared-path regression.",
        "**Regression Areas**",
        "- Re-run the AEM Site and HTML5 output types with Retain temporary files and confirm the retained metadata.xml is unchanged (shared-path regression).", ""])
    check("shared code with shared-path regression passes", sp.validate({}, good) == [])
    print("test_shared_path_regression_coverage: OK")


def test_qe_completeness_coverage() -> None:
    gate = qe_completeness_coverage_mod
    nl = chr(10)

    clean_plan = nl.join([
        "**Acceptance Criteria**",
        "- AC-01: The selected item remains visible after save.",
        "**Open Questions**",
        "- No open questions from current evidence",
        "",
    ])
    check("plan with no real question or regression passes untouched", gate.validate(clean_plan, {}) == [])
    check("clean plan does not activate QE completeness", not gate.is_present(clean_plan, {}))
    plain_sentinel_plan = clean_plan.replace(
        "- No open questions from current evidence",
        "No open questions from current evidence",
    )
    check(
        "exact unbulleted no-question sentinel also passes untouched",
        gate.validate(plain_sentinel_plan, {}) == []
        and not gate.is_present(plain_sentinel_plan, {}),
    )

    oq_plan = nl.join([
        "**Acceptance Criteria**",
        "- AC-01: The selected item remains visible after save.",
        "- AC-02: The selected item keeps the accepted label.",
        "**Open Questions**",
        "- OQ-01: Which label is the accepted product contract? QA impact: the answer selects the exact UI oracle.",
        "",
    ])
    oq_manifest = {
        "open_questions": [
            {
                "id": "OQ-01",
                "question": "Which label is the accepted product contract?",
            }
        ]
    }
    problems = gate.validate(oq_plan, oq_manifest)
    check("activated plan without qe_completeness fails", bool(problems))
    check("missing qe_completeness uses the stable prefix", all(p.startswith(gate.PREFIX) for p in problems))

    deferred_manifest = json.loads(json.dumps(oq_manifest))
    deferred_manifest["qe_completeness"] = {
        "schema_version": gate.SCHEMA_VERSION,
        "open_question_classification": [
            {
                "oq_ref": "OQ-01",
                "category": "DEFERRED_COVERAGE",
                "reason": "The expected label can be checked and belongs in acceptance.",
                "promoted_ac_ref": "AC-02",
                "can_be_ac_with_expected": True,
            }
        ],
        "regression_classification": [],
    }
    problems = gate.validate(oq_plan, deferred_manifest)
    check("DEFERRED_COVERAGE hard-fails even with a real promoted AC", any("DEFERRED_COVERAGE" in p for p in problems))
    check("deferred coverage failure keeps the stable prefix", all(p.startswith(gate.PREFIX) for p in problems))

    unclassified_manifest = json.loads(json.dumps(oq_manifest))
    unclassified_manifest["qe_completeness"] = {
        "schema_version": gate.SCHEMA_VERSION,
        "open_question_classification": [],
        "regression_classification": [],
    }
    problems = gate.validate(oq_plan, unclassified_manifest)
    check("Open Question missing from classification hard-fails", any("missing from open_question_classification" in p for p in problems))

    regression_item = "P3 [Regression]: Re-run the unchanged export and confirm the saved output still opens."
    regression_plan = nl.join([
        "**Acceptance Criteria**",
        "- AC-01: The export produces the accepted output.",
        "**Test Scenarios**",
        f"- {regression_item}",
        "",
    ])
    regression_manifest = {
        "qe_completeness": {
            "schema_version": gate.SCHEMA_VERSION,
            "open_question_classification": [],
            "regression_classification": [
                {
                    "item": regression_item,
                    "category": "IN_SCOPE_BEHAVIOR",
                    "ac_ref": "",
                }
            ],
        }
    }
    problems = gate.validate(regression_plan, regression_manifest)
    check("IN_SCOPE_BEHAVIOR without ac_ref hard-fails", any("requires ac_ref" in p for p in problems))

    p3_item = "P3 [Regression] [AC-01]: Re-run the secondary entry point and confirm the accepted output."
    safety_item = "Re-run an unchanged adjacent workflow and confirm its saved result is unchanged."
    positive_plan = nl.join([
        "**Acceptance Criteria**",
        "- AC-01: The secondary entry point produces the accepted output.",
        "- AC-02: The selected item keeps the accepted label.",
        "**Test Scenarios**",
        f"- {p3_item}",
        "**Regression Areas**",
        f"- {safety_item}",
        "**Open Questions**",
        "- OQ-01: Which label is the accepted product contract? QA impact: the answer selects the exact UI oracle.",
        "",
    ])
    positive_manifest = {
        "open_questions": oq_manifest["open_questions"],
        "qe_completeness": {
            "schema_version": gate.SCHEMA_VERSION,
            "open_question_classification": [
                {
                    "oq_ref": "OQ-01",
                    "category": "GENUINE_PRODUCT_DECISION",
                    "reason": "Only an authorized product decision can select the accepted label.",
                    "can_be_ac_with_expected": False,
                }
            ],
            "regression_classification": [
                {
                    "item": p3_item,
                    "category": "IN_SCOPE_BEHAVIOR",
                    "ac_ref": "AC-01",
                },
                {
                    "item": safety_item,
                    "category": "SAFETY_RETEST",
                    "ac_ref": "",
                },
            ],
        },
    }
    check("fully classified genuine decisions and regressions pass", gate.validate(positive_plan, positive_manifest) == [])
    check("clean classified plan has no review", gate.review(positive_plan, positive_manifest) == [])

    review_manifest = json.loads(json.dumps(positive_manifest))
    review_record = review_manifest["qe_completeness"]["open_question_classification"][0]
    review_record["can_be_ac_with_expected"] = True
    review_notes = gate.review(positive_plan, review_manifest)
    expected_review = (
        "QE COMPLETENESS REVIEW: OQ-01 can be written as an AC with the QE-expected "
        "contract and flagged for dev down-scope; prefer an AC over an Open Question."
    )
    check("QE-expected contract emits the exact REVIEW note", review_notes == [expected_review])
    check("REVIEW case keeps hard validation green", gate.validate(positive_plan, review_manifest) == [])

    promoted_manifest = json.loads(json.dumps(review_manifest))
    promoted_manifest["qe_completeness"]["open_question_classification"][0]["promoted_ac_ref"] = "AC-02"
    check("genuine decision promoted to a real AC passes", gate.validate(positive_plan, promoted_manifest) == [])
    check("promoted genuine decision clears REVIEW", gate.review(positive_plan, promoted_manifest) == [])

# Reviewer-requested coverage must not disappear behind alternate headings.
    check_item = "Open the secondary view and confirm its saved text stays intact."
    empty_ledger = {
        "qe_completeness": {
            "schema_version": gate.SCHEMA_VERSION,
            "open_question_classification": [],
            "regression_classification": [],
        },
    }
    mapped_ledger = json.loads(json.dumps(empty_ledger))
    mapped_ledger["qe_completeness"]["regression_classification"] = [{
        "item": check_item, "category": "IN_SCOPE_BEHAVIOR", "ac_ref": "AC-01",
    }]
    headings = [
        "## QE checks retained from the review",
        "**QE checks**",
        "## QA checks:",
        "## Reviewer checks",
        "## Reviewer-requested checks",
        "## Additional QE checks",
        "## QE regression coverage",
        "## **QE checks:** ##",
    ]
    for heading in headings:
        for marker in ("- ", "* ", "+ ", "1. ", "1) ", ""):
            alias_plan = nl.join([
                "# Test plan", "## Acceptance Criteria",
                "- AC-01: The secondary view keeps the saved text intact.",
                heading, marker + check_item,
            ])
            check(f"checklist activates: {heading}/{marker}", gate.is_present(alias_plan, {}))
            check(f"unclassified checklist fails: {heading}/{marker}", bool(gate.validate(alias_plan, {})))
            check(f"empty ledger cannot hide checklist: {heading}/{marker}",
                  any("missing from regression_classification" in p for p in gate.validate(alias_plan, empty_ledger)))
            check(f"mapped checklist in full plan passes: {heading}/{marker}",
                  gate.validate(alias_plan, mapped_ledger) == [])

    alias_plan = nl.join([
        "## Acceptance Criteria", "- AC-01: The secondary view keeps the saved text intact.",
        "## QE checks retained from the review", "- " + check_item,
    ])
    safety_ledger = json.loads(json.dumps(mapped_ledger))
    safety_ledger["qe_completeness"]["regression_classification"][0]["category"] = "SAFETY_RETEST"
    check("reviewer checklist cannot be labeled safety retest even with an AC reference",
          any("not parked as SAFETY_RETEST" in p for p in gate.validate(alias_plan, safety_ledger)))
    for invalid_ref in ("", "AC-99"):
        invalid_ledger = json.loads(json.dumps(mapped_ledger))
        invalid_ledger["qe_completeness"]["regression_classification"][0]["ac_ref"] = invalid_ref
        check(f"reviewer checklist needs a real AC: {invalid_ref}",
              bool(gate.validate(alias_plan, invalid_ledger)))

    fake_item = "AC-01: " + check_item
    fake_ledger = json.loads(json.dumps(mapped_ledger))
    fake_ledger["qe_completeness"]["regression_classification"][0]["item"] = fake_item
    fake_plan = nl.join(["## QE checks", "- " + fake_item])
    check("AC label only in checklist is not an acceptance criterion",
          any("not present in the plan" in p for p in gate.validate(fake_plan, fake_ledger)))
    for fence in ("`" * 3, "~" * 3):
        example_plan = nl.join([
            "## Acceptance Criteria", fence, "- AC-01: An example is not an AC.", fence,
            "## QE checks", "- " + check_item,
        ])
        check("AC in a fenced example cannot satisfy a checklist reference",
              any("not present in the plan" in p for p in gate.validate(example_plan, mapped_ledger)))
    nested_plan = alias_plan.replace("- " + check_item, "### Secondary view" + nl + "- " + check_item)
    check("nested check heading cannot hide coverage", bool(gate.validate(nested_plan, empty_ledger)))
    check("nested check can map to real AC", gate.validate(nested_plan, mapped_ledger) == [])
    for ac_heading in ("Acceptance Criteria", "Acceptance Contract", "Proposed acceptance contract"):
        headed_ac_plan = alias_plan.replace("Acceptance Criteria", ac_heading).replace(
            "- AC-01:", "### AC-01:"
        )
        check("AC subheading remains a real acceptance criterion",
              gate.validate(headed_ac_plan, mapped_ledger) == [])
    ac_only_plan = nl.join([
        "## Acceptance Criteria", "- AC-01: The secondary view keeps the saved text intact.",
    ])
    check("moving reviewer coverage into ACs needs no duplicate checklist",
          gate.validate(ac_only_plan, {}) == [])
    evidence_plan = ac_only_plan + nl + "## Evidence gaps" + nl + "- An optional source was unavailable."
    check("unrelated evidence headings are not reviewer checklists", gate.validate(evidence_plan, {}) == [])
    check("existing genuine undecided outcomes remain questions",
          gate.validate(positive_plan, positive_manifest) == []
          and gate.review(positive_plan, positive_manifest) == [])

    run_gates_source = Path(__file__).with_name("run_gates.py").read_text(encoding="utf-8")
    check("run_gates loads QE completeness", 'qe_completeness_coverage_mod = _load(' in run_gates_source)
    check("run_gates invokes QE completeness validation", "qe_completeness_coverage_mod.validate(body, manifest_data)" in run_gates_source)
    check("run_gates preserves the QE completeness prefix", "failures += qe_completeness_coverage_mod.validate(body, manifest_data)" in run_gates_source)
    check("run_gates collects QE completeness REVIEW notes", "notes += qe_completeness_coverage_mod.review(body, manifest_data)" in run_gates_source)
    run_gates = _load("run_gates_for_qe_completeness", "run_gates.py")
    check("QE completeness REVIEW makes a receipt non-postable", run_gates._postability_review_present(review_notes))

    print("test_qe_completeness_coverage: OK")


def test_manifest_completeness_gate() -> None:
    gate = manifest_completeness_gate_mod
    nl = chr(10)
    plain_plan = nl.join([
        "**Acceptance Criteria**",
        "- AC-01: The selected item remains visible after save.",
        "",
    ])

    ok, messages = gate.validate(plain_plan, {})
    check("signal-free manifest has no completeness requirement", ok and messages == [])
    check("signal-free manifest reports gate not active", not gate.is_present({}))

    publishing_plan = nl.join([
        "**Acceptance Criteria**",
        "- AC-01: The Native PDF output preset generates the expected document.",
        "",
    ])
    ok, messages = gate.validate(publishing_plan, {})
    check(
        "publishing signal without publishing_scope hard-fails",
        not ok
        and any("'publishing_scope' is absent or empty" in message for message in messages),
    )
    check(
        "every completeness failure has the stable prefix",
        all(message.startswith("COMPLETENESS GATE:") for message in messages),
    )
    check(
        "publishing plan activates completeness",
        gate.is_present({}, publishing_plan),
    )

    present = {"publishing_scope": {"schema_version": "fixture-v1"}}
    ok, messages = gate.validate(publishing_plan, present)
    check("non-empty publishing_scope satisfies completeness", ok and messages == [])

    empty = {"publishing_scope": {}}
    ok, messages = gate.validate(publishing_plan, empty)
    check(
        "empty publishing_scope does not satisfy completeness",
        not ok and any("absent or empty" in message for message in messages),
    )

    scalar = {"publishing_scope": True}
    ok, messages = gate.validate(publishing_plan, scalar)
    check(
        "scalar publishing_scope cannot impersonate a manifest block",
        not ok and any("absent or empty" in message for message in messages),
    )

    waived = {
        "block_waivers": [
            {
                "block": "publishing_scope",
                "reason": "Legacy captured run did not store this structured block.",
                "waived_by": "author",
            }
        ]
    }
    ok, messages = gate.validate(publishing_plan, waived)
    check("reasoned attributable waiver satisfies completeness", ok and messages == [])

    bad_waiver = json.loads(json.dumps(waived))
    bad_waiver["block_waivers"][0]["reason"] = " "
    ok, messages = gate.validate(publishing_plan, bad_waiver)
    check(
        "blank waiver reason hard-fails",
        not ok and any("reason is required" in message for message in messages),
    )

    ok, messages = gate.validate(
        plain_plan,
        {"behaviour_matters": False, "behavior_model": {"versioned_models": ["v1"]}},
    )
    check("behaviour_matters false preserves behavior-block opt-out", ok and messages == [])

    behavior_manifest = {
        "behaviour_matters": True,
        "clarification": {"schema_version": "fixture-v1"},
    }
    for block in gate.CORE_BEHAVIOR_BLOCKS:
        behavior_manifest[block] = {"declared": True}
    behavior_manifest["behavior_model"] = {
        "trigger": ["versioned operation"],
        "operations": ["render"],
        "versioned_models": ["current and previous"],
    }
    ok, messages = gate.validate(plain_plan, behavior_manifest)
    check(
        "versioned behavior requires temporal_evidence",
        not ok and any("'temporal_evidence'" in message for message in messages),
    )
    behavior_manifest["temporal_evidence"] = {"items": []}
    ok, messages = gate.validate(plain_plan, behavior_manifest)
    check("non-empty temporal_evidence satisfies version signal", ok and messages == [])

    check(
        "summary reports a clean positive fixture",
        gate.summarize(present, publishing_plan).startswith(
            "ManifestCompletenessGate: CLEAN"
        ),
    )
    print("test_manifest_completeness_gate: OK")


def test_v3_scaffolding() -> None:
    _load("test_v3_scaffold", "test_v3_scaffold.py").run_tests(check)
    scaffolder = _load("v3_scaffold", "v3_scaffold.py")
    gates = _load("run_gates_v3_scaffold", "run_gates.py")
    manifest = _canonical_semantic_fixture()
    source_id = manifest["contract_facts"]["source_refs"][0]
    manifest["behavior_model"] = {
        "trigger": ["a value is requested"], "operations": ["resolve the value"],
        "processors": ["value resolver"],
        "facts": [{"fact": "A value resolver supplies the requested value.", "evidence_ids": [source_id],
                   "authority": "JIRA", "confidence": 1.0}],
    }
    manifest["evidence_catalog"] = [{"id": source_id, "source_type": "jira"}]
    manifest.pop("behavior_graph")
    manifest.pop("semantic_closure")
    draft = scaffolder.scaffold(manifest)
    check("canonical gate rejects generated review placeholders", any("author must confirm" in p
          for p in gates.validate_canonical_semantic_pipeline(draft)))
    # Synthetic author decisions exercise the full existing semantic pipeline.
    # The generator itself must not create any of these verdicts/dispositions.
    for row in draft["behavior_graph"]["nodes"] + draft["behavior_graph"]["edges"]:
        row.update(author_review_required=False, review_note="Reviewed against this synthetic fixture's source.")
    edge = draft["behavior_graph"]["edges"][0]
    edge.update(verification_state="REJECTED", applicability="NOT_APPLICABLE")
    hypothesis = draft["coverage_hypotheses"][0]
    hypothesis["status"] = "REJECTED"
    for row in draft["semantic_closure"]["records"]:
        row.update(author_review_required=False, reason="The fixture's reviewed scalar contract excludes this relationship.", disposition_ref="CD-03")
    draft["evidence_lifecycle"] = [{"evidence_id": source_id, "source": "linked jira",
        "query": "Inspect the scalar contract boundary", "pass": "initial", "status": "USED",
        "hypothesis_id": hypothesis["hypothesis_id"], "subject": "PRODUCT_CONTRACT", "authority": "JIRA_EXPECTED_BEHAVIOR"}]
    draft["verifications"] = [{"hypothesis_id": hypothesis["hypothesis_id"], "verdict": "REJECTED",
        "disproving_evidence": [source_id], "subject": "PRODUCT_CONTRACT", "disposition": "EXCLUDED"}]
    draft["dispositions"][2]["source_refs"] = [
        *behavior_graph_mod.material_item_ids(draft["behavior_graph"]),
        *semantic_closure_mod.material_item_ids(draft["semantic_closure"]), hypothesis["hypothesis_id"],
    ]
    problems = gates.validate_canonical_semantic_pipeline(draft)
    check("scaffold then author disposition passes canonical semantic gates", problems == [])
    check("scaffolding does not expand the fixture's acceptance set", draft["acceptance_promotions"] == manifest["acceptance_promotions"])


def test_v3_authoring_pipeline() -> None:
    """Synthetic evidence exercises authoring, not a fixture with skipped blocks."""
    import copy

    gate = manifest_completeness_gate_mod
    ds = dimension_synthesizer_mod
    run_gates = _load("run_gates", "run_gates.py")
    model = {
        "trigger": ["select an item"], "operations": ["display the selected item"],
        "inputs": ["selected item"], "outputs": ["selected item is visible"],
        "affected_state": ["current selection"], "consumers": [], "processors": [],
        "write_paths": [], "read_paths": [],
        "facts": [{"fact": "The supplied selection is displayed.", "evidence_ids": ["E1"],
                   "authority": "JIRA", "confidence": 1.0}],
    }
    check("grounded authoring model passes", behavior_mod.validate_behavior_model(model, require_grounding=True) == [])
    ungrounded = dict(model, facts=[])
    check("empty facts cannot impersonate behavioral understanding",
          bool(behavior_mod.validate_behavior_model(ungrounded, require_grounding=True)))
    malformed = dict(model, facts=[{"fact": "x", "evidence_ids": 5}])
    check("wrong-typed fact evidence fails without crashing",
          bool(behavior_mod.validate_behavior_model(malformed, require_grounding=True)))

    rich_model = dict(model,
        consumers=["reader"], capabilities=[{"name": "supported item kinds"}],
        generated_artifacts=["result document"], configuration_branches=["enabled and disabled"],
        publishing_modes=["configured output"], write_paths=["item writer"],
        versioned_models=["earlier saved state"], side_effects=["consumer cache"],
        facts=model["facts"] + [{"fact": "Bulk traversal follows reference semantics.",
                                "evidence_ids": ["E2"], "authority": "DITA_SPEC", "confidence": 1.0}])
    all_families = coverage_mod.generate_from_model({"behavior_model": rich_model})
    check("all twelve exploration families execute and activate on grounded signals",
          {x["dimension"] for x in all_families["candidates"]}
          == set(coverage_mod.EXPLORATION_FIELDS) and len(all_families["explorers"]) == 12)
    check("exploration candidates carry non-empty technical basis and no verdict",
          all(x["technical_basis"] and x["status"] == "INVESTIGATION_CANDIDATE"
              for x in all_families["candidates"]))
    check("ungrounded model emits no exploration guesses",
          coverage_mod.generate_from_model({"behavior_model": ungrounded})["candidates"] == [])
    check("simple UI does not activate irrelevant exploration families",
          {x["dimension"] for x in coverage_mod.generate_from_model({"behavior_model": model})["candidates"]}
          == {"CONTRACT_BOUNDARY", "STATE_PARTITION"})

    offline_loader = ds._load_offline_retrieval
    ds._load_offline_retrieval = lambda: None
    try:
        manifest = _canonical_semantic_fixture()
        manifest.update(schema_version="aem-guides-evidence-manifest-v3", behaviour_matters=True,
                        behavior_model=model, clarification={"schema_version": "fixture-v1"},
                        evidence_catalog=[{"id": "E1", "kind": "jira", "source_ref": "synthetic issue capture"}])
        generated = ds.synthesize(manifest)
        check("all generated candidates are legal v3 hypotheses",
              coverage_mod.validate_coverage_block(generated["candidates"]) == [])
        check("generation is stable and does not mutate its input",
              generated == ds.synthesize(manifest) and manifest["coverage_hypotheses"] == [])
        manifest["coverage_hypotheses"] = generated["candidates"]
        check("retained explorer candidates still need terminal decisions", bool(ds.review_notes(manifest)))
        first_hid = generated["candidates"][0]["hypothesis_id"]
        for index, hyp in enumerate(manifest["coverage_hypotheses"]):
            hyp.update(status="CONFIRMED", requires_more_evidence=False)
            eid, hid = f"EV-{index}", hyp["hypothesis_id"]
            subject = "PRODUCT_CONTRACT" if index == 0 else "ACTUAL_IMPLEMENTATION"
            authority = "JIRA_EXPECTED_BEHAVIOR" if index == 0 else "CURRENT_IMPLEMENTATION"
            manifest["evidence_lifecycle"].append({
                "evidence_id": eid, "hypothesis_id": hid, "source": "current repository" if index else "linked jira",
                "query": f"inspect observed relationship {index}", "pass": "initial", "status": "USED",
                "subject": subject, "authority": authority,
            })
            manifest["verifications"].append({
                "hypothesis_id": hid, "verdict": "CONFIRMED", "subject": subject,
                "supporting_authorities": [authority], "supporting_evidence": [eid],
                "disposition": "ACCEPTANCE_CRITERION" if index == 0 else "REGRESSION",
            })
            if index:
                manifest["dispositions"].append({
                    "finding_id": f"CD-H-{index}", "source_refs": [hid],
                    "statement": "The selected item remains visible.", "disposition": "REGRESSION_COVERAGE",
                })
        manifest["dispositions"][0]["source_refs"].append(first_hid)
        manifest["acceptance_promotions"]["records"][0]["candidate_ref"] = first_hid
        pipeline_problems = run_gates.validate_canonical_semantic_pipeline(manifest)
        assert not pipeline_problems, pipeline_problems
        check("v3 model, hypotheses, evidence, verification, disposition and promotion validate together", True)
        check("complete reasoning record needs no block waivers", gate.validate("", manifest)[0])
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "manifest.json"
            path.write_text(json.dumps(manifest), encoding="utf-8")
            check("strict authoring model runs through run_gates", run_gates.check_behavior_model(str(path))[0] == [])
            check("real v3 hypotheses satisfy reasoning-required", run_gates.check_reasoning_required(str(path))[0] == [])
            check("terminal verification runs through run_gates", run_gates.check_verifications(str(path))[0] == [])
            check("actual evidence ledger runs through retrieval gate", run_gates.check_retrieval(str(path))[0] == [])
        incomplete = copy.deepcopy(manifest)
        incomplete["verifications"].pop()
        check("dropping a candidate verdict fails", any("no verification" in p
              for p in run_gates.validate_canonical_semantic_pipeline(incomplete)))
        missing_disposition = copy.deepcopy(manifest)
        missing_disposition["dispositions"].pop()
        check("verified hypotheses cannot silently lose their disposition",
              any("has no coverage disposition" in p for p in run_gates.validate_canonical_semantic_pipeline(missing_disposition)))
        anonymous = copy.deepcopy(manifest)
        anonymous["coverage_hypotheses"][0]["hypothesis_id"] = ""
        check("authoring rejects anonymous candidates before verification",
              any("non-empty hypothesis_id" in p for p in run_gates.validate_canonical_semantic_pipeline(anonymous)))
        wrong_authority = copy.deepcopy(manifest)
        wrong_authority["verifications"][0]["supporting_authorities"] = ["CURRENT_IMPLEMENTATION"]
        check("implementation authority cannot be relabelled as acceptance truth",
              bool(run_gates.validate_canonical_semantic_pipeline(wrong_authority)))

        upload = {"behavior_model": dict(model, facts=[{
            "fact": "The shared asset upload overwrites a repository node property.",
            "evidence_ids": ["E-UPLOAD"], "authority": "CURRENT_IMPLEMENTATION", "confidence": 1.0}])}
        upload_candidates = ds.synthesize(upload)["candidates"]
        check("feature-map and learned-probe candidates both run", {"FEATURE_MAP", "LEARNED_PROBE"}
              <= {h["generator"] for h in upload_candidates})
        check("all discovery axes normalize into valid hypotheses",
              coverage_mod.validate_coverage_block(upload_candidates) == [])
        axes = probe_coverage_gate_mod._covered_axes({"coverage_hypotheses": upload_candidates})
        check("hypotheses alone preserve discovery-axis probe coverage", "CODE_PATH_CONSUMER" in axes and "VALUE_SET_CHANNEL" in axes)
        activated = probe_coverage_gate_mod.activated_probes("asset upload overwrite", {})
        check("real active probes accept hypothesis dimensions without parallel clarification",
              probe_coverage_gate_mod.validate("asset upload overwrite", {
                  "coverage_hypotheses": [{"dimension": p["axis"]} for p in activated]}) == [])
    finally:
        ds._load_offline_retrieval = offline_loader

    legacy = {"schema_version": gate.LEGACY_SCHEMA, "behaviour_matters": True,
              "block_waivers": [{"block": b, "reason": "Legacy capture lacks this block.", "waived_by": "author"}
                                for b in gate.CORE_BEHAVIOR_BLOCKS],
              "clarification": {"schema_version": "fixture-v1"}}
    ok, problems = gate.validate("", legacy)
    check("blanket behavioral v2 waivers hard-fail all three protected blocks",
          not ok and all(any(b in p and "cannot be waived" in p for p in problems)
                         for b in gate.PROTECTED_BEHAVIOR_BLOCKS))
    check("every reasoning waiver emits non-postable REVIEW", len(gate.review_notes(legacy)) == len(gate.CORE_BEHAVIOR_BLOCKS))
    check("reasoning waiver reviews engage the actual posting guard",
          run_gates._postability_review_present(gate.review_notes(legacy)))
    reviewed = copy.deepcopy(legacy)
    for waiver in reviewed["block_waivers"]:
        if waiver["block"] in gate.PROTECTED_BEHAVIOR_BLOCKS:
            waiver["reviewed_escape"] = {"decision": "APPROVED", "reviewed_by": "QE reviewer",
                                         "review_ref": "synthetic migration review"}
    check("reviewed legacy escape is accepted as a review record", gate.validate("", reviewed)[0])
    check("reviewed escape never reports CLEAN", "REVIEW" in gate.summarize(reviewed))
    self_review = copy.deepcopy(reviewed)
    self_review["block_waivers"][2]["reviewed_escape"]["reviewed_by"] = "author"
    check("author self-review cannot bypass protected blocks", not gate.validate("", self_review)[0])
    modern = dict(reviewed, schema_version="aem-guides-evidence-manifest-v3")
    check("v3 reasoning waivers require explicit reviewed escapes", not gate.validate("", modern)[0])
    structural = {"block_waivers": [{"block": "publishing_scope", "reason": "Legacy capture.", "waived_by": "author"}]}
    check("legacy structural waiver behavior is unchanged", gate.validate("", structural)[0] and not gate.review_notes(structural))
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "legacy.json"
        path.write_text(json.dumps(legacy), encoding="utf-8")
        failures, notes = run_gates.check_reasoning_required(str(path))
        check("run_gates no longer silently skips behavioral v2 reasoning", bool(failures) and any(n.startswith("REVIEW") for n in notes))

    questions = [{"question_id": f"Q-{i}", "question": f"Which consumer owns state {i}?",
                  "why_it_matters": "Changes the test scope.", "hypothesis_id": f"H-{i}",
                  "preferred_sources": ["current repository"], "search_concepts": [f"state {i}"],
                  "blocking": True, "material": False} for i in (1, 2)]
    evidence = [{"evidence_id": "E-SECOND", "source": "current repository", "query": "inspect consumer state 1",
                 "pass": "second", "status": "USED", "question_id": "Q-1", "hypothesis_id": "H-1"}]
    check("one question's second pass cannot satisfy another blocking question",
          any("Q-2 has no linked" in p for p in mq_mod.check_retrieval_discipline(questions, evidence)))
    print("test_v3_authoring_pipeline: OK")


def test_clarification_gate() -> None:
    cg = clarification_gate_mod
    nl = chr(10)

    plain_plan = nl.join([
        "**Acceptance Criteria**",
        "- AC-01: The selected item remains visible after save.",
        "",
    ])
    ok, messages = cg.validate(plain_plan, {})
    check("non-activated plan may omit clarification", ok and messages == [])
    ok, messages = cg.validate(plain_plan, {"clarification": []})
    check(
        "declared clarification must be an object",
        not ok and any("must be an object" in message for message in messages),
    )

    ok, messages = cg.validate(plain_plan, {"behaviour_matters": True})
    check(
        "activated plan must declare clarification",
        not ok and any("clarification block is required" in message for message in messages),
    )

    value_plan = nl.join([
        "**Acceptance Criteria**",
        "- AC-01: Selected File properties are written to metadata.xml for the topic.",
        "",
    ])
    resolved_value = {
        "behaviour_matters": True,
        "open_questions": [],
        "clarification": {
            "schema_version": "aem-guides-clarification-v1",
            "dimension_space": [
                {
                    "dimension_id": "D-01",
                    "axis": "VALUE_SET_CHANNEL",
                    "candidate": "repository metadata node via CRX/DE (jcr:content/metadata)",
                    "material": True,
                    "materiality_reason": "The output reads the property from the source asset.",
                    "resolution": "COVERED_BY_AC",
                    "evidence_refs": ["E-01"],
                    "ac_refs": ["AC-01"],
                }
            ],
            "questions_surfaced_to_user": [],
            "authoring_gated_on_answers": True,
        },
    }
    ok, messages = cg.validate(value_plan, resolved_value)
    check("fully resolved clarification block passes", ok and messages == [])
    check("clarification block is detected", cg.is_present(resolved_value))
    check("clarification summary reports the dimension", "1 dimension" in cg.summarize(resolved_value))

    unresolved = json.loads(json.dumps(resolved_value))
    unresolved["clarification"]["dimension_space"][0]["resolution"] = "UNRESOLVED"
    ok, messages = cg.validate(value_plan, unresolved)
    check(
        "material UNRESOLVED dimension fails",
        not ok and any("must not remain UNRESOLVED" in message for message in messages),
    )
    check(
        "every clarification failure has the stable prefix",
        all(message.startswith("CLARIFICATION GATE:") for message in messages),
    )

    waiting = json.loads(json.dumps(resolved_value))
    waiting["clarification"]["dimension_space"][0]["resolution"] = "RESOLVED_FROM_EVIDENCE"
    waiting["clarification"]["questions_surfaced_to_user"] = [
        {
            "question_id": "CQ-01",
            "question": "Which source controls the output value?",
            "blocking": True,
            "answer": "",
            "answered_by": "",
            "status": "WAITING",
        }
    ]
    waiting["clarification"]["authoring_gated_on_answers"] = False
    ok, messages = cg.validate(value_plan, waiting)
    check(
        "WAITING blocking question fails",
        not ok and any("blocking question must be ANSWERED" in message for message in messages),
    )
    check(
        "blocking question requires authoring gate assertion",
        any("authoring_gated_on_answers must be true" in message for message in messages),
    )

    bad_ac = json.loads(json.dumps(resolved_value))
    bad_ac["clarification"]["dimension_space"][0]["ac_refs"] = ["AC-99"]
    ok, messages = cg.validate(value_plan, bad_ac)
    check(
        "COVERED_BY_AC must reference a plan AC",
        not ok and any("AC-99" in message and "absent" in message for message in messages),
    )

    bad_oq = json.loads(json.dumps(resolved_value))
    bad_oq["clarification"]["dimension_space"][0]["resolution"] = "DEFERRED_OPEN_QUESTION"
    bad_oq["clarification"]["dimension_space"][0]["open_question_ref"] = "OQ-02"
    ok, messages = cg.validate(value_plan, bad_oq)
    check(
        "deferred dimension must reference a declared Open Question",
        not ok and any("OQ-02" in message and "not declared" in message for message in messages),
    )

    missing_value_axis = json.loads(json.dumps(resolved_value))
    missing_value_axis["clarification"]["dimension_space"][0].update({
        "axis": "TOPIC_TYPE",
        "candidate": "topic",
        "resolution": "RESOLVED_FROM_EVIDENCE",
        "ac_refs": [],
    })
    ok, messages = cg.validate(value_plan, missing_value_axis)
    check(
        "value-write plan cannot omit VALUE_SET_CHANNEL",
        not ok and any("requires a VALUE_SET_CHANNEL" in message for message in messages),
    )

    missing_repository_candidate = json.loads(json.dumps(resolved_value))
    missing_repository_candidate["clarification"]["dimension_space"][0]["candidate"] = "authoring UI"
    ok, messages = cg.validate(value_plan, missing_repository_candidate)
    check(
        "value-write dimension must enumerate CRX/DE or repository node",
        not ok and any("CRX/DE or repository-node" in message for message in messages),
    )

    publishing_plan = nl.join([
        "**Acceptance Criteria**",
        "- AC-01: The Native PDF output preset generates the expected document.",
        "",
    ])
    publishing_manifest = json.loads(json.dumps(resolved_value))
    publishing_manifest["clarification"]["dimension_space"][0].update({
        "axis": "TOPIC_TYPE",
        "candidate": "topic",
        "resolution": "RESOLVED_FROM_EVIDENCE",
        "ac_refs": [],
    })
    ok, messages = cg.validate(publishing_plan, publishing_manifest)
    check(
        "publishing plan must enumerate OUTPUT_PRESET",
        not ok and any("requires an OUTPUT_PRESET" in message for message in messages),
    )

    shared_plan = nl.join([
        "**Acceptance Criteria**",
        "- AC-01: Shared code used by both output engines keeps the generated result unchanged.",
        "**Regression Areas**",
        "- Re-test both output engines because they use the same shared handler.",
        "",
    ])
    shared_manifest = json.loads(json.dumps(resolved_value))
    shared_manifest["clarification"]["dimension_space"][0].update({
        "axis": "TOPIC_TYPE",
        "candidate": "topic",
        "resolution": "RESOLVED_FROM_EVIDENCE",
        "ac_refs": [],
    })
    ok, messages = cg.validate(shared_plan, shared_manifest)
    check(
        "shared code plan must enumerate CODE_PATH_CONSUMER",
        not ok and any("requires a CODE_PATH_CONSUMER" in message for message in messages),
    )

    print("test_clarification_gate: OK")


def test_guides_vocabulary() -> None:
    import guides_vocabulary as gv
    gv.run_self_tests()
    # block list fires inside the coverage_forcing gate
    import coverage_forcing as cf
    bad = "## Acceptance Criteria\n- AC-01: advise recreation only when the preset is confirmed stale."
    assert any("stale-preset" in p for p in cf.validate(
        {"issue": {"summary": "x", "description": "stale preset failed status"}}, bad)), \
        "stale-preset block must fire through coverage_forcing"
    print("test_guides_vocabulary: OK")


def test_customer_discovery() -> None:
    import copy
    import customer_discovery as profiles
    import dimension_synthesizer as ds
    import miss_probe_library as probes

    probes.run_self_tests()
    packet = {"schema_version": profiles.SCHEMA_VERSION, "profiles": [{
        "profile_id": "CP-TEST", "customer": "Acme", "labels": ["Acme"],
        "source": "LEARNED", "promotion_state": "VALIDATING", "confidence": 0.2,
        "source_ref": "hashed CSV fixture", "source_hash": "sha256:" + "a" * 64,
        "semantic_match": {"components": ["Authoring"], "any_terms": ["input method"]},
        "dimensions": [
            {"id": name, "axis": axis, "candidate": "Investigate " + name,
             "case_refs": ["case-one", "case-two"]}
            for name, axis in (("input", "LOCALIZATION"), ("structure", "STATE_PARTITION"),
                               ("reference", "REFERENCE_ARTIFACT"))
        ]}]}
    base = {"issue": {"labels": ["Acme"], "components": ["Authoring"]},
            "customer_discovery_profiles": packet,
            "behavior_model": {"facts": [{"fact": "Selection state changes", "evidence_ids": ["E1"]}]}}
    check("customer profile packet valid", profiles.validate_packet(packet) == [])
    before = copy.deepcopy(base)
    candidates = profiles.candidates_for(base, [("E1", "Selection state changes")])
    check("customer label surfaces three advisory dimensions", len(candidates) == 3)
    check("customer profiles do not mutate author input", base == before)
    check("no profile can authorize criteria", all(c["status"] == "INVESTIGATION_CANDIDATE"
          and c["promotion_state"] == "VALIDATING" and c["non_authoritative"]
          and not c["auto_author_ac"] and not c["auto_promote"] for c in candidates))
    check("profile version and provenance survive", all(c["profile_version"] and c["source_case_refs"] for c in candidates))
    unrelated = copy.deepcopy(base)
    unrelated["issue"]["labels"] = ["Another"]
    check("unmatched customer contributes nothing", profiles.candidates_for(unrelated, [("E1", "Selection")]) == [])
    check("component plus semantic input matches", len(profiles.candidates_for(unrelated, [("E1", "input method")])) == 3)
    unrelated["issue"]["components"] = ["Publishing"]
    check("semantic input without component does not match", profiles.candidates_for(unrelated, [("E1", "input method")]) == [])
    unrelated["issue"]["labels"] = ["Acme-like"]
    check("partial customer name not matched", profiles.candidates_for(unrelated, [("E1", "Acme")]) == [])
    for bad in (None, [], {}, {"schema_version": profiles.SCHEMA_VERSION, "profiles": [None]}):
        check("malformed profile is advisory gap", profiles.discover({"customer_discovery_profiles": bad}, []) ["candidates"] == [])
    for field, value in (("axis", []), ("case_refs", ["one"]), ("candidate", 12)):
        malformed = copy.deepcopy(packet)
        malformed["profiles"][0]["dimensions"][0][field] = value
        check("malformed dimension safely rejected", profiles.discover({"customer_discovery_profiles": malformed}, []) ["candidates"] == [])
    for field, value in (("source", "MODEL"), ("promotion_state", "APPROVED"), ("confidence", 0.8), ("labels", [12])):
        malformed = copy.deepcopy(packet)
        malformed["profiles"][0][field] = value
        check("profile cannot assert approval", profiles.discover({"customer_discovery_profiles": malformed}, []) ["candidates"] == [])
    oversized = copy.deepcopy(packet)
    oversized["profiles"][0]["source_ref"] = "x" * (profiles.MAX_BYTES + 1)
    check("explicit profile packet has size bound", bool(profiles.validate_packet(oversized)))
    collision = copy.deepcopy(packet)
    collision["profiles"][0]["profile_id"] = "CP:TEST"
    check("profile ids cannot collide with key separators", bool(profiles.validate_packet(collision)))
    collision = copy.deepcopy(packet)
    collision["profiles"][0]["dimensions"][0]["id"] = "input:other"
    check("dimension ids cannot collide with key separators", bool(profiles.validate_packet(collision)))
    check("explicit null has honest gap", bool(profiles.discover({"customer_discovery_profiles": None}, [])["gaps"][0]))
    original_loader = ds._load_offline_retrieval
    ds._load_offline_retrieval = lambda: None
    try:
        generated = ds.synthesize(base)
        profile_candidates = [c for c in generated["candidates"] if c["generator"] == "CUSTOMER_PROFILE"]
        check("sweep wires profiles into hypotheses", len(profile_candidates) == 3)
        check("sweep profiles have stable IDs and valid families", all(c["hypothesis_id"].startswith("DS-")
              and c["dimension"] in profiles.coverage_hypotheses.COVERAGE_DIMENSIONS for c in profile_candidates))
        check("unrepresented profiles create discovery note", sum("generator=CUSTOMER_PROFILE" in n for n in ds.review_notes(base)) == 3)
        broad = copy.deepcopy(base)
        broad["coverage_hypotheses"] = [{"dimension": "STATE_PARTITION"}]
        check("broad axis does not conceal profile candidates", sum("generator=CUSTOMER_PROFILE" in n for n in ds.review_notes(broad)) == 3)
        broad["coverage_hypotheses"] = profile_candidates
        check("exact profile candidates still require terminal decisions", any("generator=CUSTOMER_PROFILE" in n for n in ds.review_notes(broad)))
        changed = copy.deepcopy(broad)
        changed["customer_discovery_profiles"]["profiles"][0]["dimensions"][0]["candidate"] += " and current retained content"
        check("old dispositions cannot conceal a changed profile version", any("generator=CUSTOMER_PROFILE" in n for n in ds.review_notes(changed)))
        with tempfile.TemporaryDirectory() as tmp:
            gate = _load("customer_profile_gate_integration", "run_gates.py")
            gate.dimension_synthesizer_mod._load_offline_retrieval = lambda: None
            plan_path = Path(tmp) / "plan.md"
            manifest_path = Path(tmp) / "manifest.json"
            plan_path.write_text("# Test Plan\n", encoding="utf-8")
            no_profile = copy.deepcopy(base)
            no_profile["customer_discovery_profiles"]["profiles"] = []
            manifest_path.write_text(json.dumps(no_profile), encoding="utf-8")
            before_failures, _ = gate.run(str(plan_path), str(plan_path), str(manifest_path), None, True)
            manifest_path.write_text(json.dumps(base), encoding="utf-8")
            after_failures, notes = gate.run(str(plan_path), str(plan_path), str(manifest_path), None, True)
            check("customer advice creates no new hard gate failures", before_failures == after_failures)
            check("actual gate emits customer REVIEW DISCOVERY", sum(n.startswith("REVIEW DISCOVERY:") and "generator=CUSTOMER_PROFILE" in n for n in notes) == 3)
    finally:
        ds._load_offline_retrieval = original_loader
    print("test_customer_discovery: OK")


def main() -> int:
    test_validator()
    test_ac_readability()
    test_verifier()
    test_attachment_manifest()
    test_run_gates()
    test_extract_acs()
    test_compact_view()
    test_semantic_explorer()
    test_anti_hardcoding()
    test_production_jira_hardcoding_audit()
    test_behavior_model()
    test_coverage_hypotheses()
    test_missing_questions()
    test_hypothesis_verifier()
    test_coverage_gate()
    test_uac_integration()
    test_reasoning_required()
    test_authoring_state_contract()
    test_uac_fidelity_reference()
    test_agent_registrations()
    test_component_reference_routing()
    test_relevance_prioritizer()
    test_disposition_classifier()
    test_oracle_builder()
    test_state_compatibility()
    test_cross_surface_resolver()
    test_structural_equivalence()
    test_scenario_reducer()
    test_evidence_authority()
    test_change_impact()
    test_pre_uac_critic()
    test_implementation_grounding()
    test_capability_eligibility()
    test_scope_conflict()
    test_affected_surface()
    test_comment_claims()
    test_pr_supersession()
    test_feature_class_registry()
    test_relationship_traversal()
    test_configuration_enumeration_scope()
    test_ui_surface_scope()
    test_role_provisioning()
    test_fluffyjaws_evidence()
    test_temporal_evidence()
    test_evidence_conflict_resolver()
    test_question_research()
    test_behavior_classification()
    test_question_planner()
    test_question_resolver()
    test_coverage_reasoner()
    test_coverage_equivalence()
    test_coverage_equivalence_e1()
    test_requirement_lineage()
    test_requirement_lineage_regressions()
    test_historical_jira_safety()
    test_historical_jira_safety_regressions()
    test_retrieval_admission()
    test_retrieval_admission_regressions()
    test_retrieval_benchmark()
    test_canonical_runtime_projection()
    test_runtime_replay_modes()
    test_evidence_sufficiency()
    test_evidence_sufficiency_output_history_regression()
    test_evidence_sufficiency_unfamiliar_ticket()
    test_evidence_sufficiency_hard_negatives()
    test_evidence_sufficiency_claim_level_unfamiliar()
    test_doc_research_routing()
    test_doc_research_routing_regressions()
    test_question_reasoning_chain_regressions()
    test_question_reasoning_unseen_fixture()
    test_scope_applicability()
    test_ac_language_policy()
    test_publishing_scope_coverage()
    test_root_cause_fix_driven()
    test_reviewer_request_coverage()
    test_reproducibility_gate()
    test_probe_coverage_gate()
    test_dita_semantics_activation()
    test_evidence_anchor_recognition()
    test_jira_safe_text()
    test_miss_probe_library()
    test_customer_discovery()
    test_feature_map()
    _load("test_native_pdf_feature_discovery", "test_native_pdf_feature_discovery.py").run_tests(check)
    check("recorded neighbor discovery adversarial suite passes",
          _load("test_recorded_neighbor_discovery", "test_recorded_neighbor_discovery.py").run_self_tests())
    check("discovery disposition adversarial suite passes",
          _load("test_discovery_disposition", "test_discovery_disposition.py").run_self_tests())
    _load("test_discovery_pipeline", "test_discovery_pipeline.py").run_tests(check)
    test_offline_retrieval()
    test_dimension_synthesizer()
    test_evidence_provenance()
    test_security_coverage()
    test_localization_regression_coverage()
    test_upgrade_migration_coverage()
    test_repro_dimension_matrix()
    test_acceptance_synthesizer()
    test_uac_linter()
    test_plain_ac_grammar()
    test_human_feedback_delta()
    test_feedback_capture()
    test_execution_outcome()
    test_entry_point_equivalence()
    test_value_provenance_coverage()
    test_shared_path_regression_coverage()
    test_qe_completeness_coverage()
    test_manifest_completeness_gate()
    test_v3_authoring_pipeline()
    test_clarification_gate()
    test_terminal_states()
    test_concurrency_race()
    test_enumerated_coverage()
    test_source_requirement_fidelity()
    test_ac_decidability()
    test_operational_contract()
    test_skill_bundle_fingerprint()
    test_gate_receipt_and_adapter()
    test_remote_approved_pattern_resolver()
    test_contract_facts_and_integrity()
    test_issue_domain_routing_and_publishing_scope()
    test_behavior_graph_relation_ontology()
    test_semantic_closure_required()
    test_v3_scaffolding()
    test_missing_question_directed_retrieval_by_subject()
    test_coverage_disposition_completeness()
    test_acceptance_promotion_authority()
    test_generated_output_contract()
    test_generated_artifact_delivery_regression()
    test_content_identity_lifecycle_regression()
    test_postability_semantic_reviews()
    test_guides_vocabulary()
    print("\nALL SELF-TESTS PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
