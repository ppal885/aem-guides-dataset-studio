---
description: Upload a local file or folder to AEM Assets using the local config/aem-upload.properties file.
argument-hint: source_path=C:\Users\you\Downloads\aem-seed-data target_path=/content/dam/guides-qa/GUIDES-12345
---

You are running the AEM Guides local AEM upload slash command.

Request:

```text
$ARGUMENTS
```

Rules:

1. Use only the registered MCP tool `upload_dataset_to_aem` for the upload.
2. Read AEM URL and credentials from the client-local `config/aem-upload.properties` file unless the user explicitly provides overrides in this request.
3. Required upload inputs are `source_path` and `target_path`. If either is missing, ask for the missing value and do not upload.
4. `source_path` must be a local path on the same Windows/Mac/Linux machine where Claude Code is running. Do not ask the user to copy upload files to the VM.
5. `target_path` must be an AEM DAM path under `/content/dam/`. If it is outside DAM, ask for confirmation/correction before calling the tool.
6. If credentials are missing, tell the user to copy `config/aem-upload.properties.example` to `config/aem-upload.properties` and fill `aem.base.url` plus either `aem.username`/`aem.password` or `aem.access.token`.
7. After upload, summarize source path, target path, AEM URL used if returned by the tool, uploaded count, skipped/failed count, and any error messages.
8. Do not call removed dataset generation, DITA generation, test-plan, RAG status, recipe, job, chat, review, or fix tools.

Call shape:

- `source_path`: local file/folder path from `$ARGUMENTS`
- `target_path`: DAM target path from `$ARGUMENTS`
- optional overrides only if explicitly provided: `aem_base_url`, `username`, `password`, `access_token`, `max_concurrent`, `max_upload_files`
