# Test Plan: GUIDES-49065 — Asset Status API fails for paths containing commas

**Jira:** GUIDES-49065 · Major  
**Scope:** REST — `POST` / `GET` `/bin/guides/v1/assets/status` only  
**Plan status:** Draft — comma-path manual tests on Author still pending

---

## 1. Summary & expected behaviour

- **Bug:** Comma in DAM folder name breaks the path. `test,comma/file.dita` becomes `comma/file.dita` → poll `FAILED` / `"Job failed"`.
- **API flow:** POST starts job → GET `?jobId=` polls until done.
- **Fix:** `AssetStatusJobPathCodec` JSON-encodes paths in job properties.

### Expected behaviour

- **EB-1:** POST with comma folder path returns `jobId` and `WAITING`.
- **EB-2:** Poll reaches `SUCCESS` — not `FAILED` / `"Job failed"`.
- **EB-3:** `assets[].path` is the full path (comma intact).
- **EB-4:** `assets[].status` matches CRX `guides:assetStatus`.
- **EB-5:** Batch POST (comma + normal paths) — one correct row per path.
- **EB-6:** Normal paths without commas still work.
- **EB-7:** POST without auth returns HTTP **401**.

### Sign-off checks (minimum before release)

Author + Bearer token + DAM `/content/dam/guides-qa/GUIDES-49065-comma-path/`. **Must pass:** AC-1–AC-5, AC-8, AC-9.

- **AC-1** (S-01) Setup: topic under `test,comma/`. Do: POST path; poll. Pass: 200, `SUCCESS`; not `FAILED`.
- **AC-2** (S-02) Do: read `assets[].path`. Pass: path contains `test,comma` exactly.
- **AC-3** (S-03) Do: compare CRX vs API status. Pass: values match.

### Where we got the facts (evidence)

- **Jira:** customer curl, Splunk at `AssetStatusJob.java:73`.
- **Code:** `AssetStatusService.java`, `AssetStatusJobPathCodec.java`.
- **Why still Draft:** Author manual sign-off for comma paths not done.

---

## 2. What can break & risks

### Code path (where the fix lives)

POST → `AssetStatusServlet` → `AssetStatusService.createJob` → `AssetStatusJob` → GET returns `assets[]`.

| Area | Impact | Why | Test / skip |
| --- | --- | --- | --- |
| POST `/assets/status` | Direct | Customer entry | S-01 |
| Job path decode | Direct | Comma bug root cause | S-01 |
| Normal paths | Compatibility | Must not regress | S-06 |

| Risk ID | Priority | What goes wrong | Test / skip |
| --- | --- | --- | --- |
| R-DIRECT-01 | P0 | Comma splits path → job FAILED | S-01 |
| R-COMPAT-01 | P0 | Normal paths break after fix | S-06 |

### Must not break (regression checks)

- **S-06** normal path SUCCESS; **S-12** no token → 401.

### Likely bugs to watch (top 3)

| ID | What we suspect | How you'd notice | Test |
| --- | --- | --- | --- |
| BH-01 | Comma join/split drops prefix | Splunk comma parse error | S-01 |

### Related past Jiras

| Jira | What happened | Why it matters here | Test |
| --- | --- | --- | --- |
| GUIDES-30456 | API introduced | Comma was path delimiter | S-06 |

Historical search: no other related Jiras found (query: asset status comma path).

---

## 3. Test scenarios & release

### Test list (priority order)

| Scenario ID | Priority | Title | Links to | How to verify |
| --- | --- | --- | --- | --- |
| S-01 | P0 | Comma folder — customer repro | EB-1, R-DIRECT-01 | SUCCESS; no comma log error |
| S-02 | P0 | Full path in response | EB-3 | `path` has `test,comma` |
| S-06 | P0 R0 | Normal path regression | EB-6, R-COMPAT-01 | same as baseline |
| S-12 | P0 R0 | No auth token | EB-7 | HTTP 401 |

**Before you start:** post-process DAM pack; CRX status SUCCESS; Author URL + token.

### Steps for P0 / P1 tests

- **S-01** POST comma path → poll. **How to check:** API + Splunk no comma error.
- **S-02** Read `assets[].path`. **How to check:** exact match to POST body.
- **S-06** POST normal path. **How to check:** matches `AssetStatusIT`.
- **S-12** POST no Authorization. **How to check:** HTTP 401.

### Automation coverage

| Check | Where | Coverage | Gap |
| --- | --- | --- | --- |
| `AssetStatusJobPathCodecTest` | starling unit | Partial | no servlet/JCR |
| `AssetStatusIT` | dxml-it-tests | Partial | no comma folder |
| Manual curl Author | Manual | Best match for this bug | main sign-off gate |

### What's left & sign-off

- **Not tested yet:** comma in file name.
- **Known gap:** comma-path IT not added.
- **Release confidence:** Medium until AC-1–AC-5 pass on Author.
- **Review status:** Draft
