DITA Flat + Hierarchical Dataset (Dataset Studio recipe: flat_hierarchical_dita)

Topic count per structure: 1000

== Flat Structure ==
  Root map:  flat_1000/rootmap_1000.ditamap
  Guide maps: flat_1000/maps/  (12 ditamap files)
  Topics:    flat_1000/topics/  (1000 files)
  DTD stubs: flat_1000/technicalContent/dtd/

== Hierarchical Structure ==
  Root map:  hierarchical_1000/rootmap_1000.ditamap  (20 maprefs)
  Sections:  hierarchical_1000/sections/  (20 sections, 50 topics each)
  DTD stubs: hierarchical_1000/technicalContent/dtd/

All topicref, mapref, and xref links are relative and resolve within this package.
DTD SYSTEM paths are relative to each file's location.

customer_style=true: topic and map titles use enterprise customer-guide phrasing.
Set content_subject to your product or offering name (optional but recommended).

Cross-topic body links use DITA 1.3 xref with scope="peer" and format="dita" 
(targets are included in this bundle so href + fragment IDs resolve for validation).