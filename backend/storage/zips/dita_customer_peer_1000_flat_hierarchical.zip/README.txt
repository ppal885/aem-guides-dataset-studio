Dataset Generation Job
====================

Job ID: zip-export
Generated: 2026-05-13T16:19:37.352096
Dataset Name: customer-peer-1000
Seed: cust-1000

Recipes Processed: 1
Files Generated: 2041

This dataset was generated using the AEM Guides Dataset Studio.
